/*
 * Brush for INI configuration files 
 *
 * Example:
 *
 * [section]
 *
 * prop=value #comment
 * another.prop=value
 *
 * (c) 2008, PTV AG
 */
dp.sh.Brushes.Ini = function()
{
	this.regexList = [ 
		{regex: /#.*/g, css:'comment'}, 	// comments start with "#" 
		{regex: /\[.*\]/g, css:'keyword'}, 	// sections a la [section]
		{regex: /.+=/g, css:'prop'},
		{regex: dp.sh.RegexLib.DoubleQuotedString, css:'string'},
		{regex: dp.sh.RegexLib.SingleQuotedString, css:'string'}
	];
	
	this.CssClass='dp-ini';
	this.Style='.dp-ini .prop { color: #0000AA; font-weight: bold; }';
};

dp.sh.Brushes.Ini.prototype = new dp.sh.Highlighter();
dp.sh.Brushes.Ini.Aliases = ['ini'];
