/*
 * Brush for Cmd.exe sessions 
 *
 * (c) 2008, PTV AG
 */
dp.sh.Brushes.Cmd = function()
{
	this.regexList = [ 
		{regex: /.*(\&gt;|>)/g, css:'prompt'}
	];
	this.CssClass = "dp-cmd";
};

dp.sh.Brushes.Cmd.prototype = new dp.sh.Highlighter();
dp.sh.Brushes.Cmd.Aliases = ['cmd'];
