using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;
using System.Collections.Generic;
using System.Text;

/// <summary>
/// This class shows how to read a tour's TimeEvent data and combine it with the
/// route itinerary
/// </summary>
public class ItineraryWithTimeEvents {

    DateTime StartTime;
    Tour Tour;
    
    /// <summary>
    /// Maps TimeEvents to segment IDs
    /// </summary>
    private Dictionary<int, List<TimeEvent>> eventsPerSegment = new Dictionary<int, List<TimeEvent>>();


    public ItineraryWithTimeEvents() {
        this.StartTime = DateTime.Now;
        this.Tour = CalculateTour(this.StartTime);

        createMappings();
    }

    /// <summary>
    /// Creates the RouteListSegment to TimeEvent mapping
    /// <see cref="eventsPerSegment"/>
    /// </summary>
    private void createMappings() {
        TimeEvent[] tourEvents = this.Tour.wrappedTimeEvents;
        foreach (TimeEvent timeEvent in tourEvents) {
            int segmentID = timeEvent.segmentIdx;

            if (!eventsPerSegment.ContainsKey(segmentID))
                eventsPerSegment[segmentID] = new List<TimeEvent>();
            eventsPerSegment[segmentID].Add(timeEvent);
        }
    }

    /// <summary>
    /// Fills a Table with the data from the tour's TimeEvents
    /// </summary>
    /// <param name="eventsTable">the table to be filled</param>
    public void fillEventsTable(Table eventsTable) {
        TimeEvent[] tourEvents = this.Tour.wrappedTimeEvents;
        RouteListSegment[] routeSegments = this.Tour.route.wrappedSegments;
        string[] texts = this.Tour.route.wrappedTexts;

        foreach (TimeEvent timeEvent in tourEvents) {
            DateTime start = this.StartTime.AddSeconds(timeEvent.startTime);
            string startTime = start.ToString("dd MMM,  HH:mm:ss");

            AddTableRow(eventsTable,
                new string[]{
                    timeEvent.type.ToString(), // type of the event (eg.: TOUR_START, DRIVING ...)
                    (timeEvent.tourPointIdx < 0 ? "" : timeEvent.tourPointIdx.ToString()),
                    timeEvent.segmentIdx.ToString(),
                    startTime,// start time of the event
                    TimeSpan.FromSeconds(timeEvent.period).ToString()  // end time of the event     
                });
        }
    }

    /// <summary>
    /// Combines  RouteManoeuvres with TimeEvents and fills a table with this data
    /// </summary>
    /// <param name="table">the table to be filled</param>
    public void fillItineraryTable(Table table) {
        string[] texts = this.Tour.route.wrappedTexts;
        RouteListSegment[] routeSegments = this.Tour.route.wrappedSegments;
        TimeEvent[] tourEvents = this.Tour.wrappedTimeEvents;
        RouteManoeuvre[] manoeuvres = this.Tour.route.wrappedManoeuvres;

        foreach (RouteManoeuvre manoeuvre in manoeuvres) {
            RouteListSegment segment = routeSegments[manoeuvre.routeListSegmentIdx];

            string formattedTimeEvents = formatEventsForSegment(manoeuvre.routeListSegmentIdx);

            // Add only entries that have either an assiociated TimeEvent or are
            // very important manoeuvres
            if (formattedTimeEvents != "" || manoeuvre.detailLevel == DetailLevel.VERY_IMPORTANT) {
                DateTime time = this.StartTime.AddSeconds(segment.accTime);
                double dist = segment.accDist / 1000.0;

                AddTableRow(table,
                    new string[]{
                      manoeuvre.routeListSegmentIdx.ToString(),
                      dist.ToString("0.00 km"),
                      time.ToString("dd MMM, HH:mm:ss"),
                      manoeuvre.manoeuvreDesc,
                      (segment.streetNameIdx >=0 ? texts[segment.streetNameIdx] : "") + 
		      " " + (segment.streetNoIdx>=0 ? texts[segment.streetNoIdx] : ""),
                      formattedTimeEvents
                    });
            }
        }
    }

    /// <summary>
    /// Formats the list of TimeEvents assiciated with the provided segment ID
    /// </summary>
    /// <param name="segmentIdx">RouteListSegment ID (position in Tour.route.wrappedSegments)</param>
    /// <returns>HTML string containing a list of TimeEvents</returns>
    private string formatEventsForSegment(int segmentIdx) {
        if (!eventsPerSegment.ContainsKey(segmentIdx))
            return "";

        StringBuilder sb = new StringBuilder();
        sb.Append("<ul>");
        foreach (TimeEvent e in eventsPerSegment[segmentIdx]) {
            sb.AppendFormat("<li>{0} <ul><li><i>start time:</i> {1}</li><li><i>period:</i> {2}h</li></ul></li>",
                e.type, this.StartTime.AddSeconds(e.startTime).ToShortTimeString(), TimeSpan.FromSeconds(e.period));
        }
        sb.Append("</ul>");
        return sb.ToString();

    }

    /// <summary>
    /// Calculates an example tour like described in xRoute_CalculateTour.aspx
    /// </summary>
    /// <returns>a Tour</returns>
    private static Tour CalculateTour(DateTime startTime) {
        XRouteWSService xrouteClient = new XRouteWSService();

        DateTime today = DateTime.Today;
        DateTime tommorow = new DateTime(today.Ticks);
        tommorow.AddDays(1);

        Point point;

        //---------------------------------------------------------------------
        // 1. Tour point: Hamburg
        TourPointDesc hamburg = new TourPointDesc();
        hamburg.linkType = LinkType.AUTO_LINKING;
        point = new Point();
        point.point = new PlainPoint();
        point.point.x = 1108401;
        point.point.y = 7078031;
        hamburg.wrappedCoords = new Point[] { point };

        //---------------------------------------------------------------------
        // 2. Tour point: Leipzig
        TourPointDesc leipzip = new TourPointDesc();
        leipzip.linkType = LinkType.AUTO_LINKING;
        point = new Point();
        point.point = new PlainPoint();
        point.point.x = 1378012;
        point.point.y = 6681209;
        leipzip.wrappedCoords = new Point[] { point };

        // it takes 1 hour to unload the truck in Leipzig
        leipzip.servicePeriod = 3600;

        // the driver does not have to help and can use the service period as break
        leipzip.useServicePeriodForRecreation = true;

        // the driver has to arrive within the opening hours
        leipzip.wrappedOpeningIntervals = new Interval[] { new Interval() };

        leipzip.wrappedOpeningIntervals[0].from = new DateTime(2008, 11, 16, 8, 0, 0); //from 8:00h till 18:00h
        leipzip.wrappedOpeningIntervals[0].fromSpecified = true;
        leipzip.wrappedOpeningIntervals[0].till = new DateTime(2008, 11, 16, 18, 0, 0);
        leipzip.wrappedOpeningIntervals[0].tillSpecified = true;

        // the unloading does not need to be finished within the opening hours
        leipzip.completeServiceInIntervals = false;
        //---------------------------------------------------------------------

        //---------------------------------------------------------------------
        // 3. Tour point: Frankfurt
        TourPointDesc frankfurt = new TourPointDesc();
        frankfurt.linkType = LinkType.AUTO_LINKING;
        point = new Point();
        point.point = new PlainPoint();
        point.point.x = 962659;
        point.point.y = 6461857;
        frankfurt.wrappedCoords = new Point[] { point };
        frankfurt.servicePeriod = 1800; // 30 minutes

        frankfurt.wrappedOpeningIntervals = new Interval[] { new Interval(), new Interval() };
        // 8:00h - 13:00h
        frankfurt.wrappedOpeningIntervals[0].from = new DateTime(2008, 11, 16, 8, 0, 0);
        frankfurt.wrappedOpeningIntervals[0].fromSpecified = true;
        frankfurt.wrappedOpeningIntervals[0].till = new DateTime(2008, 11, 16, 13, 0, 0);
        frankfurt.wrappedOpeningIntervals[0].tillSpecified = true;
        // 15:00h - 22:00h
        frankfurt.wrappedOpeningIntervals[1].from = new DateTime(2008, 11, 16, 15, 0, 0);
        frankfurt.wrappedOpeningIntervals[1].fromSpecified = true;
        frankfurt.wrappedOpeningIntervals[1].till = new DateTime(2008, 11, 16, 22, 0, 0);
        frankfurt.wrappedOpeningIntervals[1].tillSpecified = true;
        //---------------------------------------------------------------------


        //---------------------------------------------------------------------
        // 4. Tour point: Munich
        TourPointDesc munich = new TourPointDesc();
        munich.linkType = LinkType.AUTO_LINKING;
        point = new Point();
        point.point = new PlainPoint();
        point.point.x = 1292573;
        point.point.y = 6125849;
        munich.wrappedCoords = new Point[] { point };
        munich.servicePeriod = 1800; // 30 minutes

        munich.wrappedOpeningIntervals = new Interval[] { new Interval(), new Interval() };
        // next day 8:00h - 13:00h
        munich.wrappedOpeningIntervals[0].from = new DateTime(2008, 11, 17, 8, 0, 0);
        munich.wrappedOpeningIntervals[0].fromSpecified = true;
        munich.wrappedOpeningIntervals[0].till = new DateTime(2008, 11, 17, 13, 0, 0);
        munich.wrappedOpeningIntervals[0].tillSpecified = true;
        // next day  15:00h - 20:00h
        munich.wrappedOpeningIntervals[1].from = new DateTime(2008, 11, 17, 15, 0, 0);
        munich.wrappedOpeningIntervals[1].fromSpecified = true;
        munich.wrappedOpeningIntervals[1].till = new DateTime(2008, 11, 17, 20, 0, 0);
        munich.wrappedOpeningIntervals[1].tillSpecified = true;

        //---------------------------------------------------------------------
        WaypointDesc[] tourPoints = new WaypointDesc[] { hamburg, leipzip, frankfurt, munich };

        ResultListOptions resultListOptions = new ResultListOptions();
        // set manoveurs to true, if itinerary with manoveurs is wanted
        resultListOptions.manoeuvres = true;
        resultListOptions.manoeuvreGroups = true;
        resultListOptions.texts = true;
        resultListOptions.segments = true;
        resultListOptions.detailLevel = DetailLevel.ALL;

        RoutingOption[] options = new RoutingOption[] { new RoutingOption() };
        options[0].parameter = RoutingParameter.START_TIME;
        options[0].value = startTime.ToString("u");

        Tour tour
            = xrouteClient.calculateTour(tourPoints, options, null, resultListOptions, null, null);
        return tour;
    }

    /// <summary>
    /// Adds a new row of string values to a Table
    /// </summary>
    /// <param name="table"></param>
    /// <param name="cellValues"></param>
    private void AddTableRow(Table table, string[] cellValues) {
        TableRow row = new TableRow();
        TableCell cell;
        foreach (string s in cellValues) {
            cell = new TableCell();
            cell.Controls.Add(new LiteralControl(s));
            row.Cells.Add(cell);
        }
        table.Rows.Add(row);
    }
}


public partial class xRoute_ItineraryWithTimeEvents : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        ItineraryWithTimeEvents helper = new ItineraryWithTimeEvents();
        helper.fillEventsTable(EventTable);
        helper.fillItineraryTable(ItineraryTable);
    }
}
