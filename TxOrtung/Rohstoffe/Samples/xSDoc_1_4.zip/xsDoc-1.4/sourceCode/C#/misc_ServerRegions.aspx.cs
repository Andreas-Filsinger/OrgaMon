using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using xserver;

public class StandardServerInfo {

    #region�Fields�(5)

    private int mapDetail;
    private string xlocateUrl;
    private string xmapUrl;
    private string xrouteUrl;
    private string xsequenceUrl;

    #endregion�Fields

    #region�Constructors�(2)

    public StandardServerInfo(int mapDetail) {
        this.MapDetail = mapDetail;
    }

    public StandardServerInfo() {
    }

    #endregion�Constructors

    #region�Properties�(5)

    public int MapDetail {
        get { return mapDetail; }
        set { mapDetail = value; }
    }

    public string XlocateUrl {
        get { return xlocateUrl; }
        set { xlocateUrl = value; }
    }

    public string XmapUrl {
        get { return xmapUrl; }
        set { xmapUrl = value; }
    }

    public string XrouteUrl {
        get { return xrouteUrl; }
        set { xrouteUrl = value; }
    }

    public string XsequenceUrl {
        get { return xsequenceUrl; }
        set { xsequenceUrl = value; }
    }

    #endregion�Properties

}

public class ServerRegion<T> {

    #region�Fields�(5)

    private double bottom;
    private double left;
    private double right;
    private T serverInformation;
    private double top;

    #endregion�Fields

    #region�Properties�(5)

    public double Bottom {
        get { return bottom; }
        set { bottom = value; }
    }

    public double Left {
        get { return left; }
        set { left = value; }
    }

    public double Right {
        get { return right; }
        set { right = value; }
    }

    public T ServerInformation {
        get { return serverInformation; }
        set { serverInformation = value; }
    }

    public double Top {
        get { return top; }
        set { top = value; }
    }

    #endregion�Properties

    public ServerRegion(double left, double right, double bottom, double top ){
        this.Bottom = bottom;
		this.Left = left;
		this.Right = right;
		this.Top = top;
    }

    #region�Methods�(1)


    //�Public�Methods�(1)�

    public bool isPointInside(double x, double y) {
        return (left <= x && x <= right) && (bottom <= y && y <= top);
    }


    #endregion�Methods

}

public interface IRegionDirectory<T> {

    void addRegion(ServerRegion<T> server);
    bool removeRegion(ServerRegion<T> server);
    ServerRegion<T> getRegion(double x, double y);
    ServerRegion<T> getRegion(PlainPoint point);
    ServerRegion<T> getRegion(double left, double right, double bottom, double top);
    ServerRegion<T> getRegion(PlainPoint leftTop, PlainPoint rightBottom);
    ServerRegion<T> getRegion(BoundingBox boundingBox);
}

public delegate int RegionCompareDelegate<T>(ServerRegion<T> a, ServerRegion<T> b);

public class SimpleRegionDirectory<T> : IRegionDirectory<T> {

    #region�Fields�(2)

    private RegionCompareDelegate<T> compareFunction;
    private IList<ServerRegion<T>> listOfRegions;

    #endregion�Fields

    #region�Constructors�(1)

    public SimpleRegionDirectory(RegionCompareDelegate<T> compareFunction) {
        this.listOfRegions = new List<ServerRegion<T>>();
        this.compareFunction = compareFunction;
    }

    #endregion�Constructors


    #region IRegionDirectory<T> Members

    public void addRegion(ServerRegion<T> server) {
        listOfRegions.Add(server);
    }

    public bool removeRegion(ServerRegion<T> server) {
        return listOfRegions.Remove(server);
    }

    public ServerRegion<T> getRegion(double x, double y) {
        ServerRegion<T> foundRegion = null;

        foreach (ServerRegion<T> region in listOfRegions) {
            if (region.isPointInside(x, y) // point is in region
                && (foundRegion == null
                    || compareFunction(region, foundRegion) > 0)) {
                foundRegion = region;
            }
        }

        return foundRegion;
    }

    public ServerRegion<T> getRegion(double left, double right, double bottom, double top) {
        ServerRegion<T> foundRegion = null;

        foreach (ServerRegion<T> region in listOfRegions) {
            if (region.isPointInside(left, top) && region.isPointInside(right, bottom)
                && (foundRegion == null
                    || compareFunction(region, foundRegion) > 0)) {
                foundRegion = region;
            }
        }
        return foundRegion;
    }

    public ServerRegion<T> getRegion(PlainPoint point) {
        return this.getRegion(point.x, point.y);
    }

    public ServerRegion<T> getRegion(PlainPoint leftTop, PlainPoint rightBottom) {
        return this.getRegion(leftTop.x, rightBottom.x, rightBottom.y, leftTop.y);
    }

    public ServerRegion<T> getRegion(BoundingBox boundingBox) {
        return this.getRegion(boundingBox.leftTop.point, boundingBox.rightBottom.point);
    }

    #endregion
}

public partial class misc_ServerRegions : System.Web.UI.Page {

    static IRegionDirectory<StandardServerInfo> directory = new SimpleRegionDirectory<StandardServerInfo>(
        delegate(ServerRegion<StandardServerInfo> a, ServerRegion<StandardServerInfo> b) {
            return a.ServerInformation.MapDetail - b.ServerInformation.MapDetail;
        });

    static misc_ServerRegions() {
        ServerRegion<StandardServerInfo> regionGermany = 
            new ServerRegion<StandardServerInfo>(663234, 1665183, 6028293, 7316753);
        
        regionGermany.ServerInformation = new StandardServerInfo();
        regionGermany.ServerInformation.MapDetail = 3;
        regionGermany.ServerInformation.XmapUrl = "http://localhost:50010/xmap/ws/XMap";

        directory.addRegion(regionGermany);
    }

    #region�Methods�(1)
    //�Protected�Methods�(1)�

    //static int compareRegionByDetailLevel(ServerRegion<StandardServerInfo> a, ServerRegion<StandardServerInfo> b) {
    //}
    protected void Page_Load(object sender, EventArgs e) {
        PlainPoint leftTop = new PlainPoint();
        leftTop.x = 910115.0;
        leftTop.y = 6480990.0;

        PlainPoint rightBottom = new PlainPoint();
        rightBottom.x = 985750.0;
        rightBottom.y = 6431678.0;

        BoundingBox boundingBox = new BoundingBox();
        boundingBox.leftTop = new Point();
        boundingBox.leftTop.point = leftTop;
        boundingBox.rightBottom = new Point();
        boundingBox.rightBottom.point = rightBottom;

        ServerRegion<StandardServerInfo> region = directory.getRegion(boundingBox);

        if (region == null) {
            throw new Exception("No server found for rectangle");
        }

        XMapWSService xmapClient = new XMapWSService();
        xmapClient.Url = region.ServerInformation.XmapUrl;


        MapParams mapParams = new MapParams();
        
        ImageInfo imageInfo = new ImageInfo();
        imageInfo.format = ImageFileFormat.PNG;
        imageInfo.width = 800;
        imageInfo.height = 600;

        Map map = xmapClient.renderMapBoundingBox(boundingBox, mapParams, imageInfo, null, false, null);

        mapImage.ImageUrl = "http://" + map.image.url;


    }


    #endregion�Methods

}

