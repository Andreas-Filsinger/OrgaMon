using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;

public partial class xMap_PointsInMap : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		// ######
		// This sample is enhanced from the sample xMap_SimpleMapping_MapSection
		// ######

		// Set a MapSection necessary for the function call .renderMap
		// In this sample where we want to display several objects on the map
		// the mapSection will not really be used as we will center the layer with 
		// all the visible objects and the xMap server will render the map 
		// independent of the mapSection.
		MapSection mapSection = new MapSection();

		// MapSection needs at least a center and a scale/zoom
		// important for documentation...
		// with the use of the object MapSection you have to make sure
		// that all necessary properties are set properly.
		// If you do not specify a property, it's data type default will be used,
		// e.g. MapSection.scale = 0;
		// which does not make any sense.
		mapSection.center = new Point();
		mapSection.center.point = new PlainPoint();
		mapSection.center.point.x = 681201.0;  // x and y coordinates of Luxembourg, capital of Luxembourg
		mapSection.center.point.y = 6371804.0;
		mapSection.scale = 700;
		mapSection.scrollHorizontal = 0;
		mapSection.scrollVertical = 0;
		mapSection.zoom = 0;

		// set the ImageInfos such as FileFormat, Width and Height...
		ImageInfo imageInfo = new ImageInfo();
		imageInfo.format = ImageFileFormat.GIF;
		imageInfo.height = Convert.ToInt32(pbMap.Height.Value);
		imageInfo.width = Convert.ToInt32(pbMap.Width.Value);


		// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		// >>>
		// >>>
		//
		// Now let's show some bitmaps on the map
		// 
		// First of all we need two plain points
		PlainPoint plainPoint1 = new PlainPoint();
		plainPoint1.x = 681254.0;
		plainPoint1.y = 6372399.0;
		PlainPoint plainPoint2 = new PlainPoint();
		plainPoint2.x = 682875.0;
		plainPoint2.y = 6369972.0;

		// Second we have to put our PlainPoints to the point-property of two new Points.
		Point point1 = new Point();
		point1.point = plainPoint1;
		Point point2 = new Point();
		point2.point = plainPoint2;

		// Third we have to put our Points into an array of BasicBitmaps
		// Bitmap inherits from BasicBitmap, we have to decide wheather we want to 
		// make use of physically available bitmaps on the computer -> Bitmap
		// or raw binary formatted bitmaps -> RawBitmap
		// In this example we will use the Bitmap.
		Bitmap[] arrBitmap = new Bitmap[2];
		arrBitmap[0] = new Bitmap();
		arrBitmap[0].position = point1;
		arrBitmap[0].descr = "MyFirstBitmap";
		arrBitmap[0].name = "dealer.bmp";
		arrBitmap[1] = new Bitmap();
		arrBitmap[1].position = point2;
		arrBitmap[1].descr = "MySecondBitmap";
		arrBitmap[1].name = "flagblue.bmp";
		
		// Fourth we have to set the BitmapOptions
		// escpecially the transparencyColor
		BitmapOptions bitmapOptions = new BitmapOptions();
		bitmapOptions.transparencyColor = new Color();
		bitmapOptions.transparencyColor.blue = 255;
		bitmapOptions.transparencyColor.green = 255;
		bitmapOptions.transparencyColor.red = 255;

		// Fifth we have to create an array with all our BasicBitmaps
		Bitmaps[] arrBitmaps = new Bitmaps[1];
		arrBitmaps[0] = new Bitmaps();
		arrBitmaps[0].wrappedBitmaps = arrBitmap;
		arrBitmaps[0].options = bitmapOptions;
		
		// Sixth we have to put our Bitmaps into a CustomLayer
		CustomLayer customLayer = new CustomLayer();
		customLayer.centerObjects = true;	// zoom into a scale where all objects are visible
		customLayer.drawPriority = 25000;	// this is POIDEFAULT
		customLayer.name = "ObjectLayer";
		customLayer.objectInfos = ObjectInfoType.REFERENCEPOINT;	// if you want to retrieve
																	// the pixelposition of your objects
																	// in the generated map
		customLayer.visible = true;
		customLayer.wrappedBitmaps = arrBitmaps;

		// Seventh we have to put our customLayer into an array of Layers.
		Layer[] arrLayers = new Layer[] { customLayer };
		//
		// <<<
		// <<<
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

		// Create a new Client for xMap Service and call the server
		XMapWSService xMapClient = new XMapWSService();
		Map map = xMapClient.renderMap(mapSection, null, imageInfo, arrLayers, false, null);
		// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// the delivery by URL has to be configured properly
		// within the xMap Server config-files:
		//	xmap.properties
		//		imageMapServer.remotePath=C:/mgtmp
		//		imageMapServer.remoteURL=localhost/mgtmp
		pbMap.ImageUrl = "http://" + map.image.url;

		// Lets show the pixel position of the placed bitmaps on the generated map
		lblMyFirstBitmapX.Text = map.wrappedObjects[0].wrappedObjects[0].pixel.x.ToString();
		lblMyFirstBitmapY.Text = map.wrappedObjects[0].wrappedObjects[0].pixel.y.ToString();
		lblMySecondBitmapX.Text = map.wrappedObjects[0].wrappedObjects[1].pixel.x.ToString();
		lblMySecondBitmapY.Text = map.wrappedObjects[0].wrappedObjects[1].pixel.y.ToString();

    }
}
