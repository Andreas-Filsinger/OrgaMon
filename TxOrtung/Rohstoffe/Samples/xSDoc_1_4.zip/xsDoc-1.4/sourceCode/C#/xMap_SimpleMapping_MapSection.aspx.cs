using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;

public partial class xMap_SimpleMapping_MapSection : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		// Set a MapSection necessary for the function call .renderMap
		MapSection mapSection = new MapSection();

		// MapSection needs at least a center and a scale/zoom
		// important for documentation...
		// with the use of the object MapSection you have to make sure
		// that all necessary properties are set properly.
		// If you do not specify a property, it's data type default will be used,
		// e.g. MapSection.scale = 0;
		// which does not make any sense.
		mapSection.center = new Point();
		mapSection.center.point = new PlainPoint();
		mapSection.center.point.x = 681201.0;  // x and y coordinates of Luxembourg, capital of Luxembourg
		mapSection.center.point.y = 6371804.0;
		mapSection.scale = 700;
		mapSection.scrollHorizontal = 0;
		mapSection.scrollVertical = 0;
		mapSection.zoom = 0;

		// set the ImageInfos such as FileFormat, Width and Height...
		ImageInfo imageInfo = new ImageInfo();
		imageInfo.format = ImageFileFormat.GIF;
		imageInfo.height = Convert.ToInt32(pbMap.Height.Value);
		imageInfo.width = Convert.ToInt32(pbMap.Width.Value);

		// set MapParams for the decision wheather to draw the scale or not
		// and if to use miles or kilometers as the scale's unit
		MapParams mapParams = new MapParams();
		mapParams.showScale = true;
		mapParams.useMiles = false;

		// Create a new Client for xMap Service and call the server
		XMapWSService xMapClient = new XMapWSService();
		Map map = xMapClient.renderMap(mapSection, mapParams, imageInfo, null, false, null);
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		double leftTopX = map.visibleSection.boundingBox.leftTop.point.x;
		double leftTopY = map.visibleSection.boundingBox.leftTop.point.y;
		double rightBottomX = map.visibleSection.boundingBox.rightBottom.point.x;
		double rightBottomY = map.visibleSection.boundingBox.rightBottom.point.y;

		// the delivery by URL has to be configured properly
		// within the xMap Server config-files:
		//	xmap.properties
		//		imageMapServer.remotePath=C:/mgtmp
		//		imageMapServer.remoteURL=localhost/mgtmp
		pbMap.ImageUrl = "http://" + map.image.url;
    }
}
