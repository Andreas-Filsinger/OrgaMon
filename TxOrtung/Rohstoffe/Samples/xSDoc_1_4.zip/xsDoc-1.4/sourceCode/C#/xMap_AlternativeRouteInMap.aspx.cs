using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using xserver;

public partial class xMap_AlternativeRouteInMap : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		// create the WayPoint for the Start
		// ATTENTION: Here at the object WaypointDesc the parameters are not named
		// "coords" as described within the documentation but
		// "wrappedCoords"
		WaypointDesc wpdStart = new WaypointDesc();
		// please note that this has to be an array of Point...
		wpdStart.wrappedCoords = new Point[] { new Point() };
		wpdStart.wrappedCoords[0].point = new PlainPoint();
		wpdStart.wrappedCoords[0].point.x = 653413.0;  // x and y coordinates of P�telange, a small village in Luxembourg
		wpdStart.wrappedCoords[0].point.y = 6362650.0;

		// Waypoint for the Destination...
		WaypointDesc wpdDestination = new WaypointDesc();
		wpdDestination.wrappedCoords = new Point[] { new Point() };
		wpdDestination.wrappedCoords[0].point = new PlainPoint();
		wpdDestination.wrappedCoords[0].point.x = 681451.0;  // x and y coordinates of Luxembourg, the capital of Luxembourg in the heart of Europe
		wpdDestination.wrappedCoords[0].point.y = 6371797.0;

		// create a new array of WayPointDescriptions and fill it with Start and Destination
		WaypointDesc[] waypointDesc = new WaypointDesc[] { wpdStart, wpdDestination };

		// With our second call to the xRoute Server we will use the binaryPathDesc, therefore we have to fetch it.
		ResultListOptions resultListOptions = new ResultListOptions();
		resultListOptions.binaryPathDesc = true;
		resultListOptions.polygon = true;
		resultListOptions.totalRectangle = true;

		// We have to get the polygon as wkb to directly use it with xMapserver
		CallerContext xRouteCallerContext = new CallerContext();
		xRouteCallerContext.wrappedProperties = new CallerContextProperty[] { new CallerContextProperty() };
		xRouteCallerContext.wrappedProperties[0].key = "ResponseGeometry";
		xRouteCallerContext.wrappedProperties[0].value = "WKB";

		// create a new Client for xRoute Service and call the server
		XRouteWSService xRouteClient = new XRouteWSService();
		Route routeOrig = xRouteClient.calculateRoute(waypointDesc, null, null, resultListOptions, xRouteCallerContext);
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// Having calculated the route we have to retrieve the polygon information in the 
		// wkb format to put them in the next calculation to the argument ExceptionPath
		ExceptionPath epAltRoute = new ExceptionPath();
		// we use the binary Path Description of the original route to put it into our property.
		epAltRoute.binaryPathDesc = routeOrig.binaryPathDesc;
		// also we have to specify which malus the first route has got in relation to the original
		// "route costs" during the calculation.
		epAltRoute.relMalus = 500;

		// create an array of ExceptionPath and put our current exceptionPath into it.
		ExceptionPath[] exceptionPath = new ExceptionPath[] { epAltRoute };

		// call the server with the same start and destination
		Route routeAlt = xRouteClient.calculateRoute(waypointDesc, null, exceptionPath, resultListOptions, xRouteCallerContext);
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// until here we dealt with xRoute Server

		// -------------------------------------------------------------------------------------------

		// here begins the section for xMap Server


		// set the ImageInfos such as FileFormat, Width and Height...
		ImageInfo imageInfo = new ImageInfo();
		imageInfo.format = ImageFileFormat.GIF;
		imageInfo.height = Convert.ToInt32(pbMap.Height.Value);
		imageInfo.width = Convert.ToInt32(pbMap.Width.Value);

		// Then we need an array of LineString[] where we directly put our polygon into
		LineString[] lineString1 = new LineString[1];
		lineString1[0] = new LineString();
		lineString1[0].wkb = routeOrig.polygon.wkb;

		// For the alternative route we need a second one
		LineString[] lineString2 = new LineString[1];
		lineString2[0] = new LineString();
		lineString2[0].wkb = routeAlt.polygon.wkb;

		// the bounding has to be set, but we will make use of the centerObjects property...
		BoundingBox boundingBox = new BoundingBox();
		boundingBox.leftTop = new Point();
		boundingBox.rightBottom = new Point();
		boundingBox.leftTop.wkb = routeOrig.totalRectangle.leftBottom.wkb;
		boundingBox.rightBottom.wkb = routeOrig.totalRectangle.rightTop.wkb;

		// Fourth we need an array of Lines[] where we put all our Lines into, in this case the line with the
		// original route and the alternative route.
		Lines[] lines = new Lines[2];
		lines[0] = new Lines();
		lines[1] = new Lines();
		lines[0].wrappedLines = lineString1;
		lines[1].wrappedLines = lineString2;
		lines[0].options = new LineOptions();
		lines[1].options = new LineOptions();
		lines[0].options.mainLine = new LinePartOptions(); 
		lines[1].options.mainLine = new LinePartOptions();
		lines[0].options.mainLine.visible = true;				
		lines[1].options.mainLine.visible = true;
		lines[0].options.mainLine.width = -12;					
		lines[1].options.mainLine.width = -15;		// make it some pixels broader than the first line...
		lines[0].options.mainLine.color = new Color();		
		lines[1].options.mainLine.color = new Color();
		Color color = new Color();					
		color.blue = 255; color.green = 50; color.red = 20;
		Color color1 = new Color();
		color1.blue = 50; color1.green = 255; color1.red = 20;	// choose another representing colour...
		lines[0].options.mainLine.color = color;				
		lines[1].options.mainLine.color = color1;
		lines[0].options.transparent = true;					
		lines[1].options.transparent = true;

		// Fifth we add the line to the CustomLayer that we need for drawing lines
		CustomLayer customLayer = new CustomLayer();
		// customLayer.centerObjects = true;
		customLayer.visible = true;				// you have to make your layer visible
		// The priority of the custom Layer you want to draw has to be specified.
		// The xMap Documentation says that you have to take a value of the
		//     DrawPriority enum
		// but this enum does not exist here. Therefore you have to look
		// at the Diagrams -> Enumerations -> enum:DrawPriorities,
		// fetch the integer value you want to use and set it at the .drawPriority property.
		// !!! Please note that you have to use a value between PRIORMIN and PRIORMAX !!!
		customLayer.drawPriority = 100;	// this is PRIORROUTE
		customLayer.wrappedLines = lines;

		customLayer.centerObjects = true;

		// create an array of Layer and fill it with the customLayer
		Layer[] layer = new Layer[] { customLayer };

		// Create a new Client for xMap Service and call the server
		XMapWSService xMapClient = new XMapWSService();
		Map map = xMapClient.renderMapBoundingBox(boundingBox, null, imageInfo, layer, false, null);
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// the delivery by URL has to be configured properly
		// within the xMap Server config-files:
		//	xmap.properties
		//		imageMapServer.remotePath=C:/mgtmp
		//		imageMapServer.remoteURL=localhost/mgtmp
		pbMap.ImageUrl = "http://" + map.image.url;

	}
}
