using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;

public partial class xLocate_GeocodeWithCountryCodes : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		// in addition to the simple geocoding sample
		// we now use the possibility to pass the country code in different formats to the xLocate Server:
		SearchOption soCountryCodeType = new SearchOption();
		soCountryCodeType.param = SearchParameter.COUNTRY_CODETYPE;
		// 0 - Country name
		// 1 - ISO2
		// 2 - ISO3
		// 3 - country code plate
		soCountryCodeType.value = "2";

		// in addition to the COUNTRY_CODETYPE we want to get back the result in the swedish language.
		SearchOption soResultLanguage = new SearchOption();
		soResultLanguage.param = SearchParameter.RESULT_LANGUAGE;
		soResultLanguage.value = "FRE";

		// create a new SearchOptions Array and fill it with the Option.
		SearchOption[] searchOptions = new SearchOption[] { soCountryCodeType, soResultLanguage };

		// Instantiate a new instance of an address and fill at least 
		// city or postCode.
		Address address = new Address();
		address.city = "Luxembourg";
		address.postCode = "";
		address.country = "LUX";	// this is the country code in the above specified ISO3 format
		address.street = "";
		address.houseNumber = "";
		
		// Create a new Client for xLocate Service and call the server
		XLocateWSService xLocateClient = new XLocateWSService();
		AddressResponse addressResponse = xLocateClient.findAddress(address, searchOptions, null, null, null);
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// Clear the List Box of existing items
		ListBox1.Items.Clear();

		// For each Result Address in the returned List add it to the Drop Down List
		foreach (ResultAddress resultAddress in addressResponse.wrappedResultList)
		{
			ListBox1.Items.Add(new ListItem(resultAddress.country
				+ " - " + resultAddress.city + ", "
				+ resultAddress.city2,
				resultAddress.coordinates.point.x + "|" + resultAddress.coordinates.point.y));
		}

		// Bind the Items to the List Box
		ListBox1.DataBind();

    }
}
