using System;
using System.Collections;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


public partial class misc_Coordinates_Transformation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        // Mercator to ...
        if (TextBox1.Text.ToString() != "" && TextBox2.Text.ToString() != "" ) {
            long[] xOut = new long[2];
            long[] yOut = new long[2];
            int geodecimal = Transformation.Mercator_2_GeoDecimal((long)Int32.Parse(TextBox1.Text), (long)Int32.Parse(TextBox2.Text), out xOut[0], out yOut[0]);
            int geominsec = Transformation.Mercator_2_GeoMinSec((long)Int32.Parse(TextBox1.Text), (long)Int32.Parse(TextBox2.Text), out xOut[1], out yOut[1]);
            TextBox3.Text = xOut[1].ToString();
            TextBox4.Text = yOut[1].ToString();
            TextBox5.Text = xOut[0].ToString();
            TextBox6.Text = yOut[0].ToString();
        }

        // GeoMinSec to ...
        if (TextBox3.Text.ToString() != "" && TextBox4.Text.ToString() != "" ) {
            long[] xOut = new long[2];
            long[] yOut = new long[2];
            int geodecimal = Transformation.GeoMinSec_2_GeoDecimal((long)Int32.Parse(TextBox3.Text), (long)Int32.Parse(TextBox4.Text), out xOut[0], out yOut[0]);
            int mercator = Transformation.GeoMinSec_2_Mercator((long)Int32.Parse(TextBox3.Text), (long)Int32.Parse(TextBox4.Text), out xOut[1], out yOut[1]);
            TextBox1.Text = xOut[1].ToString();
            TextBox2.Text = yOut[1].ToString();
            TextBox5.Text = xOut[0].ToString();
            TextBox6.Text = yOut[0].ToString();
        }

        // GeoDecimal to ...
        if (TextBox5.Text.ToString() != "" && TextBox6.Text.ToString() != "" ) {
            long[] xOut = new long[2];
            long[] yOut = new long[2];
            int geominsec = Transformation.GeoDecimal_2_GeoMinSec((long)Int32.Parse(TextBox5.Text), (long)Int32.Parse(TextBox6.Text), out xOut[0], out yOut[0]);
            int mercator = Transformation.GeoDecimal_2_Mercator((long)Int32.Parse(TextBox5.Text), (long)Int32.Parse(TextBox6.Text), out xOut[1], out yOut[1]);
            TextBox1.Text = xOut[1].ToString();
            TextBox2.Text = yOut[1].ToString();
            TextBox3.Text = xOut[0].ToString();
            TextBox4.Text = yOut[0].ToString();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Server.Transfer("misc_Coordinates_Transformation.aspx");
    }
}

