using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using xserver;

public partial class xMap_PointsAndLinesInMap : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // source point which is the source for all lines
        PlainPoint sourcePoint = new PlainPoint();
        sourcePoint.x = 933578.1487672555;  // Willy-Andreas-Allee, a street in Karlsruhe city
        sourcePoint.y = 6270660.7289422;

        // coordinate values of the lines' destination Points 
        double[,] pointCoordinates = new double[,]{
            {930621.47566777,  6271594.97834858}, //  Nancystrasse
            {937171.968796402, 6270162.27882922}, //  Stumpfstr 7
            {933257.907378521, 6269796.08934093}, //  Stephanienstrasse
            {936046.676138759, 6269801.17519725}, //  Adenauerring
            {932631.879941512, 6269421.43968697}, //  Reinhold-Frank-Stra�e
            {932089.248699486, 6269672.33444846}, //  Kaiserallee 
            {936734.972734693, 6269118.00260869}, //  Durlacher Allee
            {933820.553707339, 6270484.40308829}, //  Willy-Brandt-Allee
        };

        // Color values for each line
        int[,] colorValues = new int[,]{
            // {blue, green, red}
            {255,   0,   0},
            {  0,   0, 255},
            {  0, 255,   0},
            {238, 134,  28},
            {139, 123, 108},
            { 79,  79,  47},
            {131, 139, 131},
            {  0, 290, 139}
        };

        int numberOfDestinationPoints = pointCoordinates.GetLength(0);

        // create PlainPoints from coordinate values
        PlainPoint[] destinationPlainPoints = new PlainPoint[numberOfDestinationPoints];
        for (int i = 0; i < numberOfDestinationPoints; i++)
        {
            destinationPlainPoints[i] = new PlainPoint();
            destinationPlainPoints[i].x = pointCoordinates[i, 0 /*X*/];
            destinationPlainPoints[i].y = pointCoordinates[i, 1 /*Y*/];
        }

        //===============================================================================
        // We need Lines[] arrays where we put all our Lines into

        // one Lines object for each line, because we want to set different Color values, etc.
        // on each line. Otherwise we could put all lines together into one Lines object
        Lines[] lines = new Lines[numberOfDestinationPoints];

        for (int i = 0; i < numberOfDestinationPoints; i++)
        {
            // "draw" a line between source and destination point
            PlainLineString plainLineString = new PlainLineString();
            plainLineString.wrappedPoints = new PlainPoint[] { sourcePoint, destinationPlainPoints[i] };

            // put our PlainLineStrings into a LineString array
            LineString[] lineStrings = new LineString[1];
            lineStrings[0] = new LineString();
            lineStrings[0].lineString = plainLineString;

            // Create a new Lines object, in which we put the new LineString array
            lines[i] = new Lines();
            lines[i].wrappedLines = lineStrings;

            // The appearance of each line can be set at the Lines objects:
            lines[i].options = new LineOptions();
            lines[i].options.mainLine = new LinePartOptions();
            lines[i].options.mainLine.visible = true;
            lines[i].options.mainLine.width = 7;
            lines[i].options.transparent = true;

            // set the line specific color
            Color lineColor = new Color();
            lineColor.blue = colorValues[i, 0];
            lineColor.green = colorValues[i, 1];
            lineColor.red = colorValues[i, 2];
            lines[i].options.mainLine.color = lineColor;
        }

        //===============================================================================
        // create a Bitmap for each point
        Bitmap[] arrBitmap = new Bitmap[numberOfDestinationPoints + 1]; // plus the source point itself

        for (int i = 0; i < numberOfDestinationPoints; i++)
        {
            Point bitmapPoint = new Point();
            bitmapPoint.point = destinationPlainPoints[i];

            arrBitmap[i] = new Bitmap();
            arrBitmap[i].position = bitmapPoint;
            arrBitmap[i].descr = "MyFirstBitmap";
            arrBitmap[i].name = "flagblue.bmp";
        }

        // the source point gets a different bitmap ...
        arrBitmap[8] = new Bitmap();
        arrBitmap[8].descr = "MyFirstBitmap";
        arrBitmap[8].name = "dealer.bmp";
        arrBitmap[8].position = new Point();
        arrBitmap[8].position.point = sourcePoint;

        //===============================================================================
        // 4. we have to set the BitmapOptions
        // escpecially the transparencyColor
        BitmapOptions bitmapOptions = new BitmapOptions();
        bitmapOptions.transparencyColor = new Color();
        bitmapOptions.transparencyColor.blue = 255;
        bitmapOptions.transparencyColor.green = 255;
        bitmapOptions.transparencyColor.red = 255;

        //===============================================================================
        // 5. we have to create an array with all our BasicBitmaps
        Bitmaps[] arrBitmaps = new Bitmaps[1];
        arrBitmaps[0] = new Bitmaps();
        arrBitmaps[0].wrappedBitmaps = arrBitmap;
        arrBitmaps[0].options = bitmapOptions;

        //===============================================================================
        // 6. we have to put our Bitmaps into a CustomLayer
        CustomLayer customLayer = new CustomLayer();
        customLayer.name = "ObjectLayer";
        customLayer.visible = true;
        customLayer.drawPriority = 25000;	// this is POIDEFAULT
        customLayer.centerObjects = true;	// zoom into a scale where all objects are visible

        // if you want to retrieve the pixelposition of your objects in the generated map
        customLayer.objectInfos = ObjectInfoType.REFERENCEPOINT;

        customLayer.wrappedBitmaps = arrBitmaps;
        customLayer.wrappedLines = lines;

        //===============================================================================
        // 7. we have to put our customLayer into an array of Layers.
        Layer[] arrLayers = new Layer[] { customLayer };

        //==============================================================================
        // Set a MapSection, but because we set "centerObjects = true" the value
        // is actually irrelevant
        MapSection mapSection = new MapSection();
        mapSection.center = new Point();
        mapSection.center.point = sourcePoint;

        // set the ImageInfos such as FileFormat, Width and Height...
        ImageInfo imageInfo = new ImageInfo();
        imageInfo.format = ImageFileFormat.GIF;
        imageInfo.height = Convert.ToInt32(pbMap.Height.Value);
        imageInfo.width = Convert.ToInt32(pbMap.Width.Value);

        // set MapParams for the decision whether to draw the scale or not
        // and if to use miles or kilometers as the scale's unit
        MapParams mapParams = new MapParams();
        mapParams.showScale = true;
        mapParams.useMiles = false;

        // initiate client & call XMap SOAP service
        XMapWSService xMapClient = new XMapWSService();
        Map map = xMapClient.renderMap(mapSection, null, imageInfo, arrLayers, false, null);
        
        // the delivery by URL has to be configured properly
        // within the xMap Server config-files:
        //	xmap.properties
        //		imageMapServer.remotePath=C:/mgtmp
        //		imageMapServer.remoteURL=localhost/mgtmp
        pbMap.ImageUrl = "http://"+map.image.url;
    }
}


