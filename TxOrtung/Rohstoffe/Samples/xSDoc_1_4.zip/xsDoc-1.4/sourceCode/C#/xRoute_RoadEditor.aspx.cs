using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using xserver;

public partial class xRoute_RoadEditor : System.Web.UI.Page
{
    struct REAttribute {
        public string key;
        public bool direction;
        public string value;
    }

    protected void Page_Load(object sender, EventArgs e)
    {

        XRouteWSService xrouteClient = new XRouteWSService();
        XMapWSService xmapClient = new XMapWSService();

        xrouteClient.Url = "http://mg-fr-w4:50030/xroute/ws/XRoute";
        xrouteClient.Proxy = new System.Net.WebProxy("localhost:8888");

        //xmapClient.Url = "http://mg-fr-w4:50010/xmap/ws/XMap";
        //xmapClient.Proxy = new System.Net.WebProxy("localhost:8888");
        
        WaypointDesc start = new WaypointDesc();
        start.wrappedCoords = new Point[] { new Point() };
        start.wrappedCoords[0].point = new PlainPoint();

        start.wrappedCoords[0].point.x = 931842;
        start.wrappedCoords[0].point.y = 6265686; // good

        //start.wrappedCoords[0].point.x = 932065;
        //start.wrappedCoords[0].point.y = 6265918; // bad

        WaypointDesc destination = new WaypointDesc();
        destination.wrappedCoords = new Point[] { new Point() };
        destination.wrappedCoords[0].point = new PlainPoint();

        destination.wrappedCoords[0].point.x = 932527;
        destination.wrappedCoords[0].point.y = 6266531;

        WaypointDesc[] waypoints = new WaypointDesc[] { start, destination };

        ResultListOptions resultListOptions = new ResultListOptions();
        resultListOptions.polygon = true;
        resultListOptions.segments = true;
        resultListOptions.segmentAttributes = true;

        RoutingOption enableRE = new RoutingOption();
        enableRE.parameter = RoutingParameter.ENABLE_ROADEDITOR;
        enableRE.value = "true";

        RoutingOption reLayerName = new RoutingOption();
        reLayerName.parameter = RoutingParameter.ROADEDITOR_LAYERNAME;
        reLayerName.value = "truckattributes";

        RoutingOption vehicleHeight = new RoutingOption();
        vehicleHeight.parameter = RoutingParameter.ROADEDITOR_ADDITIONAL_OPTIONS;
        vehicleHeight.value = "MAX_HEIGHT=260";

        CallerContext calllerContextRoute = new CallerContext();
        calllerContextRoute.wrappedProperties = new CallerContextProperty[] { new CallerContextProperty(), new CallerContextProperty() };
        calllerContextRoute.wrappedProperties[0].key = "CoordFormat";
        calllerContextRoute.wrappedProperties[0].value = "PTV_MERCATOR";
        calllerContextRoute.wrappedProperties[1].key = "Profile";
        calllerContextRoute.wrappedProperties[1].value = "re";

        RoutingOption[] routingOptions = new RoutingOption[] { enableRE, reLayerName, vehicleHeight };

        //ExtendedRoute route = xrouteClient.calculateExtendedRoute(waypoints, routingOptions, null, resultListOptions, null, calllerContextRoute);
        Route route = xrouteClient.calculateRoute(waypoints, routingOptions, null, resultListOptions, calllerContextRoute);


        CustomLayer customLayer = createLayerFromRoute(route);

        MapParams mapParams = new MapParams();
        mapParams.showScale = true;

        ImageInfo imageInfo = new ImageInfo();
        imageInfo.format = ImageFileFormat.PNG;
        imageInfo.width = 800;
        imageInfo.height = 600;


        RoadEditorLayer reLayer = new RoadEditorLayer();
        reLayer.name = "truckattributes";
        reLayer.objectInfos = ObjectInfoType.FULLGEOMETRY;
        reLayer.visible = true;        

        BoundingBox bbox = new BoundingBox();
        bbox.leftTop = new Point();
        bbox.leftTop.point = new PlainPoint();
        bbox.leftTop.point.x = 0;
        bbox.leftTop.point.y = 0;

        bbox.rightBottom = new Point();
        bbox.rightBottom.point = new PlainPoint();
        bbox.rightBottom.point.x = 0;
        bbox.rightBottom.point.y = 0;


        CallerContext calllerContext = new CallerContext();
        calllerContext.wrappedProperties = new CallerContextProperty[] { new CallerContextProperty(),new CallerContextProperty() };
        calllerContext.wrappedProperties[0].key = "Profile";
        calllerContext.wrappedProperties[0].value = "re";
        calllerContext.wrappedProperties[1].key = "CoordFormat";
        calllerContext.wrappedProperties[1].value = "PTV_MERCATOR";


        Map map = xmapClient.renderMapBoundingBox(bbox, mapParams, imageInfo, new Layer[] { customLayer, reLayer }, false, calllerContext);

        Response.Write( String.Format("<img src='http://{0}' />",map.image.url));

        
        foreach (RouteListSegment segment in route.wrappedSegments) {

            if (segment.segmentAttr != null && segment.segmentAttr.additionalRE != null ) {
                foreach (REAttribute reAttr in unpackRoadEditorAttributes(segment.segmentAttr.additionalRE)) {
                    Response.Write(
                        String.Format("{0}={1} (direction={2})",
                        reAttr.key, reAttr.value, (reAttr.direction ? "deposite" : "opposite"))
                        );
                }
            }
        }
        
    }

    /// <summary>
    /// Unpack a RoadEditor attribute string of the format "KEY|1=value,KEY2|1=value,.."
    /// </summary>
    /// <param name="roadEditorAtrributesString"> string of the format:  KEY1|1=value,ANOTHER_KEY|0=abc</param>
    /// <returns></returns>
    private static REAttribute[] unpackRoadEditorAttributes(string roadEditorAtrributesString) {
        string[] attrStrings = roadEditorAtrributesString.Split(',');
        REAttribute[] reAttributes = new REAttribute[attrStrings.Length];
        int idx = 0;
        foreach (string s in attrStrings) {
            string[] tmp = s.Split('|'); // key | direction=value
            string[] tmp2 = tmp[1].Split('='); // direction = value
            reAttributes[idx].key = tmp[0];
            reAttributes[idx].direction = (tmp2[0] == "1");
            reAttributes[idx].value = tmp2[1];
            idx++;
        }
        return reAttributes;
    }

    /// <summary>
    /// Creates an CustomLayer from a routes 'polygon'
    /// </summary>
    /// <param name="route"></param>
    /// <returns></returns>
    private static CustomLayer createLayerFromRoute(Route route) {
        System.Diagnostics.Debug.Assert(route.polygon != null,
            "Route's polygon must not be null! Set resultListOptions.polygon = true; ");
        Lines[] lines = new Lines[1];
        lines[0] = new Lines();
        lines[0].wrappedLines = new LineString[] { new LineString() };
        lines[0].wrappedLines[0].lineString = route.polygon.lineString;

        lines[0].options = new LineOptions();
        lines[0].options.mainLine = new LinePartOptions();
        lines[0].options.mainLine.visible = true;
        lines[0].options.mainLine.width = -8;
        lines[0].options.mainLine.color = new Color();
        lines[0].options.transparent = true;
        Color color = new Color();
        color.blue = 50; color.green = 255; color.red = 20;
        lines[0].options.mainLine.color = color;

        CustomLayer customLayer = new CustomLayer();
        customLayer.visible = true;
        customLayer.drawPriority = 200;
        customLayer.wrappedLines = lines;
        customLayer.centerObjects = true;
        return customLayer;
    }
}
