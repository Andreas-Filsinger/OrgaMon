using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using xserver;
public partial class xRoute_NetworkClassKilometers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        XRouteWSService xrouteClient = new XRouteWSService();

        WaypointDesc wpdStart = new WaypointDesc();
		wpdStart.wrappedCoords = new Point[] { new Point() };
		wpdStart.wrappedCoords[0].point = new PlainPoint();
		wpdStart.wrappedCoords[0].point.x = 653413.0;
		wpdStart.wrappedCoords[0].point.y = 6362650.0;

		WaypointDesc wpdDestination = new WaypointDesc();
		wpdDestination.wrappedCoords = new Point[] { new Point() };
		wpdDestination.wrappedCoords[0].point = new PlainPoint();
		wpdDestination.wrappedCoords[0].point.x = 681451.0;
		wpdDestination.wrappedCoords[0].point.y = 6371797.0;
		WaypointDesc[] waypoints = new WaypointDesc[] { wpdStart, wpdDestination };

        ResultListOptions resultListOptions = new ResultListOptions();

        ExtendedRoute route = xrouteClient
            .calculateExtendedRoute(waypoints, null, null, resultListOptions, null, null);

        string[] networkClassNames = new string[] {
			 "MOTORWAY", "HIGHWAY", "TRUNK_ROAD",
			 "COUNTRY_ROAD", "CITY_ROAD", "RESIDENTIAL_ROAD",
			 "SPECIAL_ROAD", "CYCLE_AND_WALKWAY" };

        foreach (CountryInfo countryInfo in route.wrappedCountryInfos ) {
            textBox.Text += "Country:" + countryInfo.iuCode + Environment.NewLine ;
            textBox.Text += "----------------------------" + Environment.NewLine;

             textBox.Text += "Network Class (NC)\t distance (m)" + Environment.NewLine;

            int ncID = 0;
            foreach (RouteInfo info in countryInfo.wrappedPerNCRouteInfo) {
                textBox.Text +=  String.Format("{0}\t{1}" + Environment.NewLine, networkClassNames[ncID++], info.distance);
            }
        }




    }
}
