using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;


public partial class xRoute_SimpleRouting : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		// create the WayPoint for the Start
		// ATTENTION: Here at the object WaypointDesc the parameters are not named
		// "coords" as described within the documentation but
		// "wrappedCoords"
		WaypointDesc wpdStart = new WaypointDesc();
		// please note that this has to be an array of Point...
		wpdStart.wrappedCoords = new Point[] { new Point() };
		wpdStart.wrappedCoords[0].point = new PlainPoint();
		wpdStart.wrappedCoords[0].point.x = 653413.0;  // x and y coordinates of P�telange, a small village in Luxembourg
		wpdStart.wrappedCoords[0].point.y = 6362650.0;

		// Waypoint for the Destination...
		WaypointDesc wpdDestination = new WaypointDesc();
		wpdDestination.wrappedCoords = new Point[] { new Point() };
		wpdDestination.wrappedCoords[0].point = new PlainPoint();
		wpdDestination.wrappedCoords[0].point.x = 681451.0;  // x and y coordinates of Luxembourg, the capital of Luxembourg in the heart of Europe
		wpdDestination.wrappedCoords[0].point.y = 6371797.0;

		// create a new array of WayPointDescriptions and fill it with Start and Destination
		WaypointDesc[] waypointDesc = new WaypointDesc[] { wpdStart, wpdDestination };

		// create a new Client for xRoute Service and call the server
		XRouteWSService xRouteClient = new XRouteWSService();
		RouteInfo routeInfo = xRouteClient.calculateRouteInfo(waypointDesc, null, null, null);
		// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// write the results to the web page...
		tbxDistance.Text = routeInfo.distance.ToString();
		tbxTime.Text = routeInfo.time.ToString();
	}
}
