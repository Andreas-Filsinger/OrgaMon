using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;

using xserver;

public partial class xRoute_TollCalculation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		// Please note:
		// for this sample you need a europe city map.
		//

		// First of all we create 5 WayPoints in 4 countries to get 
		// different toll values for different countries.
		WaypointDesc wpdParis = new WaypointDesc();
		WaypointDesc wpdAalborg = new WaypointDesc();
		WaypointDesc wpdWien = new WaypointDesc();
		WaypointDesc wpdInnsbruck = new WaypointDesc();
		WaypointDesc wpdBolzano = new WaypointDesc();

		wpdParis.wrappedCoords = new Point[] { new Point() };
		wpdAalborg.wrappedCoords = new Point[] { new Point() };
		wpdWien.wrappedCoords = new Point[] { new Point() };
		wpdInnsbruck.wrappedCoords = new Point[] { new Point() };
		wpdBolzano.wrappedCoords = new Point[] { new Point() };

		wpdParis.wrappedCoords[0].point = new PlainPoint();
		wpdAalborg.wrappedCoords[0].point = new PlainPoint();
		wpdWien.wrappedCoords[0].point = new PlainPoint();
		wpdInnsbruck.wrappedCoords[0].point = new PlainPoint();
		wpdBolzano.wrappedCoords[0].point = new PlainPoint();

		wpdParis.wrappedCoords[0].point.x = 262175.0;
		wpdParis.wrappedCoords[0].point.y = 6242590.0;
		wpdAalborg.wrappedCoords[0].point.x = 1101633.0;	
		wpdAalborg.wrappedCoords[0].point.y = 7751335.0;	
		wpdWien.wrappedCoords[0].point.x = 1820467.0;
		wpdWien.wrappedCoords[0].point.y = 6134685.0;
		wpdInnsbruck.wrappedCoords[0].point.x = 1267389.0;
		wpdInnsbruck.wrappedCoords[0].point.y = 5978788.0;
		wpdBolzano.wrappedCoords[0].point.x = 1262552.0;
		wpdBolzano.wrappedCoords[0].point.y = 5853474.0;

		WaypointDesc[] waypointDesc = new WaypointDesc[] { wpdParis, wpdAalborg, wpdWien, wpdInnsbruck, wpdBolzano };
		
		// ResultListOptions are mandatory, but we can leave them "null".
		ResultListOptions resultListOptions = new ResultListOptions();

		// CountryInfoOptions have to be set in order to specify how the 
		// toll should be returned.
		CountryInfoOptions countryInfoOptions = new CountryInfoOptions();
		// we want to get the amounts in each country's currency
		countryInfoOptions.allEuro = false;
		// we want to get Detailed Toll Costs
		countryInfoOptions.detailedTollCosts = true;
		
		// We should use a truck profile to get some valuable toll cost information
		// therefore we make use of the CallerContext
		CallerContext callerContext = new CallerContext();
		callerContext.wrappedProperties = new CallerContextProperty[] { new CallerContextProperty() };
		callerContext.wrappedProperties[0].key = "Profile";
		callerContext.wrappedProperties[0].value = "truckfast";

		// create a new Client for xRoute Service and call the server
		XRouteWSService xRouteClient = new XRouteWSService();
		ExtendedRoute extendedRoute = xRouteClient.calculateExtendedRoute(waypointDesc, null, null, resultListOptions, countryInfoOptions, callerContext);
		// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// create a StringBuilder that contains my ResultTable that represents the Toll Information
		StringBuilder sb = new StringBuilder();
		// two variables to accumlulate the distance and prices for the different segments
		int tollDistance = 0;
		int tollPrice = 0;

		// we create a table with the columns we want to display
		sb.Append("<table cellpadding=\"2\">");
		sb.Append("<th>CountryCode</th><th>Distance</th><th>TollDistance</th><th>TollPrice</th>");

		// Read out the Toll Information 
		foreach (CountryInfo countryInfo in extendedRoute.wrappedCountryInfos)
		{
			// for each entry in the itinerary we create an own row
			sb.Append("<tr>");

			// before each accumlation we have to set the values for tollDistance and tollPrice to "0"
			tollDistance = 0;
			tollPrice = 0;
			// iterate through all TollCostInfos...
			foreach (TollCostInfo tollCostInfo in countryInfo.wrappedTollCostInfos)
			{
				tollPrice += tollCostInfo.tollPrice;
				tollDistance += tollCostInfo.tollDistance;
			}
			// our first table cell contains the country code of the country we have to pay toll
			sb.Append("<td>" + countryInfo.iuCode.ToString() + "</td>");
			// our second table cell contains the complete distance we have driven in that special country
			sb.Append("<td align=\"right\">" + Convert.ToDouble(Convert.ToDouble(countryInfo.partRouteInfo.distance) / 1000.0).ToString("0.00") + " km</td>");
			// our third table cell contains the distance we have driven on toll related streets in that special country
			sb.Append("<td align=\"right\">" + Convert.ToDouble(Convert.ToDouble(tollDistance) / 1000.0).ToString("0.00") + " km</td>");
			// our fourth table cell contains the price we have to pay in that special country
			sb.Append("<td align=\"right\">" + Convert.ToDouble(Convert.ToDouble(tollPrice) / 100.0).ToString("0.00") + " " + countryInfo.currency +"</td>");

			// close the row
			sb.Append("</tr>");
		}
		// close the table
		sb.Append("</table>");

		// pass the created table to the litaral.		
		ltToll.Text = sb.ToString();
    }
}
