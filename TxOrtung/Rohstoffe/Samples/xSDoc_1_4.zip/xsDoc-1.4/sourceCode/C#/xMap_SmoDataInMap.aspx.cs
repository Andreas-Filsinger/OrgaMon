using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

using xserver;

public partial class xMap_SmoDataInMap: System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {

        // init web service client
        XMapWSService xMapClient = new XMapWSService();
        
        // ------------------------------------------------------
        // 1.) read SMO data from file
        string smoFile = Server.MapPath("data/sample_smo.bin");
        byte[] smoData = File.ReadAllBytes(smoFile);

        // ------------------------------------------------------
        // 2.) define SMO layer
        SMOLayer smoLayer = new SMOLayer();
        smoLayer.visible = true;
        smoLayer.name = "SmoLayer1";
        smoLayer.smoData = smoData;
        smoLayer.objectInfos  = ObjectInfoType.REFERENCEPOINT;

        Layer[] layers = new Layer[] { smoLayer };

        // ------------------------------------------------------
        // 3.) define standard mapping parameters
        MapSection mapSection = new MapSection();
        mapSection.center = new Point();
        mapSection.center.point = new PlainPoint();
        mapSection.center.point.x = 685407.751736;
        mapSection.center.point.y = 6372537.965244;
        mapSection.scale = 50000;
        mapSection.scrollHorizontal = 0;
        mapSection.scrollVertical = 0;
        mapSection.zoom = 0;  

        MapParams mapParams = new MapParams();
        mapParams.showScale = true;
        mapParams.useMiles = false;

        ImageInfo imageInfo = new ImageInfo();
        imageInfo.format = ImageFileFormat.PNG;
        imageInfo.width = 480;
        imageInfo.height = 320;

        bool includeImageInResponse = false;
        // ------------------------------------------------------

        // ------------------------------------------------------
        // 3.) render map
        Map map = xMapClient.renderMap(mapSection, mapParams, imageInfo,
                                        layers, includeImageInResponse, null);


        MapImage.ImageUrl = "http://"+map.image.url;
    }
}
