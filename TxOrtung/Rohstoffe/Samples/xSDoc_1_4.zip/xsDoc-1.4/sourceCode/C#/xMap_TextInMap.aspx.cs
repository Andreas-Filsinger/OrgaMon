using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;

public partial class xMap_TextInMap: System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // coordinate values of the lines' destination Points 
        double[,] pointCoordinates = new double[,]{
            {933257.0, 6269796.0}, //  Stephanienstrasse
            {932089.0, 6269672.0}, //  Kaiserallee 
            {933820.553707339, 6270484.40308829}, //  Willy-Brandt-Allee
        };

        int numberOfPoints = pointCoordinates.GetLength(0);

        // create PlainPoints from coordinate values
        PlainPoint[] destinationPlainPoints = new PlainPoint[numberOfPoints];
        for (int i = 0; i < numberOfPoints; i++) {
            destinationPlainPoints[i] = new PlainPoint();
            destinationPlainPoints[i].x = pointCoordinates[i, 0 /*X*/];
            destinationPlainPoints[i].y = pointCoordinates[i, 1 /*Y*/];
        }


        //================================================================================
        // 1.)  Create the texts
   
        Text text1 = new Text();
        text1.position = new Point();
        text1.position.wkt = "POINT( 933257.0 6269796.0 )";
        text1.text = "This is\ncustom text";

        Text text2 = new Text();
        text2.position = new Point();
        text2.position.wkt = "POINT( 932089.0 6269672.0 )";
        text2.text = "More text...";


        //================================================================================
        // 2.)  set the style of the  texts

        /*
         * The text options  allow you to set
         *  - font style (bold, underline, etc), size and color
         *  - frame and background
         *  - text align for multi-line texts
         */
        TextOptions textOptions = new TextOptions();
        // font color
        textOptions.textColor = new Color();
        textOptions.textColor.red = 0;
        textOptions.textColor.green = 0;
        textOptions.textColor.blue = 0;

        // font
        textOptions.font = new Font();
        textOptions.font.name = "Arial";
        textOptions.font.bold = true;
        textOptions.font.size = 24;
        // textOptions.font.italic = false;
        // textOptions.font.underline = false;        

        // frame
        textOptions.showFrame = true;
        textOptions.frameColor = new Color();
        textOptions.frameColor.red = 255;
        textOptions.frameColor.green = 0;
        textOptions.frameColor.blue = 0;
        
        // background
        textOptions.fillBg = true;
        textOptions.bgColor = new Color();
        textOptions.bgColor.red = 255;
        textOptions.bgColor.green = 255;
        textOptions.bgColor.blue = 255;
        
        // text align
        textOptions.alignment = TextAlignment.CENTER;

        //================================================================================
        // 3.) put the texts and the text opttion together

        // Note: if you want to style each Text object differently
        //       you have to create a Texts object for each Text.
        //       Which allows you to use different text options.
        Texts texts = new Texts();
        texts.wrappedTexts = new Text[] { text1, text2 };
        texts.options = textOptions;

        //================================================================================
        // 4.) put our Texts objects into a CustomLayer
        
        CustomLayer customLayer = new CustomLayer();
        customLayer.wrappedTexts = new Texts[] { texts };

        customLayer.name = "Text layer";
        customLayer.visible = true;
        customLayer.drawPriority = 25000;	// this is POIDEFAULT

        // if you want to retrieve the pixelposition of your objects in the generated map
        customLayer.objectInfos = ObjectInfoType.REFERENCEPOINT;        
        
        //==============================================================================
        // Set a MapSection
        MapSection mapSection = new MapSection();
        mapSection.center = new Point();
        mapSection.center.wkt = "POINT( 933257.0 6269796.0)";
        mapSection.scale = 100;

        // set the ImageInfos such as FileFormat, Width and Height...
        ImageInfo imageInfo = new ImageInfo();
        imageInfo.format = ImageFileFormat.GIF;
        imageInfo.height = Convert.ToInt32(pbMap.Height.Value);
        imageInfo.width  = Convert.ToInt32(pbMap.Width.Value);

        // set MapParams for the decision whether to draw the scale or not
        // and if to use miles or kilometers as the scale's unit
        MapParams mapParams = new MapParams();
        mapParams.showScale = false;
        mapParams.useMiles = false;

        // initiate client & call XMap SOAP service
        XMapWSService xMapClient = new XMapWSService();
        Map map = xMapClient.renderMap(mapSection, mapParams, imageInfo, new Layer[] { customLayer }, false, null);

        // the delivery by URL has to be configured properly
        // within the xMap Server config-files:
        //	xmap.properties
        //		imageMapServer.remotePath=C:/mgtmp
        //		imageMapServer.remoteURL=localhost/mgtmp
        pbMap.ImageUrl = "http://"+map.image.url;
    }
}



