using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using xserver;

public partial class xRoute_CalculateTour : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {

        // init xRoute client
        //String URL = "http://localhost:50030/xroute/ws/XRoute";
        XRouteWSService xrouteClient = new XRouteWSService();
        

        DateTime today = DateTime.Today;
        DateTime tommorow = new DateTime(today.Ticks);
        tommorow.AddDays(1);

        Point point;

        //---------------------------------------------------------------------
        // 1. Tour point: Hamburg
        TourPointDesc hamburg = new TourPointDesc();
        hamburg.linkType = LinkType.AUTO_LINKING;
        point = new Point();
        point.point = new PlainPoint();
        point.point.x = 1108401;
        point.point.y = 7078031;
        hamburg.wrappedCoords = new Point[] { point };

        //---------------------------------------------------------------------
        // 2. Tour point: Leipzig
        TourPointDesc leipzip = new TourPointDesc();
        leipzip.linkType = LinkType.AUTO_LINKING;
        point = new Point();
        point.point = new PlainPoint();
        point.point.x = 1378012;
        point.point.y = 6681209;
        leipzip.wrappedCoords = new Point[] { point };

        // it takes 1 hour to unload the truck in Leipzig
        leipzip.servicePeriod = 3600;

        // the driver does not have to help and can use the service period as break
        leipzip.useServicePeriodForRecreation = true;

        // the driver has to arrive within the opening hours
        leipzip.wrappedOpeningIntervals = new Interval[] { new Interval() };

        leipzip.wrappedOpeningIntervals[0].from = new DateTime(2008, 11, 16, 8, 0, 0); //from 8:00h till 18:00h
        leipzip.wrappedOpeningIntervals[0].fromSpecified = true;
        leipzip.wrappedOpeningIntervals[0].till = new DateTime(2008, 11, 16, 18, 0, 0);
        leipzip.wrappedOpeningIntervals[0].tillSpecified = true;

        // the unloading does not need to be finished within the opening hours
        leipzip.completeServiceInIntervals = false;
        //---------------------------------------------------------------------

        //---------------------------------------------------------------------
        // 3. Tour point: Frankfurt
        TourPointDesc frankfurt = new TourPointDesc();
        frankfurt.linkType = LinkType.AUTO_LINKING;
        point = new Point();
        point.point = new PlainPoint();
        point.point.x = 962659;
        point.point.y = 6461857;
        frankfurt.wrappedCoords = new Point[] { point };
        frankfurt.servicePeriod = 1800; // 30 minutes

        frankfurt.wrappedOpeningIntervals = new Interval[] { new Interval(), new Interval() };
        // 8:00h - 13:00h
        frankfurt.wrappedOpeningIntervals[0].from = new DateTime(2008, 11, 16, 8, 0, 0);
        frankfurt.wrappedOpeningIntervals[0].fromSpecified = true;
        frankfurt.wrappedOpeningIntervals[0].till = new DateTime(2008, 11, 16, 13, 0, 0);
        frankfurt.wrappedOpeningIntervals[0].tillSpecified = true;
        // 15:00h - 22:00h
        frankfurt.wrappedOpeningIntervals[1].from = new DateTime(2008, 11, 16, 15, 0, 0);
        frankfurt.wrappedOpeningIntervals[1].fromSpecified = true;
        frankfurt.wrappedOpeningIntervals[1].till = new DateTime(2008, 11, 16, 22, 0, 0);
        frankfurt.wrappedOpeningIntervals[1].tillSpecified = true;
        //---------------------------------------------------------------------


        //---------------------------------------------------------------------
        // 4. Tour point: Munich
        TourPointDesc munich = new TourPointDesc();
        munich.linkType = LinkType.AUTO_LINKING;
        point = new Point();
        point.point = new PlainPoint();
        point.point.x = 1292573;
        point.point.y = 6125849;
        munich.wrappedCoords = new Point[] { point };
        munich.servicePeriod = 1800; // 30 minutes

        munich.wrappedOpeningIntervals = new Interval[] { new Interval(), new Interval() };
        // next day 8:00h - 13:00h
        munich.wrappedOpeningIntervals[0].from = new DateTime(2008, 11, 17, 8, 0, 0);
        munich.wrappedOpeningIntervals[0].fromSpecified = true;
        munich.wrappedOpeningIntervals[0].till = new DateTime(2008, 11, 17, 13, 0, 0);
        munich.wrappedOpeningIntervals[0].tillSpecified = true;
        // next day  15:00h - 20:00h
        munich.wrappedOpeningIntervals[1].from = new DateTime(2008, 11, 17, 15, 0, 0);
        munich.wrappedOpeningIntervals[1].fromSpecified = true;
        munich.wrappedOpeningIntervals[1].till = new DateTime(2008, 11, 17, 20, 0, 0);
        munich.wrappedOpeningIntervals[1].tillSpecified = true;

        //---------------------------------------------------------------------
        WaypointDesc[] tourPoints = new WaypointDesc[] { hamburg, leipzip, frankfurt, munich };

        ResultListOptions resultListOptions = new ResultListOptions();
        // set manoveurs to true, if itinerary with manoveurs is wanted
        //		resultListOptions.setManoeuvres(true);
        resultListOptions.texts = true;
        resultListOptions.segments = true;
        resultListOptions.detailLevel = DetailLevel.STANDARD;

        Tour tour
            = xrouteClient.calculateTour(tourPoints, null, null, resultListOptions, null, null);
        
       
        // the Texts array contains strings which are referenced
        // by other data of the route (e.g. street names)
        String[] texts = tour.route.wrappedTexts;
        RouteListSegment[] routeSegments = tour.route.wrappedSegments;


        // the TimeEvents array contains events, which (should) occur during the
        // tour. Events include driving periods, rest periods, breaks, etc.
        // The observable event types are documented in the API reference. 
        TimeEvent[] events = tour.wrappedTimeEvents;

        string[][] rows = new string[events.Length][];
        Object[] cols = new Object[] { "Event", "at tour point", "street", "start time", "end time", };

        DateTime tourStart = tour.tourSummary.lastestTourStart;

        for (int i = 0; i < events.Length; i++) {

            String streetName = "";
            // in order to get the street name we 
            // check if the events references a valid segment ID
            if (events[i].segmentIdx < routeSegments.Length) {
                // get the reference segment
                RouteListSegment segment = routeSegments[events[i].segmentIdx];
                // get the street name ID from the segment
                int streetId = segment.streetNameIdx;

                // if street idx is valid, get the street name
                // from the array of texts
                if (streetId >= 0)
                    streetName = texts[streetId];
            }

            DateTime start = tourStart.AddSeconds(events[i].startTime);
            string startTime = start.ToString("dd MMM, HH:mm:ss");

            DateTime end = start.AddSeconds(events[i].period);
            string endTime = end.ToString("dd MMM, HH:mm:ss");

            AddTableRow(EventTable,
                new string[]{
                    events[i].type.ToString(), // type of the event (eg.: TOUR_START, DRIVING ...)
                    (events[i].tourPointIdx < 0 ? "" : events[i].tourPointIdx.ToString()),
                    streetName, // name of street if available
                    startTime,// start time of the event
                    endTime  // end time of the event     
                });
        }
    }
    /// <summary>
    /// Adds a new row of string values to a Table
    /// </summary>
    /// <param name="table"></param>
    /// <param name="cellValues"></param>
    private void AddTableRow(Table table, string[] cellValues) {
        TableRow row = new TableRow();
        TableCell cell;
        foreach (string s in cellValues) {
            cell = new TableCell();
            cell.Controls.Add(new LiteralControl(s));
            row.Cells.Add(cell);
        }
        table.Rows.Add(row);
    }
}