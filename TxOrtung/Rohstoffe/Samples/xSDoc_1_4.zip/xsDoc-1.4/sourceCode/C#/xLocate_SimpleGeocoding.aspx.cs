using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;

public partial class xLocate_SimpleGeocoding : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		// Instantiate a new instance of an address and fill at least 
		// city or postCode.
		Address address = new Address();
		address.city = "Luxembourg";
		address.postCode = "";
		address.country = "";
		address.street = "";
		address.houseNumber = "";

		// Create a new Client for xLocate Service and call the server
		XLocateWSService xLocateClient = new XLocateWSService();
		AddressResponse addressResponse = xLocateClient.findAddress(address, null, null, null, null);
		// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// Clear the List Box of existing items
		ListBox1.Items.Clear();

		// For each Result Address in the returned List add it to the List Box
		foreach (ResultAddress resultAddress in addressResponse.wrappedResultList)
		{
			ListBox1.Items.Add(new ListItem(resultAddress.country
				+ " - " + resultAddress.city + ", "
				+ resultAddress.city2,
				resultAddress.coordinates.point.x + "|" + resultAddress.coordinates.point.y));
		}

		// Bind the Items to the List Box
		ListBox1.DataBind();
	}
}
