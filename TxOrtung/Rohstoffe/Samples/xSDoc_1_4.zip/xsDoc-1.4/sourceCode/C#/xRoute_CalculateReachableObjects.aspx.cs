using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;


public partial class xRoute_CalculateReachableObjects : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		// create the WayPoint for the Start
		// ATTENTION: Here at the object WaypointDesc the parameters are not named
		// "coords" as described within the documentation but
		// "wrappedCoords"
		WaypointDesc wpdLocation = new WaypointDesc();
		// please note that this has to be an array of Point...
		wpdLocation.wrappedCoords = new Point[] { new Point() };
		wpdLocation.wrappedCoords[0].point = new PlainPoint();
		wpdLocation.wrappedCoords[0].point.x = 681451.0;	// x and y coordinates of Luxembourg, the capital of Luxembourg in the heart of Europe
		wpdLocation.wrappedCoords[0].point.y = 6371797.0;


		// Two waypoints that should be reached within a certain time or distance
		WaypointDesc wpd1 = new WaypointDesc();
		wpd1.wrappedCoords = new Point[] { new Point() };
		wpd1.wrappedCoords[0].point = new PlainPoint();
		wpd1.wrappedCoords[0].point.x = 653413.0;  // x and y coordinates of P�telange, a small village in Luxembourg
		wpd1.wrappedCoords[0].point.y = 6362650.0;
		WaypointDesc wpd2 = new WaypointDesc();
		wpd2.wrappedCoords = new Point[] { new Point() };
		wpd2.wrappedCoords[0].point = new PlainPoint();
		wpd2.wrappedCoords[0].point.x = 1820467.0;	// x and y coordinates of Vienna, the capital of Austria
		wpd2.wrappedCoords[0].point.y = 6134685.0;

		// create a new array of WayPointDescriptions and fill it with the two waypoints
		WaypointDesc[] waypointDesc = new WaypointDesc[] { wpd1, wpd2 };
		
		// To define the kilometer distance that should be set as the maximum 
		// we have to define a Horizon and set the corresponding expansionType.
		// With the method calculateReachableObjects() it does not make sense to 
		// specify more than one Horizon.
		// This is interesting for the calculateIsochrones().
		ExpansionDescription expansionDescription = new ExpansionDescription();
		expansionDescription.expansionType = ExpansionType.EXP_DIST;
		expansionDescription.wrappedHorizons = new int[]{20000};

		// create a new Client for xRoute Service and call the server
		XRouteWSService xRouteClient = new XRouteWSService();
		Reach reach = xRouteClient.calculateReachableObjects(wpdLocation, null, waypointDesc, null, expansionDescription, null);
		// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


		// write the results to the web page...
		tbxWpd1Reachable.Text = reach.wrappedReachInfo[0].reachable.ToString();
		tbxWpd1Distance.Text = reach.wrappedReachInfo[0].routeInfo.distance.ToString();
		tbxWpd1Time.Text = reach.wrappedReachInfo[0].routeInfo.time.ToString();

		tbxWpd2Reachable.Text = reach.wrappedReachInfo[1].reachable.ToString();
		tbxWpd2Distance.Text = reach.wrappedReachInfo[1].routeInfo.distance.ToString();
		tbxWpd2Time.Text = reach.wrappedReachInfo[1].routeInfo.time.ToString();


	}
}
