using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;

public partial class xMap_ShapesWithGeometryLayer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Create a new Client for xMap Service and call the server
        XMapWSService xMapClient = new XMapWSService();

	xMapClient.Proxy = new System.Net.WebProxy("http://127.0.0.1:8888",false);

        // region contains code that isn't new in this example
        #region mapping parameters from previous example
        MapSection mapSection = new MapSection();

        mapSection.center = new Point();
        mapSection.center.point = new PlainPoint();
        mapSection.center.point.x = 800000;
        mapSection.center.point.y = 6900000;
        mapSection.scale = 1000;
        mapSection.scrollHorizontal = 0;
        mapSection.scrollVertical = 0;
        mapSection.zoom = 0;

        ImageInfo imageInfo = new ImageInfo();
        imageInfo.format = ImageFileFormat.GIF;
        imageInfo.height = Convert.ToInt32(mapImage.Height.Value);
        imageInfo.width = Convert.ToInt32(mapImage.Width.Value);

        MapParams mapParams = new MapParams();
        mapParams.showScale = true;
        mapParams.useMiles = false;
        #endregion

        Polygon polygon = new Polygon();
        // Berlin state boundaries
        polygon.wkt = "POLYGON((1365280  5234036,1363789  5234270,1363355  5235239,1363358  5235994,1363916  5236634,1364154  5237223,1363888  5237835,1363176  5237862,1362555  5238492,1360067  5237848,1360139  5238498,1359280  5238916,1359072  5239561,1356608  5239041,1353629  5239011,1353787  5240277,1352725  5240014,1351753  5240445,1351968  5240796,1351196  5240736,1350011  5240532,1348788  5240316,1347749  5240054,1346835  5242414,1341898  5241323,1342418  5239561,1342683  5238919,1342040  5238217,1338501  5237888,1337828  5238739,1337951  5239194,1336790  5239205,1336819  5239616,1334107  5240656,1333915  5241320,1331667  5240564,1330683  5240026,1329300  5241054,1327335  5240296,1326777  5240528,1325713  5240675,1324664  5240683,1324298  5242067,1322894  5242079,1322353  5242209,1321675  5242112,1320753  5241925,1319645  5241775,1318517  5241591,1317500  5241301,1316708  5241034,1316178  5240742,1315742  5240448,1315868  5240173,1317045  5240062,1317146  5239388,1316241  5239098,1315349  5239505,1314813  5239885,1313563  5240111,1312809  5239889,1312838  5239375,1313505  5239074,1312994  5238724,1312271  5239117,1312547  5239948,1311749  5240364,1310743  5240634,1310017  5240971,1309160  5241217,1308320  5241405,1309065  5242290,1309255  5242391,1310709  5243008,1310717  5243430,1311417  5243858,1311779  5244186,1311676  5244735,1310910  5244865,1310195  5245385,1310569  5245826,1310929  5245983,1310382  5246399,1311199  5247464,1312567  5248424,1313630  5249088,1314521  5249629,1315492  5250352,1316159  5250872,1316710  5251209,1315365  5251620,1314319  5251958,1314508  5253063,1313932  5253341,1313735  5253925,1314173  5254229,1314151  5255085,1314122  5255519,1314637  5255994,1314711  5256929,1314912  5257611,1315413  5258269,1315385  5258840,1314445  5258824,1314266  5258347,1313272  5258434,1313128  5258846,1313792  5259138,1314701  5259450,1315517  5259809,1316600  5260109,1317481  5260204,1318921  5259736,1320288  5259418,1321356  5259146,1322065  5258901,1322309  5259834,1320720  5260315,1320748  5260772,1321230  5261406,1321809  5262086,1322177  5262608,1322377  5263176,1326935  5263206,1326845  5264359,1328731  5264388,1329143  5265195,1328582  5265416,1328749  5266167,1331275  5266168,1331588  5265868,1330901  5265498,1331527  5264774,1331592  5264340,1330452  5262993,1331656  5262970,1332592  5262699,1333791  5262426,1334803  5262211,1335798  5262144,1336614  5262366,1336738  5262398,1337624  5262721,1337716  5263073,1338176  5263270,1338751  5263441,1339029  5263756,1339346  5264082,1339196  5264462,1339598  5264603,1340117  5264444,1341247  5264411,1341751  5263555,1342480  5263815,1343312  5263513,1343149  5264408,1343905  5264450,1343965  5264894,1345330  5264685,1347382  5265399,1346370  5265510,1345007  5266166,1346102  5266945,1346719  5266841,1347771  5267517,1348030  5267421,1347586  5266846,1348620  5267146,1348331  5265905,1351326  5264416,1351995  5264597,1352642  5264355,1352146  5263851,1352125  5263097,1351030  5262661,1350770  5262027,1350045  5261092,1350372  5260469,1350862  5259384,1352273  5259355,1353573  5259031,1354752  5258550,1355640  5257880,1356479  5257050,1357625  5256993,1358220  5256534,1358210  5255997,1358545  5255201,1360079  5255132,1360421  5255116,1361546  5252954,1362414  5253347,1363292  5253249,1364017  5253119,1364753  5253183,1365644  5253313,1365882  5252850,1364707  5252338,1363770  5251683,1362871  5250674,1362041  5249913,1362483  5249401,1362049  5248999,1361399  5248441,1360867  5247961,1361316  5247597,1360978  5247226,1362161  5246538,1362601  5247032,1362518  5247606,1363076  5247868,1364180  5248119,1365031  5247906,1365673  5247728,1366326  5247546,1367559  5247097,1368766  5246865,1370051  5246700,1371385  5246372,1372147  5245887,1372965  5245435,1374230  5245234,1375796  5245394,1375914  5244511,1375554  5244428,1375209  5244642,1374406  5244373,1374304  5243895,1373679  5243772,1373449  5243022,1372561  5241887,1373716  5241096,1372748  5240202,1370933  5239911,1370345  5239112,1368911  5238606,1369775  5238278,1370717  5239059,1371559  5239039,1371289  5238577,1370600  5238306,1370417  5237704,1369738  5237605,1369231  5236907,1369687  5236691,1369029  5236305,1367982  5236329,1367635  5235822,1366505  5235675,1366241  5235292,1365804  5234501,1365280  5234036))";
        Point referencePoint = new Point();
        referencePoint.wkt = "POINT(1365280  5234036)";

        Geometry geometry = new Geometry();
        geometry.id = 999;
        geometry.description = "triangle";
        geometry.referencePoint = referencePoint;
        geometry.geometry = polygon;

        GeometryOption fillColor = new GeometryOption();
        fillColor.option = GeometryOptions.FILLCOLOR;
        fillColor.value = rgbToColorString(128, 255, 0);

        GeometryOption borderAlpha = new GeometryOption();
        borderAlpha.option = GeometryOptions.BORDERALPHA;
        borderAlpha.value = "0";

        GeometryOption fillAlpha = new GeometryOption();
        fillAlpha.option = GeometryOptions.FILLALPHA;
        fillAlpha.value = "150";

        GeometryOption autoCenter = new GeometryOption();
        autoCenter.option = GeometryOptions.AUTOCENTEROBJECTS;
        autoCenter.value = "1";


        GeometryOption[] geometryOptions = new GeometryOption[] {
            fillColor, autoCenter, fillAlpha, borderAlpha
        };

        Geometries geometries = new Geometries();
        geometries.wrappedGeometries = new Geometry[] { geometry };
        geometries.wrappedOptions = geometryOptions;

        GeometryLayer layer = new GeometryLayer();
        layer.name = "myGeometryLayer";
        layer.drawPriority = 200;
        layer.visible = true;
        layer.wrappedGeometries = new Geometries[] { geometries };
        layer.objectInfos = ObjectInfoType.GEOMETRY;


        CallerContextProperty ccProp = new CallerContextProperty();
        ccProp.key = "CoordFormat";
        ccProp.value = "PTV_GEODECIMAL";

        CallerContext cc = new CallerContext();
        cc.wrappedProperties = new CallerContextProperty[]{
            ccProp
        };

        Map map = xMapClient.renderMap(mapSection, mapParams, imageInfo,
            new Layer[] {layer}, false, cc);



        //------------------------------------------------------------------------
        mapImage.ImageUrl = "http://" + map.image.url;


        //------------------------------------------------------------------------
        // Use the returned information to create a image map

        LayerObject o = map.wrappedObjects[0].wrappedObjects[0];
        PlainPolygon pixelPolygon = (PlainPolygon)o.geometry.pixelGeometry;

        string pixelCoordinates = null;
        foreach (PlainPoint pt in pixelPolygon.wrappedLinearRings[0].wrappedPoints) {
            if (pixelCoordinates == null) {
                pixelCoordinates = pt.x + "," + pt.y;
            } else {
                pixelCoordinates += "," + pt.x + "," + pt.y;
            }
        }

       PolygonHotSpot hotspot = new PolygonHotSpot();
       hotspot.Coordinates = pixelCoordinates;
       mapImage.HotSpots.Add(hotspot);

    }

    string rgbToColorString(int red, int green, int blue) {
        int color = (blue << 16) + (green << 8) + (red);
        return "" + color;
    }
}
