using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using xserver;

public partial class xRoute_SoftViaPoints : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) {
        WaypointDesc wpdStart = new WaypointDesc();
        wpdStart.wrappedCoords = new Point[] { new Point() };
        wpdStart.wrappedCoords[0].point = new PlainPoint();
        wpdStart.wrappedCoords[0].point.x = 980172; 
        wpdStart.wrappedCoords[0].point.y = 6286080;

        WaypointDesc wpdDestination = new WaypointDesc();
        wpdDestination.wrappedCoords = new Point[] { new Point() };
        wpdDestination.wrappedCoords[0].point = new PlainPoint();
        wpdDestination.wrappedCoords[0].point.x = 989947; 
        wpdDestination.wrappedCoords[0].point.y = 6285085;
        
        
        WaypointDesc wpdSoftVia = new WaypointDesc();
        wpdSoftVia.wrappedCoords = new Point[] { new Point() };
        wpdSoftVia.wrappedCoords[0].point = new PlainPoint();
        wpdSoftVia.wrappedCoords[0].point.x = 990923;
        wpdSoftVia.wrappedCoords[0].point.y = 6291255;

        // #######################################################
        wpdSoftVia.linkType = LinkType.FUZZY_LINKING;
        wpdSoftVia.fuzzyRadius = 5000; // 5km
        // #######################################################

        WaypointDesc[] waypointDesc = new WaypointDesc[] { wpdStart, wpdSoftVia, wpdDestination };

        ResultListOptions resultListOptions = new ResultListOptions();
        resultListOptions.polygon = true;
        resultListOptions.totalRectangle = true;

        // create a new Client for xRoute Service and call the server
        XRouteWSService xRouteClient = new XRouteWSService();
        Route route = xRouteClient.calculateRoute(waypointDesc, null, null, resultListOptions, null);

        mapRoute(route, wpdSoftVia);
    }

    /// <summary>
    /// Renders and displays a map showing the route and the soft via-point
    /// </summary>
    /// <param name="route">the route</param>
    /// <param name="wpdSoftVia">soft via point</param>
    private void mapRoute(Route route, WaypointDesc wpdSoftVia) {
        // set the ImageInfos such as FileFormat, Width and Height...
        ImageInfo imageInfo = new ImageInfo();
        imageInfo.format = ImageFileFormat.PNG;
        imageInfo.height = Convert.ToInt32(image.Height.Value);
        imageInfo.width = Convert.ToInt32(image.Width.Value);

        BoundingBox boundingBox = new BoundingBox();
        boundingBox.leftTop = new Point();
        boundingBox.leftTop.wkt = "POINT( 0 0 )";
        boundingBox.rightBottom = new Point();
        boundingBox.rightBottom.wkt = "POINT( 0 0 )";

        Lines[] lines = new Lines[1];
        lines[0] = new Lines();
        lines[0].wrappedLines = new LineString[] { route.polygon };


        lines[0].options = new LineOptions();
        lines[0].options.mainLine = new LinePartOptions();
        lines[0].options.mainLine.visible = true;
        lines[0].options.mainLine.width = -6;
        lines[0].options.mainLine.color = new Color();
        Color color = new Color();
        color.blue = 255; color.green = 50; color.red = 20;
        lines[0].options.mainLine.color = color;
        lines[0].options.transparent = true;

        Bitmap[] arrBitmap = new Bitmap[] { new Bitmap() };
        arrBitmap[0].position = wpdSoftVia.wrappedCoords[0];
        arrBitmap[0].descr = "SoftVia";
        arrBitmap[0].name = "location_rough.bmp";

        Bitmaps[] arrBitmaps = new Bitmaps[] { new Bitmaps() };
        arrBitmaps[0].wrappedBitmaps = arrBitmap;
        arrBitmaps[0].options = new BitmapOptions();

        CustomLayer customLayer = new CustomLayer();
        customLayer.visible = true;
        customLayer.drawPriority = 200;
        customLayer.wrappedLines = lines;
        customLayer.centerObjects = true;
        customLayer.wrappedBitmaps = arrBitmaps;

        Layer[] layer = new Layer[] { customLayer };


        XMapWSService xMapClient = new XMapWSService();
        Map map = xMapClient.renderMapBoundingBox(boundingBox, null, imageInfo, layer, false, null);

        image.ImageUrl = "http://" + map.image.url;
    }
}
