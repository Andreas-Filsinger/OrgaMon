using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;

using xserver;

public partial class xRoute_ExceptionPath : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) {
        // define the waypoints of the route
        WaypointDesc wpdStart = _createWaypoint(937057.94, 6269204.96);
        WaypointDesc wpdDest = _createWaypoint(938255.51, 6269398.21);
        WaypointDesc[] waypoints = new WaypointDesc[] { wpdStart, wpdDest };

        // set some result list options to make xRoute return a route
        // with textual information ( required for displayRouteInTable(...) )
        ResultListOptions resultListOptions = new ResultListOptions();
        resultListOptions.manoeuvres = true;
        resultListOptions.texts = true;
        resultListOptions.segments = true;
        resultListOptions.detailLevel = DetailLevel.STANDARD;

        // ============================================================================
        // Define ExceptionPaths to alter route in order to follow preferences
        ExceptionPath[] exceptionPaths = new ExceptionPath[] {
            new ExceptionPath(),
            new ExceptionPath()
        };

        // block Gerwigstra�e
        exceptionPaths[0].absTimeMalus = -1;
        exceptionPaths[0].absTimeMalusSpecified = true;
        exceptionPaths[0].relMalus = 2500;
        exceptionPaths[0].street = "Gerwigstra�e";

        // strongly prefer Essenweinstra�e in route
        exceptionPaths[1].absTimeMalus = -1;
        exceptionPaths[1].absTimeMalusSpecified = true;
        exceptionPaths[1].relMalus = -100;
        exceptionPaths[1].street = "Striederstra�e";
        // ============================================================================

        XRouteWSService xRoute = new XRouteWSService();

        // calculate default route w/o ExceptionPath
        Route defaultRoute = xRoute
            .calculateRoute(waypoints, null, null, resultListOptions, null);

        // calculate route w/ ExceptionPath
        Route route = xRoute
            .calculateRoute(waypoints, null, exceptionPaths, resultListOptions, null);

        // display both routes  in tables
        displayRouteInTable(route, this.table);
        displayRouteInTable(defaultRoute, this.defaultRouteTable);
    }


    /// <summary>
    /// Formats some information of a given route in a table. 
    /// </summary>
    /// <param name="route">The route.</param>
    /// <param name="table">The table.</param>
    private void displayRouteInTable(Route route, Table table) {
        foreach (RouteManoeuvre manoeuvre in route.wrappedManoeuvres) {
            RouteListSegment segment = route.wrappedSegments[manoeuvre.routeListSegmentIdx];
            string streetName = (segment.streetNameIdx >= 0 ? route.wrappedTexts[segment.streetNameIdx] : "");

            Control[] cellControls = new Control[] {
                new LiteralControl(streetName),
                new LiteralControl(manoeuvre.manoeuvreDesc)
            };

            TableRow row = new TableRow();
            foreach (Control c in cellControls) {
                TableCell cell = new TableCell();
                cell.Controls.Add(c);
                row.Cells.Add(cell);
            }
            table.Rows.Add(row);
        }
    }


    /// <summary>
    /// Convinience method to create a waypoint.
    /// </summary>
    /// <param name="x">The point's x value</param>
    /// <param name="y">The point's y value</param>
    /// <returns></returns>
    private static WaypointDesc _createWaypoint(double x, double y) {
        WaypointDesc waypoint = new WaypointDesc();
        waypoint.wrappedCoords = new Point[] { new Point() };
        waypoint.wrappedCoords[0].point = new PlainPoint();
        waypoint.wrappedCoords[0].point.x = x;
        waypoint.wrappedCoords[0].point.y = y;
        return waypoint;
    }
}

