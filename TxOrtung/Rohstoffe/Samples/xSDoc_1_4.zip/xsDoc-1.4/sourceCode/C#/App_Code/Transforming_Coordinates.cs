﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

public enum CoordinateTypeEnum
{
    Default = 0, Mercator = 0, GeoDecimal_WGS84 = 1, EuroConform = 2, SuperConform = 2, GeoMinSec = 3, GaussKrueger = 4, UTM = 5, Conform = 6, RasterSmartUnits = 7
    // UTMREF = MGRS
}

public class Transformation
{

    /* Functions for coordinates transformation
     * 
     * They all follow the same pattern:
     * coordinates are first computed as floating numbers
     * then rounded to the nearest integer number
     * before being returned
     */

    /* Conversion from Mercator to ... */

    public static int Mercator_2_GeoDecimal(long xIn, long yIn, out long xOut, out long yOut)
    {
        int zIn = 0, zOut = 0;
        double xRes, yRes;

        // compute the coordinates as floating numbers
        int result = Mercator_2_GeoDecimal((double)xIn, (double)yIn, out xRes, out yRes, ref zIn, ref zOut);

        // the values are rounded each to the nearest integer
        xOut = (long)Math.Round(xRes);
        yOut = (long)Math.Round(yRes);
        return result;
    }

    public static int Mercator_2_GeoDecimal(long xIn, long yIn, out long xOut, out long yOut, ref int zIn, ref int zOut)
    {
        double xRes, yRes;
        int result = Mercator_2_GeoDecimal((double)xIn, (double)yIn, out xRes, out yRes, ref zIn, ref zOut);
        xOut = (long)Math.Round(xRes);
        yOut = (long)Math.Round(yRes);
        return result;
    }

    public static int Mercator_2_GeoDecimal(double xIn, double yIn, out double xOut, out double yOut, ref int zIn, ref int zOut)
    {
        int result = 0;
        double xArg = xIn, yArg = yIn;

        {
            double lambda, phi;
            lambda = (180 / Math.PI) * (xArg / 6371000.0 + 0.0);
            phi = (180 / Math.PI) * (Math.Atan(Math.Exp(yArg / 6371000.0)) - (Math.PI / 4)) / 0.5;
            xArg = lambda;
            yArg = phi;
        }
        {
            xArg = xArg * 100000;
            yArg = yArg * 100000;
        }

        xOut = xArg;
        yOut = yArg;
        return result;
    }

    public static int Mercator_2_GeoMinSec(long xIn, long yIn, out long xOut, out long yOut)
    {
        int zIn = 0, zOut = 0;
        double xRes, yRes;
        int result = Mercator_2_GeoMinSec((double)xIn, (double)yIn, out xRes, out yRes, ref zIn, ref zOut);
        xOut = (long)Math.Round(xRes);
        yOut = (long)Math.Round(yRes);
        return result;
    }

    public static int Mercator_2_GeoMinSec(long xIn, long yIn, out long xOut, out long yOut, ref int zIn, ref int zOut)
    {
        double xRes, yRes;
        int result = Mercator_2_GeoMinSec((double)xIn, (double)yIn, out xRes, out yRes, ref zIn, ref zOut);
        xOut = (long)Math.Round(xRes);
        yOut = (long)Math.Round(yRes);
        return result;
    }

    public static int Mercator_2_GeoMinSec(double xIn, double yIn, out double xOut, out double yOut, ref int zIn, ref int zOut)
    {
        int result = 0;
        double xArg = xIn, yArg = yIn;

        {
            double lambda, phi;
            lambda = (180 / Math.PI) * (xArg / 6371000.0 + 0.0);
            phi = (180 / Math.PI) * (Math.Atan(Math.Exp(yArg / 6371000.0)) - (Math.PI / 4)) / 0.5;
            xArg = lambda;
            yArg = phi;
        }
        {
            xArg = xArg * 100000;
            yArg = yArg * 100000;
        }

        {
            double deg, min, sec, tmp;
            int vz;
            if (xArg >= 0)
            {
                vz = 1;
            }
            else
            {
                vz = -1;
                xArg = -xArg;
            }
            deg = (double)(int)(xArg / 100000);
            min = ((xArg / 100000) - deg) * 60;
            tmp = (double)(int)min;
            sec = (min - tmp) * 600;
            min = tmp;
            xArg = (deg * 100000 + min * 1000 + sec) * vz;
        }
        {
            double deg, min, sec, tmp;
            int vz;
            if (yArg >= 0)
            {
                vz = 1;
            }
            else
            {
                vz = -1;
                yArg = -yArg;
            }
            deg = (double)(int)(yArg / 100000);
            min = ((yArg / 100000) - deg) * 60;
            tmp = (double)(int)min;
            sec = (min - tmp) * 600;
            min = tmp;
            yArg = (deg * 100000 + min * 1000 + sec) * vz;
        }
        xOut = xArg;
        yOut = yArg;
        return result;
    }


    /* Conversion from GeoDecimal (WGS84) to ... */

    public static int GeoDecimal_2_Mercator(long xIn, long yIn, out long xOut, out long yOut)
    {
        int zIn = 0, zOut = 0;
        double xRes, yRes;
        int result = GeoDecimal_2_Mercator((double)xIn, (double)yIn, out xRes, out yRes, ref zIn, ref zOut);
        xOut = (long)Math.Round(xRes);
        yOut = (long)Math.Round(yRes);
        return result;
    }

    public static int GeoDecimal_2_Mercator(long xIn, long yIn, out long xOut, out long yOut, ref int zIn, ref int zOut)
    {
        double xRes, yRes;
        int result = GeoDecimal_2_Mercator((double)xIn, (double)yIn, out xRes, out yRes, ref zIn, ref zOut);
        xOut = (long)Math.Round(xRes);
        yOut = (long)Math.Round(yRes);
        return result;
    }

    public static int GeoDecimal_2_Mercator(double xIn, double yIn, out double xOut, out double yOut, ref int zIn, ref int zOut)
    {
        int result = 0;
        double xArg = xIn, yArg = yIn;

        {
            xArg = xArg / 100000;
            yArg = yArg / 100000;
        }
        {
            double lambda, phi;
            lambda = xArg;
            phi = yArg;
            xArg = 6371000.0 * ((Math.PI / 180) * ((lambda) - 0.0));
            yArg = 6371000.0 * Math.Log(Math.Tan((Math.PI / 4) + (Math.PI / 180) * phi * 0.5));
        }

        xOut = xArg;
        yOut = yArg;
        return result;
    }

    public static int GeoDecimal_2_GeoMinSec(long xIn, long yIn, out long xOut, out long yOut)
    {
        int zIn = 0, zOut = 0;
        double xRes, yRes;
        int result = GeoDecimal_2_GeoMinSec((double)xIn, (double)yIn, out xRes, out yRes, ref zIn, ref zOut);
        xOut = (long)Math.Round(xRes);
        yOut = (long)Math.Round(yRes);
        return result;
    }

    public static int GeoDecimal_2_GeoMinSec(long xIn, long yIn, out long xOut, out long yOut, ref int zIn, ref int zOut)
    {
        double xRes, yRes;
        int result = GeoDecimal_2_GeoMinSec((double)xIn, (double)yIn, out xRes, out yRes, ref zIn, ref zOut);
        xOut = (long)Math.Round(xRes);
        yOut = (long)Math.Round(yRes);
        return result;
    }

    public static int GeoDecimal_2_GeoMinSec(double xIn, double yIn, out double xOut, out double yOut, ref int zIn, ref int zOut)
    {
        int result = 0;
        double xArg = xIn, yArg = yIn;
        {
            double deg, min, sec, tmp;
            int vz;
            if (xArg >= 0)
            {
                vz = 1;
            }
            else
            {
                vz = -1;
                xArg = -xArg;
            }
            deg = (double)(int)(xArg / 100000);
            min = ((xArg / 100000) - deg) * 60;
            tmp = (double)(int)min;
            sec = (min - tmp) * 600;
            min = tmp;
            xArg = (deg * 100000 + min * 1000 + sec) * vz;
        }
        {
            double deg, min, sec, tmp;
            int vz;
            if (yArg >= 0)
            {
                vz = 1;
            }
            else
            {
                vz = -1;
                yArg = -yArg;
            }
            deg = (double)(int)(yArg / 100000);
            min = ((yArg / 100000) - deg) * 60;
            tmp = (double)(int)min;
            sec = (min - tmp) * 600;
            min = tmp;
            yArg = (deg * 100000 + min * 1000 + sec) * vz;
        }
        xOut = xArg;
        yOut = yArg;
        return result;
    }


    /* Conversion from GeoMinSec to ... */

    public static int GeoMinSec_2_Mercator(long xIn, long yIn, out long xOut, out long yOut)
    {
        int zIn = 0, zOut = 0;
        double xRes, yRes;
        int result = GeoMinSec_2_Mercator((double)xIn, (double)yIn, out xRes, out yRes, ref zIn, ref zOut);
        xOut = (long)Math.Round(xRes);
        yOut = (long)Math.Round(yRes);
        return result;
    }

    public static int GeoMinSec_2_Mercator(long xIn, long yIn, out long xOut, out long yOut, ref int zIn, ref int zOut)
    {
        double xRes, yRes;
        int result = GeoMinSec_2_Mercator((double)xIn, (double)yIn, out xRes, out yRes, ref zIn, ref zOut);
        xOut = (long)Math.Round(xRes);
        yOut = (long)Math.Round(yRes);
        return result;
    }

    public static int GeoMinSec_2_Mercator(double xIn, double yIn, out double xOut, out double yOut, ref int zIn, ref int zOut)
    {
        int result = 0;
        double xArg = xIn, yArg = yIn;
        {
            double deg, min, sec, tmp;
            int vz;
            if (xArg >= 0)
            {
                vz = 1;
            }
            else
            {
                vz = -1;
                xArg = -xArg;
            }
            deg = (double)(int)(xArg / 100000);
            min = ((xArg / 100000) - deg) * 100;
            tmp = (double)(int)min;
            sec = (min - tmp) * 100;
            min = tmp;
            xArg = (deg * 100000 + (min * 60 + sec) / 0.036) * vz;
        }
        {
            double deg, min, sec, tmp;
            int vz;
            if (yArg >= 0)
            {
                vz = 1;
            }
            else
            {
                vz = -1;
                yArg = -yArg;
            }
            deg = (double)(int)(yArg / 100000);
            min = ((yArg / 100000) - deg) * 100;
            tmp = (double)(int)min;
            sec = (min - tmp) * 100;
            min = tmp;
            yArg = (deg * 100000 + (min * 60 + sec) / 0.036) * vz;
        }

        {
            xArg = xArg / 100000;
            yArg = yArg / 100000;
        }
        {
            double lambda, phi;
            lambda = xArg;
            phi = yArg;
            xArg = 6371000.0 * ((Math.PI / 180) * ((lambda) - 0.0));
            yArg = 6371000.0 * Math.Log(Math.Tan((Math.PI / 4) + (Math.PI / 180) * phi * 0.5));
        }

        xOut = xArg;
        yOut = yArg;
        return result;
    }

    public static int GeoMinSec_2_GeoDecimal(long xIn, long yIn, out long xOut, out long yOut)
    {
        int zIn = 0, zOut = 0;
        double xRes, yRes;
        int result = GeoMinSec_2_GeoDecimal((double)xIn, (double)yIn, out xRes, out yRes, ref zIn, ref zOut);
        xOut = (long)Math.Round(xRes);
        yOut = (long)Math.Round(yRes);
        return result;
    }

    public static int GeoMinSec_2_GeoDecimal(long xIn, long yIn, out long xOut, out long yOut, ref int zIn, ref int zOut)
    {
        double xRes, yRes;
        int result = GeoMinSec_2_GeoDecimal((double)xIn, (double)yIn, out xRes, out yRes, ref zIn, ref zOut);
        xOut = (long)Math.Round(xRes);
        yOut = (long)Math.Round(yRes);
        return result;
    }

    public static int GeoMinSec_2_GeoDecimal(double xIn, double yIn, out double xOut, out double yOut, ref int zIn, ref int zOut)
    {
        int result = 0;
        double xArg = xIn, yArg = yIn;
        {
            double deg, min, sec, tmp;
            int vz;
            if (xArg >= 0)
            {
                vz = 1;
            }
            else
            {
                vz = -1;
                xArg = -xArg;
            }
            deg = (double)(int)(xArg / 100000);
            min = ((xArg / 100000) - deg) * 100;
            tmp = (double)(int)min;
            sec = (min - tmp) * 100;
            min = tmp;
            xArg = (deg * 100000 + (min * 60 + sec) / 0.036) * vz;
        }
        {
            double deg, min, sec, tmp;
            int vz;
            if (yArg >= 0)
            {
                vz = 1;
            }
            else
            {
                vz = -1;
                yArg = -yArg;
            }
            deg = (double)(int)(yArg / 100000);
            min = ((yArg / 100000) - deg) * 100;
            tmp = (double)(int)min;
            sec = (min - tmp) * 100;
            min = tmp;
            yArg = (deg * 100000 + (min * 60 + sec) / 0.036) * vz;
        }
        xOut = xArg;
        yOut = yArg;
        return result;
    }


    /* Wrapping the coordinates transformation */

    /*
    // List of functions
    */
    private static ArrayList m_listTransformation = new ArrayList();

    /*
    // Number of the different coordinate formats
    */
    private static int m_nStep;

    /*
    // Constructor
    */
    static Transformation()
    {
        m_nStep = (int)(CoordinateTypeEnum)Enum.GetValues(typeof(CoordinateTypeEnum)).GetValue(Enum.GetValues(typeof(CoordinateTypeEnum)).Length - 1) + 1;

        // Mercator
        m_listTransformation.Add(new TransformationDelegate(Dummy));
        m_listTransformation.Add(new TransformationDelegate(Mercator_2_GeoDecimal));
        m_listTransformation.Add(new TransformationDelegate(Mercator_2_GeoMinSec));

        // GeoDecimal_WGS84
        m_listTransformation.Add(new TransformationDelegate(GeoDecimal_2_Mercator));
        m_listTransformation.Add(new TransformationDelegate(Dummy));
        m_listTransformation.Add(new TransformationDelegate(GeoDecimal_2_GeoMinSec));

        // GeoMinSec
        m_listTransformation.Add(new TransformationDelegate(GeoMinSec_2_Mercator));
        m_listTransformation.Add(new TransformationDelegate(GeoMinSec_2_GeoDecimal));
        m_listTransformation.Add(new TransformationDelegate(Dummy));

    }

    public static int Dummy(long xIn, long yIn, out long xOut, out long yOut, ref int zIn, ref int zOut) { xOut = xIn; yOut = yIn; return 0; }

    private delegate int TransformationDelegate(long xIn, long yIn, out long xOut, out long yOut, ref int zIn, ref int zOut);

    public static int Transform(CoordinateTypeEnum nTypeIn, CoordinateTypeEnum nTypeOut, long xIn, long yIn, out long xOut, out long yOut, ref int zIn, ref int zOut)
    {
        xOut = 0;
        yOut = 0;

        int result = 0;
        int nIndex = (int)nTypeOut + m_nStep * (int)nTypeIn;
        if (nIndex < m_listTransformation.Count)
        {
            result = ((TransformationDelegate)m_listTransformation[nIndex])(xIn, yIn, out xOut, out yOut, ref zIn, ref zOut);
        }
        return result;
    }
}