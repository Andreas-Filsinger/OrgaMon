using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;

public partial class xMap_LinesInMap_ThicknessAndColours : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		// Set a BoundingBox for rendering...
		BoundingBox boundingBox = new BoundingBox();
		boundingBox.leftTop = new Point();
		boundingBox.leftTop.point = new PlainPoint();
		boundingBox.leftTop.point.x = 667734.27959999815;	// left top coordinates of the visible section
		boundingBox.leftTop.point.y = 6381904.0403000042;	// you can see in the xMap_SimpleMapping.aspx.cs
		boundingBox.rightBottom = new Point();
		boundingBox.rightBottom.point = new PlainPoint();
		boundingBox.rightBottom.point.x = 694667.72039999813;	// right bottom coordinates of the visible section
		boundingBox.rightBottom.point.y = 6361703.9597000033;	// you can see in the xMap_SimpleMapping.aspx.cs

		// set the ImageInfos such as FileFormat, Width and Height...
		ImageInfo imageInfo = new ImageInfo();
		imageInfo.format = ImageFileFormat.GIF;
		imageInfo.height = Convert.ToInt32(pbMap.Height.Value);
		imageInfo.width = Convert.ToInt32(pbMap.Width.Value);

		// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		// >>>
		// >>>
		// 
		// First of all we need an array of PlainPoint[]
		// as big as the number of base points the line has got...
		PlainPoint[] plainPoint = new PlainPoint[4];
		plainPoint[0] = new PlainPoint();
		plainPoint[0].x = 677691.0;
		plainPoint[0].y = 6371723.0;
		plainPoint[1] = new PlainPoint();
		plainPoint[1].x = 686966.0;
		plainPoint[1].y = 6373784.0;
		plainPoint[2] = new PlainPoint();
		plainPoint[2].x = 687664.0;
		plainPoint[2].y = 6372354.0;
		plainPoint[3] = new PlainPoint();
		plainPoint[3].x = 679765.0;
		plainPoint[3].y = 6366289.0;

		// Second we need a PlainLineString where we put the PlainPoint array to the wrappedPoints property
		PlainLineString plainLineString = new PlainLineString();
		plainLineString.wrappedPoints = plainPoint;

		// Third we need an array of LineString[] where we put our PlainLineString into
		LineString[] lineString = new LineString[1];
		lineString[0] = new LineString();
		lineString[0].lineString = plainLineString;

		// Fourth we need an array of Lines[] where we put all our Lines into, in this case just the single one.
		Lines[] lines = new Lines[1];
		lines[0] = new Lines();
		lines[0].wrappedLines = lineString;
		// The appearance of the line can be set at the Lines objects:
		lines[0].options = new LineOptions();
		lines[0].options.mainLine = new LinePartOptions();
		lines[0].options.mainLine.visible = true;
		lines[0].options.mainLine.width = 7;
		lines[0].options.mainLine.color = new Color();
		Color color = new Color();
		color.blue = 255; color.green = 50; color.red = 20;
		lines[0].options.mainLine.color = color;
		lines[0].options.transparent = true;
				
		// Fifth we add the line to the CustomLayer that we need for drawing lines
		CustomLayer customLayer = new CustomLayer();
		// customLayer.centerObjects = true;
		customLayer.visible = true;				// you have to make your layer visible
		// The priority of the custom Layer you want to draw has to be specified.
		// The xMap Documentation says that you have to take a value of the
		//     DrawPriority enum
		// but this enum does not exist here. Therefore you have to look
		// at the Diagrams -> Enumerations -> enum:DrawPriorities,
		// fetch the integer value you want to use and set it at the .drawPriority property.
		// !!! Please note that you have to use a value between PRIORMIN and PRIORMAX !!!
		customLayer.drawPriority = 25000;	// this is PRIORMAX
		customLayer.wrappedLines = lines;
		
		// create an array of Layer and fill it with the customLayer
		Layer[] layer = new Layer[]{customLayer};
		//
		// <<<
		// <<<
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


		// Create a new Client for xMap Service and call the server
		XMapWSService xMapClient = new XMapWSService();
		Map map = xMapClient.renderMapBoundingBox(boundingBox, null, imageInfo, layer, false, null);
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// the delivery by URL has to be configured properly
		// within the xMap Server config-files:
		//	xmap.properties
		//		imageMapServer.remotePath=C:/mgtmp
		//		imageMapServer.remoteURL=localhost/mgtmp
		pbMap.ImageUrl = "http://" + map.image.url;
    }
}
