using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;

public partial class xRoute_AvoidCountries : System.Web.UI.Page {

    protected void Page_Load(object sender, EventArgs e) {
        // define the waypoints of the route
        WaypointDesc wpdStart = _createWaypoint(524730.47, 6397686.86);
        WaypointDesc wpdDest = _createWaypoint(737927.84, 6397192.86);
        WaypointDesc[] waypoints = new WaypointDesc[] { wpdStart, wpdDest };

        // set some result list options to make xRoute return a route
        // with textual information ( required for displayRouteInTable(...) )
        ResultListOptions resultListOptions = new ResultListOptions();
        resultListOptions.manoeuvres = true;
        resultListOptions.texts = true;
        resultListOptions.segments = true;
        resultListOptions.detailLevel = DetailLevel.STANDARD;

        // ============================================================================
        // Note: the default route starts in France (33), 
        // and leads thru Belgium (32) and Luxemburg (52) to Germany (49)
        
        RoutingOption[] routingOptions = new RoutingOption[] { new RoutingOption() };
        if (radioButtonList.SelectedValue == "EXCLUDE_COUNTRIES") {
            // exclude Luxemburg from the route
            routingOptions[0].parameter = RoutingParameter.EXCLUDE_COUNTRIES;
            routingOptions[0].value = "52";
        }else if (radioButtonList.SelectedValue == "ROUTING_COUNTRIES") {
            // ... or limit the route to Germany & France
            routingOptions[0].parameter = RoutingParameter.ROUTING_COUNTRIES;
            routingOptions[0].value = "49,33";
        }else {
            routingOptions = null;
        }
        // ============================================================================

        XRouteWSService xRoute = new XRouteWSService();
        Route route = xRoute.calculateRoute(waypoints, routingOptions, null, resultListOptions, null);
        // display route in table
        displayRouteInTable(route, this.table);
    }


    /// <summary>
    /// Formats some information of a given route in a table. 
    /// </summary>
    /// <param name="route">The route.</param>
    /// <param name="table">The table.</param>
    private void displayRouteInTable(Route route, Table table) {
        foreach (RouteManoeuvre manoeuvre in route.wrappedManoeuvres) {
            RouteListSegment segment = route.wrappedSegments[manoeuvre.routeListSegmentIdx];
            string streetName = (segment.streetNameIdx >= 0 ? route.wrappedTexts[segment.streetNameIdx] : "");

            System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();
            img.ImageUrl = _imageUrlForIuCode(segment.iuCode);

            Control[] cellControls = new Control[] {
                img,
                new LiteralControl(""+segment.iuCode),
                new LiteralControl(manoeuvre.manoeuvreDesc),
                new LiteralControl(streetName)
            };

            TableRow row = new TableRow();
            foreach (Control c in cellControls) {
                TableCell cell = new TableCell();
                cell.Controls.Add(c);
                row.Cells.Add(cell);
            }
            table.Rows.Add(row);
        }
    }


    /// <summary>
    /// Convinience method to create a waypoint.
    /// </summary>
    /// <param name="x">The point's x value</param>
    /// <param name="y">The point's y value</param>
    /// <returns></returns>
    private static WaypointDesc _createWaypoint(double x, double y) {
        WaypointDesc waypoint = new WaypointDesc();
        waypoint.wrappedCoords = new Point[] { new Point() };
        waypoint.wrappedCoords[0].point = new PlainPoint();
        waypoint.wrappedCoords[0].point.x = x;
        waypoint.wrappedCoords[0].point.y = y;
        return waypoint;
    }

    /// <summary>
    /// Returns an country flag image encoded as data:-URL for a given IU code.
    /// </summary>
    /// <param name="iuCode">The countries IU code.</param>
    /// <returns></returns>
    private static string _imageUrlForIuCode(int iuCode) {
        switch (iuCode) {
            case 32: // Belgium
                return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAFTSURBVHjaYmRABR/fM/D8AjH+/WP4J8Dw7xPDP3GGfwwIBBBALEC56upqsAoQ4OD6y8D3l4HhD+P/P8wMf5h4f/+P+fP/9+//f0Dkl02bAAKIBWzu/ydPnv4Fg3//fjMw/P3//zcU/f39//av/79+AVUzysoCbQAIIBaw2f+BSv8AEdCk/0DVv/7//wPW8AuEfv2GaGD4/RuoASCAQBpAqiHg9x+E2dg0ABUDBBBIw58/f3///o2k4RdCwz+waoiGP3+ANgAEEMQGkOJfv3+haoCRMBsYwU4CCCCQBqDxv379Alnw6xe6Df9/w40HBtQTBgaAAII4CehbKIC6G66aFazhD1DDX5BLGBgAAghiwx9JSUmwN/4yMgJ99htMAmWBHv3DoPQHqBSCgE4CCCBGtJi+fZfhFwsD0Hf//jAIcTD8e8fwQh8kDtTNxsBwh4EBIMAAr1pl7/uLhvQAAAAASUVORK5CYII=";
            case 33: // France
                return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAGzSURBVHjaYiyeepkBBv79+Zfnx/f379+fP38CyT9//jAyMiq5GP77wvDnJ8MfoAIGBoAAYgGqC7STApL///3/9++/pCTv////Qdz/QO4/IMna0vf/z+9/v379//37bUUTQACBNDD8Z/j87fffvyAVX79+/Q8GQDbQeKA9fM+e/Pv18/+vnwzCIkBLAAKQOAY5AIAwCEv4/4PddNUm3ji0QJyxW3rgzE0iLfqDGr2oYuu0l54AYvnz5x9Q6d+/QPQfyAQqAin9B3EOyG1A1UDj//36zfjr1y8GBoAAFI9BDgAwCMIw+P8Ho3GDO6XQ0l4MN8b2kUwYaLszqgKM/KHcDXwBxAJUD3TJ779A8h9Q5D8SAHoARP36+Rfo41+/mcA2AAQQy49ff0Cu//MPpAeI/0FdA1QNYYNVA/3wmwEYVgwMAAHE8uPHH5BqoD1//gJJLADoJKDS378Z//wFhhJAALF8A3rizz8uTmYg788fJkj4QOKREQyYxSWBhjEC/fcXZANAALF8+/anbcHlHz9+ffvx58uPX9KckkCn/gby/wLd8uvHjx96k+cD1UGiGQgAAgwA7q17ZpsMdUQAAAAASUVORK5CYII=";
            case 49: // Germany
                return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAGzSURBVHjaYvTxcWb4+53h3z8GZpZff/79+v3n/7/fDAz/GHAAgABi+f37e3FxOZD1Dwz+/v3z9y+E/AMFv3//+Qumfv9et241QACxMDExAVWfOHkJJAEW/gUEP0EQDn78+AHE/gFOQJUAAcQiy8Ag8O+fLFj1n1+/QDp+/gQioK7fP378+vkDqOH39x9A/RJ/gE5lAAhAYhzcAACCQBDkgRXRjP034R0IaDTZTFZn0DItot37S94KLOINerEcI7aKHAHE8v/3r/9//zIA1f36/R+o4tevf1ANYNVA9P07RD9IJQMDQACxADHD3z8Ig4GMHz+AqqHagKp//fwLVA0U//v7LwMDQACx/LZiYFD7/5/53/+///79BqK/EMZ/UPACSYa/v/8DyX9A0oTxx2EGgABi+a/H8F/m339BoCoQ+g8kgRaCQvgPJJiBYmAuw39hxn+uDAABxMLwi+E/0PusRkwMvxhBGoDkH4b/v/+D2EDyz///QB1/QLb8+sP0lQEggFh+vGXYM2/SP6A2Zoaf30Ex/J+PgekHwz9gQDAz/P0FYrAyMfz7wcDAzPDtFwNAgAEAd3SIyRitX1gAAAAASUVORK5CYII=";
            case 52: // Luxemburg
                return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAFzSURBVHjaYvxvrsvw6QMDGPz794/h1x+GPz+A5L9fv/79+v3vF8O/3wz/GBAIIIBYGD68YahsAqr+/+8f4/9/DH/+/geSf/8y/v3H/Pcv05/f///+BSEw40tTJ0AAsTD8+MXw+9f/168Y/v1l+Pvv/58/DH//gFWAFf3+AyJBjN+M4hJAGwACiIXBL+S/kiqDiBhI9X+wHpCREBKs8x9QJ4jBwM//T14cIIAY3759KygoCHLS//8MYIgLMDIyvn79GiCAWCDehQjBGVgBAyMjMFQAAogFoQi/+UAbgKHx7x9AALGUnOAL0/j/4TvQ2QzAAAI5HuhzIAljQ7wDDHBBzv8VO5kBAohl/pl/ygLMTz7///2XAaju918QAobQ73/gcIIwQIhBjpfh4y4GgAACOukfEwOTNDfDn/9AaQaQPf8Yfv9jhDD+/IOIMIJiBxSo/wACiJGx9ev/L2CZX2D0hwFMgtn//kHZ/yAkAwMHA0CAAQDhxHlrsArfvwAAAABJRU5ErkJggg==";
            default:
                throw new NotImplementedException("The function _imageUrlForIuCode wasn't implemented for the parameter: "+iuCode); 
        }
    }
}