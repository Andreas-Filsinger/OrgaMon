using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using xserver;

public partial class xRoute_CalculateIsochrones : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        XRouteWSService xRouteClient = new XRouteWSService();

        WaypointDesc location = new WaypointDesc();
        location.wrappedCoords = new Point[] { new Point() };
        location.wrappedCoords[0].wkt = "POINT(930621 6271594)";

        IsochroneOptions isochroneOptions = new IsochroneOptions();
        isochroneOptions.expansionDesc = new ExpansionDescription();
        isochroneOptions.expansionDesc.expansionType = ExpansionType.EXP_TIME;
        isochroneOptions.expansionDesc.wrappedHorizons = new int[] { 600, 1200, 1800 };

        Isochrone isochrone = xRouteClient.calculateIsochrones(location, null, isochroneOptions, null);

        Map map = mapIsochrone(isochrone);

        mapImage.ImageUrl = "http://" + map.image.url;
    }


    /// <summary>
    /// Maps the isochrone(s) as polygons with xMap and GeometryLayers
    /// </summary>
    /// <param name="isochrone">The isochrone.</param>
    /// <returns>a map</returns>
    private Map mapIsochrone(Isochrone isochrone) {
        XMapWSService xMapClient = new XMapWSService();
        xMapClient.Url = "http://mg-fr-w4:50010/xmap/ws/XMap";
        xMapClient.Proxy = new System.Net.WebProxy("localhost:8888", false);


        int numberOfIsochrones = isochrone.wrappedIsochrones.Length;

        Geometries[] arrayOfGeometries = new Geometries[numberOfIsochrones];

        // create a Polygon geometry from each isochrone
        for (int i = 0; i < numberOfIsochrones; i++) {
            Geometry geometry = new Geometry();
            geometry.geometry = LineStringToPolygon(isochrone.wrappedIsochrones[i].polys);
            geometry.id = i;
            geometry.description = "";
            geometry.referencePoint = new Point();
            geometry.referencePoint.point =
                isochrone.wrappedIsochrones[i].polys.lineString.wrappedPoints[0];

            GeometryOption autoCenter = new GeometryOption();
            autoCenter.option = GeometryOptions.AUTOCENTEROBJECTS;
            autoCenter.value = "1";

            // color isochrones in shades of red
            GeometryOption fillColor = new GeometryOption();
            fillColor.option = GeometryOptions.FILLCOLOR;
            fillColor.value = 200-Math.Round(255 * ((double)i / numberOfIsochrones)) + "";

            GeometryOption noStroke = new GeometryOption();
            noStroke.option = GeometryOptions.BORDERWIDTH;
            noStroke.value  = "0";
            

            arrayOfGeometries[i] = new Geometries();
            arrayOfGeometries[i].wrappedGeometries = new Geometry[] { geometry };
            arrayOfGeometries[i].wrappedOptions = new GeometryOption[] { autoCenter, fillColor, noStroke };

        }
        
        GeometryLayer geometryLayer = new GeometryLayer();
        geometryLayer.name = "GeometryLayer";
        geometryLayer.drawPriority = 200;
        geometryLayer.objectInfos = ObjectInfoType.NONE;
        geometryLayer.visible = true;
        geometryLayer.wrappedGeometries = arrayOfGeometries;
        

        ImageInfo imageInfo = new ImageInfo();
        imageInfo.format = ImageFileFormat.PNG;
        imageInfo.height = 480;
        imageInfo.width = 640;

        MapSection mapSection = new MapSection();
        // MapSection can be empty since we set AUTOCENTEROBJECTS=true earlier
        
        MapParams mapParams = new MapParams();
        mapParams.showScale = true;
        mapParams.useMiles = false;
        return xMapClient.renderMap(mapSection, mapParams, imageInfo, new Layer[] { geometryLayer }, false, null);
    }


    /// <summary>
    /// Creates a Polygon from a LineString
    /// </summary>
    /// <param name="lineString">a line string.</param>
    /// <returns></returns>
    private Polygon LineStringToPolygon(LineString lineString) {
        PlainLinearRing ring = new PlainLinearRing();
        ring.wrappedPoints = lineString.lineString.wrappedPoints;
        
        Polygon poly = new Polygon();
        poly.polygon = new PlainPolygon();
        poly.polygon.wrappedLinearRings = new PlainLinearRing[] { ring };

        return poly;
    }
}

