using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;

public partial class xMap_SimpleMapping_BoundingBox : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		// Set a BoundingBox for rendering...
		// BoundingBox completely defines the visible section of the map that will be created.
		// please note that the aspect ration of your bounding box should
		// correspond to the width and the height of your image.
		BoundingBox boundingBox = new BoundingBox();
		boundingBox.leftTop = new Point();
		boundingBox.leftTop.point = new PlainPoint();
		boundingBox.leftTop.point.x = 667734.27959999815;	// left top coordinates of the visible section
		boundingBox.leftTop.point.y = 6381904.0403000042;	// you can see in the xMap_SimpleMapping.aspx.cs
		boundingBox.rightBottom = new Point();
		boundingBox.rightBottom.point = new PlainPoint();
		boundingBox.rightBottom.point.x = 694667.72039999813;	// right bottom coordinates of the visible section
		boundingBox.rightBottom.point.y = 6361703.9597000033;	// you can see in the xMap_SimpleMapping.aspx.cs

		// set the ImageInfos such as FileFormat, Width and Height...
		ImageInfo imageInfo = new ImageInfo();
		imageInfo.format = ImageFileFormat.GIF;
		imageInfo.height = Convert.ToInt32(pbMap.Height.Value);
		imageInfo.width = Convert.ToInt32(pbMap.Width.Value);

		// Create a new Client for xMap Service and call the server
		XMapWSService xMapClient = new XMapWSService();
		Map map = xMapClient.renderMapBoundingBox(boundingBox, null, imageInfo, null, false, null);
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// the delivery by URL has to be configured properly
		// within the xMap Server config-files:
		//	xmap.properties
		//		imageMapServer.remotePath=C:/mgtmp
		//		imageMapServer.remoteURL=localhost/mgtmp
		pbMap.ImageUrl = "http://" + map.image.url;
    }
}
