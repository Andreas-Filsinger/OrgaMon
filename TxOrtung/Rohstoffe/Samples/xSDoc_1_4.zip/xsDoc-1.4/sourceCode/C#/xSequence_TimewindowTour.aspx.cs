using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;

public partial class xSequence_TimewindowTour : System.Web.UI.Page {

    /// <summary>
    /// Convenience method to quickly create Intervals
    /// </summary>
    /// <param name="from"></param>
    /// <param name="till"></param>
    /// <returns></returns>
    private Interval1 createInterval(int from, int till) {
        Interval1 interval = new Interval1();
        interval.from = from;
        interval.till = till;

        return interval;
    }

    protected void Page_Load(object sender, EventArgs e) {

        // ----------------------------------------------------
        // 1. Define stops

        double[,] stopCoordinates = new double[,]{
                {843650, 4901137},
                {842164, 4901883},
                {843914, 4900754},
                {841020, 4900941},
                {841050, 4900578},
        };

        string[] stopNames = new string[]{
            "Rintheimer Str.",
            "Klosterweg",
            "K�ppelestrasse",
            "Berliner Platz",
            "R�purrer Str. 1"
        };

        Interval1[][] businessHours = new Interval1[][]{
            new Interval1[]{ createInterval( 8*3600, 18*3600) },  // 8:00 to 18:00
            new Interval1[]{ createInterval( 9*3600, 12*3600), createInterval(14*3600, 18*3600) }, // 9:00 to 12:00 & 14:00 to 18:00
            new Interval1[]{ createInterval(13*3600, 18*3600) }, // 13:00 to 18:00
            new Interval1[]{ createInterval( 8*3600, 18*3600) }, // 13:00 to 18:00
            new Interval1[]{ createInterval( 8*3600, 18*3600) }, // 13:00 to 18:00
        };

        int numberOfStops = stopCoordinates.GetLength(0);

        TimewindowStop[] stops = new TimewindowStop[numberOfStops];

        for (int i = 0; i < numberOfStops; i++) {
            stops[i] = new TimewindowStop();
            stops[i].servicePeriod = 0;
            stops[i].stopID = i + 1;
            stops[i].loc = new Point();
            stops[i].loc.point = new PlainPoint();
            stops[i].loc.point.x = stopCoordinates[i, 0];
            stops[i].loc.point.y = stopCoordinates[i, 1];

            stops[i].wrappedOpeningIntervals = businessHours[i];
        }

        // ----------------------------------------------------
        // 2. set planning params

        // With PlanningParams you can assign costs to distance and time
        // For example, if KM costs you 10 cents and a minute driving 50 cents
        // then you would set the following parameters
        TimewindowPlanningParams planningParams = new TimewindowPlanningParams();
        planningParams.costDistanceKm = 10; 	// costs for one kilometer
        planningParams.costPeriodMinute = 50;   // costs for one minute
        planningParams.maxProcessorPeriod = 5; //secs

        LLInterval[] workTime = new LLInterval[2];

        workTime[0] = new LLInterval();
        workTime[0].from = 8 * 3600;
        workTime[0].till = 12 * 3600;

        workTime[1] = new LLInterval();
        workTime[1].from = 13 * 3600;
        workTime[1].till = 17 * 3600;

        planningParams.wrappedOperatingIntervals = workTime;


        // set CoordFormat to PTV_GEODECIMAL because we used 
        // GEODECIMAL coordinates for the stops 
        CallerContextProperty coordFormat = new CallerContextProperty();
        coordFormat.key = "CoordFormat";
        coordFormat.value = "PTV_GEODECIMAL";

        CallerContext callerContext = new CallerContext();
        callerContext.wrappedProperties = new CallerContextProperty[] { coordFormat };

        XSequenceWSService xSequence = new XSequenceWSService();
        Plan plan = xSequence
            .planTimewindowTour(stops, planningParams, null, callerContext);

        // show planned tour in a table ...
        foreach (OutputTourPoint tourPoint in plan.tour.wrappedOutputTourPoints) {
            appendTableRow(
                tourPoint.stopID.ToString(),
                stopNames[tourPoint.stopID - 1],
                secondsToTimeOfDayString(tourPoint.arrivalTime),
                tourPoint.drivingDistance.ToString()
            );
        }
        // show some totals of the tour
        costLabel.Text = plan.tour.costs.ToString();
        distanceLabel.Text = plan.tour.distance + "m";
        timeLabel.Text = secondsToTimeOfDayString(plan.tour.drivingPeriod);
    }

    private string secondsToTimeOfDayString(int s) {
        int hours = s / 3600;
        int minutes = (s - 3600 * hours) / 60;
        int secs = (s - 3600 * hours) - 60 * minutes;
        return String.Format("{0:0#}:{1:0#}:{2:0#}", hours, minutes, secs);
    }

    private void appendTableRow(params string[] values) {
        TableRow row = new TableRow();
        foreach (string s in values) {
            TableCell cell = new TableCell();
            cell.Controls.Add(new LiteralControl(s));
            row.Cells.Add(cell);
        }
        table.Rows.Add(row);
    }
}
