using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using xserver;

public partial class xLocate_ReverseGeocoding : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		// define the location per coordinates that has to be found
		Location location = new Location();
		location.coordinate = new Point();
		location.coordinate.point = new PlainPoint();
		location.coordinate.point.x = 612820.0;	// coordinates of a street in Luxembourg
		location.coordinate.point.y = 4960959.0;

		// to delimit the number of returned addresses we use the parameter EngineTargetSize
		ReverseSearchOption soEngineTargetSize = new ReverseSearchOption();
		soEngineTargetSize.param = ReverseSearchParameter.ENGINE_TARGETSIZE;
		soEngineTargetSize.value = "1";

		// create a new SearchOptions Array and fill it with the Option.
		SearchOptionBase[] searchOptionBase = new SearchOptionBase[] { soEngineTargetSize };

		// specify the coordinate format as GeoDecimal for GPS positions
		CallerContext xLocateCallerContext = new CallerContext();
		xLocateCallerContext.wrappedProperties = new CallerContextProperty[] { new CallerContextProperty() };
		xLocateCallerContext.wrappedProperties[0].key = "CoordFormat";
		xLocateCallerContext.wrappedProperties[0].value = "PTV_GEODECIMAL"; 
	
		// Create a new Client for xLocate Service and call the server
		XLocateWSService xLocateClient = new XLocateWSService();
		AddressResponse addressResponse = xLocateClient.findLocation(location, searchOptionBase, null, null, xLocateCallerContext);
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// Clear the List Box of existing items
		ListBox1.Items.Clear();

		// For each Result Address in the returned List add it to the List Box
		foreach (ResultAddress resultAddress in addressResponse.wrappedResultList)
		{
			ListBox1.Items.Add(new ListItem(resultAddress.country + " - "
				+ resultAddress.postCode + ", "
				+ resultAddress.city + ", "
				+ resultAddress.city2 + ", "
				+ resultAddress.street + ", "
				+ resultAddress.houseNumber,
				resultAddress.coordinates.point.x + "|" + resultAddress.coordinates.point.y));
		}

		// Bind the Items to the List Box
		ListBox1.DataBind();
    }
}
