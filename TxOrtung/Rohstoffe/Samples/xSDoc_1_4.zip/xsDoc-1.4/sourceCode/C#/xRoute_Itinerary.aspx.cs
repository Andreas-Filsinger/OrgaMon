using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;

using xserver;

public partial class xRoute_Itinerary : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		// create the WayPoint for the Start
		// ATTENTION: Here at the object WaypointDesc the parameters are not named
		// "coords" as described within the documentation but
		// "wrappedCoords"
		WaypointDesc wpdStart = new WaypointDesc();
		// please note that this has to be an array of Point...
		wpdStart.wrappedCoords = new Point[] { new Point() };
		wpdStart.wrappedCoords[0].point = new PlainPoint();
		wpdStart.wrappedCoords[0].point.x = 653413.0;  // x and y coordinates of P�telange, a small village in Luxembourg
		wpdStart.wrappedCoords[0].point.y = 6362650.0;

		// Waypoint for the Destination...
		WaypointDesc wpdDestination = new WaypointDesc();
		wpdDestination.wrappedCoords = new Point[] { new Point() };
		wpdDestination.wrappedCoords[0].point = new PlainPoint();
		wpdDestination.wrappedCoords[0].point.x = 681451.0;  // x and y coordinates of Luxembourg, the capital of Luxembourg in the heart of Europe
		wpdDestination.wrappedCoords[0].point.y = 6371797.0;

		// create a new array of WayPointDescriptions and fill it with Start and Destination
		WaypointDesc[] waypointDesc = new WaypointDesc[] { wpdStart, wpdDestination };

		// Specify the ResultListOptions. They provide the information,
		// e.g. how detailed the itinerary should be.
		ResultListOptions resultListOptions = new ResultListOptions();
		// To create a standard Itinerary you have to enable at least
		// manoeuvres, texts and segments.
		resultListOptions.manoeuvres = true;
		resultListOptions.texts = true;
		resultListOptions.segments = true;
		// also important is to tell the xRoute Server how detailed the itinerary should be
		resultListOptions.detailLevel = DetailLevel.STANDARD;

		// to get the itinerary in english, we have to make use of the RoutingOptions
		RoutingOption[] routingOption = new RoutingOption[1];
		routingOption[0] = new RoutingOption();
		routingOption[0].parameter = RoutingParameter.ROUTE_LANGUAGE;
		routingOption[0].value = "EN";

		// create a new Client for xRoute Service and call the server
		XRouteWSService xRouteClient = new XRouteWSService();
		Route route = xRouteClient.calculateRoute(waypointDesc, routingOption, null, resultListOptions, null);
		// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// create a StringBuilder that contains my ResultTable that represents the Itinerary.
		StringBuilder sb = new StringBuilder();

		// we create a table with the four columns we want to display.
		sb.Append("<table cellpadding=\"2\">");
		sb.Append("<th>km</th><th>min</th><th>ManoeuvreDescription</th><th>StreetName</th>");

		// We iterate through the superior element of the itinerary, the manoeuvres.
		foreach (RouteManoeuvre routeManoeuvre in route.wrappedManoeuvres)
		{
			// for each entry in the itinerary we create an own row.
			sb.Append("<tr>");
			// our first table cell contains the accumulated distance from the start
			sb.Append("<td align=\"right\">" + (Convert.ToDouble(route.wrappedSegments[routeManoeuvre.routeListSegmentIdx].accDist) / 1000).ToString("0.00") + "</td>");
			// our second table cell contains the accumulated time from the start
			sb.Append("<td align=\"right\">" + (Convert.ToDouble(route.wrappedSegments[routeManoeuvre.routeListSegmentIdx].accTime) / 60).ToString("0") + "</td>");
			// our third table cell contains the manoeuvre description
			sb.Append("<td>" + routeManoeuvre.manoeuvreDesc + "</td>");
			// our fourth table cell contains the street where to turn
			// please note that this is only the case if the streetNameIdx is != -1
			// otherwise we have to look in the texts[] array.
			if (route.wrappedSegments[routeManoeuvre.routeListSegmentIdx].streetNameIdx != -1)
				sb.Append("<td>" + route.wrappedTexts[route.wrappedSegments[routeManoeuvre.routeListSegmentIdx].streetNameIdx].ToString() + "</td>");
			// close the row.
			sb.Append("</tr>");
		}
		sb.Append("</table>");

		// pass the created table to the litaral.		
		ltItinerary.Text = sb.ToString();
    }
}
