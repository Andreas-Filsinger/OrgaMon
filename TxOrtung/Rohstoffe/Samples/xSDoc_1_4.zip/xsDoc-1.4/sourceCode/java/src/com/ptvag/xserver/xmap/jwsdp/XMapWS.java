/**
 * XMapWS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap.jwsdp;

public interface XMapWS extends java.rmi.Remote {
    public com.ptvag.xserver.xmap.Map renderMap(com.ptvag.xserver.xmap.MapSection mapSection_1, com.ptvag.xserver.xmap.MapParams mapParams_2, com.ptvag.xserver.xmap.ImageInfo imageInfo_3, com.ptvag.xserver.xmap.Layer[] arrayOfLayer_4, boolean boolean_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xmap.XMapException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException;
    public com.ptvag.xserver.xmap.Map renderMapBoundingBox(com.ptvag.xserver.common.BoundingBox boundingBox_1, com.ptvag.xserver.xmap.MapParams mapParams_2, com.ptvag.xserver.xmap.ImageInfo imageInfo_3, com.ptvag.xserver.xmap.Layer[] arrayOfLayer_4, boolean boolean_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xmap.XMapException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException;
    public com.ptvag.xserver.xmap.Map renderMapRot(com.ptvag.xserver.xmap.MapSectionRot mapSectionRot_1, com.ptvag.xserver.xmap.MapParams mapParams_2, com.ptvag.xserver.xmap.ImageInfo imageInfo_3, com.ptvag.xserver.xmap.Layer[] arrayOfLayer_4, boolean boolean_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xmap.XMapException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException;
}
