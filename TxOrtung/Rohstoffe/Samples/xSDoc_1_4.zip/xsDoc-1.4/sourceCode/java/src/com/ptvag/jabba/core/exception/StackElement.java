/**
 * StackElement.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.jabba.core.exception;

public class StackElement  implements java.io.Serializable {
    private com.ptvag.jabba.core.exception.StackElement cause;

    private java.lang.String[] wrappedContext;

    private java.lang.String className;  // attribute

    private java.lang.String errorKey;  // attribute

    private java.lang.String message;  // attribute

    public StackElement() {
    }

    public StackElement(
           com.ptvag.jabba.core.exception.StackElement cause,
           java.lang.String[] wrappedContext,
           java.lang.String className,
           java.lang.String errorKey,
           java.lang.String message) {
           this.cause = cause;
           this.wrappedContext = wrappedContext;
           this.className = className;
           this.errorKey = errorKey;
           this.message = message;
    }


    /**
     * Gets the cause value for this StackElement.
     * 
     * @return cause
     */
    public com.ptvag.jabba.core.exception.StackElement getCause() {
        return cause;
    }


    /**
     * Sets the cause value for this StackElement.
     * 
     * @param cause
     */
    public void setCause(com.ptvag.jabba.core.exception.StackElement cause) {
        this.cause = cause;
    }


    /**
     * Gets the wrappedContext value for this StackElement.
     * 
     * @return wrappedContext
     */
    public java.lang.String[] getWrappedContext() {
        return wrappedContext;
    }


    /**
     * Sets the wrappedContext value for this StackElement.
     * 
     * @param wrappedContext
     */
    public void setWrappedContext(java.lang.String[] wrappedContext) {
        this.wrappedContext = wrappedContext;
    }


    /**
     * Gets the className value for this StackElement.
     * 
     * @return className
     */
    public java.lang.String getClassName() {
        return className;
    }


    /**
     * Sets the className value for this StackElement.
     * 
     * @param className
     */
    public void setClassName(java.lang.String className) {
        this.className = className;
    }


    /**
     * Gets the errorKey value for this StackElement.
     * 
     * @return errorKey
     */
    public java.lang.String getErrorKey() {
        return errorKey;
    }


    /**
     * Sets the errorKey value for this StackElement.
     * 
     * @param errorKey
     */
    public void setErrorKey(java.lang.String errorKey) {
        this.errorKey = errorKey;
    }


    /**
     * Gets the message value for this StackElement.
     * 
     * @return message
     */
    public java.lang.String getMessage() {
        return message;
    }


    /**
     * Sets the message value for this StackElement.
     * 
     * @param message
     */
    public void setMessage(java.lang.String message) {
        this.message = message;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof StackElement)) return false;
        StackElement other = (StackElement) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cause==null && other.getCause()==null) || 
             (this.cause!=null &&
              this.cause.equals(other.getCause()))) &&
            ((this.wrappedContext==null && other.getWrappedContext()==null) || 
             (this.wrappedContext!=null &&
              java.util.Arrays.equals(this.wrappedContext, other.getWrappedContext()))) &&
            ((this.className==null && other.getClassName()==null) || 
             (this.className!=null &&
              this.className.equals(other.getClassName()))) &&
            ((this.errorKey==null && other.getErrorKey()==null) || 
             (this.errorKey!=null &&
              this.errorKey.equals(other.getErrorKey()))) &&
            ((this.message==null && other.getMessage()==null) || 
             (this.message!=null &&
              this.message.equals(other.getMessage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCause() != null) {
            _hashCode += getCause().hashCode();
        }
        if (getWrappedContext() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedContext());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedContext(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getClassName() != null) {
            _hashCode += getClassName().hashCode();
        }
        if (getErrorKey() != null) {
            _hashCode += getErrorKey().hashCode();
        }
        if (getMessage() != null) {
            _hashCode += getMessage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(StackElement.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "StackElement"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("className");
        attrField.setXmlName(new javax.xml.namespace.QName("", "className"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("errorKey");
        attrField.setXmlName(new javax.xml.namespace.QName("", "errorKey"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("message");
        attrField.setXmlName(new javax.xml.namespace.QName("", "message"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cause");
        elemField.setXmlName(new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "cause"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "StackElement"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedContext");
        elemField.setXmlName(new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "wrappedContext"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "String"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
