/**
 * Stop.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class Stop  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.common.Point loc;

    private int servicePeriod;  // attribute

    private int stopID;  // attribute

    public Stop() {
    }

    public Stop(
           int servicePeriod,
           int stopID,
           com.ptvag.xserver.common.Point loc) {
        this.servicePeriod = servicePeriod;
        this.stopID = stopID;
        this.loc = loc;
    }


    /**
     * Gets the loc value for this Stop.
     * 
     * @return loc
     */
    public com.ptvag.xserver.common.Point getLoc() {
        return loc;
    }


    /**
     * Sets the loc value for this Stop.
     * 
     * @param loc
     */
    public void setLoc(com.ptvag.xserver.common.Point loc) {
        this.loc = loc;
    }


    /**
     * Gets the servicePeriod value for this Stop.
     * 
     * @return servicePeriod
     */
    public int getServicePeriod() {
        return servicePeriod;
    }


    /**
     * Sets the servicePeriod value for this Stop.
     * 
     * @param servicePeriod
     */
    public void setServicePeriod(int servicePeriod) {
        this.servicePeriod = servicePeriod;
    }


    /**
     * Gets the stopID value for this Stop.
     * 
     * @return stopID
     */
    public int getStopID() {
        return stopID;
    }


    /**
     * Sets the stopID value for this Stop.
     * 
     * @param stopID
     */
    public void setStopID(int stopID) {
        this.stopID = stopID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Stop)) return false;
        Stop other = (Stop) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.loc==null && other.getLoc()==null) || 
             (this.loc!=null &&
              this.loc.equals(other.getLoc()))) &&
            this.servicePeriod == other.getServicePeriod() &&
            this.stopID == other.getStopID();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLoc() != null) {
            _hashCode += getLoc().hashCode();
        }
        _hashCode += getServicePeriod();
        _hashCode += getStopID();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Stop.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Stop"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("servicePeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "servicePeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("stopID");
        attrField.setXmlName(new javax.xml.namespace.QName("", "stopID"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "loc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
