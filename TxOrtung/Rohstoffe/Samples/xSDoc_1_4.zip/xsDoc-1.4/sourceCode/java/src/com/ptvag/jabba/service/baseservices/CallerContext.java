/**
 * CallerContext.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.jabba.service.baseservices;

public class CallerContext  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.jabba.service.baseservices.CallerContextProperty[] wrappedProperties;

    private java.lang.String log1;  // attribute

    private java.lang.String log2;  // attribute

    private java.lang.String log3;  // attribute

    public CallerContext() {
    }

    public CallerContext(
           java.lang.String log1,
           java.lang.String log2,
           java.lang.String log3,
           com.ptvag.jabba.service.baseservices.CallerContextProperty[] wrappedProperties) {
        this.log1 = log1;
        this.log2 = log2;
        this.log3 = log3;
        this.wrappedProperties = wrappedProperties;
    }


    /**
     * Gets the wrappedProperties value for this CallerContext.
     * 
     * @return wrappedProperties
     */
    public com.ptvag.jabba.service.baseservices.CallerContextProperty[] getWrappedProperties() {
        return wrappedProperties;
    }


    /**
     * Sets the wrappedProperties value for this CallerContext.
     * 
     * @param wrappedProperties
     */
    public void setWrappedProperties(com.ptvag.jabba.service.baseservices.CallerContextProperty[] wrappedProperties) {
        this.wrappedProperties = wrappedProperties;
    }


    /**
     * Gets the log1 value for this CallerContext.
     * 
     * @return log1
     */
    public java.lang.String getLog1() {
        return log1;
    }


    /**
     * Sets the log1 value for this CallerContext.
     * 
     * @param log1
     */
    public void setLog1(java.lang.String log1) {
        this.log1 = log1;
    }


    /**
     * Gets the log2 value for this CallerContext.
     * 
     * @return log2
     */
    public java.lang.String getLog2() {
        return log2;
    }


    /**
     * Sets the log2 value for this CallerContext.
     * 
     * @param log2
     */
    public void setLog2(java.lang.String log2) {
        this.log2 = log2;
    }


    /**
     * Gets the log3 value for this CallerContext.
     * 
     * @return log3
     */
    public java.lang.String getLog3() {
        return log3;
    }


    /**
     * Sets the log3 value for this CallerContext.
     * 
     * @param log3
     */
    public void setLog3(java.lang.String log3) {
        this.log3 = log3;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CallerContext)) return false;
        CallerContext other = (CallerContext) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedProperties==null && other.getWrappedProperties()==null) || 
             (this.wrappedProperties!=null &&
              java.util.Arrays.equals(this.wrappedProperties, other.getWrappedProperties()))) &&
            ((this.log1==null && other.getLog1()==null) || 
             (this.log1!=null &&
              this.log1.equals(other.getLog1()))) &&
            ((this.log2==null && other.getLog2()==null) || 
             (this.log2!=null &&
              this.log2.equals(other.getLog2()))) &&
            ((this.log3==null && other.getLog3()==null) || 
             (this.log3!=null &&
              this.log3.equals(other.getLog3())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedProperties() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedProperties());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedProperties(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLog1() != null) {
            _hashCode += getLog1().hashCode();
        }
        if (getLog2() != null) {
            _hashCode += getLog2().hashCode();
        }
        if (getLog3() != null) {
            _hashCode += getLog3().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CallerContext.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("log1");
        attrField.setXmlName(new javax.xml.namespace.QName("", "log1"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("log2");
        attrField.setXmlName(new javax.xml.namespace.QName("", "log2"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("log3");
        attrField.setXmlName(new javax.xml.namespace.QName("", "log3"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedProperties");
        elemField.setXmlName(new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "wrappedProperties"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
