/**
 * DistanceCalculation.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class DistanceCalculation  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xsequence.DimaParams dimaParams;

    private com.ptvag.xserver.xsequence.DistanceMatrix distanceMatrix;

    private com.ptvag.xserver.xsequence.DistanceType distanceType;  // attribute

    private double drivingPeriodFactor;  // attribute

    private int geometricSpeed;  // attribute

    public DistanceCalculation() {
    }

    public DistanceCalculation(
           com.ptvag.xserver.xsequence.DistanceType distanceType,
           double drivingPeriodFactor,
           int geometricSpeed,
           com.ptvag.xserver.xsequence.DimaParams dimaParams,
           com.ptvag.xserver.xsequence.DistanceMatrix distanceMatrix) {
        this.distanceType = distanceType;
        this.drivingPeriodFactor = drivingPeriodFactor;
        this.geometricSpeed = geometricSpeed;
        this.dimaParams = dimaParams;
        this.distanceMatrix = distanceMatrix;
    }


    /**
     * Gets the dimaParams value for this DistanceCalculation.
     * 
     * @return dimaParams
     */
    public com.ptvag.xserver.xsequence.DimaParams getDimaParams() {
        return dimaParams;
    }


    /**
     * Sets the dimaParams value for this DistanceCalculation.
     * 
     * @param dimaParams
     */
    public void setDimaParams(com.ptvag.xserver.xsequence.DimaParams dimaParams) {
        this.dimaParams = dimaParams;
    }


    /**
     * Gets the distanceMatrix value for this DistanceCalculation.
     * 
     * @return distanceMatrix
     */
    public com.ptvag.xserver.xsequence.DistanceMatrix getDistanceMatrix() {
        return distanceMatrix;
    }


    /**
     * Sets the distanceMatrix value for this DistanceCalculation.
     * 
     * @param distanceMatrix
     */
    public void setDistanceMatrix(com.ptvag.xserver.xsequence.DistanceMatrix distanceMatrix) {
        this.distanceMatrix = distanceMatrix;
    }


    /**
     * Gets the distanceType value for this DistanceCalculation.
     * 
     * @return distanceType
     */
    public com.ptvag.xserver.xsequence.DistanceType getDistanceType() {
        return distanceType;
    }


    /**
     * Sets the distanceType value for this DistanceCalculation.
     * 
     * @param distanceType
     */
    public void setDistanceType(com.ptvag.xserver.xsequence.DistanceType distanceType) {
        this.distanceType = distanceType;
    }


    /**
     * Gets the drivingPeriodFactor value for this DistanceCalculation.
     * 
     * @return drivingPeriodFactor
     */
    public double getDrivingPeriodFactor() {
        return drivingPeriodFactor;
    }


    /**
     * Sets the drivingPeriodFactor value for this DistanceCalculation.
     * 
     * @param drivingPeriodFactor
     */
    public void setDrivingPeriodFactor(double drivingPeriodFactor) {
        this.drivingPeriodFactor = drivingPeriodFactor;
    }


    /**
     * Gets the geometricSpeed value for this DistanceCalculation.
     * 
     * @return geometricSpeed
     */
    public int getGeometricSpeed() {
        return geometricSpeed;
    }


    /**
     * Sets the geometricSpeed value for this DistanceCalculation.
     * 
     * @param geometricSpeed
     */
    public void setGeometricSpeed(int geometricSpeed) {
        this.geometricSpeed = geometricSpeed;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DistanceCalculation)) return false;
        DistanceCalculation other = (DistanceCalculation) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.dimaParams==null && other.getDimaParams()==null) || 
             (this.dimaParams!=null &&
              this.dimaParams.equals(other.getDimaParams()))) &&
            ((this.distanceMatrix==null && other.getDistanceMatrix()==null) || 
             (this.distanceMatrix!=null &&
              this.distanceMatrix.equals(other.getDistanceMatrix()))) &&
            ((this.distanceType==null && other.getDistanceType()==null) || 
             (this.distanceType!=null &&
              this.distanceType.equals(other.getDistanceType()))) &&
            this.drivingPeriodFactor == other.getDrivingPeriodFactor() &&
            this.geometricSpeed == other.getGeometricSpeed();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDimaParams() != null) {
            _hashCode += getDimaParams().hashCode();
        }
        if (getDistanceMatrix() != null) {
            _hashCode += getDistanceMatrix().hashCode();
        }
        if (getDistanceType() != null) {
            _hashCode += getDistanceType().hashCode();
        }
        _hashCode += new Double(getDrivingPeriodFactor()).hashCode();
        _hashCode += getGeometricSpeed();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DistanceCalculation.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistanceCalculation"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("distanceType");
        attrField.setXmlName(new javax.xml.namespace.QName("", "distanceType"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistanceType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("drivingPeriodFactor");
        attrField.setXmlName(new javax.xml.namespace.QName("", "drivingPeriodFactor"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("geometricSpeed");
        attrField.setXmlName(new javax.xml.namespace.QName("", "geometricSpeed"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dimaParams");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "dimaParams"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DimaParams"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("distanceMatrix");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "distanceMatrix"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistanceMatrix"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
