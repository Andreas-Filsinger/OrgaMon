/**
 * PlainLineString.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.common;

public class PlainLineString  extends com.ptvag.xserver.common.PlainGeometryBase  implements java.io.Serializable {
    private com.ptvag.xserver.common.PlainPoint[] wrappedPoints;

    public PlainLineString() {
    }

    public PlainLineString(
           com.ptvag.xserver.common.PlainPoint[] wrappedPoints) {
        this.wrappedPoints = wrappedPoints;
    }


    /**
     * Gets the wrappedPoints value for this PlainLineString.
     * 
     * @return wrappedPoints
     */
    public com.ptvag.xserver.common.PlainPoint[] getWrappedPoints() {
        return wrappedPoints;
    }


    /**
     * Sets the wrappedPoints value for this PlainLineString.
     * 
     * @param wrappedPoints
     */
    public void setWrappedPoints(com.ptvag.xserver.common.PlainPoint[] wrappedPoints) {
        this.wrappedPoints = wrappedPoints;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PlainLineString)) return false;
        PlainLineString other = (PlainLineString) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedPoints==null && other.getWrappedPoints()==null) || 
             (this.wrappedPoints!=null &&
              java.util.Arrays.equals(this.wrappedPoints, other.getWrappedPoints())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedPoints() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedPoints());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedPoints(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PlainLineString.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLineString"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedPoints");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "wrappedPoints"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
