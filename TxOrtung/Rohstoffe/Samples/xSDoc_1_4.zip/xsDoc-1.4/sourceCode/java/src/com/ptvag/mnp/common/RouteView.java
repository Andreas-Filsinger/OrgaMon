/**
 * RouteView.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class RouteView  implements java.io.Serializable {
    private java.lang.String[] wrappedAdditionalInfos;

    private com.ptvag.mnp.common.BoundingBox bbox;

    private java.lang.String[] wrappedCountries;

    private java.lang.Double distance;

    private com.ptvag.mnp.common.DynProperties dynamicProperties;

    private com.ptvag.mnp.common.RouteElement[] wrappedElements;

    private java.lang.String geoDataSource;

    private com.ptvag.mnp.common.Polyline line;

    private com.ptvag.mnp.common.RouteElementMapRect[] wrappedReMaps;

    private com.ptvag.mnp.common.CoordinateList stations;

    private java.lang.Long time;

    private com.ptvag.mnp.common.Toll toll;

    public RouteView() {
    }

    public RouteView(
           java.lang.String[] wrappedAdditionalInfos,
           com.ptvag.mnp.common.BoundingBox bbox,
           java.lang.String[] wrappedCountries,
           java.lang.Double distance,
           com.ptvag.mnp.common.DynProperties dynamicProperties,
           com.ptvag.mnp.common.RouteElement[] wrappedElements,
           java.lang.String geoDataSource,
           com.ptvag.mnp.common.Polyline line,
           com.ptvag.mnp.common.RouteElementMapRect[] wrappedReMaps,
           com.ptvag.mnp.common.CoordinateList stations,
           java.lang.Long time,
           com.ptvag.mnp.common.Toll toll) {
           this.wrappedAdditionalInfos = wrappedAdditionalInfos;
           this.bbox = bbox;
           this.wrappedCountries = wrappedCountries;
           this.distance = distance;
           this.dynamicProperties = dynamicProperties;
           this.wrappedElements = wrappedElements;
           this.geoDataSource = geoDataSource;
           this.line = line;
           this.wrappedReMaps = wrappedReMaps;
           this.stations = stations;
           this.time = time;
           this.toll = toll;
    }


    /**
     * Gets the wrappedAdditionalInfos value for this RouteView.
     * 
     * @return wrappedAdditionalInfos
     */
    public java.lang.String[] getWrappedAdditionalInfos() {
        return wrappedAdditionalInfos;
    }


    /**
     * Sets the wrappedAdditionalInfos value for this RouteView.
     * 
     * @param wrappedAdditionalInfos
     */
    public void setWrappedAdditionalInfos(java.lang.String[] wrappedAdditionalInfos) {
        this.wrappedAdditionalInfos = wrappedAdditionalInfos;
    }


    /**
     * Gets the bbox value for this RouteView.
     * 
     * @return bbox
     */
    public com.ptvag.mnp.common.BoundingBox getBbox() {
        return bbox;
    }


    /**
     * Sets the bbox value for this RouteView.
     * 
     * @param bbox
     */
    public void setBbox(com.ptvag.mnp.common.BoundingBox bbox) {
        this.bbox = bbox;
    }


    /**
     * Gets the wrappedCountries value for this RouteView.
     * 
     * @return wrappedCountries
     */
    public java.lang.String[] getWrappedCountries() {
        return wrappedCountries;
    }


    /**
     * Sets the wrappedCountries value for this RouteView.
     * 
     * @param wrappedCountries
     */
    public void setWrappedCountries(java.lang.String[] wrappedCountries) {
        this.wrappedCountries = wrappedCountries;
    }


    /**
     * Gets the distance value for this RouteView.
     * 
     * @return distance
     */
    public java.lang.Double getDistance() {
        return distance;
    }


    /**
     * Sets the distance value for this RouteView.
     * 
     * @param distance
     */
    public void setDistance(java.lang.Double distance) {
        this.distance = distance;
    }


    /**
     * Gets the dynamicProperties value for this RouteView.
     * 
     * @return dynamicProperties
     */
    public com.ptvag.mnp.common.DynProperties getDynamicProperties() {
        return dynamicProperties;
    }


    /**
     * Sets the dynamicProperties value for this RouteView.
     * 
     * @param dynamicProperties
     */
    public void setDynamicProperties(com.ptvag.mnp.common.DynProperties dynamicProperties) {
        this.dynamicProperties = dynamicProperties;
    }


    /**
     * Gets the wrappedElements value for this RouteView.
     * 
     * @return wrappedElements
     */
    public com.ptvag.mnp.common.RouteElement[] getWrappedElements() {
        return wrappedElements;
    }


    /**
     * Sets the wrappedElements value for this RouteView.
     * 
     * @param wrappedElements
     */
    public void setWrappedElements(com.ptvag.mnp.common.RouteElement[] wrappedElements) {
        this.wrappedElements = wrappedElements;
    }


    /**
     * Gets the geoDataSource value for this RouteView.
     * 
     * @return geoDataSource
     */
    public java.lang.String getGeoDataSource() {
        return geoDataSource;
    }


    /**
     * Sets the geoDataSource value for this RouteView.
     * 
     * @param geoDataSource
     */
    public void setGeoDataSource(java.lang.String geoDataSource) {
        this.geoDataSource = geoDataSource;
    }


    /**
     * Gets the line value for this RouteView.
     * 
     * @return line
     */
    public com.ptvag.mnp.common.Polyline getLine() {
        return line;
    }


    /**
     * Sets the line value for this RouteView.
     * 
     * @param line
     */
    public void setLine(com.ptvag.mnp.common.Polyline line) {
        this.line = line;
    }


    /**
     * Gets the wrappedReMaps value for this RouteView.
     * 
     * @return wrappedReMaps
     */
    public com.ptvag.mnp.common.RouteElementMapRect[] getWrappedReMaps() {
        return wrappedReMaps;
    }


    /**
     * Sets the wrappedReMaps value for this RouteView.
     * 
     * @param wrappedReMaps
     */
    public void setWrappedReMaps(com.ptvag.mnp.common.RouteElementMapRect[] wrappedReMaps) {
        this.wrappedReMaps = wrappedReMaps;
    }


    /**
     * Gets the stations value for this RouteView.
     * 
     * @return stations
     */
    public com.ptvag.mnp.common.CoordinateList getStations() {
        return stations;
    }


    /**
     * Sets the stations value for this RouteView.
     * 
     * @param stations
     */
    public void setStations(com.ptvag.mnp.common.CoordinateList stations) {
        this.stations = stations;
    }


    /**
     * Gets the time value for this RouteView.
     * 
     * @return time
     */
    public java.lang.Long getTime() {
        return time;
    }


    /**
     * Sets the time value for this RouteView.
     * 
     * @param time
     */
    public void setTime(java.lang.Long time) {
        this.time = time;
    }


    /**
     * Gets the toll value for this RouteView.
     * 
     * @return toll
     */
    public com.ptvag.mnp.common.Toll getToll() {
        return toll;
    }


    /**
     * Sets the toll value for this RouteView.
     * 
     * @param toll
     */
    public void setToll(com.ptvag.mnp.common.Toll toll) {
        this.toll = toll;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RouteView)) return false;
        RouteView other = (RouteView) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.wrappedAdditionalInfos==null && other.getWrappedAdditionalInfos()==null) || 
             (this.wrappedAdditionalInfos!=null &&
              java.util.Arrays.equals(this.wrappedAdditionalInfos, other.getWrappedAdditionalInfos()))) &&
            ((this.bbox==null && other.getBbox()==null) || 
             (this.bbox!=null &&
              this.bbox.equals(other.getBbox()))) &&
            ((this.wrappedCountries==null && other.getWrappedCountries()==null) || 
             (this.wrappedCountries!=null &&
              java.util.Arrays.equals(this.wrappedCountries, other.getWrappedCountries()))) &&
            ((this.distance==null && other.getDistance()==null) || 
             (this.distance!=null &&
              this.distance.equals(other.getDistance()))) &&
            ((this.dynamicProperties==null && other.getDynamicProperties()==null) || 
             (this.dynamicProperties!=null &&
              this.dynamicProperties.equals(other.getDynamicProperties()))) &&
            ((this.wrappedElements==null && other.getWrappedElements()==null) || 
             (this.wrappedElements!=null &&
              java.util.Arrays.equals(this.wrappedElements, other.getWrappedElements()))) &&
            ((this.geoDataSource==null && other.getGeoDataSource()==null) || 
             (this.geoDataSource!=null &&
              this.geoDataSource.equals(other.getGeoDataSource()))) &&
            ((this.line==null && other.getLine()==null) || 
             (this.line!=null &&
              this.line.equals(other.getLine()))) &&
            ((this.wrappedReMaps==null && other.getWrappedReMaps()==null) || 
             (this.wrappedReMaps!=null &&
              java.util.Arrays.equals(this.wrappedReMaps, other.getWrappedReMaps()))) &&
            ((this.stations==null && other.getStations()==null) || 
             (this.stations!=null &&
              this.stations.equals(other.getStations()))) &&
            ((this.time==null && other.getTime()==null) || 
             (this.time!=null &&
              this.time.equals(other.getTime()))) &&
            ((this.toll==null && other.getToll()==null) || 
             (this.toll!=null &&
              this.toll.equals(other.getToll())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getWrappedAdditionalInfos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedAdditionalInfos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedAdditionalInfos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getBbox() != null) {
            _hashCode += getBbox().hashCode();
        }
        if (getWrappedCountries() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedCountries());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedCountries(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDistance() != null) {
            _hashCode += getDistance().hashCode();
        }
        if (getDynamicProperties() != null) {
            _hashCode += getDynamicProperties().hashCode();
        }
        if (getWrappedElements() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedElements());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedElements(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGeoDataSource() != null) {
            _hashCode += getGeoDataSource().hashCode();
        }
        if (getLine() != null) {
            _hashCode += getLine().hashCode();
        }
        if (getWrappedReMaps() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedReMaps());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedReMaps(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getStations() != null) {
            _hashCode += getStations().hashCode();
        }
        if (getTime() != null) {
            _hashCode += getTime().hashCode();
        }
        if (getToll() != null) {
            _hashCode += getToll().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RouteView.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteView"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedAdditionalInfos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedAdditionalInfos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bbox");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "bbox"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BoundingBox"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedCountries");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedCountries"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("distance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "distance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dynamicProperties");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "dynamicProperties"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "DynProperties"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedElements");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedElements"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElement"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfRouteElement"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("geoDataSource");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "geoDataSource"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("line");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "line"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Polyline"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedReMaps");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedReMaps"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElementMapRect"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfRouteElementMapRect"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stations");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "stations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "CoordinateList"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("time");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "time"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("toll");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "toll"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Toll"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
