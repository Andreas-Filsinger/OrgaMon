/**
 * ResultListOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class ResultListOptions  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.DetailDescriptionOption destDetail;

    private com.ptvag.xserver.xroute.DetailDescriptionOption startDetail;

    private boolean binaryPathDesc;  // attribute

    private int boundingRectanglesC;  // attribute

    private int boundingRectanglesOffset;  // attribute

    private boolean brunnelManoeuvres;  // attribute

    private com.ptvag.xserver.xroute.DetailLevel detailLevel;  // attribute

    private boolean dynamicInfo;  // attribute

    private java.lang.Boolean extSegments;  // attribute

    private boolean manoeuvreAttributes;  // attribute

    private java.lang.Double manoeuvreGroupRatio;  // attribute

    private boolean manoeuvreGroups;  // attribute

    private boolean manoeuvres;  // attribute

    private boolean nodes;  // attribute

    private boolean polygon;  // attribute

    private boolean segmentAttributes;  // attribute

    private boolean segments;  // attribute

    private boolean texts;  // attribute

    private boolean totalRectangle;  // attribute

    private boolean urbanManoeuvres;  // attribute

    public ResultListOptions() {
    }

    public ResultListOptions(
           boolean binaryPathDesc,
           int boundingRectanglesC,
           int boundingRectanglesOffset,
           boolean brunnelManoeuvres,
           com.ptvag.xserver.xroute.DetailLevel detailLevel,
           boolean dynamicInfo,
           java.lang.Boolean extSegments,
           boolean manoeuvreAttributes,
           java.lang.Double manoeuvreGroupRatio,
           boolean manoeuvreGroups,
           boolean manoeuvres,
           boolean nodes,
           boolean polygon,
           boolean segmentAttributes,
           boolean segments,
           boolean texts,
           boolean totalRectangle,
           boolean urbanManoeuvres,
           com.ptvag.xserver.xroute.DetailDescriptionOption destDetail,
           com.ptvag.xserver.xroute.DetailDescriptionOption startDetail) {
        this.binaryPathDesc = binaryPathDesc;
        this.boundingRectanglesC = boundingRectanglesC;
        this.boundingRectanglesOffset = boundingRectanglesOffset;
        this.brunnelManoeuvres = brunnelManoeuvres;
        this.detailLevel = detailLevel;
        this.dynamicInfo = dynamicInfo;
        this.extSegments = extSegments;
        this.manoeuvreAttributes = manoeuvreAttributes;
        this.manoeuvreGroupRatio = manoeuvreGroupRatio;
        this.manoeuvreGroups = manoeuvreGroups;
        this.manoeuvres = manoeuvres;
        this.nodes = nodes;
        this.polygon = polygon;
        this.segmentAttributes = segmentAttributes;
        this.segments = segments;
        this.texts = texts;
        this.totalRectangle = totalRectangle;
        this.urbanManoeuvres = urbanManoeuvres;
        this.destDetail = destDetail;
        this.startDetail = startDetail;
    }


    /**
     * Gets the destDetail value for this ResultListOptions.
     * 
     * @return destDetail
     */
    public com.ptvag.xserver.xroute.DetailDescriptionOption getDestDetail() {
        return destDetail;
    }


    /**
     * Sets the destDetail value for this ResultListOptions.
     * 
     * @param destDetail
     */
    public void setDestDetail(com.ptvag.xserver.xroute.DetailDescriptionOption destDetail) {
        this.destDetail = destDetail;
    }


    /**
     * Gets the startDetail value for this ResultListOptions.
     * 
     * @return startDetail
     */
    public com.ptvag.xserver.xroute.DetailDescriptionOption getStartDetail() {
        return startDetail;
    }


    /**
     * Sets the startDetail value for this ResultListOptions.
     * 
     * @param startDetail
     */
    public void setStartDetail(com.ptvag.xserver.xroute.DetailDescriptionOption startDetail) {
        this.startDetail = startDetail;
    }


    /**
     * Gets the binaryPathDesc value for this ResultListOptions.
     * 
     * @return binaryPathDesc
     */
    public boolean isBinaryPathDesc() {
        return binaryPathDesc;
    }


    /**
     * Sets the binaryPathDesc value for this ResultListOptions.
     * 
     * @param binaryPathDesc
     */
    public void setBinaryPathDesc(boolean binaryPathDesc) {
        this.binaryPathDesc = binaryPathDesc;
    }


    /**
     * Gets the boundingRectanglesC value for this ResultListOptions.
     * 
     * @return boundingRectanglesC
     */
    public int getBoundingRectanglesC() {
        return boundingRectanglesC;
    }


    /**
     * Sets the boundingRectanglesC value for this ResultListOptions.
     * 
     * @param boundingRectanglesC
     */
    public void setBoundingRectanglesC(int boundingRectanglesC) {
        this.boundingRectanglesC = boundingRectanglesC;
    }


    /**
     * Gets the boundingRectanglesOffset value for this ResultListOptions.
     * 
     * @return boundingRectanglesOffset
     */
    public int getBoundingRectanglesOffset() {
        return boundingRectanglesOffset;
    }


    /**
     * Sets the boundingRectanglesOffset value for this ResultListOptions.
     * 
     * @param boundingRectanglesOffset
     */
    public void setBoundingRectanglesOffset(int boundingRectanglesOffset) {
        this.boundingRectanglesOffset = boundingRectanglesOffset;
    }


    /**
     * Gets the brunnelManoeuvres value for this ResultListOptions.
     * 
     * @return brunnelManoeuvres
     */
    public boolean isBrunnelManoeuvres() {
        return brunnelManoeuvres;
    }


    /**
     * Sets the brunnelManoeuvres value for this ResultListOptions.
     * 
     * @param brunnelManoeuvres
     */
    public void setBrunnelManoeuvres(boolean brunnelManoeuvres) {
        this.brunnelManoeuvres = brunnelManoeuvres;
    }


    /**
     * Gets the detailLevel value for this ResultListOptions.
     * 
     * @return detailLevel
     */
    public com.ptvag.xserver.xroute.DetailLevel getDetailLevel() {
        return detailLevel;
    }


    /**
     * Sets the detailLevel value for this ResultListOptions.
     * 
     * @param detailLevel
     */
    public void setDetailLevel(com.ptvag.xserver.xroute.DetailLevel detailLevel) {
        this.detailLevel = detailLevel;
    }


    /**
     * Gets the dynamicInfo value for this ResultListOptions.
     * 
     * @return dynamicInfo
     */
    public boolean isDynamicInfo() {
        return dynamicInfo;
    }


    /**
     * Sets the dynamicInfo value for this ResultListOptions.
     * 
     * @param dynamicInfo
     */
    public void setDynamicInfo(boolean dynamicInfo) {
        this.dynamicInfo = dynamicInfo;
    }


    /**
     * Gets the extSegments value for this ResultListOptions.
     * 
     * @return extSegments
     */
    public java.lang.Boolean getExtSegments() {
        return extSegments;
    }


    /**
     * Sets the extSegments value for this ResultListOptions.
     * 
     * @param extSegments
     */
    public void setExtSegments(java.lang.Boolean extSegments) {
        this.extSegments = extSegments;
    }


    /**
     * Gets the manoeuvreAttributes value for this ResultListOptions.
     * 
     * @return manoeuvreAttributes
     */
    public boolean isManoeuvreAttributes() {
        return manoeuvreAttributes;
    }


    /**
     * Sets the manoeuvreAttributes value for this ResultListOptions.
     * 
     * @param manoeuvreAttributes
     */
    public void setManoeuvreAttributes(boolean manoeuvreAttributes) {
        this.manoeuvreAttributes = manoeuvreAttributes;
    }


    /**
     * Gets the manoeuvreGroupRatio value for this ResultListOptions.
     * 
     * @return manoeuvreGroupRatio
     */
    public java.lang.Double getManoeuvreGroupRatio() {
        return manoeuvreGroupRatio;
    }


    /**
     * Sets the manoeuvreGroupRatio value for this ResultListOptions.
     * 
     * @param manoeuvreGroupRatio
     */
    public void setManoeuvreGroupRatio(java.lang.Double manoeuvreGroupRatio) {
        this.manoeuvreGroupRatio = manoeuvreGroupRatio;
    }


    /**
     * Gets the manoeuvreGroups value for this ResultListOptions.
     * 
     * @return manoeuvreGroups
     */
    public boolean isManoeuvreGroups() {
        return manoeuvreGroups;
    }


    /**
     * Sets the manoeuvreGroups value for this ResultListOptions.
     * 
     * @param manoeuvreGroups
     */
    public void setManoeuvreGroups(boolean manoeuvreGroups) {
        this.manoeuvreGroups = manoeuvreGroups;
    }


    /**
     * Gets the manoeuvres value for this ResultListOptions.
     * 
     * @return manoeuvres
     */
    public boolean isManoeuvres() {
        return manoeuvres;
    }


    /**
     * Sets the manoeuvres value for this ResultListOptions.
     * 
     * @param manoeuvres
     */
    public void setManoeuvres(boolean manoeuvres) {
        this.manoeuvres = manoeuvres;
    }


    /**
     * Gets the nodes value for this ResultListOptions.
     * 
     * @return nodes
     */
    public boolean isNodes() {
        return nodes;
    }


    /**
     * Sets the nodes value for this ResultListOptions.
     * 
     * @param nodes
     */
    public void setNodes(boolean nodes) {
        this.nodes = nodes;
    }


    /**
     * Gets the polygon value for this ResultListOptions.
     * 
     * @return polygon
     */
    public boolean isPolygon() {
        return polygon;
    }


    /**
     * Sets the polygon value for this ResultListOptions.
     * 
     * @param polygon
     */
    public void setPolygon(boolean polygon) {
        this.polygon = polygon;
    }


    /**
     * Gets the segmentAttributes value for this ResultListOptions.
     * 
     * @return segmentAttributes
     */
    public boolean isSegmentAttributes() {
        return segmentAttributes;
    }


    /**
     * Sets the segmentAttributes value for this ResultListOptions.
     * 
     * @param segmentAttributes
     */
    public void setSegmentAttributes(boolean segmentAttributes) {
        this.segmentAttributes = segmentAttributes;
    }


    /**
     * Gets the segments value for this ResultListOptions.
     * 
     * @return segments
     */
    public boolean isSegments() {
        return segments;
    }


    /**
     * Sets the segments value for this ResultListOptions.
     * 
     * @param segments
     */
    public void setSegments(boolean segments) {
        this.segments = segments;
    }


    /**
     * Gets the texts value for this ResultListOptions.
     * 
     * @return texts
     */
    public boolean isTexts() {
        return texts;
    }


    /**
     * Sets the texts value for this ResultListOptions.
     * 
     * @param texts
     */
    public void setTexts(boolean texts) {
        this.texts = texts;
    }


    /**
     * Gets the totalRectangle value for this ResultListOptions.
     * 
     * @return totalRectangle
     */
    public boolean isTotalRectangle() {
        return totalRectangle;
    }


    /**
     * Sets the totalRectangle value for this ResultListOptions.
     * 
     * @param totalRectangle
     */
    public void setTotalRectangle(boolean totalRectangle) {
        this.totalRectangle = totalRectangle;
    }


    /**
     * Gets the urbanManoeuvres value for this ResultListOptions.
     * 
     * @return urbanManoeuvres
     */
    public boolean isUrbanManoeuvres() {
        return urbanManoeuvres;
    }


    /**
     * Sets the urbanManoeuvres value for this ResultListOptions.
     * 
     * @param urbanManoeuvres
     */
    public void setUrbanManoeuvres(boolean urbanManoeuvres) {
        this.urbanManoeuvres = urbanManoeuvres;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ResultListOptions)) return false;
        ResultListOptions other = (ResultListOptions) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.destDetail==null && other.getDestDetail()==null) || 
             (this.destDetail!=null &&
              this.destDetail.equals(other.getDestDetail()))) &&
            ((this.startDetail==null && other.getStartDetail()==null) || 
             (this.startDetail!=null &&
              this.startDetail.equals(other.getStartDetail()))) &&
            this.binaryPathDesc == other.isBinaryPathDesc() &&
            this.boundingRectanglesC == other.getBoundingRectanglesC() &&
            this.boundingRectanglesOffset == other.getBoundingRectanglesOffset() &&
            this.brunnelManoeuvres == other.isBrunnelManoeuvres() &&
            ((this.detailLevel==null && other.getDetailLevel()==null) || 
             (this.detailLevel!=null &&
              this.detailLevel.equals(other.getDetailLevel()))) &&
            this.dynamicInfo == other.isDynamicInfo() &&
            ((this.extSegments==null && other.getExtSegments()==null) || 
             (this.extSegments!=null &&
              this.extSegments.equals(other.getExtSegments()))) &&
            this.manoeuvreAttributes == other.isManoeuvreAttributes() &&
            ((this.manoeuvreGroupRatio==null && other.getManoeuvreGroupRatio()==null) || 
             (this.manoeuvreGroupRatio!=null &&
              this.manoeuvreGroupRatio.equals(other.getManoeuvreGroupRatio()))) &&
            this.manoeuvreGroups == other.isManoeuvreGroups() &&
            this.manoeuvres == other.isManoeuvres() &&
            this.nodes == other.isNodes() &&
            this.polygon == other.isPolygon() &&
            this.segmentAttributes == other.isSegmentAttributes() &&
            this.segments == other.isSegments() &&
            this.texts == other.isTexts() &&
            this.totalRectangle == other.isTotalRectangle() &&
            this.urbanManoeuvres == other.isUrbanManoeuvres();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDestDetail() != null) {
            _hashCode += getDestDetail().hashCode();
        }
        if (getStartDetail() != null) {
            _hashCode += getStartDetail().hashCode();
        }
        _hashCode += (isBinaryPathDesc() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getBoundingRectanglesC();
        _hashCode += getBoundingRectanglesOffset();
        _hashCode += (isBrunnelManoeuvres() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getDetailLevel() != null) {
            _hashCode += getDetailLevel().hashCode();
        }
        _hashCode += (isDynamicInfo() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getExtSegments() != null) {
            _hashCode += getExtSegments().hashCode();
        }
        _hashCode += (isManoeuvreAttributes() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getManoeuvreGroupRatio() != null) {
            _hashCode += getManoeuvreGroupRatio().hashCode();
        }
        _hashCode += (isManoeuvreGroups() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isManoeuvres() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isNodes() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isPolygon() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isSegmentAttributes() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isSegments() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isTexts() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isTotalRectangle() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isUrbanManoeuvres() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ResultListOptions.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ResultListOptions"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("binaryPathDesc");
        attrField.setXmlName(new javax.xml.namespace.QName("", "binaryPathDesc"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("boundingRectanglesC");
        attrField.setXmlName(new javax.xml.namespace.QName("", "boundingRectanglesC"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("boundingRectanglesOffset");
        attrField.setXmlName(new javax.xml.namespace.QName("", "boundingRectanglesOffset"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("brunnelManoeuvres");
        attrField.setXmlName(new javax.xml.namespace.QName("", "brunnelManoeuvres"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("detailLevel");
        attrField.setXmlName(new javax.xml.namespace.QName("", "detailLevel"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "DetailLevel"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("dynamicInfo");
        attrField.setXmlName(new javax.xml.namespace.QName("", "dynamicInfo"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("extSegments");
        attrField.setXmlName(new javax.xml.namespace.QName("", "extSegments"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("manoeuvreAttributes");
        attrField.setXmlName(new javax.xml.namespace.QName("", "manoeuvreAttributes"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("manoeuvreGroupRatio");
        attrField.setXmlName(new javax.xml.namespace.QName("", "manoeuvreGroupRatio"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("manoeuvreGroups");
        attrField.setXmlName(new javax.xml.namespace.QName("", "manoeuvreGroups"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("manoeuvres");
        attrField.setXmlName(new javax.xml.namespace.QName("", "manoeuvres"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("nodes");
        attrField.setXmlName(new javax.xml.namespace.QName("", "nodes"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("polygon");
        attrField.setXmlName(new javax.xml.namespace.QName("", "polygon"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("segmentAttributes");
        attrField.setXmlName(new javax.xml.namespace.QName("", "segmentAttributes"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("segments");
        attrField.setXmlName(new javax.xml.namespace.QName("", "segments"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("texts");
        attrField.setXmlName(new javax.xml.namespace.QName("", "texts"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("totalRectangle");
        attrField.setXmlName(new javax.xml.namespace.QName("", "totalRectangle"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("urbanManoeuvres");
        attrField.setXmlName(new javax.xml.namespace.QName("", "urbanManoeuvres"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("destDetail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "destDetail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "DetailDescriptionOption"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startDetail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "startDetail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "DetailDescriptionOption"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
