/**
 * DynamicInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class DynamicInfo  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private java.lang.Integer distanceDiff;  // attribute

    private int timeBenefit;  // attribute

    private int timeLoss;  // attribute

    private int timeLoss2;  // attribute

    public DynamicInfo() {
    }

    public DynamicInfo(
           java.lang.Integer distanceDiff,
           int timeBenefit,
           int timeLoss,
           int timeLoss2) {
        this.distanceDiff = distanceDiff;
        this.timeBenefit = timeBenefit;
        this.timeLoss = timeLoss;
        this.timeLoss2 = timeLoss2;
    }


    /**
     * Gets the distanceDiff value for this DynamicInfo.
     * 
     * @return distanceDiff
     */
    public java.lang.Integer getDistanceDiff() {
        return distanceDiff;
    }


    /**
     * Sets the distanceDiff value for this DynamicInfo.
     * 
     * @param distanceDiff
     */
    public void setDistanceDiff(java.lang.Integer distanceDiff) {
        this.distanceDiff = distanceDiff;
    }


    /**
     * Gets the timeBenefit value for this DynamicInfo.
     * 
     * @return timeBenefit
     */
    public int getTimeBenefit() {
        return timeBenefit;
    }


    /**
     * Sets the timeBenefit value for this DynamicInfo.
     * 
     * @param timeBenefit
     */
    public void setTimeBenefit(int timeBenefit) {
        this.timeBenefit = timeBenefit;
    }


    /**
     * Gets the timeLoss value for this DynamicInfo.
     * 
     * @return timeLoss
     */
    public int getTimeLoss() {
        return timeLoss;
    }


    /**
     * Sets the timeLoss value for this DynamicInfo.
     * 
     * @param timeLoss
     */
    public void setTimeLoss(int timeLoss) {
        this.timeLoss = timeLoss;
    }


    /**
     * Gets the timeLoss2 value for this DynamicInfo.
     * 
     * @return timeLoss2
     */
    public int getTimeLoss2() {
        return timeLoss2;
    }


    /**
     * Sets the timeLoss2 value for this DynamicInfo.
     * 
     * @param timeLoss2
     */
    public void setTimeLoss2(int timeLoss2) {
        this.timeLoss2 = timeLoss2;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DynamicInfo)) return false;
        DynamicInfo other = (DynamicInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.distanceDiff==null && other.getDistanceDiff()==null) || 
             (this.distanceDiff!=null &&
              this.distanceDiff.equals(other.getDistanceDiff()))) &&
            this.timeBenefit == other.getTimeBenefit() &&
            this.timeLoss == other.getTimeLoss() &&
            this.timeLoss2 == other.getTimeLoss2();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDistanceDiff() != null) {
            _hashCode += getDistanceDiff().hashCode();
        }
        _hashCode += getTimeBenefit();
        _hashCode += getTimeLoss();
        _hashCode += getTimeLoss2();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DynamicInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "DynamicInfo"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("distanceDiff");
        attrField.setXmlName(new javax.xml.namespace.QName("", "distanceDiff"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("timeBenefit");
        attrField.setXmlName(new javax.xml.namespace.QName("", "timeBenefit"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("timeLoss");
        attrField.setXmlName(new javax.xml.namespace.QName("", "timeLoss"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("timeLoss2");
        attrField.setXmlName(new javax.xml.namespace.QName("", "timeLoss2"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
