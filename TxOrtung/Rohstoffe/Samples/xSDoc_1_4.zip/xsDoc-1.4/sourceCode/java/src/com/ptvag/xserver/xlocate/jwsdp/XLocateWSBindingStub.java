/**
 * XLocateWSBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xlocate.jwsdp;

public class XLocateWSBindingStub extends org.apache.axis.client.Stub implements com.ptvag.xserver.xlocate.jwsdp.XLocateWS {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[12];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findAddress");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "Address_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "Address"), com.ptvag.xserver.xlocate.Address.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase"), com.ptvag.xserver.xlocate.SearchOptionBase[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSortOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption"), com.ptvag.xserver.xlocate.SortOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfResultField_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField"), com.ptvag.xserver.xlocate.ResultField[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "AddressResponse"));
        oper.setReturnClass(com.ptvag.xserver.xlocate.AddressResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"),
                      "com.ptvag.xserver.xlocate.XLocateException",
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findAddresses");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfAddress_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfAddress"), com.ptvag.xserver.xlocate.Address[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "Address"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase"), com.ptvag.xserver.xlocate.SearchOptionBase[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSortOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption"), com.ptvag.xserver.xlocate.SortOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfResultField_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField"), com.ptvag.xserver.xlocate.ResultField[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfAddressResponse"));
        oper.setReturnClass(com.ptvag.xserver.xlocate.AddressResponse[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "AddressResponse"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"),
                      "com.ptvag.xserver.xlocate.XLocateException",
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findLocation");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "Location_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "Location"), com.ptvag.xserver.xlocate.Location.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase"), com.ptvag.xserver.xlocate.SearchOptionBase[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSortOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption"), com.ptvag.xserver.xlocate.SortOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfResultField_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField"), com.ptvag.xserver.xlocate.ResultField[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "AddressResponse"));
        oper.setReturnClass(com.ptvag.xserver.xlocate.AddressResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"),
                      "com.ptvag.xserver.xlocate.XLocateException",
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findLocations");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfLocation_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfLocation"), com.ptvag.xserver.xlocate.Location[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "Location"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase"), com.ptvag.xserver.xlocate.SearchOptionBase[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSortOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption"), com.ptvag.xserver.xlocate.SortOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfResultField_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField"), com.ptvag.xserver.xlocate.ResultField[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfAddressResponse"));
        oper.setReturnClass(com.ptvag.xserver.xlocate.AddressResponse[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "AddressResponse"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"),
                      "com.ptvag.xserver.xlocate.XLocateException",
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findPoiByAddress");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "PoiAddress_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiAddress"), com.ptvag.xserver.xlocate.PoiAddress.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase"), com.ptvag.xserver.xlocate.SearchOptionBase[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSortOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption"), com.ptvag.xserver.xlocate.SortOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfResultField_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField"), com.ptvag.xserver.xlocate.ResultField[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiAddressResponse"));
        oper.setReturnClass(com.ptvag.xserver.xlocate.PoiAddressResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"),
                      "com.ptvag.xserver.xlocate.XLocateException",
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findPoiByAddresses");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfPoiAddress_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfPoiAddress"), com.ptvag.xserver.xlocate.PoiAddress[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiAddress"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase"), com.ptvag.xserver.xlocate.SearchOptionBase[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSortOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption"), com.ptvag.xserver.xlocate.SortOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfResultField_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField"), com.ptvag.xserver.xlocate.ResultField[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfPoiAddressResponse"));
        oper.setReturnClass(com.ptvag.xserver.xlocate.PoiAddressResponse[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiAddressResponse"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"),
                      "com.ptvag.xserver.xlocate.XLocateException",
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findPoiByLocation");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "PoiLocation_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiLocation"), com.ptvag.xserver.xlocate.PoiLocation.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase"), com.ptvag.xserver.xlocate.SearchOptionBase[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSortOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption"), com.ptvag.xserver.xlocate.SortOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfResultField_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField"), com.ptvag.xserver.xlocate.ResultField[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiAddressResponse"));
        oper.setReturnClass(com.ptvag.xserver.xlocate.PoiAddressResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"),
                      "com.ptvag.xserver.xlocate.XLocateException",
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findPoiByLocations");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfPoiLocation_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfPoiLocation"), com.ptvag.xserver.xlocate.PoiLocation[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiLocation"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase"), com.ptvag.xserver.xlocate.SearchOptionBase[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSortOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption"), com.ptvag.xserver.xlocate.SortOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfResultField_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField"), com.ptvag.xserver.xlocate.ResultField[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfPoiAddressResponse"));
        oper.setReturnClass(com.ptvag.xserver.xlocate.PoiAddressResponse[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiAddressResponse"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"),
                      "com.ptvag.xserver.xlocate.XLocateException",
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("matchAddress");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "Address_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "Address"), com.ptvag.xserver.xlocate.Address.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase"), com.ptvag.xserver.xlocate.SearchOptionBase[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSortOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption"), com.ptvag.xserver.xlocate.SortOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfResultField_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField"), com.ptvag.xserver.xlocate.ResultField[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultAddress"));
        oper.setReturnClass(com.ptvag.xserver.xlocate.ResultAddress[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultAddress"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"),
                      "com.ptvag.xserver.xlocate.XLocateException",
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("matchAddresses");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfAddress_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfAddress"), com.ptvag.xserver.xlocate.Address[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "Address"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase"), com.ptvag.xserver.xlocate.SearchOptionBase[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSortOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption"), com.ptvag.xserver.xlocate.SortOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfResultField_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField"), com.ptvag.xserver.xlocate.ResultField[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfArrayOfResultAddress"));
        oper.setReturnClass(com.ptvag.xserver.xlocate.ResultAddress[][].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultAddress"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"),
                      "com.ptvag.xserver.xlocate.XLocateException",
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("matchLocation");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "Point_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"), com.ptvag.xserver.common.Point.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase"), com.ptvag.xserver.xlocate.SearchOptionBase[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSortOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption"), com.ptvag.xserver.xlocate.SortOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfResultField_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField"), com.ptvag.xserver.xlocate.ResultField[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultAddress"));
        oper.setReturnClass(com.ptvag.xserver.xlocate.ResultAddress[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultAddress"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"),
                      "com.ptvag.xserver.xlocate.XLocateException",
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("matchLocations");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfPoint_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPoint"), com.ptvag.xserver.common.Point[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase"), com.ptvag.xserver.xlocate.SearchOptionBase[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfSortOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption"), com.ptvag.xserver.xlocate.SortOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "ArrayOfResultField_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField"), com.ptvag.xserver.xlocate.ResultField[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfArrayOfResultAddress"));
        oper.setReturnClass(com.ptvag.xserver.xlocate.ResultAddress[][].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultAddress"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"),
                      "com.ptvag.xserver.xlocate.XLocateException",
                      new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[11] = oper;

    }

    public XLocateWSBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public XLocateWSBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public XLocateWSBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "ArrayOfCallerContextProperty");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.CallerContextProperty[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty");
            qName2 = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.CallerContext.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.CallerContextProperty.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfGeometryEncoding");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.GeometryEncoding[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryEncoding");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryEncoding");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainGeometryBase");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainGeometryBase[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryBase");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryBase");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainLinearRing");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainLinearRing[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLinearRing");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLinearRing");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainLineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainLineString[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLineString");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLineString");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainPoint[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainPolygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainPolygon[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPolygon");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPolygon");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.Point[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "BoundingBox");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.BoundingBox.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "CoordFormat");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.CoordFormat.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "EncodedGeometry");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.EncodedGeometry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "EncodedGeometryBase");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.EncodedGeometryBase.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryCollection");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.GeometryCollection.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryEncoding");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.GeometryEncoding.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "LinearRing");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.LinearRing.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "LineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.LineString.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "MultiLineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.MultiLineString.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "MultiPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.MultiPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "MultiPolygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.MultiPolygon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryBase");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainGeometryBase.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryCollection");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainGeometryCollection.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLinearRing");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainLinearRing.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainLineString.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainMultiLineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainMultiLineString.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainMultiPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainMultiPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainMultiPolygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainMultiPolygon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPolygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainPolygon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.Point.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Polygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.Polygon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "RequestOptions");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.RequestOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.XServiceException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "BaseException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.BaseException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "BusinessException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.BusinessException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "IllegalParameterException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.IllegalParameterException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ParameterNotSetException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.ParameterNotSetException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "RemoteAccessException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.RemoteAccessException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "StackElement");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.StackElement.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.SystemException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.UnexpectedException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://value.core.jabba.ptvag.com", "TransientVO");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.value.TransientVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "String");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "AdditionalField");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.AdditionalField.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "Address");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.Address.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "AddressResponse");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.AddressResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfAdditionalField");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.AdditionalField[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "AdditionalField");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "AdditionalField");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfAddress");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.Address[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "Address");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "Address");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfAddressResponse");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.AddressResponse[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "AddressResponse");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "AddressResponse");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfArrayOfResultAddress");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.ResultAddress[][].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultAddress");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultAddress");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfLocation");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.Location[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "Location");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "Location");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfPoiAddress");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.PoiAddress[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiAddress");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiAddress");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfPoiAddressResponse");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.PoiAddressResponse[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiAddressResponse");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiAddressResponse");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfPoiLocation");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.PoiLocation[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiLocation");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiLocation");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfPoiResultAddress");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.PoiResultAddress[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiResultAddress");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiResultAddress");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultAddress");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.ResultAddress[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultAddress");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultAddress");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfResultField");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.ResultField[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSearchOptionBase");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.SearchOptionBase[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ArrayOfSortOption");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.SortOption[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption");
            qName2 = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ClassificationDescription");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.ClassificationDescription.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "DetailLevelDescription");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.DetailLevelDescription.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "Location");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.Location.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "NamedSearchOption");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.NamedSearchOption.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiAddress");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.PoiAddress.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiAddressResponse");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.PoiAddressResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiLocation");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.PoiLocation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiResultAddress");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.PoiResultAddress.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiSearchOption");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.PoiSearchOption.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiSearchParameter");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.PoiSearchParameter.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultAddress");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.ResultAddress.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.ResultField.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ReverseSearchOption");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.ReverseSearchOption.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ReverseSearchParameter");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.ReverseSearchParameter.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOption");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.SearchOption.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchOptionBase");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.SearchOptionBase.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchParameter");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.SearchParameter.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.SortOption.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOrder");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.SortOrder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "XLocateException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xlocate.XLocateException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.ptvag.xserver.xlocate.AddressResponse findAddress(com.ptvag.xserver.xlocate.Address address_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "findAddress"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {address_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xlocate.AddressResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xlocate.AddressResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xlocate.AddressResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xlocate.XLocateException) {
              throw (com.ptvag.xserver.xlocate.XLocateException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xlocate.AddressResponse[] findAddresses(com.ptvag.xserver.xlocate.Address[] arrayOfAddress_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "findAddresses"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfAddress_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xlocate.AddressResponse[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xlocate.AddressResponse[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xlocate.AddressResponse[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xlocate.XLocateException) {
              throw (com.ptvag.xserver.xlocate.XLocateException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xlocate.AddressResponse findLocation(com.ptvag.xserver.xlocate.Location location_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "findLocation"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {location_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xlocate.AddressResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xlocate.AddressResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xlocate.AddressResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xlocate.XLocateException) {
              throw (com.ptvag.xserver.xlocate.XLocateException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xlocate.AddressResponse[] findLocations(com.ptvag.xserver.xlocate.Location[] arrayOfLocation_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "findLocations"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfLocation_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xlocate.AddressResponse[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xlocate.AddressResponse[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xlocate.AddressResponse[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xlocate.XLocateException) {
              throw (com.ptvag.xserver.xlocate.XLocateException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xlocate.PoiAddressResponse findPoiByAddress(com.ptvag.xserver.xlocate.PoiAddress poiAddress_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "findPoiByAddress"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {poiAddress_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xlocate.PoiAddressResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xlocate.PoiAddressResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xlocate.PoiAddressResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xlocate.XLocateException) {
              throw (com.ptvag.xserver.xlocate.XLocateException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xlocate.PoiAddressResponse[] findPoiByAddresses(com.ptvag.xserver.xlocate.PoiAddress[] arrayOfPoiAddress_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "findPoiByAddresses"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfPoiAddress_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xlocate.PoiAddressResponse[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xlocate.PoiAddressResponse[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xlocate.PoiAddressResponse[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xlocate.XLocateException) {
              throw (com.ptvag.xserver.xlocate.XLocateException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xlocate.PoiAddressResponse findPoiByLocation(com.ptvag.xserver.xlocate.PoiLocation poiLocation_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "findPoiByLocation"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {poiLocation_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xlocate.PoiAddressResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xlocate.PoiAddressResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xlocate.PoiAddressResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xlocate.XLocateException) {
              throw (com.ptvag.xserver.xlocate.XLocateException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xlocate.PoiAddressResponse[] findPoiByLocations(com.ptvag.xserver.xlocate.PoiLocation[] arrayOfPoiLocation_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "findPoiByLocations"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfPoiLocation_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xlocate.PoiAddressResponse[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xlocate.PoiAddressResponse[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xlocate.PoiAddressResponse[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xlocate.XLocateException) {
              throw (com.ptvag.xserver.xlocate.XLocateException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xlocate.ResultAddress[] matchAddress(com.ptvag.xserver.xlocate.Address address_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "matchAddress"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {address_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xlocate.ResultAddress[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xlocate.ResultAddress[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xlocate.ResultAddress[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xlocate.XLocateException) {
              throw (com.ptvag.xserver.xlocate.XLocateException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xlocate.ResultAddress[][] matchAddresses(com.ptvag.xserver.xlocate.Address[] arrayOfAddress_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "matchAddresses"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfAddress_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xlocate.ResultAddress[][]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xlocate.ResultAddress[][]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xlocate.ResultAddress[][].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xlocate.XLocateException) {
              throw (com.ptvag.xserver.xlocate.XLocateException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xlocate.ResultAddress[] matchLocation(com.ptvag.xserver.common.Point point_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "matchLocation"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {point_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xlocate.ResultAddress[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xlocate.ResultAddress[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xlocate.ResultAddress[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xlocate.XLocateException) {
              throw (com.ptvag.xserver.xlocate.XLocateException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xlocate.ResultAddress[][] matchLocations(com.ptvag.xserver.common.Point[] arrayOfPoint_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xlocate.xserver.ptvag.com", "matchLocations"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfPoint_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xlocate.ResultAddress[][]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xlocate.ResultAddress[][]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xlocate.ResultAddress[][].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xlocate.XLocateException) {
              throw (com.ptvag.xserver.xlocate.XLocateException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

}
