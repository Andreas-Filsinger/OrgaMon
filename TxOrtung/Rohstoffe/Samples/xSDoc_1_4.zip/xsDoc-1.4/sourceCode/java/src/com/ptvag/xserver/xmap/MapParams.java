/**
 * MapParams.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class MapParams  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private boolean showScale;  // attribute

    private boolean useMiles;  // attribute

    public MapParams() {
    }

    public MapParams(
           boolean showScale,
           boolean useMiles) {
        this.showScale = showScale;
        this.useMiles = useMiles;
    }


    /**
     * Gets the showScale value for this MapParams.
     * 
     * @return showScale
     */
    public boolean isShowScale() {
        return showScale;
    }


    /**
     * Sets the showScale value for this MapParams.
     * 
     * @param showScale
     */
    public void setShowScale(boolean showScale) {
        this.showScale = showScale;
    }


    /**
     * Gets the useMiles value for this MapParams.
     * 
     * @return useMiles
     */
    public boolean isUseMiles() {
        return useMiles;
    }


    /**
     * Sets the useMiles value for this MapParams.
     * 
     * @param useMiles
     */
    public void setUseMiles(boolean useMiles) {
        this.useMiles = useMiles;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MapParams)) return false;
        MapParams other = (MapParams) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.showScale == other.isShowScale() &&
            this.useMiles == other.isUseMiles();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += (isShowScale() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isUseMiles() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MapParams.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "MapParams"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("showScale");
        attrField.setXmlName(new javax.xml.namespace.QName("", "showScale"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("useMiles");
        attrField.setXmlName(new javax.xml.namespace.QName("", "useMiles"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
