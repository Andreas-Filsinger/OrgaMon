/**
 * TollCostInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class TollCostInfo  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.TollStationDescription tollStationFrom;

    private com.ptvag.xserver.xroute.TollStationDescription tollStationTo;

    private com.ptvag.xserver.xroute.Currency currency;  // attribute

    private java.lang.String currencyName;  // attribute

    private java.lang.String streetName;  // attribute

    private int tollDistance;  // attribute

    private int tollPrice;  // attribute

    private int tollProviderID;  // attribute

    private java.lang.String tollProviderName;  // attribute

    private int tollSectionID;  // attribute

    private java.lang.String tollSectionName;  // attribute

    private com.ptvag.xserver.xroute.TollType tollType;  // attribute

    private java.lang.Integer vehicleTarifID;  // attribute

    public TollCostInfo() {
    }

    public TollCostInfo(
           com.ptvag.xserver.xroute.Currency currency,
           java.lang.String currencyName,
           java.lang.String streetName,
           int tollDistance,
           int tollPrice,
           int tollProviderID,
           java.lang.String tollProviderName,
           int tollSectionID,
           java.lang.String tollSectionName,
           com.ptvag.xserver.xroute.TollType tollType,
           java.lang.Integer vehicleTarifID,
           com.ptvag.xserver.xroute.TollStationDescription tollStationFrom,
           com.ptvag.xserver.xroute.TollStationDescription tollStationTo) {
        this.currency = currency;
        this.currencyName = currencyName;
        this.streetName = streetName;
        this.tollDistance = tollDistance;
        this.tollPrice = tollPrice;
        this.tollProviderID = tollProviderID;
        this.tollProviderName = tollProviderName;
        this.tollSectionID = tollSectionID;
        this.tollSectionName = tollSectionName;
        this.tollType = tollType;
        this.vehicleTarifID = vehicleTarifID;
        this.tollStationFrom = tollStationFrom;
        this.tollStationTo = tollStationTo;
    }


    /**
     * Gets the tollStationFrom value for this TollCostInfo.
     * 
     * @return tollStationFrom
     */
    public com.ptvag.xserver.xroute.TollStationDescription getTollStationFrom() {
        return tollStationFrom;
    }


    /**
     * Sets the tollStationFrom value for this TollCostInfo.
     * 
     * @param tollStationFrom
     */
    public void setTollStationFrom(com.ptvag.xserver.xroute.TollStationDescription tollStationFrom) {
        this.tollStationFrom = tollStationFrom;
    }


    /**
     * Gets the tollStationTo value for this TollCostInfo.
     * 
     * @return tollStationTo
     */
    public com.ptvag.xserver.xroute.TollStationDescription getTollStationTo() {
        return tollStationTo;
    }


    /**
     * Sets the tollStationTo value for this TollCostInfo.
     * 
     * @param tollStationTo
     */
    public void setTollStationTo(com.ptvag.xserver.xroute.TollStationDescription tollStationTo) {
        this.tollStationTo = tollStationTo;
    }


    /**
     * Gets the currency value for this TollCostInfo.
     * 
     * @return currency
     */
    public com.ptvag.xserver.xroute.Currency getCurrency() {
        return currency;
    }


    /**
     * Sets the currency value for this TollCostInfo.
     * 
     * @param currency
     */
    public void setCurrency(com.ptvag.xserver.xroute.Currency currency) {
        this.currency = currency;
    }


    /**
     * Gets the currencyName value for this TollCostInfo.
     * 
     * @return currencyName
     */
    public java.lang.String getCurrencyName() {
        return currencyName;
    }


    /**
     * Sets the currencyName value for this TollCostInfo.
     * 
     * @param currencyName
     */
    public void setCurrencyName(java.lang.String currencyName) {
        this.currencyName = currencyName;
    }


    /**
     * Gets the streetName value for this TollCostInfo.
     * 
     * @return streetName
     */
    public java.lang.String getStreetName() {
        return streetName;
    }


    /**
     * Sets the streetName value for this TollCostInfo.
     * 
     * @param streetName
     */
    public void setStreetName(java.lang.String streetName) {
        this.streetName = streetName;
    }


    /**
     * Gets the tollDistance value for this TollCostInfo.
     * 
     * @return tollDistance
     */
    public int getTollDistance() {
        return tollDistance;
    }


    /**
     * Sets the tollDistance value for this TollCostInfo.
     * 
     * @param tollDistance
     */
    public void setTollDistance(int tollDistance) {
        this.tollDistance = tollDistance;
    }


    /**
     * Gets the tollPrice value for this TollCostInfo.
     * 
     * @return tollPrice
     */
    public int getTollPrice() {
        return tollPrice;
    }


    /**
     * Sets the tollPrice value for this TollCostInfo.
     * 
     * @param tollPrice
     */
    public void setTollPrice(int tollPrice) {
        this.tollPrice = tollPrice;
    }


    /**
     * Gets the tollProviderID value for this TollCostInfo.
     * 
     * @return tollProviderID
     */
    public int getTollProviderID() {
        return tollProviderID;
    }


    /**
     * Sets the tollProviderID value for this TollCostInfo.
     * 
     * @param tollProviderID
     */
    public void setTollProviderID(int tollProviderID) {
        this.tollProviderID = tollProviderID;
    }


    /**
     * Gets the tollProviderName value for this TollCostInfo.
     * 
     * @return tollProviderName
     */
    public java.lang.String getTollProviderName() {
        return tollProviderName;
    }


    /**
     * Sets the tollProviderName value for this TollCostInfo.
     * 
     * @param tollProviderName
     */
    public void setTollProviderName(java.lang.String tollProviderName) {
        this.tollProviderName = tollProviderName;
    }


    /**
     * Gets the tollSectionID value for this TollCostInfo.
     * 
     * @return tollSectionID
     */
    public int getTollSectionID() {
        return tollSectionID;
    }


    /**
     * Sets the tollSectionID value for this TollCostInfo.
     * 
     * @param tollSectionID
     */
    public void setTollSectionID(int tollSectionID) {
        this.tollSectionID = tollSectionID;
    }


    /**
     * Gets the tollSectionName value for this TollCostInfo.
     * 
     * @return tollSectionName
     */
    public java.lang.String getTollSectionName() {
        return tollSectionName;
    }


    /**
     * Sets the tollSectionName value for this TollCostInfo.
     * 
     * @param tollSectionName
     */
    public void setTollSectionName(java.lang.String tollSectionName) {
        this.tollSectionName = tollSectionName;
    }


    /**
     * Gets the tollType value for this TollCostInfo.
     * 
     * @return tollType
     */
    public com.ptvag.xserver.xroute.TollType getTollType() {
        return tollType;
    }


    /**
     * Sets the tollType value for this TollCostInfo.
     * 
     * @param tollType
     */
    public void setTollType(com.ptvag.xserver.xroute.TollType tollType) {
        this.tollType = tollType;
    }


    /**
     * Gets the vehicleTarifID value for this TollCostInfo.
     * 
     * @return vehicleTarifID
     */
    public java.lang.Integer getVehicleTarifID() {
        return vehicleTarifID;
    }


    /**
     * Sets the vehicleTarifID value for this TollCostInfo.
     * 
     * @param vehicleTarifID
     */
    public void setVehicleTarifID(java.lang.Integer vehicleTarifID) {
        this.vehicleTarifID = vehicleTarifID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TollCostInfo)) return false;
        TollCostInfo other = (TollCostInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.tollStationFrom==null && other.getTollStationFrom()==null) || 
             (this.tollStationFrom!=null &&
              this.tollStationFrom.equals(other.getTollStationFrom()))) &&
            ((this.tollStationTo==null && other.getTollStationTo()==null) || 
             (this.tollStationTo!=null &&
              this.tollStationTo.equals(other.getTollStationTo()))) &&
            ((this.currency==null && other.getCurrency()==null) || 
             (this.currency!=null &&
              this.currency.equals(other.getCurrency()))) &&
            ((this.currencyName==null && other.getCurrencyName()==null) || 
             (this.currencyName!=null &&
              this.currencyName.equals(other.getCurrencyName()))) &&
            ((this.streetName==null && other.getStreetName()==null) || 
             (this.streetName!=null &&
              this.streetName.equals(other.getStreetName()))) &&
            this.tollDistance == other.getTollDistance() &&
            this.tollPrice == other.getTollPrice() &&
            this.tollProviderID == other.getTollProviderID() &&
            ((this.tollProviderName==null && other.getTollProviderName()==null) || 
             (this.tollProviderName!=null &&
              this.tollProviderName.equals(other.getTollProviderName()))) &&
            this.tollSectionID == other.getTollSectionID() &&
            ((this.tollSectionName==null && other.getTollSectionName()==null) || 
             (this.tollSectionName!=null &&
              this.tollSectionName.equals(other.getTollSectionName()))) &&
            ((this.tollType==null && other.getTollType()==null) || 
             (this.tollType!=null &&
              this.tollType.equals(other.getTollType()))) &&
            ((this.vehicleTarifID==null && other.getVehicleTarifID()==null) || 
             (this.vehicleTarifID!=null &&
              this.vehicleTarifID.equals(other.getVehicleTarifID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getTollStationFrom() != null) {
            _hashCode += getTollStationFrom().hashCode();
        }
        if (getTollStationTo() != null) {
            _hashCode += getTollStationTo().hashCode();
        }
        if (getCurrency() != null) {
            _hashCode += getCurrency().hashCode();
        }
        if (getCurrencyName() != null) {
            _hashCode += getCurrencyName().hashCode();
        }
        if (getStreetName() != null) {
            _hashCode += getStreetName().hashCode();
        }
        _hashCode += getTollDistance();
        _hashCode += getTollPrice();
        _hashCode += getTollProviderID();
        if (getTollProviderName() != null) {
            _hashCode += getTollProviderName().hashCode();
        }
        _hashCode += getTollSectionID();
        if (getTollSectionName() != null) {
            _hashCode += getTollSectionName().hashCode();
        }
        if (getTollType() != null) {
            _hashCode += getTollType().hashCode();
        }
        if (getVehicleTarifID() != null) {
            _hashCode += getVehicleTarifID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TollCostInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TollCostInfo"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("currency");
        attrField.setXmlName(new javax.xml.namespace.QName("", "currency"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Currency"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("currencyName");
        attrField.setXmlName(new javax.xml.namespace.QName("", "currencyName"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("streetName");
        attrField.setXmlName(new javax.xml.namespace.QName("", "streetName"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tollDistance");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tollDistance"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tollPrice");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tollPrice"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tollProviderID");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tollProviderID"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tollProviderName");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tollProviderName"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tollSectionID");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tollSectionID"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tollSectionName");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tollSectionName"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tollType");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tollType"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TollType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("vehicleTarifID");
        attrField.setXmlName(new javax.xml.namespace.QName("", "vehicleTarifID"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tollStationFrom");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "tollStationFrom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TollStationDescription"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tollStationTo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "tollStationTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TollStationDescription"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
