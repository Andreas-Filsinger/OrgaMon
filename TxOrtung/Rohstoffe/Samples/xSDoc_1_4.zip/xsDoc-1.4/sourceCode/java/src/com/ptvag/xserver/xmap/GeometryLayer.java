/**
 * GeometryLayer.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class GeometryLayer  extends com.ptvag.xserver.xmap.Layer  implements java.io.Serializable {
    private com.ptvag.xserver.xmap.Geometries[] wrappedGeometries;

    private int drawPriority;  // attribute

    private com.ptvag.xserver.xmap.ObjectInfoType objectInfos;  // attribute

    public GeometryLayer() {
    }

    public GeometryLayer(
           java.lang.String name,
           boolean visible,
           int drawPriority,
           com.ptvag.xserver.xmap.ObjectInfoType objectInfos,
           com.ptvag.xserver.xmap.Geometries[] wrappedGeometries) {
        super(
            name,
            visible);
        this.drawPriority = drawPriority;
        this.objectInfos = objectInfos;
        this.wrappedGeometries = wrappedGeometries;
    }


    /**
     * Gets the wrappedGeometries value for this GeometryLayer.
     * 
     * @return wrappedGeometries
     */
    public com.ptvag.xserver.xmap.Geometries[] getWrappedGeometries() {
        return wrappedGeometries;
    }


    /**
     * Sets the wrappedGeometries value for this GeometryLayer.
     * 
     * @param wrappedGeometries
     */
    public void setWrappedGeometries(com.ptvag.xserver.xmap.Geometries[] wrappedGeometries) {
        this.wrappedGeometries = wrappedGeometries;
    }


    /**
     * Gets the drawPriority value for this GeometryLayer.
     * 
     * @return drawPriority
     */
    public int getDrawPriority() {
        return drawPriority;
    }


    /**
     * Sets the drawPriority value for this GeometryLayer.
     * 
     * @param drawPriority
     */
    public void setDrawPriority(int drawPriority) {
        this.drawPriority = drawPriority;
    }


    /**
     * Gets the objectInfos value for this GeometryLayer.
     * 
     * @return objectInfos
     */
    public com.ptvag.xserver.xmap.ObjectInfoType getObjectInfos() {
        return objectInfos;
    }


    /**
     * Sets the objectInfos value for this GeometryLayer.
     * 
     * @param objectInfos
     */
    public void setObjectInfos(com.ptvag.xserver.xmap.ObjectInfoType objectInfos) {
        this.objectInfos = objectInfos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GeometryLayer)) return false;
        GeometryLayer other = (GeometryLayer) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedGeometries==null && other.getWrappedGeometries()==null) || 
             (this.wrappedGeometries!=null &&
              java.util.Arrays.equals(this.wrappedGeometries, other.getWrappedGeometries()))) &&
            this.drawPriority == other.getDrawPriority() &&
            ((this.objectInfos==null && other.getObjectInfos()==null) || 
             (this.objectInfos!=null &&
              this.objectInfos.equals(other.getObjectInfos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedGeometries() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedGeometries());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedGeometries(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getDrawPriority();
        if (getObjectInfos() != null) {
            _hashCode += getObjectInfos().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GeometryLayer.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "GeometryLayer"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("drawPriority");
        attrField.setXmlName(new javax.xml.namespace.QName("", "drawPriority"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("objectInfos");
        attrField.setXmlName(new javax.xml.namespace.QName("", "objectInfos"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "ObjectInfoType"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedGeometries");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "wrappedGeometries"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Geometries"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Geometries"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
