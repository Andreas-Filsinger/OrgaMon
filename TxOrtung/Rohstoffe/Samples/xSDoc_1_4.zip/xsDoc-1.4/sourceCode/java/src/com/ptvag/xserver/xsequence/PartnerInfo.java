/**
 * PartnerInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class PartnerInfo  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private int partnerID;  // attribute

    private com.ptvag.xserver.xsequence.PartnerPos precedence;  // attribute

    public PartnerInfo() {
    }

    public PartnerInfo(
           int partnerID,
           com.ptvag.xserver.xsequence.PartnerPos precedence) {
        this.partnerID = partnerID;
        this.precedence = precedence;
    }


    /**
     * Gets the partnerID value for this PartnerInfo.
     * 
     * @return partnerID
     */
    public int getPartnerID() {
        return partnerID;
    }


    /**
     * Sets the partnerID value for this PartnerInfo.
     * 
     * @param partnerID
     */
    public void setPartnerID(int partnerID) {
        this.partnerID = partnerID;
    }


    /**
     * Gets the precedence value for this PartnerInfo.
     * 
     * @return precedence
     */
    public com.ptvag.xserver.xsequence.PartnerPos getPrecedence() {
        return precedence;
    }


    /**
     * Sets the precedence value for this PartnerInfo.
     * 
     * @param precedence
     */
    public void setPrecedence(com.ptvag.xserver.xsequence.PartnerPos precedence) {
        this.precedence = precedence;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PartnerInfo)) return false;
        PartnerInfo other = (PartnerInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.partnerID == other.getPartnerID() &&
            ((this.precedence==null && other.getPrecedence()==null) || 
             (this.precedence!=null &&
              this.precedence.equals(other.getPrecedence())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getPartnerID();
        if (getPrecedence() != null) {
            _hashCode += getPrecedence().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PartnerInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "PartnerInfo"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("partnerID");
        attrField.setXmlName(new javax.xml.namespace.QName("", "partnerID"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("precedence");
        attrField.setXmlName(new javax.xml.namespace.QName("", "precedence"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "PartnerPos"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
