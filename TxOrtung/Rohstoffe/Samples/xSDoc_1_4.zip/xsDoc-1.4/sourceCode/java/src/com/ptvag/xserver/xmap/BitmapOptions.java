/**
 * BitmapOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class BitmapOptions  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.common.PlainPoint referencePoint;

    private com.ptvag.xserver.xmap.Color transparencyColor;

    public BitmapOptions() {
    }

    public BitmapOptions(
           com.ptvag.xserver.common.PlainPoint referencePoint,
           com.ptvag.xserver.xmap.Color transparencyColor) {
        this.referencePoint = referencePoint;
        this.transparencyColor = transparencyColor;
    }


    /**
     * Gets the referencePoint value for this BitmapOptions.
     * 
     * @return referencePoint
     */
    public com.ptvag.xserver.common.PlainPoint getReferencePoint() {
        return referencePoint;
    }


    /**
     * Sets the referencePoint value for this BitmapOptions.
     * 
     * @param referencePoint
     */
    public void setReferencePoint(com.ptvag.xserver.common.PlainPoint referencePoint) {
        this.referencePoint = referencePoint;
    }


    /**
     * Gets the transparencyColor value for this BitmapOptions.
     * 
     * @return transparencyColor
     */
    public com.ptvag.xserver.xmap.Color getTransparencyColor() {
        return transparencyColor;
    }


    /**
     * Sets the transparencyColor value for this BitmapOptions.
     * 
     * @param transparencyColor
     */
    public void setTransparencyColor(com.ptvag.xserver.xmap.Color transparencyColor) {
        this.transparencyColor = transparencyColor;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BitmapOptions)) return false;
        BitmapOptions other = (BitmapOptions) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.referencePoint==null && other.getReferencePoint()==null) || 
             (this.referencePoint!=null &&
              this.referencePoint.equals(other.getReferencePoint()))) &&
            ((this.transparencyColor==null && other.getTransparencyColor()==null) || 
             (this.transparencyColor!=null &&
              this.transparencyColor.equals(other.getTransparencyColor())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getReferencePoint() != null) {
            _hashCode += getReferencePoint().hashCode();
        }
        if (getTransparencyColor() != null) {
            _hashCode += getTransparencyColor().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BitmapOptions.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "BitmapOptions"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referencePoint");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "referencePoint"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transparencyColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "transparencyColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Color"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
