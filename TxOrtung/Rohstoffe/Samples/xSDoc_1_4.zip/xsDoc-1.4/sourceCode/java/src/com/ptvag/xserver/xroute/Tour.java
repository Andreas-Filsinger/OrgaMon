/**
 * Tour.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class Tour  extends com.ptvag.xserver.xroute.ExtendedRoute  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.TimeEvent[] wrappedTimeEvents;

    private com.ptvag.xserver.xroute.TourPoint[] wrappedTourPoints;

    private com.ptvag.xserver.xroute.TourSummary tourSummary;

    public Tour() {
    }

    public Tour(
           com.ptvag.xserver.xroute.CountryInfo[] wrappedCountryInfos,
           com.ptvag.xserver.xroute.Route route,
           com.ptvag.xserver.xroute.TimeEvent[] wrappedTimeEvents,
           com.ptvag.xserver.xroute.TourPoint[] wrappedTourPoints,
           com.ptvag.xserver.xroute.TourSummary tourSummary) {
        super(
            wrappedCountryInfos,
            route);
        this.wrappedTimeEvents = wrappedTimeEvents;
        this.wrappedTourPoints = wrappedTourPoints;
        this.tourSummary = tourSummary;
    }


    /**
     * Gets the wrappedTimeEvents value for this Tour.
     * 
     * @return wrappedTimeEvents
     */
    public com.ptvag.xserver.xroute.TimeEvent[] getWrappedTimeEvents() {
        return wrappedTimeEvents;
    }


    /**
     * Sets the wrappedTimeEvents value for this Tour.
     * 
     * @param wrappedTimeEvents
     */
    public void setWrappedTimeEvents(com.ptvag.xserver.xroute.TimeEvent[] wrappedTimeEvents) {
        this.wrappedTimeEvents = wrappedTimeEvents;
    }


    /**
     * Gets the wrappedTourPoints value for this Tour.
     * 
     * @return wrappedTourPoints
     */
    public com.ptvag.xserver.xroute.TourPoint[] getWrappedTourPoints() {
        return wrappedTourPoints;
    }


    /**
     * Sets the wrappedTourPoints value for this Tour.
     * 
     * @param wrappedTourPoints
     */
    public void setWrappedTourPoints(com.ptvag.xserver.xroute.TourPoint[] wrappedTourPoints) {
        this.wrappedTourPoints = wrappedTourPoints;
    }


    /**
     * Gets the tourSummary value for this Tour.
     * 
     * @return tourSummary
     */
    public com.ptvag.xserver.xroute.TourSummary getTourSummary() {
        return tourSummary;
    }


    /**
     * Sets the tourSummary value for this Tour.
     * 
     * @param tourSummary
     */
    public void setTourSummary(com.ptvag.xserver.xroute.TourSummary tourSummary) {
        this.tourSummary = tourSummary;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Tour)) return false;
        Tour other = (Tour) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedTimeEvents==null && other.getWrappedTimeEvents()==null) || 
             (this.wrappedTimeEvents!=null &&
              java.util.Arrays.equals(this.wrappedTimeEvents, other.getWrappedTimeEvents()))) &&
            ((this.wrappedTourPoints==null && other.getWrappedTourPoints()==null) || 
             (this.wrappedTourPoints!=null &&
              java.util.Arrays.equals(this.wrappedTourPoints, other.getWrappedTourPoints()))) &&
            ((this.tourSummary==null && other.getTourSummary()==null) || 
             (this.tourSummary!=null &&
              this.tourSummary.equals(other.getTourSummary())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedTimeEvents() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedTimeEvents());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedTimeEvents(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedTourPoints() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedTourPoints());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedTourPoints(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTourSummary() != null) {
            _hashCode += getTourSummary().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Tour.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Tour"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedTimeEvents");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedTimeEvents"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TimeEvent"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TimeEvent"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedTourPoints");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedTourPoints"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TourPoint"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TourPoint"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tourSummary");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "tourSummary"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TourSummary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
