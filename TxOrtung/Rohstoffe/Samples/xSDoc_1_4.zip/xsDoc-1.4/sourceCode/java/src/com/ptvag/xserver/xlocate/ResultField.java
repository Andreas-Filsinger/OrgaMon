/**
 * ResultField.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xlocate;

public class ResultField implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected ResultField(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _COUNTRY = "COUNTRY";
    public static final java.lang.String _STATE = "STATE";
    public static final java.lang.String _ADMINREGION = "ADMINREGION";
    public static final java.lang.String _CITY = "CITY";
    public static final java.lang.String _CITY2 = "CITY2";
    public static final java.lang.String _POSTCODE = "POSTCODE";
    public static final java.lang.String _STREET = "STREET";
    public static final java.lang.String _HOUSENR = "HOUSENR";
    public static final java.lang.String _COORDX = "COORDX";
    public static final java.lang.String _COORDY = "COORDY";
    public static final java.lang.String _DETAILLEVEL = "DETAILLEVEL";
    public static final java.lang.String _DETAILLEVEL_DESCRIPTION = "DETAILLEVEL_DESCRIPTION";
    public static final java.lang.String _POPULATION = "POPULATION";
    public static final java.lang.String _EXTENSIONCLASS = "EXTENSIONCLASS";
    public static final java.lang.String _LEVEL = "LEVEL";
    public static final java.lang.String _ISCITYDISTRICT = "ISCITYDISTRICT";
    public static final java.lang.String _COUNTRY_ISO2 = "COUNTRY_ISO2";
    public static final java.lang.String _COUNTRY_ISO3 = "COUNTRY_ISO3";
    public static final java.lang.String _COUNTRY_COUNTRYCODEPLATE = "COUNTRY_COUNTRYCODEPLATE";
    public static final java.lang.String _COUNTRY_DIALINGCODE = "COUNTRY_DIALINGCODE";
    public static final java.lang.String _COUNTRY_CAPITAL = "COUNTRY_CAPITAL";
    public static final java.lang.String _COUNTRY_NAME = "COUNTRY_NAME";
    public static final java.lang.String _HOUSENR_SIDE = "HOUSENR_SIDE";
    public static final java.lang.String _HOUSENR_STRUCTURE = "HOUSENR_STRUCTURE";
    public static final java.lang.String _HOUSENR_STARTFORMAT = "HOUSENR_STARTFORMAT";
    public static final java.lang.String _HOUSENR_ENDFORMAT = "HOUSENR_ENDFORMAT";
    public static final java.lang.String _APPENDIX = "APPENDIX";
    public static final java.lang.String _SCORE_TOTALSCORE = "SCORE_TOTALSCORE";
    public static final java.lang.String _SCORE_FINALPENALTY = "SCORE_FINALPENALTY";
    public static final java.lang.String _FOUNDBY_CITY = "FOUNDBY_CITY";
    public static final java.lang.String _FOUNDBY_CITY2 = "FOUNDBY_CITY2";
    public static final java.lang.String _FOUNDBY_POSTCODE = "FOUNDBY_POSTCODE";
    public static final java.lang.String _FOUNDBY_STREET = "FOUNDBY_STREET";
    public static final java.lang.String _CLASSIFICATION = "CLASSIFICATION";
    public static final java.lang.String _CLASSIFICATION_DESCRIPTION = "CLASSIFICATION_DESCRIPTION";
    public static final java.lang.String _SWAPANDSPLITMODE = "SWAPANDSPLITMODE";
    public static final ResultField COUNTRY = new ResultField(_COUNTRY);
    public static final ResultField STATE = new ResultField(_STATE);
    public static final ResultField ADMINREGION = new ResultField(_ADMINREGION);
    public static final ResultField CITY = new ResultField(_CITY);
    public static final ResultField CITY2 = new ResultField(_CITY2);
    public static final ResultField POSTCODE = new ResultField(_POSTCODE);
    public static final ResultField STREET = new ResultField(_STREET);
    public static final ResultField HOUSENR = new ResultField(_HOUSENR);
    public static final ResultField COORDX = new ResultField(_COORDX);
    public static final ResultField COORDY = new ResultField(_COORDY);
    public static final ResultField DETAILLEVEL = new ResultField(_DETAILLEVEL);
    public static final ResultField DETAILLEVEL_DESCRIPTION = new ResultField(_DETAILLEVEL_DESCRIPTION);
    public static final ResultField POPULATION = new ResultField(_POPULATION);
    public static final ResultField EXTENSIONCLASS = new ResultField(_EXTENSIONCLASS);
    public static final ResultField LEVEL = new ResultField(_LEVEL);
    public static final ResultField ISCITYDISTRICT = new ResultField(_ISCITYDISTRICT);
    public static final ResultField COUNTRY_ISO2 = new ResultField(_COUNTRY_ISO2);
    public static final ResultField COUNTRY_ISO3 = new ResultField(_COUNTRY_ISO3);
    public static final ResultField COUNTRY_COUNTRYCODEPLATE = new ResultField(_COUNTRY_COUNTRYCODEPLATE);
    public static final ResultField COUNTRY_DIALINGCODE = new ResultField(_COUNTRY_DIALINGCODE);
    public static final ResultField COUNTRY_CAPITAL = new ResultField(_COUNTRY_CAPITAL);
    public static final ResultField COUNTRY_NAME = new ResultField(_COUNTRY_NAME);
    public static final ResultField HOUSENR_SIDE = new ResultField(_HOUSENR_SIDE);
    public static final ResultField HOUSENR_STRUCTURE = new ResultField(_HOUSENR_STRUCTURE);
    public static final ResultField HOUSENR_STARTFORMAT = new ResultField(_HOUSENR_STARTFORMAT);
    public static final ResultField HOUSENR_ENDFORMAT = new ResultField(_HOUSENR_ENDFORMAT);
    public static final ResultField APPENDIX = new ResultField(_APPENDIX);
    public static final ResultField SCORE_TOTALSCORE = new ResultField(_SCORE_TOTALSCORE);
    public static final ResultField SCORE_FINALPENALTY = new ResultField(_SCORE_FINALPENALTY);
    public static final ResultField FOUNDBY_CITY = new ResultField(_FOUNDBY_CITY);
    public static final ResultField FOUNDBY_CITY2 = new ResultField(_FOUNDBY_CITY2);
    public static final ResultField FOUNDBY_POSTCODE = new ResultField(_FOUNDBY_POSTCODE);
    public static final ResultField FOUNDBY_STREET = new ResultField(_FOUNDBY_STREET);
    public static final ResultField CLASSIFICATION = new ResultField(_CLASSIFICATION);
    public static final ResultField CLASSIFICATION_DESCRIPTION = new ResultField(_CLASSIFICATION_DESCRIPTION);
    public static final ResultField SWAPANDSPLITMODE = new ResultField(_SWAPANDSPLITMODE);
    public java.lang.String getValue() { return _value_;}
    public static ResultField fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        ResultField enumeration = (ResultField)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static ResultField fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ResultField.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
