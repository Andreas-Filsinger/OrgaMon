/**
 * TrafficInfoServiceWSService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.trafficinfoservice.jwsdp;

public interface TrafficInfoServiceWSService extends javax.xml.rpc.Service {
    public java.lang.String getTrafficInfoServiceWSPortAddress();

    public com.ptvag.mnp.trafficinfoservice.jwsdp.TrafficInfoServiceWS getTrafficInfoServiceWSPort() throws javax.xml.rpc.ServiceException;

    public com.ptvag.mnp.trafficinfoservice.jwsdp.TrafficInfoServiceWS getTrafficInfoServiceWSPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
