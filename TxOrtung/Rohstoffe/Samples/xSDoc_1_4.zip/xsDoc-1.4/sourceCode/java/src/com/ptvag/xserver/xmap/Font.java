/**
 * Font.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class Font  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private boolean bold;  // attribute

    private boolean frame;  // attribute

    private boolean italic;  // attribute

    private java.lang.String name;  // attribute

    private int size;  // attribute

    private boolean underline;  // attribute

    public Font() {
    }

    public Font(
           boolean bold,
           boolean frame,
           boolean italic,
           java.lang.String name,
           int size,
           boolean underline) {
        this.bold = bold;
        this.frame = frame;
        this.italic = italic;
        this.name = name;
        this.size = size;
        this.underline = underline;
    }


    /**
     * Gets the bold value for this Font.
     * 
     * @return bold
     */
    public boolean isBold() {
        return bold;
    }


    /**
     * Sets the bold value for this Font.
     * 
     * @param bold
     */
    public void setBold(boolean bold) {
        this.bold = bold;
    }


    /**
     * Gets the frame value for this Font.
     * 
     * @return frame
     */
    public boolean isFrame() {
        return frame;
    }


    /**
     * Sets the frame value for this Font.
     * 
     * @param frame
     */
    public void setFrame(boolean frame) {
        this.frame = frame;
    }


    /**
     * Gets the italic value for this Font.
     * 
     * @return italic
     */
    public boolean isItalic() {
        return italic;
    }


    /**
     * Sets the italic value for this Font.
     * 
     * @param italic
     */
    public void setItalic(boolean italic) {
        this.italic = italic;
    }


    /**
     * Gets the name value for this Font.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Font.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the size value for this Font.
     * 
     * @return size
     */
    public int getSize() {
        return size;
    }


    /**
     * Sets the size value for this Font.
     * 
     * @param size
     */
    public void setSize(int size) {
        this.size = size;
    }


    /**
     * Gets the underline value for this Font.
     * 
     * @return underline
     */
    public boolean isUnderline() {
        return underline;
    }


    /**
     * Sets the underline value for this Font.
     * 
     * @param underline
     */
    public void setUnderline(boolean underline) {
        this.underline = underline;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Font)) return false;
        Font other = (Font) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.bold == other.isBold() &&
            this.frame == other.isFrame() &&
            this.italic == other.isItalic() &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            this.size == other.getSize() &&
            this.underline == other.isUnderline();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += (isBold() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isFrame() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isItalic() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        _hashCode += getSize();
        _hashCode += (isUnderline() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Font.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Font"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("bold");
        attrField.setXmlName(new javax.xml.namespace.QName("", "bold"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("frame");
        attrField.setXmlName(new javax.xml.namespace.QName("", "frame"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("italic");
        attrField.setXmlName(new javax.xml.namespace.QName("", "italic"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("name");
        attrField.setXmlName(new javax.xml.namespace.QName("", "name"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("size");
        attrField.setXmlName(new javax.xml.namespace.QName("", "size"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("underline");
        attrField.setXmlName(new javax.xml.namespace.QName("", "underline"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
