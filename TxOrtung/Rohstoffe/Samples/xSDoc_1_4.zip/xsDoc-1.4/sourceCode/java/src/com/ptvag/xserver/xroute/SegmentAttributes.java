/**
 * SegmentAttributes.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class SegmentAttributes  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private java.lang.String additionalInfo;  // attribute

    private java.lang.String additionalRE;  // attribute

    private com.ptvag.xserver.xroute.BrunnelCode brunnelCode;  // attribute

    private boolean hasExtraToll;  // attribute

    private boolean hasSeparator;  // attribute

    private boolean hasTollCar;  // attribute

    private boolean hasTollTruck;  // attribute

    private boolean hasVignetteCar;  // attribute

    private boolean hasVignetteTruck;  // attribute

    private boolean isBlockedCar;  // attribute

    private boolean isBlockedTruck;  // attribute

    private boolean isFerry;  // attribute

    private boolean isPedestrianZone;  // attribute

    public SegmentAttributes() {
    }

    public SegmentAttributes(
           java.lang.String additionalInfo,
           java.lang.String additionalRE,
           com.ptvag.xserver.xroute.BrunnelCode brunnelCode,
           boolean hasExtraToll,
           boolean hasSeparator,
           boolean hasTollCar,
           boolean hasTollTruck,
           boolean hasVignetteCar,
           boolean hasVignetteTruck,
           boolean isBlockedCar,
           boolean isBlockedTruck,
           boolean isFerry,
           boolean isPedestrianZone) {
        this.additionalInfo = additionalInfo;
        this.additionalRE = additionalRE;
        this.brunnelCode = brunnelCode;
        this.hasExtraToll = hasExtraToll;
        this.hasSeparator = hasSeparator;
        this.hasTollCar = hasTollCar;
        this.hasTollTruck = hasTollTruck;
        this.hasVignetteCar = hasVignetteCar;
        this.hasVignetteTruck = hasVignetteTruck;
        this.isBlockedCar = isBlockedCar;
        this.isBlockedTruck = isBlockedTruck;
        this.isFerry = isFerry;
        this.isPedestrianZone = isPedestrianZone;
    }


    /**
     * Gets the additionalInfo value for this SegmentAttributes.
     * 
     * @return additionalInfo
     */
    public java.lang.String getAdditionalInfo() {
        return additionalInfo;
    }


    /**
     * Sets the additionalInfo value for this SegmentAttributes.
     * 
     * @param additionalInfo
     */
    public void setAdditionalInfo(java.lang.String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }


    /**
     * Gets the additionalRE value for this SegmentAttributes.
     * 
     * @return additionalRE
     */
    public java.lang.String getAdditionalRE() {
        return additionalRE;
    }


    /**
     * Sets the additionalRE value for this SegmentAttributes.
     * 
     * @param additionalRE
     */
    public void setAdditionalRE(java.lang.String additionalRE) {
        this.additionalRE = additionalRE;
    }


    /**
     * Gets the brunnelCode value for this SegmentAttributes.
     * 
     * @return brunnelCode
     */
    public com.ptvag.xserver.xroute.BrunnelCode getBrunnelCode() {
        return brunnelCode;
    }


    /**
     * Sets the brunnelCode value for this SegmentAttributes.
     * 
     * @param brunnelCode
     */
    public void setBrunnelCode(com.ptvag.xserver.xroute.BrunnelCode brunnelCode) {
        this.brunnelCode = brunnelCode;
    }


    /**
     * Gets the hasExtraToll value for this SegmentAttributes.
     * 
     * @return hasExtraToll
     */
    public boolean isHasExtraToll() {
        return hasExtraToll;
    }


    /**
     * Sets the hasExtraToll value for this SegmentAttributes.
     * 
     * @param hasExtraToll
     */
    public void setHasExtraToll(boolean hasExtraToll) {
        this.hasExtraToll = hasExtraToll;
    }


    /**
     * Gets the hasSeparator value for this SegmentAttributes.
     * 
     * @return hasSeparator
     */
    public boolean isHasSeparator() {
        return hasSeparator;
    }


    /**
     * Sets the hasSeparator value for this SegmentAttributes.
     * 
     * @param hasSeparator
     */
    public void setHasSeparator(boolean hasSeparator) {
        this.hasSeparator = hasSeparator;
    }


    /**
     * Gets the hasTollCar value for this SegmentAttributes.
     * 
     * @return hasTollCar
     */
    public boolean isHasTollCar() {
        return hasTollCar;
    }


    /**
     * Sets the hasTollCar value for this SegmentAttributes.
     * 
     * @param hasTollCar
     */
    public void setHasTollCar(boolean hasTollCar) {
        this.hasTollCar = hasTollCar;
    }


    /**
     * Gets the hasTollTruck value for this SegmentAttributes.
     * 
     * @return hasTollTruck
     */
    public boolean isHasTollTruck() {
        return hasTollTruck;
    }


    /**
     * Sets the hasTollTruck value for this SegmentAttributes.
     * 
     * @param hasTollTruck
     */
    public void setHasTollTruck(boolean hasTollTruck) {
        this.hasTollTruck = hasTollTruck;
    }


    /**
     * Gets the hasVignetteCar value for this SegmentAttributes.
     * 
     * @return hasVignetteCar
     */
    public boolean isHasVignetteCar() {
        return hasVignetteCar;
    }


    /**
     * Sets the hasVignetteCar value for this SegmentAttributes.
     * 
     * @param hasVignetteCar
     */
    public void setHasVignetteCar(boolean hasVignetteCar) {
        this.hasVignetteCar = hasVignetteCar;
    }


    /**
     * Gets the hasVignetteTruck value for this SegmentAttributes.
     * 
     * @return hasVignetteTruck
     */
    public boolean isHasVignetteTruck() {
        return hasVignetteTruck;
    }


    /**
     * Sets the hasVignetteTruck value for this SegmentAttributes.
     * 
     * @param hasVignetteTruck
     */
    public void setHasVignetteTruck(boolean hasVignetteTruck) {
        this.hasVignetteTruck = hasVignetteTruck;
    }


    /**
     * Gets the isBlockedCar value for this SegmentAttributes.
     * 
     * @return isBlockedCar
     */
    public boolean isIsBlockedCar() {
        return isBlockedCar;
    }


    /**
     * Sets the isBlockedCar value for this SegmentAttributes.
     * 
     * @param isBlockedCar
     */
    public void setIsBlockedCar(boolean isBlockedCar) {
        this.isBlockedCar = isBlockedCar;
    }


    /**
     * Gets the isBlockedTruck value for this SegmentAttributes.
     * 
     * @return isBlockedTruck
     */
    public boolean isIsBlockedTruck() {
        return isBlockedTruck;
    }


    /**
     * Sets the isBlockedTruck value for this SegmentAttributes.
     * 
     * @param isBlockedTruck
     */
    public void setIsBlockedTruck(boolean isBlockedTruck) {
        this.isBlockedTruck = isBlockedTruck;
    }


    /**
     * Gets the isFerry value for this SegmentAttributes.
     * 
     * @return isFerry
     */
    public boolean isIsFerry() {
        return isFerry;
    }


    /**
     * Sets the isFerry value for this SegmentAttributes.
     * 
     * @param isFerry
     */
    public void setIsFerry(boolean isFerry) {
        this.isFerry = isFerry;
    }


    /**
     * Gets the isPedestrianZone value for this SegmentAttributes.
     * 
     * @return isPedestrianZone
     */
    public boolean isIsPedestrianZone() {
        return isPedestrianZone;
    }


    /**
     * Sets the isPedestrianZone value for this SegmentAttributes.
     * 
     * @param isPedestrianZone
     */
    public void setIsPedestrianZone(boolean isPedestrianZone) {
        this.isPedestrianZone = isPedestrianZone;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SegmentAttributes)) return false;
        SegmentAttributes other = (SegmentAttributes) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.additionalInfo==null && other.getAdditionalInfo()==null) || 
             (this.additionalInfo!=null &&
              this.additionalInfo.equals(other.getAdditionalInfo()))) &&
            ((this.additionalRE==null && other.getAdditionalRE()==null) || 
             (this.additionalRE!=null &&
              this.additionalRE.equals(other.getAdditionalRE()))) &&
            ((this.brunnelCode==null && other.getBrunnelCode()==null) || 
             (this.brunnelCode!=null &&
              this.brunnelCode.equals(other.getBrunnelCode()))) &&
            this.hasExtraToll == other.isHasExtraToll() &&
            this.hasSeparator == other.isHasSeparator() &&
            this.hasTollCar == other.isHasTollCar() &&
            this.hasTollTruck == other.isHasTollTruck() &&
            this.hasVignetteCar == other.isHasVignetteCar() &&
            this.hasVignetteTruck == other.isHasVignetteTruck() &&
            this.isBlockedCar == other.isIsBlockedCar() &&
            this.isBlockedTruck == other.isIsBlockedTruck() &&
            this.isFerry == other.isIsFerry() &&
            this.isPedestrianZone == other.isIsPedestrianZone();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAdditionalInfo() != null) {
            _hashCode += getAdditionalInfo().hashCode();
        }
        if (getAdditionalRE() != null) {
            _hashCode += getAdditionalRE().hashCode();
        }
        if (getBrunnelCode() != null) {
            _hashCode += getBrunnelCode().hashCode();
        }
        _hashCode += (isHasExtraToll() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isHasSeparator() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isHasTollCar() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isHasTollTruck() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isHasVignetteCar() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isHasVignetteTruck() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsBlockedCar() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsBlockedTruck() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsFerry() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsPedestrianZone() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SegmentAttributes.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "SegmentAttributes"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("additionalInfo");
        attrField.setXmlName(new javax.xml.namespace.QName("", "additionalInfo"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("additionalRE");
        attrField.setXmlName(new javax.xml.namespace.QName("", "additionalRE"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("brunnelCode");
        attrField.setXmlName(new javax.xml.namespace.QName("", "brunnelCode"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "BrunnelCode"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("hasExtraToll");
        attrField.setXmlName(new javax.xml.namespace.QName("", "hasExtraToll"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("hasSeparator");
        attrField.setXmlName(new javax.xml.namespace.QName("", "hasSeparator"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("hasTollCar");
        attrField.setXmlName(new javax.xml.namespace.QName("", "hasTollCar"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("hasTollTruck");
        attrField.setXmlName(new javax.xml.namespace.QName("", "hasTollTruck"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("hasVignetteCar");
        attrField.setXmlName(new javax.xml.namespace.QName("", "hasVignetteCar"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("hasVignetteTruck");
        attrField.setXmlName(new javax.xml.namespace.QName("", "hasVignetteTruck"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("isBlockedCar");
        attrField.setXmlName(new javax.xml.namespace.QName("", "isBlockedCar"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("isBlockedTruck");
        attrField.setXmlName(new javax.xml.namespace.QName("", "isBlockedTruck"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("isFerry");
        attrField.setXmlName(new javax.xml.namespace.QName("", "isFerry"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("isPedestrianZone");
        attrField.setXmlName(new javax.xml.namespace.QName("", "isPedestrianZone"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
