package com.ptvag.xserver.xroute.jwsdp;

public class XRouteWSProxy implements com.ptvag.xserver.xroute.jwsdp.XRouteWS {
  private String _endpoint = null;
  private com.ptvag.xserver.xroute.jwsdp.XRouteWS xRouteWS = null;
  
  public XRouteWSProxy() {
    _initXRouteWSProxy();
  }
  
  public XRouteWSProxy(String endpoint) {
    _endpoint = endpoint;
    _initXRouteWSProxy();
  }
  
  private void _initXRouteWSProxy() {
    try {
      xRouteWS = (new com.ptvag.xserver.xroute.jwsdp.XRouteWSServiceLocator()).getXRouteWSPort();
      if (xRouteWS != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)xRouteWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)xRouteWS)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (xRouteWS != null)
      ((javax.xml.rpc.Stub)xRouteWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ptvag.xserver.xroute.jwsdp.XRouteWS getXRouteWS() {
    if (xRouteWS == null)
      _initXRouteWSProxy();
    return xRouteWS;
  }
  
  public com.ptvag.xserver.xroute.ExtendedRoute calculateExtendedRoute(com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_1, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_2, com.ptvag.xserver.xroute.ExceptionPath[] arrayOfExceptionPath_3, com.ptvag.xserver.xroute.ResultListOptions resultListOptions_4, com.ptvag.xserver.xroute.CountryInfoOptions countryInfoOptions_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException{
    if (xRouteWS == null)
      _initXRouteWSProxy();
    return xRouteWS.calculateExtendedRoute(arrayOfWaypointDesc_1, arrayOfRoutingOption_2, arrayOfExceptionPath_3, resultListOptions_4, countryInfoOptions_5, callerContext_6);
  }
  
  public com.ptvag.xserver.xroute.Isochrone calculateIsochrones(com.ptvag.xserver.xroute.WaypointDesc waypointDesc_1, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_2, com.ptvag.xserver.xroute.IsochroneOptions isochroneOptions_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException{
    if (xRouteWS == null)
      _initXRouteWSProxy();
    return xRouteWS.calculateIsochrones(waypointDesc_1, arrayOfRoutingOption_2, isochroneOptions_3, callerContext_4);
  }
  
  public com.ptvag.xserver.xroute.MatrixInfo calculateMatrixInfo(com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_1, com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_2, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_3, com.ptvag.xserver.xroute.MatrixOptions matrixOptions_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException{
    if (xRouteWS == null)
      _initXRouteWSProxy();
    return xRouteWS.calculateMatrixInfo(arrayOfWaypointDesc_1, arrayOfWaypointDesc_2, arrayOfRoutingOption_3, matrixOptions_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xroute.Reach calculateReachableObjects(com.ptvag.xserver.xroute.WaypointDesc waypointDesc_1, java.lang.String string_2, com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_3, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_4, com.ptvag.xserver.xroute.ExpansionDescription expansionDescription_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException{
    if (xRouteWS == null)
      _initXRouteWSProxy();
    return xRouteWS.calculateReachableObjects(waypointDesc_1, string_2, arrayOfWaypointDesc_3, arrayOfRoutingOption_4, expansionDescription_5, callerContext_6);
  }
  
  public com.ptvag.xserver.xroute.Route calculateRoute(com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_1, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_2, com.ptvag.xserver.xroute.ExceptionPath[] arrayOfExceptionPath_3, com.ptvag.xserver.xroute.ResultListOptions resultListOptions_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException{
    if (xRouteWS == null)
      _initXRouteWSProxy();
    return xRouteWS.calculateRoute(arrayOfWaypointDesc_1, arrayOfRoutingOption_2, arrayOfExceptionPath_3, resultListOptions_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xroute.RouteInfo calculateRouteInfo(com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_1, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_2, com.ptvag.xserver.xroute.ExceptionPath[] arrayOfExceptionPath_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException{
    if (xRouteWS == null)
      _initXRouteWSProxy();
    return xRouteWS.calculateRouteInfo(arrayOfWaypointDesc_1, arrayOfRoutingOption_2, arrayOfExceptionPath_3, callerContext_4);
  }
  
  public com.ptvag.xserver.xroute.Tour calculateTour(com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_1, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_2, com.ptvag.xserver.xroute.ExceptionPath[] arrayOfExceptionPath_3, com.ptvag.xserver.xroute.ResultListOptions resultListOptions_4, com.ptvag.xserver.xroute.CountryInfoOptions countryInfoOptions_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException{
    if (xRouteWS == null)
      _initXRouteWSProxy();
    return xRouteWS.calculateTour(arrayOfWaypointDesc_1, arrayOfRoutingOption_2, arrayOfExceptionPath_3, resultListOptions_4, countryInfoOptions_5, callerContext_6);
  }
  
  
}