/**
 * RoadSpeedTypeToll.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class RoadSpeedTypeToll  implements java.io.Serializable {
    private java.lang.Double distance;

    private com.ptvag.mnp.common.RoadSpeedTypeEnum roadSpeedType;

    private java.lang.Double tollDistance;

    private com.ptvag.mnp.common.TollFee tollFeeRoadType;

    public RoadSpeedTypeToll() {
    }

    public RoadSpeedTypeToll(
           java.lang.Double distance,
           com.ptvag.mnp.common.RoadSpeedTypeEnum roadSpeedType,
           java.lang.Double tollDistance,
           com.ptvag.mnp.common.TollFee tollFeeRoadType) {
           this.distance = distance;
           this.roadSpeedType = roadSpeedType;
           this.tollDistance = tollDistance;
           this.tollFeeRoadType = tollFeeRoadType;
    }


    /**
     * Gets the distance value for this RoadSpeedTypeToll.
     * 
     * @return distance
     */
    public java.lang.Double getDistance() {
        return distance;
    }


    /**
     * Sets the distance value for this RoadSpeedTypeToll.
     * 
     * @param distance
     */
    public void setDistance(java.lang.Double distance) {
        this.distance = distance;
    }


    /**
     * Gets the roadSpeedType value for this RoadSpeedTypeToll.
     * 
     * @return roadSpeedType
     */
    public com.ptvag.mnp.common.RoadSpeedTypeEnum getRoadSpeedType() {
        return roadSpeedType;
    }


    /**
     * Sets the roadSpeedType value for this RoadSpeedTypeToll.
     * 
     * @param roadSpeedType
     */
    public void setRoadSpeedType(com.ptvag.mnp.common.RoadSpeedTypeEnum roadSpeedType) {
        this.roadSpeedType = roadSpeedType;
    }


    /**
     * Gets the tollDistance value for this RoadSpeedTypeToll.
     * 
     * @return tollDistance
     */
    public java.lang.Double getTollDistance() {
        return tollDistance;
    }


    /**
     * Sets the tollDistance value for this RoadSpeedTypeToll.
     * 
     * @param tollDistance
     */
    public void setTollDistance(java.lang.Double tollDistance) {
        this.tollDistance = tollDistance;
    }


    /**
     * Gets the tollFeeRoadType value for this RoadSpeedTypeToll.
     * 
     * @return tollFeeRoadType
     */
    public com.ptvag.mnp.common.TollFee getTollFeeRoadType() {
        return tollFeeRoadType;
    }


    /**
     * Sets the tollFeeRoadType value for this RoadSpeedTypeToll.
     * 
     * @param tollFeeRoadType
     */
    public void setTollFeeRoadType(com.ptvag.mnp.common.TollFee tollFeeRoadType) {
        this.tollFeeRoadType = tollFeeRoadType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RoadSpeedTypeToll)) return false;
        RoadSpeedTypeToll other = (RoadSpeedTypeToll) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.distance==null && other.getDistance()==null) || 
             (this.distance!=null &&
              this.distance.equals(other.getDistance()))) &&
            ((this.roadSpeedType==null && other.getRoadSpeedType()==null) || 
             (this.roadSpeedType!=null &&
              this.roadSpeedType.equals(other.getRoadSpeedType()))) &&
            ((this.tollDistance==null && other.getTollDistance()==null) || 
             (this.tollDistance!=null &&
              this.tollDistance.equals(other.getTollDistance()))) &&
            ((this.tollFeeRoadType==null && other.getTollFeeRoadType()==null) || 
             (this.tollFeeRoadType!=null &&
              this.tollFeeRoadType.equals(other.getTollFeeRoadType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDistance() != null) {
            _hashCode += getDistance().hashCode();
        }
        if (getRoadSpeedType() != null) {
            _hashCode += getRoadSpeedType().hashCode();
        }
        if (getTollDistance() != null) {
            _hashCode += getTollDistance().hashCode();
        }
        if (getTollFeeRoadType() != null) {
            _hashCode += getTollFeeRoadType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RoadSpeedTypeToll.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RoadSpeedTypeToll"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("distance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "distance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roadSpeedType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "roadSpeedType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RoadSpeedTypeEnum"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tollDistance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "tollDistance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tollFeeRoadType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "tollFeeRoadType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "TollFee"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
