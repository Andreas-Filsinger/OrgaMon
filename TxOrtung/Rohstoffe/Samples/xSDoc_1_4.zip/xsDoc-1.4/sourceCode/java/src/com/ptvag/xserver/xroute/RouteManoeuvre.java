/**
 * RouteManoeuvre.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class RouteManoeuvre  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.BrunnelManoeuvre brunnelManoeuvre;

    private com.ptvag.xserver.xroute.ManoeuvreAttributes manoeuvreAttr;

    private com.ptvag.xserver.xroute.UrbanManoeuvre urbanlManoeuvre;

    private com.ptvag.xserver.xroute.DetailLevel detailLevel;  // attribute

    private int dirInfoIdx;  // attribute

    private com.ptvag.xserver.xroute.InfoNodeType dirInfoNodeType;  // attribute

    private int exitAngle;  // attribute

    private int exitAngleNorth;  // attribute

    private int exitNr;  // attribute

    private int locInfoIdx;  // attribute

    private com.ptvag.xserver.xroute.InfoNodeType locInfoNodeType;  // attribute

    private java.lang.String manoeuvreDesc;  // attribute

    private int manoeuvreGroupIdx;  // attribute

    private com.ptvag.xserver.xroute.ManoeuvreType manoeuvreType;  // attribute

    private int predSegmentIdx;  // attribute

    private int routeListSegmentIdx;  // attribute

    private int succSegmentIdx;  // attribute

    private com.ptvag.xserver.xroute.TurnOrient turnOrient;  // attribute

    private com.ptvag.xserver.xroute.TurnWeight turnWeight;  // attribute

    private int viaIdx;  // attribute

    public RouteManoeuvre() {
    }

    public RouteManoeuvre(
           com.ptvag.xserver.xroute.DetailLevel detailLevel,
           int dirInfoIdx,
           com.ptvag.xserver.xroute.InfoNodeType dirInfoNodeType,
           int exitAngle,
           int exitAngleNorth,
           int exitNr,
           int locInfoIdx,
           com.ptvag.xserver.xroute.InfoNodeType locInfoNodeType,
           java.lang.String manoeuvreDesc,
           int manoeuvreGroupIdx,
           com.ptvag.xserver.xroute.ManoeuvreType manoeuvreType,
           int predSegmentIdx,
           int routeListSegmentIdx,
           int succSegmentIdx,
           com.ptvag.xserver.xroute.TurnOrient turnOrient,
           com.ptvag.xserver.xroute.TurnWeight turnWeight,
           int viaIdx,
           com.ptvag.xserver.xroute.BrunnelManoeuvre brunnelManoeuvre,
           com.ptvag.xserver.xroute.ManoeuvreAttributes manoeuvreAttr,
           com.ptvag.xserver.xroute.UrbanManoeuvre urbanlManoeuvre) {
        this.detailLevel = detailLevel;
        this.dirInfoIdx = dirInfoIdx;
        this.dirInfoNodeType = dirInfoNodeType;
        this.exitAngle = exitAngle;
        this.exitAngleNorth = exitAngleNorth;
        this.exitNr = exitNr;
        this.locInfoIdx = locInfoIdx;
        this.locInfoNodeType = locInfoNodeType;
        this.manoeuvreDesc = manoeuvreDesc;
        this.manoeuvreGroupIdx = manoeuvreGroupIdx;
        this.manoeuvreType = manoeuvreType;
        this.predSegmentIdx = predSegmentIdx;
        this.routeListSegmentIdx = routeListSegmentIdx;
        this.succSegmentIdx = succSegmentIdx;
        this.turnOrient = turnOrient;
        this.turnWeight = turnWeight;
        this.viaIdx = viaIdx;
        this.brunnelManoeuvre = brunnelManoeuvre;
        this.manoeuvreAttr = manoeuvreAttr;
        this.urbanlManoeuvre = urbanlManoeuvre;
    }


    /**
     * Gets the brunnelManoeuvre value for this RouteManoeuvre.
     * 
     * @return brunnelManoeuvre
     */
    public com.ptvag.xserver.xroute.BrunnelManoeuvre getBrunnelManoeuvre() {
        return brunnelManoeuvre;
    }


    /**
     * Sets the brunnelManoeuvre value for this RouteManoeuvre.
     * 
     * @param brunnelManoeuvre
     */
    public void setBrunnelManoeuvre(com.ptvag.xserver.xroute.BrunnelManoeuvre brunnelManoeuvre) {
        this.brunnelManoeuvre = brunnelManoeuvre;
    }


    /**
     * Gets the manoeuvreAttr value for this RouteManoeuvre.
     * 
     * @return manoeuvreAttr
     */
    public com.ptvag.xserver.xroute.ManoeuvreAttributes getManoeuvreAttr() {
        return manoeuvreAttr;
    }


    /**
     * Sets the manoeuvreAttr value for this RouteManoeuvre.
     * 
     * @param manoeuvreAttr
     */
    public void setManoeuvreAttr(com.ptvag.xserver.xroute.ManoeuvreAttributes manoeuvreAttr) {
        this.manoeuvreAttr = manoeuvreAttr;
    }


    /**
     * Gets the urbanlManoeuvre value for this RouteManoeuvre.
     * 
     * @return urbanlManoeuvre
     */
    public com.ptvag.xserver.xroute.UrbanManoeuvre getUrbanlManoeuvre() {
        return urbanlManoeuvre;
    }


    /**
     * Sets the urbanlManoeuvre value for this RouteManoeuvre.
     * 
     * @param urbanlManoeuvre
     */
    public void setUrbanlManoeuvre(com.ptvag.xserver.xroute.UrbanManoeuvre urbanlManoeuvre) {
        this.urbanlManoeuvre = urbanlManoeuvre;
    }


    /**
     * Gets the detailLevel value for this RouteManoeuvre.
     * 
     * @return detailLevel
     */
    public com.ptvag.xserver.xroute.DetailLevel getDetailLevel() {
        return detailLevel;
    }


    /**
     * Sets the detailLevel value for this RouteManoeuvre.
     * 
     * @param detailLevel
     */
    public void setDetailLevel(com.ptvag.xserver.xroute.DetailLevel detailLevel) {
        this.detailLevel = detailLevel;
    }


    /**
     * Gets the dirInfoIdx value for this RouteManoeuvre.
     * 
     * @return dirInfoIdx
     */
    public int getDirInfoIdx() {
        return dirInfoIdx;
    }


    /**
     * Sets the dirInfoIdx value for this RouteManoeuvre.
     * 
     * @param dirInfoIdx
     */
    public void setDirInfoIdx(int dirInfoIdx) {
        this.dirInfoIdx = dirInfoIdx;
    }


    /**
     * Gets the dirInfoNodeType value for this RouteManoeuvre.
     * 
     * @return dirInfoNodeType
     */
    public com.ptvag.xserver.xroute.InfoNodeType getDirInfoNodeType() {
        return dirInfoNodeType;
    }


    /**
     * Sets the dirInfoNodeType value for this RouteManoeuvre.
     * 
     * @param dirInfoNodeType
     */
    public void setDirInfoNodeType(com.ptvag.xserver.xroute.InfoNodeType dirInfoNodeType) {
        this.dirInfoNodeType = dirInfoNodeType;
    }


    /**
     * Gets the exitAngle value for this RouteManoeuvre.
     * 
     * @return exitAngle
     */
    public int getExitAngle() {
        return exitAngle;
    }


    /**
     * Sets the exitAngle value for this RouteManoeuvre.
     * 
     * @param exitAngle
     */
    public void setExitAngle(int exitAngle) {
        this.exitAngle = exitAngle;
    }


    /**
     * Gets the exitAngleNorth value for this RouteManoeuvre.
     * 
     * @return exitAngleNorth
     */
    public int getExitAngleNorth() {
        return exitAngleNorth;
    }


    /**
     * Sets the exitAngleNorth value for this RouteManoeuvre.
     * 
     * @param exitAngleNorth
     */
    public void setExitAngleNorth(int exitAngleNorth) {
        this.exitAngleNorth = exitAngleNorth;
    }


    /**
     * Gets the exitNr value for this RouteManoeuvre.
     * 
     * @return exitNr
     */
    public int getExitNr() {
        return exitNr;
    }


    /**
     * Sets the exitNr value for this RouteManoeuvre.
     * 
     * @param exitNr
     */
    public void setExitNr(int exitNr) {
        this.exitNr = exitNr;
    }


    /**
     * Gets the locInfoIdx value for this RouteManoeuvre.
     * 
     * @return locInfoIdx
     */
    public int getLocInfoIdx() {
        return locInfoIdx;
    }


    /**
     * Sets the locInfoIdx value for this RouteManoeuvre.
     * 
     * @param locInfoIdx
     */
    public void setLocInfoIdx(int locInfoIdx) {
        this.locInfoIdx = locInfoIdx;
    }


    /**
     * Gets the locInfoNodeType value for this RouteManoeuvre.
     * 
     * @return locInfoNodeType
     */
    public com.ptvag.xserver.xroute.InfoNodeType getLocInfoNodeType() {
        return locInfoNodeType;
    }


    /**
     * Sets the locInfoNodeType value for this RouteManoeuvre.
     * 
     * @param locInfoNodeType
     */
    public void setLocInfoNodeType(com.ptvag.xserver.xroute.InfoNodeType locInfoNodeType) {
        this.locInfoNodeType = locInfoNodeType;
    }


    /**
     * Gets the manoeuvreDesc value for this RouteManoeuvre.
     * 
     * @return manoeuvreDesc
     */
    public java.lang.String getManoeuvreDesc() {
        return manoeuvreDesc;
    }


    /**
     * Sets the manoeuvreDesc value for this RouteManoeuvre.
     * 
     * @param manoeuvreDesc
     */
    public void setManoeuvreDesc(java.lang.String manoeuvreDesc) {
        this.manoeuvreDesc = manoeuvreDesc;
    }


    /**
     * Gets the manoeuvreGroupIdx value for this RouteManoeuvre.
     * 
     * @return manoeuvreGroupIdx
     */
    public int getManoeuvreGroupIdx() {
        return manoeuvreGroupIdx;
    }


    /**
     * Sets the manoeuvreGroupIdx value for this RouteManoeuvre.
     * 
     * @param manoeuvreGroupIdx
     */
    public void setManoeuvreGroupIdx(int manoeuvreGroupIdx) {
        this.manoeuvreGroupIdx = manoeuvreGroupIdx;
    }


    /**
     * Gets the manoeuvreType value for this RouteManoeuvre.
     * 
     * @return manoeuvreType
     */
    public com.ptvag.xserver.xroute.ManoeuvreType getManoeuvreType() {
        return manoeuvreType;
    }


    /**
     * Sets the manoeuvreType value for this RouteManoeuvre.
     * 
     * @param manoeuvreType
     */
    public void setManoeuvreType(com.ptvag.xserver.xroute.ManoeuvreType manoeuvreType) {
        this.manoeuvreType = manoeuvreType;
    }


    /**
     * Gets the predSegmentIdx value for this RouteManoeuvre.
     * 
     * @return predSegmentIdx
     */
    public int getPredSegmentIdx() {
        return predSegmentIdx;
    }


    /**
     * Sets the predSegmentIdx value for this RouteManoeuvre.
     * 
     * @param predSegmentIdx
     */
    public void setPredSegmentIdx(int predSegmentIdx) {
        this.predSegmentIdx = predSegmentIdx;
    }


    /**
     * Gets the routeListSegmentIdx value for this RouteManoeuvre.
     * 
     * @return routeListSegmentIdx
     */
    public int getRouteListSegmentIdx() {
        return routeListSegmentIdx;
    }


    /**
     * Sets the routeListSegmentIdx value for this RouteManoeuvre.
     * 
     * @param routeListSegmentIdx
     */
    public void setRouteListSegmentIdx(int routeListSegmentIdx) {
        this.routeListSegmentIdx = routeListSegmentIdx;
    }


    /**
     * Gets the succSegmentIdx value for this RouteManoeuvre.
     * 
     * @return succSegmentIdx
     */
    public int getSuccSegmentIdx() {
        return succSegmentIdx;
    }


    /**
     * Sets the succSegmentIdx value for this RouteManoeuvre.
     * 
     * @param succSegmentIdx
     */
    public void setSuccSegmentIdx(int succSegmentIdx) {
        this.succSegmentIdx = succSegmentIdx;
    }


    /**
     * Gets the turnOrient value for this RouteManoeuvre.
     * 
     * @return turnOrient
     */
    public com.ptvag.xserver.xroute.TurnOrient getTurnOrient() {
        return turnOrient;
    }


    /**
     * Sets the turnOrient value for this RouteManoeuvre.
     * 
     * @param turnOrient
     */
    public void setTurnOrient(com.ptvag.xserver.xroute.TurnOrient turnOrient) {
        this.turnOrient = turnOrient;
    }


    /**
     * Gets the turnWeight value for this RouteManoeuvre.
     * 
     * @return turnWeight
     */
    public com.ptvag.xserver.xroute.TurnWeight getTurnWeight() {
        return turnWeight;
    }


    /**
     * Sets the turnWeight value for this RouteManoeuvre.
     * 
     * @param turnWeight
     */
    public void setTurnWeight(com.ptvag.xserver.xroute.TurnWeight turnWeight) {
        this.turnWeight = turnWeight;
    }


    /**
     * Gets the viaIdx value for this RouteManoeuvre.
     * 
     * @return viaIdx
     */
    public int getViaIdx() {
        return viaIdx;
    }


    /**
     * Sets the viaIdx value for this RouteManoeuvre.
     * 
     * @param viaIdx
     */
    public void setViaIdx(int viaIdx) {
        this.viaIdx = viaIdx;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RouteManoeuvre)) return false;
        RouteManoeuvre other = (RouteManoeuvre) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.brunnelManoeuvre==null && other.getBrunnelManoeuvre()==null) || 
             (this.brunnelManoeuvre!=null &&
              this.brunnelManoeuvre.equals(other.getBrunnelManoeuvre()))) &&
            ((this.manoeuvreAttr==null && other.getManoeuvreAttr()==null) || 
             (this.manoeuvreAttr!=null &&
              this.manoeuvreAttr.equals(other.getManoeuvreAttr()))) &&
            ((this.urbanlManoeuvre==null && other.getUrbanlManoeuvre()==null) || 
             (this.urbanlManoeuvre!=null &&
              this.urbanlManoeuvre.equals(other.getUrbanlManoeuvre()))) &&
            ((this.detailLevel==null && other.getDetailLevel()==null) || 
             (this.detailLevel!=null &&
              this.detailLevel.equals(other.getDetailLevel()))) &&
            this.dirInfoIdx == other.getDirInfoIdx() &&
            ((this.dirInfoNodeType==null && other.getDirInfoNodeType()==null) || 
             (this.dirInfoNodeType!=null &&
              this.dirInfoNodeType.equals(other.getDirInfoNodeType()))) &&
            this.exitAngle == other.getExitAngle() &&
            this.exitAngleNorth == other.getExitAngleNorth() &&
            this.exitNr == other.getExitNr() &&
            this.locInfoIdx == other.getLocInfoIdx() &&
            ((this.locInfoNodeType==null && other.getLocInfoNodeType()==null) || 
             (this.locInfoNodeType!=null &&
              this.locInfoNodeType.equals(other.getLocInfoNodeType()))) &&
            ((this.manoeuvreDesc==null && other.getManoeuvreDesc()==null) || 
             (this.manoeuvreDesc!=null &&
              this.manoeuvreDesc.equals(other.getManoeuvreDesc()))) &&
            this.manoeuvreGroupIdx == other.getManoeuvreGroupIdx() &&
            ((this.manoeuvreType==null && other.getManoeuvreType()==null) || 
             (this.manoeuvreType!=null &&
              this.manoeuvreType.equals(other.getManoeuvreType()))) &&
            this.predSegmentIdx == other.getPredSegmentIdx() &&
            this.routeListSegmentIdx == other.getRouteListSegmentIdx() &&
            this.succSegmentIdx == other.getSuccSegmentIdx() &&
            ((this.turnOrient==null && other.getTurnOrient()==null) || 
             (this.turnOrient!=null &&
              this.turnOrient.equals(other.getTurnOrient()))) &&
            ((this.turnWeight==null && other.getTurnWeight()==null) || 
             (this.turnWeight!=null &&
              this.turnWeight.equals(other.getTurnWeight()))) &&
            this.viaIdx == other.getViaIdx();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBrunnelManoeuvre() != null) {
            _hashCode += getBrunnelManoeuvre().hashCode();
        }
        if (getManoeuvreAttr() != null) {
            _hashCode += getManoeuvreAttr().hashCode();
        }
        if (getUrbanlManoeuvre() != null) {
            _hashCode += getUrbanlManoeuvre().hashCode();
        }
        if (getDetailLevel() != null) {
            _hashCode += getDetailLevel().hashCode();
        }
        _hashCode += getDirInfoIdx();
        if (getDirInfoNodeType() != null) {
            _hashCode += getDirInfoNodeType().hashCode();
        }
        _hashCode += getExitAngle();
        _hashCode += getExitAngleNorth();
        _hashCode += getExitNr();
        _hashCode += getLocInfoIdx();
        if (getLocInfoNodeType() != null) {
            _hashCode += getLocInfoNodeType().hashCode();
        }
        if (getManoeuvreDesc() != null) {
            _hashCode += getManoeuvreDesc().hashCode();
        }
        _hashCode += getManoeuvreGroupIdx();
        if (getManoeuvreType() != null) {
            _hashCode += getManoeuvreType().hashCode();
        }
        _hashCode += getPredSegmentIdx();
        _hashCode += getRouteListSegmentIdx();
        _hashCode += getSuccSegmentIdx();
        if (getTurnOrient() != null) {
            _hashCode += getTurnOrient().hashCode();
        }
        if (getTurnWeight() != null) {
            _hashCode += getTurnWeight().hashCode();
        }
        _hashCode += getViaIdx();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RouteManoeuvre.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteManoeuvre"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("detailLevel");
        attrField.setXmlName(new javax.xml.namespace.QName("", "detailLevel"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "DetailLevel"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("dirInfoIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "dirInfoIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("dirInfoNodeType");
        attrField.setXmlName(new javax.xml.namespace.QName("", "dirInfoNodeType"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "InfoNodeType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("exitAngle");
        attrField.setXmlName(new javax.xml.namespace.QName("", "exitAngle"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("exitAngleNorth");
        attrField.setXmlName(new javax.xml.namespace.QName("", "exitAngleNorth"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("exitNr");
        attrField.setXmlName(new javax.xml.namespace.QName("", "exitNr"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("locInfoIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "locInfoIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("locInfoNodeType");
        attrField.setXmlName(new javax.xml.namespace.QName("", "locInfoNodeType"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "InfoNodeType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("manoeuvreDesc");
        attrField.setXmlName(new javax.xml.namespace.QName("", "manoeuvreDesc"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("manoeuvreGroupIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "manoeuvreGroupIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("manoeuvreType");
        attrField.setXmlName(new javax.xml.namespace.QName("", "manoeuvreType"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("predSegmentIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "predSegmentIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("routeListSegmentIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "routeListSegmentIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("succSegmentIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "succSegmentIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("turnOrient");
        attrField.setXmlName(new javax.xml.namespace.QName("", "turnOrient"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TurnOrient"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("turnWeight");
        attrField.setXmlName(new javax.xml.namespace.QName("", "turnWeight"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TurnWeight"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("viaIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "viaIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brunnelManoeuvre");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "brunnelManoeuvre"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "BrunnelManoeuvre"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manoeuvreAttr");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "manoeuvreAttr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreAttributes"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("urbanlManoeuvre");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "urbanlManoeuvre"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UrbanManoeuvre"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
