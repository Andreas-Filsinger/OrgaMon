/**
 * LineOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class LineOptions  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xmap.BasicDrawingOptions arrows;

    private com.ptvag.xserver.xmap.LinePartOptions mainLine;

    private com.ptvag.xserver.xmap.LinePartOptions sideLine;

    private boolean showFlags;  // attribute

    private boolean transparent;  // attribute

    public LineOptions() {
    }

    public LineOptions(
           boolean showFlags,
           boolean transparent,
           com.ptvag.xserver.xmap.BasicDrawingOptions arrows,
           com.ptvag.xserver.xmap.LinePartOptions mainLine,
           com.ptvag.xserver.xmap.LinePartOptions sideLine) {
        this.showFlags = showFlags;
        this.transparent = transparent;
        this.arrows = arrows;
        this.mainLine = mainLine;
        this.sideLine = sideLine;
    }


    /**
     * Gets the arrows value for this LineOptions.
     * 
     * @return arrows
     */
    public com.ptvag.xserver.xmap.BasicDrawingOptions getArrows() {
        return arrows;
    }


    /**
     * Sets the arrows value for this LineOptions.
     * 
     * @param arrows
     */
    public void setArrows(com.ptvag.xserver.xmap.BasicDrawingOptions arrows) {
        this.arrows = arrows;
    }


    /**
     * Gets the mainLine value for this LineOptions.
     * 
     * @return mainLine
     */
    public com.ptvag.xserver.xmap.LinePartOptions getMainLine() {
        return mainLine;
    }


    /**
     * Sets the mainLine value for this LineOptions.
     * 
     * @param mainLine
     */
    public void setMainLine(com.ptvag.xserver.xmap.LinePartOptions mainLine) {
        this.mainLine = mainLine;
    }


    /**
     * Gets the sideLine value for this LineOptions.
     * 
     * @return sideLine
     */
    public com.ptvag.xserver.xmap.LinePartOptions getSideLine() {
        return sideLine;
    }


    /**
     * Sets the sideLine value for this LineOptions.
     * 
     * @param sideLine
     */
    public void setSideLine(com.ptvag.xserver.xmap.LinePartOptions sideLine) {
        this.sideLine = sideLine;
    }


    /**
     * Gets the showFlags value for this LineOptions.
     * 
     * @return showFlags
     */
    public boolean isShowFlags() {
        return showFlags;
    }


    /**
     * Sets the showFlags value for this LineOptions.
     * 
     * @param showFlags
     */
    public void setShowFlags(boolean showFlags) {
        this.showFlags = showFlags;
    }


    /**
     * Gets the transparent value for this LineOptions.
     * 
     * @return transparent
     */
    public boolean isTransparent() {
        return transparent;
    }


    /**
     * Sets the transparent value for this LineOptions.
     * 
     * @param transparent
     */
    public void setTransparent(boolean transparent) {
        this.transparent = transparent;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LineOptions)) return false;
        LineOptions other = (LineOptions) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.arrows==null && other.getArrows()==null) || 
             (this.arrows!=null &&
              this.arrows.equals(other.getArrows()))) &&
            ((this.mainLine==null && other.getMainLine()==null) || 
             (this.mainLine!=null &&
              this.mainLine.equals(other.getMainLine()))) &&
            ((this.sideLine==null && other.getSideLine()==null) || 
             (this.sideLine!=null &&
              this.sideLine.equals(other.getSideLine()))) &&
            this.showFlags == other.isShowFlags() &&
            this.transparent == other.isTransparent();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getArrows() != null) {
            _hashCode += getArrows().hashCode();
        }
        if (getMainLine() != null) {
            _hashCode += getMainLine().hashCode();
        }
        if (getSideLine() != null) {
            _hashCode += getSideLine().hashCode();
        }
        _hashCode += (isShowFlags() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isTransparent() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LineOptions.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "LineOptions"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("showFlags");
        attrField.setXmlName(new javax.xml.namespace.QName("", "showFlags"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("transparent");
        attrField.setXmlName(new javax.xml.namespace.QName("", "transparent"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrows");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "arrows"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "BasicDrawingOptions"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mainLine");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "mainLine"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "LinePartOptions"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sideLine");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "sideLine"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "LinePartOptions"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
