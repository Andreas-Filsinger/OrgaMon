/**
 * SortOption.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xlocate;

public class SortOption  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xlocate.ResultField field;  // attribute

    private com.ptvag.xserver.xlocate.SortOrder order;  // attribute

    public SortOption() {
    }

    public SortOption(
           com.ptvag.xserver.xlocate.ResultField field,
           com.ptvag.xserver.xlocate.SortOrder order) {
        this.field = field;
        this.order = order;
    }


    /**
     * Gets the field value for this SortOption.
     * 
     * @return field
     */
    public com.ptvag.xserver.xlocate.ResultField getField() {
        return field;
    }


    /**
     * Sets the field value for this SortOption.
     * 
     * @param field
     */
    public void setField(com.ptvag.xserver.xlocate.ResultField field) {
        this.field = field;
    }


    /**
     * Gets the order value for this SortOption.
     * 
     * @return order
     */
    public com.ptvag.xserver.xlocate.SortOrder getOrder() {
        return order;
    }


    /**
     * Sets the order value for this SortOption.
     * 
     * @param order
     */
    public void setOrder(com.ptvag.xserver.xlocate.SortOrder order) {
        this.order = order;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SortOption)) return false;
        SortOption other = (SortOption) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.field==null && other.getField()==null) || 
             (this.field!=null &&
              this.field.equals(other.getField()))) &&
            ((this.order==null && other.getOrder()==null) || 
             (this.order!=null &&
              this.order.equals(other.getOrder())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getField() != null) {
            _hashCode += getField().hashCode();
        }
        if (getOrder() != null) {
            _hashCode += getOrder().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SortOption.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOption"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("field");
        attrField.setXmlName(new javax.xml.namespace.QName("", "field"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultField"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("order");
        attrField.setXmlName(new javax.xml.namespace.QName("", "order"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SortOrder"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
