/**
 * Quantities.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class Quantities  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private int quantity1;  // attribute

    private int quantity2;  // attribute

    private int quantity3;  // attribute

    private int quantity4;  // attribute

    private int quantity5;  // attribute

    private int quantity6;  // attribute

    public Quantities() {
    }

    public Quantities(
           int quantity1,
           int quantity2,
           int quantity3,
           int quantity4,
           int quantity5,
           int quantity6) {
        this.quantity1 = quantity1;
        this.quantity2 = quantity2;
        this.quantity3 = quantity3;
        this.quantity4 = quantity4;
        this.quantity5 = quantity5;
        this.quantity6 = quantity6;
    }


    /**
     * Gets the quantity1 value for this Quantities.
     * 
     * @return quantity1
     */
    public int getQuantity1() {
        return quantity1;
    }


    /**
     * Sets the quantity1 value for this Quantities.
     * 
     * @param quantity1
     */
    public void setQuantity1(int quantity1) {
        this.quantity1 = quantity1;
    }


    /**
     * Gets the quantity2 value for this Quantities.
     * 
     * @return quantity2
     */
    public int getQuantity2() {
        return quantity2;
    }


    /**
     * Sets the quantity2 value for this Quantities.
     * 
     * @param quantity2
     */
    public void setQuantity2(int quantity2) {
        this.quantity2 = quantity2;
    }


    /**
     * Gets the quantity3 value for this Quantities.
     * 
     * @return quantity3
     */
    public int getQuantity3() {
        return quantity3;
    }


    /**
     * Sets the quantity3 value for this Quantities.
     * 
     * @param quantity3
     */
    public void setQuantity3(int quantity3) {
        this.quantity3 = quantity3;
    }


    /**
     * Gets the quantity4 value for this Quantities.
     * 
     * @return quantity4
     */
    public int getQuantity4() {
        return quantity4;
    }


    /**
     * Sets the quantity4 value for this Quantities.
     * 
     * @param quantity4
     */
    public void setQuantity4(int quantity4) {
        this.quantity4 = quantity4;
    }


    /**
     * Gets the quantity5 value for this Quantities.
     * 
     * @return quantity5
     */
    public int getQuantity5() {
        return quantity5;
    }


    /**
     * Sets the quantity5 value for this Quantities.
     * 
     * @param quantity5
     */
    public void setQuantity5(int quantity5) {
        this.quantity5 = quantity5;
    }


    /**
     * Gets the quantity6 value for this Quantities.
     * 
     * @return quantity6
     */
    public int getQuantity6() {
        return quantity6;
    }


    /**
     * Sets the quantity6 value for this Quantities.
     * 
     * @param quantity6
     */
    public void setQuantity6(int quantity6) {
        this.quantity6 = quantity6;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Quantities)) return false;
        Quantities other = (Quantities) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.quantity1 == other.getQuantity1() &&
            this.quantity2 == other.getQuantity2() &&
            this.quantity3 == other.getQuantity3() &&
            this.quantity4 == other.getQuantity4() &&
            this.quantity5 == other.getQuantity5() &&
            this.quantity6 == other.getQuantity6();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getQuantity1();
        _hashCode += getQuantity2();
        _hashCode += getQuantity3();
        _hashCode += getQuantity4();
        _hashCode += getQuantity5();
        _hashCode += getQuantity6();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Quantities.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Quantities"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("quantity1");
        attrField.setXmlName(new javax.xml.namespace.QName("", "quantity1"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("quantity2");
        attrField.setXmlName(new javax.xml.namespace.QName("", "quantity2"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("quantity3");
        attrField.setXmlName(new javax.xml.namespace.QName("", "quantity3"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("quantity4");
        attrField.setXmlName(new javax.xml.namespace.QName("", "quantity4"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("quantity5");
        attrField.setXmlName(new javax.xml.namespace.QName("", "quantity5"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("quantity6");
        attrField.setXmlName(new javax.xml.namespace.QName("", "quantity6"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
