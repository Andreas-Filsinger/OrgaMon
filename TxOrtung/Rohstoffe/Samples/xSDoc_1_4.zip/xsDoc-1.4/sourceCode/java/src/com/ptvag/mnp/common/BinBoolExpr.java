/**
 * BinBoolExpr.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class BinBoolExpr  extends com.ptvag.mnp.common.BoolExpr  implements java.io.Serializable {
    private com.ptvag.mnp.common.BoolExpr left;

    private com.ptvag.mnp.common.BinBoolEnum op;

    private com.ptvag.mnp.common.BoolExpr right;

    public BinBoolExpr() {
    }

    public BinBoolExpr(
           com.ptvag.mnp.common.BoolExpr left,
           com.ptvag.mnp.common.BinBoolEnum op,
           com.ptvag.mnp.common.BoolExpr right) {
        this.left = left;
        this.op = op;
        this.right = right;
    }


    /**
     * Gets the left value for this BinBoolExpr.
     * 
     * @return left
     */
    public com.ptvag.mnp.common.BoolExpr getLeft() {
        return left;
    }


    /**
     * Sets the left value for this BinBoolExpr.
     * 
     * @param left
     */
    public void setLeft(com.ptvag.mnp.common.BoolExpr left) {
        this.left = left;
    }


    /**
     * Gets the op value for this BinBoolExpr.
     * 
     * @return op
     */
    public com.ptvag.mnp.common.BinBoolEnum getOp() {
        return op;
    }


    /**
     * Sets the op value for this BinBoolExpr.
     * 
     * @param op
     */
    public void setOp(com.ptvag.mnp.common.BinBoolEnum op) {
        this.op = op;
    }


    /**
     * Gets the right value for this BinBoolExpr.
     * 
     * @return right
     */
    public com.ptvag.mnp.common.BoolExpr getRight() {
        return right;
    }


    /**
     * Sets the right value for this BinBoolExpr.
     * 
     * @param right
     */
    public void setRight(com.ptvag.mnp.common.BoolExpr right) {
        this.right = right;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BinBoolExpr)) return false;
        BinBoolExpr other = (BinBoolExpr) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.left==null && other.getLeft()==null) || 
             (this.left!=null &&
              this.left.equals(other.getLeft()))) &&
            ((this.op==null && other.getOp()==null) || 
             (this.op!=null &&
              this.op.equals(other.getOp()))) &&
            ((this.right==null && other.getRight()==null) || 
             (this.right!=null &&
              this.right.equals(other.getRight())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLeft() != null) {
            _hashCode += getLeft().hashCode();
        }
        if (getOp() != null) {
            _hashCode += getOp().hashCode();
        }
        if (getRight() != null) {
            _hashCode += getRight().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BinBoolExpr.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BinBoolExpr"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("left");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "left"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BoolExpr"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("op");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "op"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BinBoolEnum"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("right");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "right"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BoolExpr"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
