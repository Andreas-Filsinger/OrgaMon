/**
 * BaseException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.jabba.core.exception;

public class BaseException  extends org.apache.axis.AxisFault  implements java.io.Serializable {
    private com.ptvag.jabba.core.exception.StackElement stackElement;

    private java.lang.String transactionId;  // attribute

    public BaseException() {
    }

    public BaseException(
           java.lang.String transactionId,
           com.ptvag.jabba.core.exception.StackElement stackElement) {
        this.transactionId = transactionId;
        this.stackElement = stackElement;
    }


    /**
     * Gets the stackElement value for this BaseException.
     * 
     * @return stackElement
     */
    public com.ptvag.jabba.core.exception.StackElement getStackElement() {
        return stackElement;
    }


    /**
     * Sets the stackElement value for this BaseException.
     * 
     * @param stackElement
     */
    public void setStackElement(com.ptvag.jabba.core.exception.StackElement stackElement) {
        this.stackElement = stackElement;
    }


    /**
     * Gets the transactionId value for this BaseException.
     * 
     * @return transactionId
     */
    public java.lang.String getTransactionId() {
        return transactionId;
    }


    /**
     * Sets the transactionId value for this BaseException.
     * 
     * @param transactionId
     */
    public void setTransactionId(java.lang.String transactionId) {
        this.transactionId = transactionId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BaseException)) return false;
        BaseException other = (BaseException) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.stackElement==null && other.getStackElement()==null) || 
             (this.stackElement!=null &&
              this.stackElement.equals(other.getStackElement()))) &&
            ((this.transactionId==null && other.getTransactionId()==null) || 
             (this.transactionId!=null &&
              this.transactionId.equals(other.getTransactionId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getStackElement() != null) {
            _hashCode += getStackElement().hashCode();
        }
        if (getTransactionId() != null) {
            _hashCode += getTransactionId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BaseException.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "BaseException"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("transactionId");
        attrField.setXmlName(new javax.xml.namespace.QName("", "transactionId"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stackElement");
        elemField.setXmlName(new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "stackElement"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "StackElement"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }


    /**
     * Writes the exception data to the faultDetails
     */
    public void writeDetails(javax.xml.namespace.QName qname, org.apache.axis.encoding.SerializationContext context) throws java.io.IOException {
        context.serialize(qname, null, this);
    }
}
