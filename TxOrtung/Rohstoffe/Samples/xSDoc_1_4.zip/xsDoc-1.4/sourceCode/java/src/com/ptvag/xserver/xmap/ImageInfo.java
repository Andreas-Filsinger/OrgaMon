/**
 * ImageInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class ImageInfo  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xmap.ImageFileFormat format;  // attribute

    private int height;  // attribute

    private java.lang.String imageParameter;  // attribute

    private int width;  // attribute

    public ImageInfo() {
    }

    public ImageInfo(
           com.ptvag.xserver.xmap.ImageFileFormat format,
           int height,
           java.lang.String imageParameter,
           int width) {
        this.format = format;
        this.height = height;
        this.imageParameter = imageParameter;
        this.width = width;
    }


    /**
     * Gets the format value for this ImageInfo.
     * 
     * @return format
     */
    public com.ptvag.xserver.xmap.ImageFileFormat getFormat() {
        return format;
    }


    /**
     * Sets the format value for this ImageInfo.
     * 
     * @param format
     */
    public void setFormat(com.ptvag.xserver.xmap.ImageFileFormat format) {
        this.format = format;
    }


    /**
     * Gets the height value for this ImageInfo.
     * 
     * @return height
     */
    public int getHeight() {
        return height;
    }


    /**
     * Sets the height value for this ImageInfo.
     * 
     * @param height
     */
    public void setHeight(int height) {
        this.height = height;
    }


    /**
     * Gets the imageParameter value for this ImageInfo.
     * 
     * @return imageParameter
     */
    public java.lang.String getImageParameter() {
        return imageParameter;
    }


    /**
     * Sets the imageParameter value for this ImageInfo.
     * 
     * @param imageParameter
     */
    public void setImageParameter(java.lang.String imageParameter) {
        this.imageParameter = imageParameter;
    }


    /**
     * Gets the width value for this ImageInfo.
     * 
     * @return width
     */
    public int getWidth() {
        return width;
    }


    /**
     * Sets the width value for this ImageInfo.
     * 
     * @param width
     */
    public void setWidth(int width) {
        this.width = width;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ImageInfo)) return false;
        ImageInfo other = (ImageInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.format==null && other.getFormat()==null) || 
             (this.format!=null &&
              this.format.equals(other.getFormat()))) &&
            this.height == other.getHeight() &&
            ((this.imageParameter==null && other.getImageParameter()==null) || 
             (this.imageParameter!=null &&
              this.imageParameter.equals(other.getImageParameter()))) &&
            this.width == other.getWidth();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getFormat() != null) {
            _hashCode += getFormat().hashCode();
        }
        _hashCode += getHeight();
        if (getImageParameter() != null) {
            _hashCode += getImageParameter().hashCode();
        }
        _hashCode += getWidth();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ImageInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "ImageInfo"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("format");
        attrField.setXmlName(new javax.xml.namespace.QName("", "format"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "ImageFileFormat"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("height");
        attrField.setXmlName(new javax.xml.namespace.QName("", "height"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("imageParameter");
        attrField.setXmlName(new javax.xml.namespace.QName("", "imageParameter"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("width");
        attrField.setXmlName(new javax.xml.namespace.QName("", "width"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
