/**
 * CustomLayer.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class CustomLayer  extends com.ptvag.xserver.xmap.Layer  implements java.io.Serializable {
    private com.ptvag.xserver.xmap.Bitmaps[] wrappedBitmaps;

    private com.ptvag.xserver.xmap.Lines[] wrappedLines;

    private com.ptvag.xserver.xmap.Texts[] wrappedTexts;

    private boolean centerObjects;  // attribute

    private int drawPriority;  // attribute

    private com.ptvag.xserver.xmap.ObjectInfoType objectInfos;  // attribute

    public CustomLayer() {
    }

    public CustomLayer(
           java.lang.String name,
           boolean visible,
           boolean centerObjects,
           int drawPriority,
           com.ptvag.xserver.xmap.ObjectInfoType objectInfos,
           com.ptvag.xserver.xmap.Bitmaps[] wrappedBitmaps,
           com.ptvag.xserver.xmap.Lines[] wrappedLines,
           com.ptvag.xserver.xmap.Texts[] wrappedTexts) {
        super(
            name,
            visible);
        this.centerObjects = centerObjects;
        this.drawPriority = drawPriority;
        this.objectInfos = objectInfos;
        this.wrappedBitmaps = wrappedBitmaps;
        this.wrappedLines = wrappedLines;
        this.wrappedTexts = wrappedTexts;
    }


    /**
     * Gets the wrappedBitmaps value for this CustomLayer.
     * 
     * @return wrappedBitmaps
     */
    public com.ptvag.xserver.xmap.Bitmaps[] getWrappedBitmaps() {
        return wrappedBitmaps;
    }


    /**
     * Sets the wrappedBitmaps value for this CustomLayer.
     * 
     * @param wrappedBitmaps
     */
    public void setWrappedBitmaps(com.ptvag.xserver.xmap.Bitmaps[] wrappedBitmaps) {
        this.wrappedBitmaps = wrappedBitmaps;
    }


    /**
     * Gets the wrappedLines value for this CustomLayer.
     * 
     * @return wrappedLines
     */
    public com.ptvag.xserver.xmap.Lines[] getWrappedLines() {
        return wrappedLines;
    }


    /**
     * Sets the wrappedLines value for this CustomLayer.
     * 
     * @param wrappedLines
     */
    public void setWrappedLines(com.ptvag.xserver.xmap.Lines[] wrappedLines) {
        this.wrappedLines = wrappedLines;
    }


    /**
     * Gets the wrappedTexts value for this CustomLayer.
     * 
     * @return wrappedTexts
     */
    public com.ptvag.xserver.xmap.Texts[] getWrappedTexts() {
        return wrappedTexts;
    }


    /**
     * Sets the wrappedTexts value for this CustomLayer.
     * 
     * @param wrappedTexts
     */
    public void setWrappedTexts(com.ptvag.xserver.xmap.Texts[] wrappedTexts) {
        this.wrappedTexts = wrappedTexts;
    }


    /**
     * Gets the centerObjects value for this CustomLayer.
     * 
     * @return centerObjects
     */
    public boolean isCenterObjects() {
        return centerObjects;
    }


    /**
     * Sets the centerObjects value for this CustomLayer.
     * 
     * @param centerObjects
     */
    public void setCenterObjects(boolean centerObjects) {
        this.centerObjects = centerObjects;
    }


    /**
     * Gets the drawPriority value for this CustomLayer.
     * 
     * @return drawPriority
     */
    public int getDrawPriority() {
        return drawPriority;
    }


    /**
     * Sets the drawPriority value for this CustomLayer.
     * 
     * @param drawPriority
     */
    public void setDrawPriority(int drawPriority) {
        this.drawPriority = drawPriority;
    }


    /**
     * Gets the objectInfos value for this CustomLayer.
     * 
     * @return objectInfos
     */
    public com.ptvag.xserver.xmap.ObjectInfoType getObjectInfos() {
        return objectInfos;
    }


    /**
     * Sets the objectInfos value for this CustomLayer.
     * 
     * @param objectInfos
     */
    public void setObjectInfos(com.ptvag.xserver.xmap.ObjectInfoType objectInfos) {
        this.objectInfos = objectInfos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CustomLayer)) return false;
        CustomLayer other = (CustomLayer) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedBitmaps==null && other.getWrappedBitmaps()==null) || 
             (this.wrappedBitmaps!=null &&
              java.util.Arrays.equals(this.wrappedBitmaps, other.getWrappedBitmaps()))) &&
            ((this.wrappedLines==null && other.getWrappedLines()==null) || 
             (this.wrappedLines!=null &&
              java.util.Arrays.equals(this.wrappedLines, other.getWrappedLines()))) &&
            ((this.wrappedTexts==null && other.getWrappedTexts()==null) || 
             (this.wrappedTexts!=null &&
              java.util.Arrays.equals(this.wrappedTexts, other.getWrappedTexts()))) &&
            this.centerObjects == other.isCenterObjects() &&
            this.drawPriority == other.getDrawPriority() &&
            ((this.objectInfos==null && other.getObjectInfos()==null) || 
             (this.objectInfos!=null &&
              this.objectInfos.equals(other.getObjectInfos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedBitmaps() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedBitmaps());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedBitmaps(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedLines() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedLines());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedLines(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedTexts() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedTexts());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedTexts(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += (isCenterObjects() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getDrawPriority();
        if (getObjectInfos() != null) {
            _hashCode += getObjectInfos().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CustomLayer.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "CustomLayer"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("centerObjects");
        attrField.setXmlName(new javax.xml.namespace.QName("", "centerObjects"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("drawPriority");
        attrField.setXmlName(new javax.xml.namespace.QName("", "drawPriority"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("objectInfos");
        attrField.setXmlName(new javax.xml.namespace.QName("", "objectInfos"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "ObjectInfoType"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedBitmaps");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "wrappedBitmaps"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Bitmaps"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Bitmaps"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedLines");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "wrappedLines"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Lines"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Lines"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedTexts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "wrappedTexts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Texts"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Texts"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
