/**
 * TollStationDescription.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class TollStationDescription  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private int routeListIndex;  // attribute

    private java.lang.String time;  // attribute

    private com.ptvag.xserver.xroute.InfoNodeType tollLocationType;  // attribute

    private int tollStationID;  // attribute

    private java.lang.String tollStationName;  // attribute

    public TollStationDescription() {
    }

    public TollStationDescription(
           int routeListIndex,
           java.lang.String time,
           com.ptvag.xserver.xroute.InfoNodeType tollLocationType,
           int tollStationID,
           java.lang.String tollStationName) {
        this.routeListIndex = routeListIndex;
        this.time = time;
        this.tollLocationType = tollLocationType;
        this.tollStationID = tollStationID;
        this.tollStationName = tollStationName;
    }


    /**
     * Gets the routeListIndex value for this TollStationDescription.
     * 
     * @return routeListIndex
     */
    public int getRouteListIndex() {
        return routeListIndex;
    }


    /**
     * Sets the routeListIndex value for this TollStationDescription.
     * 
     * @param routeListIndex
     */
    public void setRouteListIndex(int routeListIndex) {
        this.routeListIndex = routeListIndex;
    }


    /**
     * Gets the time value for this TollStationDescription.
     * 
     * @return time
     */
    public java.lang.String getTime() {
        return time;
    }


    /**
     * Sets the time value for this TollStationDescription.
     * 
     * @param time
     */
    public void setTime(java.lang.String time) {
        this.time = time;
    }


    /**
     * Gets the tollLocationType value for this TollStationDescription.
     * 
     * @return tollLocationType
     */
    public com.ptvag.xserver.xroute.InfoNodeType getTollLocationType() {
        return tollLocationType;
    }


    /**
     * Sets the tollLocationType value for this TollStationDescription.
     * 
     * @param tollLocationType
     */
    public void setTollLocationType(com.ptvag.xserver.xroute.InfoNodeType tollLocationType) {
        this.tollLocationType = tollLocationType;
    }


    /**
     * Gets the tollStationID value for this TollStationDescription.
     * 
     * @return tollStationID
     */
    public int getTollStationID() {
        return tollStationID;
    }


    /**
     * Sets the tollStationID value for this TollStationDescription.
     * 
     * @param tollStationID
     */
    public void setTollStationID(int tollStationID) {
        this.tollStationID = tollStationID;
    }


    /**
     * Gets the tollStationName value for this TollStationDescription.
     * 
     * @return tollStationName
     */
    public java.lang.String getTollStationName() {
        return tollStationName;
    }


    /**
     * Sets the tollStationName value for this TollStationDescription.
     * 
     * @param tollStationName
     */
    public void setTollStationName(java.lang.String tollStationName) {
        this.tollStationName = tollStationName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TollStationDescription)) return false;
        TollStationDescription other = (TollStationDescription) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.routeListIndex == other.getRouteListIndex() &&
            ((this.time==null && other.getTime()==null) || 
             (this.time!=null &&
              this.time.equals(other.getTime()))) &&
            ((this.tollLocationType==null && other.getTollLocationType()==null) || 
             (this.tollLocationType!=null &&
              this.tollLocationType.equals(other.getTollLocationType()))) &&
            this.tollStationID == other.getTollStationID() &&
            ((this.tollStationName==null && other.getTollStationName()==null) || 
             (this.tollStationName!=null &&
              this.tollStationName.equals(other.getTollStationName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getRouteListIndex();
        if (getTime() != null) {
            _hashCode += getTime().hashCode();
        }
        if (getTollLocationType() != null) {
            _hashCode += getTollLocationType().hashCode();
        }
        _hashCode += getTollStationID();
        if (getTollStationName() != null) {
            _hashCode += getTollStationName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TollStationDescription.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TollStationDescription"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("routeListIndex");
        attrField.setXmlName(new javax.xml.namespace.QName("", "routeListIndex"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("time");
        attrField.setXmlName(new javax.xml.namespace.QName("", "time"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tollLocationType");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tollLocationType"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "InfoNodeType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tollStationID");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tollStationID"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tollStationName");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tollStationName"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
