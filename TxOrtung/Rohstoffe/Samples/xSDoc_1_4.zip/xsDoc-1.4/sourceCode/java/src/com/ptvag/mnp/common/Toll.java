/**
 * Toll.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class Toll  implements java.io.Serializable {
    private com.ptvag.mnp.common.CountryToll[] wrappedCountryToll;

    private com.ptvag.mnp.common.TollFee tollFee;

    public Toll() {
    }

    public Toll(
           com.ptvag.mnp.common.CountryToll[] wrappedCountryToll,
           com.ptvag.mnp.common.TollFee tollFee) {
           this.wrappedCountryToll = wrappedCountryToll;
           this.tollFee = tollFee;
    }


    /**
     * Gets the wrappedCountryToll value for this Toll.
     * 
     * @return wrappedCountryToll
     */
    public com.ptvag.mnp.common.CountryToll[] getWrappedCountryToll() {
        return wrappedCountryToll;
    }


    /**
     * Sets the wrappedCountryToll value for this Toll.
     * 
     * @param wrappedCountryToll
     */
    public void setWrappedCountryToll(com.ptvag.mnp.common.CountryToll[] wrappedCountryToll) {
        this.wrappedCountryToll = wrappedCountryToll;
    }


    /**
     * Gets the tollFee value for this Toll.
     * 
     * @return tollFee
     */
    public com.ptvag.mnp.common.TollFee getTollFee() {
        return tollFee;
    }


    /**
     * Sets the tollFee value for this Toll.
     * 
     * @param tollFee
     */
    public void setTollFee(com.ptvag.mnp.common.TollFee tollFee) {
        this.tollFee = tollFee;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Toll)) return false;
        Toll other = (Toll) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.wrappedCountryToll==null && other.getWrappedCountryToll()==null) || 
             (this.wrappedCountryToll!=null &&
              java.util.Arrays.equals(this.wrappedCountryToll, other.getWrappedCountryToll()))) &&
            ((this.tollFee==null && other.getTollFee()==null) || 
             (this.tollFee!=null &&
              this.tollFee.equals(other.getTollFee())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getWrappedCountryToll() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedCountryToll());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedCountryToll(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTollFee() != null) {
            _hashCode += getTollFee().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Toll.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Toll"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedCountryToll");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedCountryToll"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "CountryToll"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfCountryToll"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tollFee");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "tollFee"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "TollFee"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
