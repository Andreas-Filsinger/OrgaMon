/**
 * RouteElementMapRef.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class RouteElementMapRef  implements java.io.Serializable {
    private int detailMapID;

    private int maxiMapID;

    private int miniMapID;

    public RouteElementMapRef() {
    }

    public RouteElementMapRef(
           int detailMapID,
           int maxiMapID,
           int miniMapID) {
           this.detailMapID = detailMapID;
           this.maxiMapID = maxiMapID;
           this.miniMapID = miniMapID;
    }


    /**
     * Gets the detailMapID value for this RouteElementMapRef.
     * 
     * @return detailMapID
     */
    public int getDetailMapID() {
        return detailMapID;
    }


    /**
     * Sets the detailMapID value for this RouteElementMapRef.
     * 
     * @param detailMapID
     */
    public void setDetailMapID(int detailMapID) {
        this.detailMapID = detailMapID;
    }


    /**
     * Gets the maxiMapID value for this RouteElementMapRef.
     * 
     * @return maxiMapID
     */
    public int getMaxiMapID() {
        return maxiMapID;
    }


    /**
     * Sets the maxiMapID value for this RouteElementMapRef.
     * 
     * @param maxiMapID
     */
    public void setMaxiMapID(int maxiMapID) {
        this.maxiMapID = maxiMapID;
    }


    /**
     * Gets the miniMapID value for this RouteElementMapRef.
     * 
     * @return miniMapID
     */
    public int getMiniMapID() {
        return miniMapID;
    }


    /**
     * Sets the miniMapID value for this RouteElementMapRef.
     * 
     * @param miniMapID
     */
    public void setMiniMapID(int miniMapID) {
        this.miniMapID = miniMapID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RouteElementMapRef)) return false;
        RouteElementMapRef other = (RouteElementMapRef) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.detailMapID == other.getDetailMapID() &&
            this.maxiMapID == other.getMaxiMapID() &&
            this.miniMapID == other.getMiniMapID();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getDetailMapID();
        _hashCode += getMaxiMapID();
        _hashCode += getMiniMapID();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RouteElementMapRef.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElementMapRef"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("detailMapID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "detailMapID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxiMapID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "maxiMapID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("miniMapID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "miniMapID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
