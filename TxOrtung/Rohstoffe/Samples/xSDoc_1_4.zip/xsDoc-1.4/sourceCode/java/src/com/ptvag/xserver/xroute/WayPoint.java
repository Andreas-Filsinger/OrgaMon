/**
 * WayPoint.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class WayPoint  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.common.Point locationCoord;

    private com.ptvag.xserver.common.Point matchCoord;

    private int accDist;  // attribute

    private int accTime;  // attribute

    private java.lang.String countryCode;  // attribute

    private int iuCode;  // attribute

    private int manoeuvreIdx;  // attribute

    private int nodeIdx;  // attribute

    private int polyIdx;  // attribute

    private int segmentIdx;  // attribute

    private com.ptvag.xserver.xroute.WayPointType wayPointType;  // attribute

    public WayPoint() {
    }

    public WayPoint(
           int accDist,
           int accTime,
           java.lang.String countryCode,
           int iuCode,
           int manoeuvreIdx,
           int nodeIdx,
           int polyIdx,
           int segmentIdx,
           com.ptvag.xserver.xroute.WayPointType wayPointType,
           com.ptvag.xserver.common.Point locationCoord,
           com.ptvag.xserver.common.Point matchCoord) {
        this.accDist = accDist;
        this.accTime = accTime;
        this.countryCode = countryCode;
        this.iuCode = iuCode;
        this.manoeuvreIdx = manoeuvreIdx;
        this.nodeIdx = nodeIdx;
        this.polyIdx = polyIdx;
        this.segmentIdx = segmentIdx;
        this.wayPointType = wayPointType;
        this.locationCoord = locationCoord;
        this.matchCoord = matchCoord;
    }


    /**
     * Gets the locationCoord value for this WayPoint.
     * 
     * @return locationCoord
     */
    public com.ptvag.xserver.common.Point getLocationCoord() {
        return locationCoord;
    }


    /**
     * Sets the locationCoord value for this WayPoint.
     * 
     * @param locationCoord
     */
    public void setLocationCoord(com.ptvag.xserver.common.Point locationCoord) {
        this.locationCoord = locationCoord;
    }


    /**
     * Gets the matchCoord value for this WayPoint.
     * 
     * @return matchCoord
     */
    public com.ptvag.xserver.common.Point getMatchCoord() {
        return matchCoord;
    }


    /**
     * Sets the matchCoord value for this WayPoint.
     * 
     * @param matchCoord
     */
    public void setMatchCoord(com.ptvag.xserver.common.Point matchCoord) {
        this.matchCoord = matchCoord;
    }


    /**
     * Gets the accDist value for this WayPoint.
     * 
     * @return accDist
     */
    public int getAccDist() {
        return accDist;
    }


    /**
     * Sets the accDist value for this WayPoint.
     * 
     * @param accDist
     */
    public void setAccDist(int accDist) {
        this.accDist = accDist;
    }


    /**
     * Gets the accTime value for this WayPoint.
     * 
     * @return accTime
     */
    public int getAccTime() {
        return accTime;
    }


    /**
     * Sets the accTime value for this WayPoint.
     * 
     * @param accTime
     */
    public void setAccTime(int accTime) {
        this.accTime = accTime;
    }


    /**
     * Gets the countryCode value for this WayPoint.
     * 
     * @return countryCode
     */
    public java.lang.String getCountryCode() {
        return countryCode;
    }


    /**
     * Sets the countryCode value for this WayPoint.
     * 
     * @param countryCode
     */
    public void setCountryCode(java.lang.String countryCode) {
        this.countryCode = countryCode;
    }


    /**
     * Gets the iuCode value for this WayPoint.
     * 
     * @return iuCode
     */
    public int getIuCode() {
        return iuCode;
    }


    /**
     * Sets the iuCode value for this WayPoint.
     * 
     * @param iuCode
     */
    public void setIuCode(int iuCode) {
        this.iuCode = iuCode;
    }


    /**
     * Gets the manoeuvreIdx value for this WayPoint.
     * 
     * @return manoeuvreIdx
     */
    public int getManoeuvreIdx() {
        return manoeuvreIdx;
    }


    /**
     * Sets the manoeuvreIdx value for this WayPoint.
     * 
     * @param manoeuvreIdx
     */
    public void setManoeuvreIdx(int manoeuvreIdx) {
        this.manoeuvreIdx = manoeuvreIdx;
    }


    /**
     * Gets the nodeIdx value for this WayPoint.
     * 
     * @return nodeIdx
     */
    public int getNodeIdx() {
        return nodeIdx;
    }


    /**
     * Sets the nodeIdx value for this WayPoint.
     * 
     * @param nodeIdx
     */
    public void setNodeIdx(int nodeIdx) {
        this.nodeIdx = nodeIdx;
    }


    /**
     * Gets the polyIdx value for this WayPoint.
     * 
     * @return polyIdx
     */
    public int getPolyIdx() {
        return polyIdx;
    }


    /**
     * Sets the polyIdx value for this WayPoint.
     * 
     * @param polyIdx
     */
    public void setPolyIdx(int polyIdx) {
        this.polyIdx = polyIdx;
    }


    /**
     * Gets the segmentIdx value for this WayPoint.
     * 
     * @return segmentIdx
     */
    public int getSegmentIdx() {
        return segmentIdx;
    }


    /**
     * Sets the segmentIdx value for this WayPoint.
     * 
     * @param segmentIdx
     */
    public void setSegmentIdx(int segmentIdx) {
        this.segmentIdx = segmentIdx;
    }


    /**
     * Gets the wayPointType value for this WayPoint.
     * 
     * @return wayPointType
     */
    public com.ptvag.xserver.xroute.WayPointType getWayPointType() {
        return wayPointType;
    }


    /**
     * Sets the wayPointType value for this WayPoint.
     * 
     * @param wayPointType
     */
    public void setWayPointType(com.ptvag.xserver.xroute.WayPointType wayPointType) {
        this.wayPointType = wayPointType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof WayPoint)) return false;
        WayPoint other = (WayPoint) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.locationCoord==null && other.getLocationCoord()==null) || 
             (this.locationCoord!=null &&
              this.locationCoord.equals(other.getLocationCoord()))) &&
            ((this.matchCoord==null && other.getMatchCoord()==null) || 
             (this.matchCoord!=null &&
              this.matchCoord.equals(other.getMatchCoord()))) &&
            this.accDist == other.getAccDist() &&
            this.accTime == other.getAccTime() &&
            ((this.countryCode==null && other.getCountryCode()==null) || 
             (this.countryCode!=null &&
              this.countryCode.equals(other.getCountryCode()))) &&
            this.iuCode == other.getIuCode() &&
            this.manoeuvreIdx == other.getManoeuvreIdx() &&
            this.nodeIdx == other.getNodeIdx() &&
            this.polyIdx == other.getPolyIdx() &&
            this.segmentIdx == other.getSegmentIdx() &&
            ((this.wayPointType==null && other.getWayPointType()==null) || 
             (this.wayPointType!=null &&
              this.wayPointType.equals(other.getWayPointType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLocationCoord() != null) {
            _hashCode += getLocationCoord().hashCode();
        }
        if (getMatchCoord() != null) {
            _hashCode += getMatchCoord().hashCode();
        }
        _hashCode += getAccDist();
        _hashCode += getAccTime();
        if (getCountryCode() != null) {
            _hashCode += getCountryCode().hashCode();
        }
        _hashCode += getIuCode();
        _hashCode += getManoeuvreIdx();
        _hashCode += getNodeIdx();
        _hashCode += getPolyIdx();
        _hashCode += getSegmentIdx();
        if (getWayPointType() != null) {
            _hashCode += getWayPointType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WayPoint.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WayPoint"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("accDist");
        attrField.setXmlName(new javax.xml.namespace.QName("", "accDist"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("accTime");
        attrField.setXmlName(new javax.xml.namespace.QName("", "accTime"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("countryCode");
        attrField.setXmlName(new javax.xml.namespace.QName("", "countryCode"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("iuCode");
        attrField.setXmlName(new javax.xml.namespace.QName("", "iuCode"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("manoeuvreIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "manoeuvreIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("nodeIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "nodeIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("polyIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "polyIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("segmentIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "segmentIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("wayPointType");
        attrField.setXmlName(new javax.xml.namespace.QName("", "wayPointType"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WayPointType"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("locationCoord");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "locationCoord"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("matchCoord");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "matchCoord"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
