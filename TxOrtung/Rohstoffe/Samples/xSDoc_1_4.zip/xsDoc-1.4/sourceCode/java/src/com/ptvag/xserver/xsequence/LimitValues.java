/**
 * LimitValues.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class LimitValues  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private int homeDistanceRadius;  // attribute

    private int maxStopCountOI;  // attribute

    private int maxStopWaitingPeriod;  // attribute

    private int maxTourDistanceOI;  // attribute

    private int maxTourPeriodOI;  // attribute

    private int maxTourWaitingPeriodOI;  // attribute

    public LimitValues() {
    }

    public LimitValues(
           int homeDistanceRadius,
           int maxStopCountOI,
           int maxStopWaitingPeriod,
           int maxTourDistanceOI,
           int maxTourPeriodOI,
           int maxTourWaitingPeriodOI) {
        this.homeDistanceRadius = homeDistanceRadius;
        this.maxStopCountOI = maxStopCountOI;
        this.maxStopWaitingPeriod = maxStopWaitingPeriod;
        this.maxTourDistanceOI = maxTourDistanceOI;
        this.maxTourPeriodOI = maxTourPeriodOI;
        this.maxTourWaitingPeriodOI = maxTourWaitingPeriodOI;
    }


    /**
     * Gets the homeDistanceRadius value for this LimitValues.
     * 
     * @return homeDistanceRadius
     */
    public int getHomeDistanceRadius() {
        return homeDistanceRadius;
    }


    /**
     * Sets the homeDistanceRadius value for this LimitValues.
     * 
     * @param homeDistanceRadius
     */
    public void setHomeDistanceRadius(int homeDistanceRadius) {
        this.homeDistanceRadius = homeDistanceRadius;
    }


    /**
     * Gets the maxStopCountOI value for this LimitValues.
     * 
     * @return maxStopCountOI
     */
    public int getMaxStopCountOI() {
        return maxStopCountOI;
    }


    /**
     * Sets the maxStopCountOI value for this LimitValues.
     * 
     * @param maxStopCountOI
     */
    public void setMaxStopCountOI(int maxStopCountOI) {
        this.maxStopCountOI = maxStopCountOI;
    }


    /**
     * Gets the maxStopWaitingPeriod value for this LimitValues.
     * 
     * @return maxStopWaitingPeriod
     */
    public int getMaxStopWaitingPeriod() {
        return maxStopWaitingPeriod;
    }


    /**
     * Sets the maxStopWaitingPeriod value for this LimitValues.
     * 
     * @param maxStopWaitingPeriod
     */
    public void setMaxStopWaitingPeriod(int maxStopWaitingPeriod) {
        this.maxStopWaitingPeriod = maxStopWaitingPeriod;
    }


    /**
     * Gets the maxTourDistanceOI value for this LimitValues.
     * 
     * @return maxTourDistanceOI
     */
    public int getMaxTourDistanceOI() {
        return maxTourDistanceOI;
    }


    /**
     * Sets the maxTourDistanceOI value for this LimitValues.
     * 
     * @param maxTourDistanceOI
     */
    public void setMaxTourDistanceOI(int maxTourDistanceOI) {
        this.maxTourDistanceOI = maxTourDistanceOI;
    }


    /**
     * Gets the maxTourPeriodOI value for this LimitValues.
     * 
     * @return maxTourPeriodOI
     */
    public int getMaxTourPeriodOI() {
        return maxTourPeriodOI;
    }


    /**
     * Sets the maxTourPeriodOI value for this LimitValues.
     * 
     * @param maxTourPeriodOI
     */
    public void setMaxTourPeriodOI(int maxTourPeriodOI) {
        this.maxTourPeriodOI = maxTourPeriodOI;
    }


    /**
     * Gets the maxTourWaitingPeriodOI value for this LimitValues.
     * 
     * @return maxTourWaitingPeriodOI
     */
    public int getMaxTourWaitingPeriodOI() {
        return maxTourWaitingPeriodOI;
    }


    /**
     * Sets the maxTourWaitingPeriodOI value for this LimitValues.
     * 
     * @param maxTourWaitingPeriodOI
     */
    public void setMaxTourWaitingPeriodOI(int maxTourWaitingPeriodOI) {
        this.maxTourWaitingPeriodOI = maxTourWaitingPeriodOI;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LimitValues)) return false;
        LimitValues other = (LimitValues) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.homeDistanceRadius == other.getHomeDistanceRadius() &&
            this.maxStopCountOI == other.getMaxStopCountOI() &&
            this.maxStopWaitingPeriod == other.getMaxStopWaitingPeriod() &&
            this.maxTourDistanceOI == other.getMaxTourDistanceOI() &&
            this.maxTourPeriodOI == other.getMaxTourPeriodOI() &&
            this.maxTourWaitingPeriodOI == other.getMaxTourWaitingPeriodOI();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getHomeDistanceRadius();
        _hashCode += getMaxStopCountOI();
        _hashCode += getMaxStopWaitingPeriod();
        _hashCode += getMaxTourDistanceOI();
        _hashCode += getMaxTourPeriodOI();
        _hashCode += getMaxTourWaitingPeriodOI();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LimitValues.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "LimitValues"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("homeDistanceRadius");
        attrField.setXmlName(new javax.xml.namespace.QName("", "homeDistanceRadius"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("maxStopCountOI");
        attrField.setXmlName(new javax.xml.namespace.QName("", "maxStopCountOI"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("maxStopWaitingPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "maxStopWaitingPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("maxTourDistanceOI");
        attrField.setXmlName(new javax.xml.namespace.QName("", "maxTourDistanceOI"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("maxTourPeriodOI");
        attrField.setXmlName(new javax.xml.namespace.QName("", "maxTourPeriodOI"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("maxTourWaitingPeriodOI");
        attrField.setXmlName(new javax.xml.namespace.QName("", "maxTourWaitingPeriodOI"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
