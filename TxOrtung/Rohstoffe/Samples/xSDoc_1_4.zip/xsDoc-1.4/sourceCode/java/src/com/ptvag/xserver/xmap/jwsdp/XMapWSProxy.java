package com.ptvag.xserver.xmap.jwsdp;

public class XMapWSProxy implements com.ptvag.xserver.xmap.jwsdp.XMapWS {
  private String _endpoint = null;
  private com.ptvag.xserver.xmap.jwsdp.XMapWS xMapWS = null;
  
  public XMapWSProxy() {
    _initXMapWSProxy();
  }
  
  public XMapWSProxy(String endpoint) {
    _endpoint = endpoint;
    _initXMapWSProxy();
  }
  
  private void _initXMapWSProxy() {
    try {
      xMapWS = (new com.ptvag.xserver.xmap.jwsdp.XMapWSServiceLocator()).getXMapWSPort();
      if (xMapWS != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)xMapWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)xMapWS)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (xMapWS != null)
      ((javax.xml.rpc.Stub)xMapWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ptvag.xserver.xmap.jwsdp.XMapWS getXMapWS() {
    if (xMapWS == null)
      _initXMapWSProxy();
    return xMapWS;
  }
  
  public com.ptvag.xserver.xmap.Map renderMap(com.ptvag.xserver.xmap.MapSection mapSection_1, com.ptvag.xserver.xmap.MapParams mapParams_2, com.ptvag.xserver.xmap.ImageInfo imageInfo_3, com.ptvag.xserver.xmap.Layer[] arrayOfLayer_4, boolean boolean_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xmap.XMapException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xMapWS == null)
      _initXMapWSProxy();
    return xMapWS.renderMap(mapSection_1, mapParams_2, imageInfo_3, arrayOfLayer_4, boolean_5, callerContext_6);
  }
  
  public com.ptvag.xserver.xmap.Map renderMapBoundingBox(com.ptvag.xserver.common.BoundingBox boundingBox_1, com.ptvag.xserver.xmap.MapParams mapParams_2, com.ptvag.xserver.xmap.ImageInfo imageInfo_3, com.ptvag.xserver.xmap.Layer[] arrayOfLayer_4, boolean boolean_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xmap.XMapException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xMapWS == null)
      _initXMapWSProxy();
    return xMapWS.renderMapBoundingBox(boundingBox_1, mapParams_2, imageInfo_3, arrayOfLayer_4, boolean_5, callerContext_6);
  }
  
  public com.ptvag.xserver.xmap.Map renderMapRot(com.ptvag.xserver.xmap.MapSectionRot mapSectionRot_1, com.ptvag.xserver.xmap.MapParams mapParams_2, com.ptvag.xserver.xmap.ImageInfo imageInfo_3, com.ptvag.xserver.xmap.Layer[] arrayOfLayer_4, boolean boolean_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xmap.XMapException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xMapWS == null)
      _initXMapWSProxy();
    return xMapWS.renderMapRot(mapSectionRot_1, mapParams_2, imageInfo_3, arrayOfLayer_4, boolean_5, callerContext_6);
  }
  
  
}