/**
 * RawBitmap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class RawBitmap  extends com.ptvag.xserver.xmap.BasicBitmap  implements java.io.Serializable {
    private byte[] rawBitmap;  // attribute

    public RawBitmap() {
    }

    public RawBitmap(
           java.lang.String descr,
           com.ptvag.xserver.common.Point position,
           byte[] rawBitmap) {
        super(
            descr,
            position);
        this.rawBitmap = rawBitmap;
    }


    /**
     * Gets the rawBitmap value for this RawBitmap.
     * 
     * @return rawBitmap
     */
    public byte[] getRawBitmap() {
        return rawBitmap;
    }


    /**
     * Sets the rawBitmap value for this RawBitmap.
     * 
     * @param rawBitmap
     */
    public void setRawBitmap(byte[] rawBitmap) {
        this.rawBitmap = rawBitmap;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RawBitmap)) return false;
        RawBitmap other = (RawBitmap) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.rawBitmap==null && other.getRawBitmap()==null) || 
             (this.rawBitmap!=null &&
              java.util.Arrays.equals(this.rawBitmap, other.getRawBitmap())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getRawBitmap() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRawBitmap());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRawBitmap(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RawBitmap.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "RawBitmap"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("rawBitmap");
        attrField.setXmlName(new javax.xml.namespace.QName("", "rawBitmap"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
