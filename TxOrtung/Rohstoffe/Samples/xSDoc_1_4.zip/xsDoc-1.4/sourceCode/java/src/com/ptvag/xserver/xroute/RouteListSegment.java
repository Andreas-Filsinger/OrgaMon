/**
 * RouteListSegment.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class RouteListSegment  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.SegmentAttributes segmentAttr;

    private int accDist;  // attribute

    private int accTime;  // attribute

    private java.lang.String countryCode;  // attribute

    private int dirInfoIdx;  // attribute

    private int firstNodeIdx;  // attribute

    private int firstPolyIdx;  // attribute

    private int iuCode;  // attribute

    private com.ptvag.xserver.xroute.NetworkClass nC;  // attribute

    private int nodeC;  // attribute

    private int polyC;  // attribute

    private int streetNameIdx;  // attribute

    private int streetNoIdx;  // attribute

    private int vNorm;  // attribute

    public RouteListSegment() {
    }

    public RouteListSegment(
           int accDist,
           int accTime,
           java.lang.String countryCode,
           int dirInfoIdx,
           int firstNodeIdx,
           int firstPolyIdx,
           int iuCode,
           com.ptvag.xserver.xroute.NetworkClass nC,
           int nodeC,
           int polyC,
           int streetNameIdx,
           int streetNoIdx,
           int vNorm,
           com.ptvag.xserver.xroute.SegmentAttributes segmentAttr) {
        this.accDist = accDist;
        this.accTime = accTime;
        this.countryCode = countryCode;
        this.dirInfoIdx = dirInfoIdx;
        this.firstNodeIdx = firstNodeIdx;
        this.firstPolyIdx = firstPolyIdx;
        this.iuCode = iuCode;
        this.nC = nC;
        this.nodeC = nodeC;
        this.polyC = polyC;
        this.streetNameIdx = streetNameIdx;
        this.streetNoIdx = streetNoIdx;
        this.vNorm = vNorm;
        this.segmentAttr = segmentAttr;
    }


    /**
     * Gets the segmentAttr value for this RouteListSegment.
     * 
     * @return segmentAttr
     */
    public com.ptvag.xserver.xroute.SegmentAttributes getSegmentAttr() {
        return segmentAttr;
    }


    /**
     * Sets the segmentAttr value for this RouteListSegment.
     * 
     * @param segmentAttr
     */
    public void setSegmentAttr(com.ptvag.xserver.xroute.SegmentAttributes segmentAttr) {
        this.segmentAttr = segmentAttr;
    }


    /**
     * Gets the accDist value for this RouteListSegment.
     * 
     * @return accDist
     */
    public int getAccDist() {
        return accDist;
    }


    /**
     * Sets the accDist value for this RouteListSegment.
     * 
     * @param accDist
     */
    public void setAccDist(int accDist) {
        this.accDist = accDist;
    }


    /**
     * Gets the accTime value for this RouteListSegment.
     * 
     * @return accTime
     */
    public int getAccTime() {
        return accTime;
    }


    /**
     * Sets the accTime value for this RouteListSegment.
     * 
     * @param accTime
     */
    public void setAccTime(int accTime) {
        this.accTime = accTime;
    }


    /**
     * Gets the countryCode value for this RouteListSegment.
     * 
     * @return countryCode
     */
    public java.lang.String getCountryCode() {
        return countryCode;
    }


    /**
     * Sets the countryCode value for this RouteListSegment.
     * 
     * @param countryCode
     */
    public void setCountryCode(java.lang.String countryCode) {
        this.countryCode = countryCode;
    }


    /**
     * Gets the dirInfoIdx value for this RouteListSegment.
     * 
     * @return dirInfoIdx
     */
    public int getDirInfoIdx() {
        return dirInfoIdx;
    }


    /**
     * Sets the dirInfoIdx value for this RouteListSegment.
     * 
     * @param dirInfoIdx
     */
    public void setDirInfoIdx(int dirInfoIdx) {
        this.dirInfoIdx = dirInfoIdx;
    }


    /**
     * Gets the firstNodeIdx value for this RouteListSegment.
     * 
     * @return firstNodeIdx
     */
    public int getFirstNodeIdx() {
        return firstNodeIdx;
    }


    /**
     * Sets the firstNodeIdx value for this RouteListSegment.
     * 
     * @param firstNodeIdx
     */
    public void setFirstNodeIdx(int firstNodeIdx) {
        this.firstNodeIdx = firstNodeIdx;
    }


    /**
     * Gets the firstPolyIdx value for this RouteListSegment.
     * 
     * @return firstPolyIdx
     */
    public int getFirstPolyIdx() {
        return firstPolyIdx;
    }


    /**
     * Sets the firstPolyIdx value for this RouteListSegment.
     * 
     * @param firstPolyIdx
     */
    public void setFirstPolyIdx(int firstPolyIdx) {
        this.firstPolyIdx = firstPolyIdx;
    }


    /**
     * Gets the iuCode value for this RouteListSegment.
     * 
     * @return iuCode
     */
    public int getIuCode() {
        return iuCode;
    }


    /**
     * Sets the iuCode value for this RouteListSegment.
     * 
     * @param iuCode
     */
    public void setIuCode(int iuCode) {
        this.iuCode = iuCode;
    }


    /**
     * Gets the nC value for this RouteListSegment.
     * 
     * @return nC
     */
    public com.ptvag.xserver.xroute.NetworkClass getNC() {
        return nC;
    }


    /**
     * Sets the nC value for this RouteListSegment.
     * 
     * @param nC
     */
    public void setNC(com.ptvag.xserver.xroute.NetworkClass nC) {
        this.nC = nC;
    }


    /**
     * Gets the nodeC value for this RouteListSegment.
     * 
     * @return nodeC
     */
    public int getNodeC() {
        return nodeC;
    }


    /**
     * Sets the nodeC value for this RouteListSegment.
     * 
     * @param nodeC
     */
    public void setNodeC(int nodeC) {
        this.nodeC = nodeC;
    }


    /**
     * Gets the polyC value for this RouteListSegment.
     * 
     * @return polyC
     */
    public int getPolyC() {
        return polyC;
    }


    /**
     * Sets the polyC value for this RouteListSegment.
     * 
     * @param polyC
     */
    public void setPolyC(int polyC) {
        this.polyC = polyC;
    }


    /**
     * Gets the streetNameIdx value for this RouteListSegment.
     * 
     * @return streetNameIdx
     */
    public int getStreetNameIdx() {
        return streetNameIdx;
    }


    /**
     * Sets the streetNameIdx value for this RouteListSegment.
     * 
     * @param streetNameIdx
     */
    public void setStreetNameIdx(int streetNameIdx) {
        this.streetNameIdx = streetNameIdx;
    }


    /**
     * Gets the streetNoIdx value for this RouteListSegment.
     * 
     * @return streetNoIdx
     */
    public int getStreetNoIdx() {
        return streetNoIdx;
    }


    /**
     * Sets the streetNoIdx value for this RouteListSegment.
     * 
     * @param streetNoIdx
     */
    public void setStreetNoIdx(int streetNoIdx) {
        this.streetNoIdx = streetNoIdx;
    }


    /**
     * Gets the vNorm value for this RouteListSegment.
     * 
     * @return vNorm
     */
    public int getVNorm() {
        return vNorm;
    }


    /**
     * Sets the vNorm value for this RouteListSegment.
     * 
     * @param vNorm
     */
    public void setVNorm(int vNorm) {
        this.vNorm = vNorm;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RouteListSegment)) return false;
        RouteListSegment other = (RouteListSegment) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.segmentAttr==null && other.getSegmentAttr()==null) || 
             (this.segmentAttr!=null &&
              this.segmentAttr.equals(other.getSegmentAttr()))) &&
            this.accDist == other.getAccDist() &&
            this.accTime == other.getAccTime() &&
            ((this.countryCode==null && other.getCountryCode()==null) || 
             (this.countryCode!=null &&
              this.countryCode.equals(other.getCountryCode()))) &&
            this.dirInfoIdx == other.getDirInfoIdx() &&
            this.firstNodeIdx == other.getFirstNodeIdx() &&
            this.firstPolyIdx == other.getFirstPolyIdx() &&
            this.iuCode == other.getIuCode() &&
            ((this.nC==null && other.getNC()==null) || 
             (this.nC!=null &&
              this.nC.equals(other.getNC()))) &&
            this.nodeC == other.getNodeC() &&
            this.polyC == other.getPolyC() &&
            this.streetNameIdx == other.getStreetNameIdx() &&
            this.streetNoIdx == other.getStreetNoIdx() &&
            this.vNorm == other.getVNorm();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getSegmentAttr() != null) {
            _hashCode += getSegmentAttr().hashCode();
        }
        _hashCode += getAccDist();
        _hashCode += getAccTime();
        if (getCountryCode() != null) {
            _hashCode += getCountryCode().hashCode();
        }
        _hashCode += getDirInfoIdx();
        _hashCode += getFirstNodeIdx();
        _hashCode += getFirstPolyIdx();
        _hashCode += getIuCode();
        if (getNC() != null) {
            _hashCode += getNC().hashCode();
        }
        _hashCode += getNodeC();
        _hashCode += getPolyC();
        _hashCode += getStreetNameIdx();
        _hashCode += getStreetNoIdx();
        _hashCode += getVNorm();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RouteListSegment.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteListSegment"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("accDist");
        attrField.setXmlName(new javax.xml.namespace.QName("", "accDist"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("accTime");
        attrField.setXmlName(new javax.xml.namespace.QName("", "accTime"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("countryCode");
        attrField.setXmlName(new javax.xml.namespace.QName("", "countryCode"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("dirInfoIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "dirInfoIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("firstNodeIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "firstNodeIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("firstPolyIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "firstPolyIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("iuCode");
        attrField.setXmlName(new javax.xml.namespace.QName("", "iuCode"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("NC");
        attrField.setXmlName(new javax.xml.namespace.QName("", "nC"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "NetworkClass"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("nodeC");
        attrField.setXmlName(new javax.xml.namespace.QName("", "nodeC"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("polyC");
        attrField.setXmlName(new javax.xml.namespace.QName("", "polyC"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("streetNameIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "streetNameIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("streetNoIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "streetNoIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("VNorm");
        attrField.setXmlName(new javax.xml.namespace.QName("", "vNorm"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("segmentAttr");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "segmentAttr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "SegmentAttributes"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
