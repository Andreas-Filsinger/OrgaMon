/**
 * RouteDisplayProperties.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class RouteDisplayProperties  implements java.io.Serializable {
    private com.ptvag.mnp.common.Icon endIcon;

    private com.ptvag.mnp.common.Icon startIcon;

    private com.ptvag.mnp.common.Icon viaIcon;

    public RouteDisplayProperties() {
    }

    public RouteDisplayProperties(
           com.ptvag.mnp.common.Icon endIcon,
           com.ptvag.mnp.common.Icon startIcon,
           com.ptvag.mnp.common.Icon viaIcon) {
           this.endIcon = endIcon;
           this.startIcon = startIcon;
           this.viaIcon = viaIcon;
    }


    /**
     * Gets the endIcon value for this RouteDisplayProperties.
     * 
     * @return endIcon
     */
    public com.ptvag.mnp.common.Icon getEndIcon() {
        return endIcon;
    }


    /**
     * Sets the endIcon value for this RouteDisplayProperties.
     * 
     * @param endIcon
     */
    public void setEndIcon(com.ptvag.mnp.common.Icon endIcon) {
        this.endIcon = endIcon;
    }


    /**
     * Gets the startIcon value for this RouteDisplayProperties.
     * 
     * @return startIcon
     */
    public com.ptvag.mnp.common.Icon getStartIcon() {
        return startIcon;
    }


    /**
     * Sets the startIcon value for this RouteDisplayProperties.
     * 
     * @param startIcon
     */
    public void setStartIcon(com.ptvag.mnp.common.Icon startIcon) {
        this.startIcon = startIcon;
    }


    /**
     * Gets the viaIcon value for this RouteDisplayProperties.
     * 
     * @return viaIcon
     */
    public com.ptvag.mnp.common.Icon getViaIcon() {
        return viaIcon;
    }


    /**
     * Sets the viaIcon value for this RouteDisplayProperties.
     * 
     * @param viaIcon
     */
    public void setViaIcon(com.ptvag.mnp.common.Icon viaIcon) {
        this.viaIcon = viaIcon;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RouteDisplayProperties)) return false;
        RouteDisplayProperties other = (RouteDisplayProperties) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.endIcon==null && other.getEndIcon()==null) || 
             (this.endIcon!=null &&
              this.endIcon.equals(other.getEndIcon()))) &&
            ((this.startIcon==null && other.getStartIcon()==null) || 
             (this.startIcon!=null &&
              this.startIcon.equals(other.getStartIcon()))) &&
            ((this.viaIcon==null && other.getViaIcon()==null) || 
             (this.viaIcon!=null &&
              this.viaIcon.equals(other.getViaIcon())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEndIcon() != null) {
            _hashCode += getEndIcon().hashCode();
        }
        if (getStartIcon() != null) {
            _hashCode += getStartIcon().hashCode();
        }
        if (getViaIcon() != null) {
            _hashCode += getViaIcon().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RouteDisplayProperties.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteDisplayProperties"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endIcon");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "endIcon"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Icon"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startIcon");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "startIcon"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Icon"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("viaIcon");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "viaIcon"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Icon"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
