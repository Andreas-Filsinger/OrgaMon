package com.ptvag.mnp.trafficinfoservice.jwsdp;

public class TrafficInfoServiceWSProxy implements com.ptvag.mnp.trafficinfoservice.jwsdp.TrafficInfoServiceWS {
  private String _endpoint = null;
  private com.ptvag.mnp.trafficinfoservice.jwsdp.TrafficInfoServiceWS trafficInfoServiceWS = null;
  
  public TrafficInfoServiceWSProxy() {
    _initTrafficInfoServiceWSProxy();
  }
  
  public TrafficInfoServiceWSProxy(String endpoint) {
    _endpoint = endpoint;
    _initTrafficInfoServiceWSProxy();
  }
  
  private void _initTrafficInfoServiceWSProxy() {
    try {
      trafficInfoServiceWS = (new com.ptvag.mnp.trafficinfoservice.jwsdp.TrafficInfoServiceWSServiceLocator()).getTrafficInfoServiceWSPort();
      if (trafficInfoServiceWS != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)trafficInfoServiceWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)trafficInfoServiceWS)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (trafficInfoServiceWS != null)
      ((javax.xml.rpc.Stub)trafficInfoServiceWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ptvag.mnp.trafficinfoservice.jwsdp.TrafficInfoServiceWS getTrafficInfoServiceWS() {
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS;
  }
  
  public void dummy(com.ptvag.mnp.common.ConstBoolExpr constBoolExpr_1, com.ptvag.mnp.common.BinBoolExpr binBoolExpr_2, com.ptvag.mnp.common.LikeExpr likeExpr_3, com.ptvag.mnp.common.CompExpr compExpr_4, com.ptvag.mnp.common.MathExpr mathExpr_5, com.ptvag.mnp.common.ColExpr colExpr_6, com.ptvag.mnp.common.ConstExpr constExpr_7, com.ptvag.mnp.common.ScalarExpr scalarExpr_8, com.ptvag.mnp.common.POIViewMapSet POIViewMapSet_9, com.ptvag.mnp.common.NullExpr nullExpr_10, com.ptvag.jabba.service.baseservices.CallerContext callerContext_11) throws java.rmi.RemoteException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    trafficInfoServiceWS.dummy(constBoolExpr_1, binBoolExpr_2, likeExpr_3, compExpr_4, mathExpr_5, colExpr_6, constExpr_7, scalarExpr_8, POIViewMapSet_9, nullExpr_10, callerContext_11);
  }
  
  public com.ptvag.mnp.common.MapView getCachedMap(com.ptvag.mnp.common.CachedObjectEnum cachedObjectEnum_1, java.lang.String string_2, com.ptvag.jabba.service.baseservices.CallerContext callerContext_3) throws java.rmi.RemoteException, com.ptvag.mnp.mapping.exception.MapHistoryNavigationException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.getCachedMap(cachedObjectEnum_1, string_2, callerContext_3);
  }
  
  public com.ptvag.mnp.common.POIViewSet[] getGeneralTrafficInfos(java.lang.String[] arrayOfString_1, java.lang.String string_2, com.ptvag.jabba.service.baseservices.CallerContext callerContext_3) throws java.rmi.RemoteException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedIsoCodeException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.getGeneralTrafficInfos(arrayOfString_1, string_2, callerContext_3);
  }
  
  public com.ptvag.mnp.common.MapView getMapByProviders(com.ptvag.mnp.common.POIViewSet[] arrayOfPOIViewSet_1, com.ptvag.mnp.common.ImageProperties imageProperties_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.mnp.common.exception.UnsupportedImageProfileException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.mapping.exception.NoPoisForBoundingMapFoundException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException, com.ptvag.mnp.common.exception.UnsupportedIsoCodeException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.getMapByProviders(arrayOfPOIViewSet_1, imageProperties_2, string_3, string_4, callerContext_5);
  }
  
  public com.ptvag.mnp.common.MapView getMapByRectangle(com.ptvag.mnp.common.BoundingBox boundingBox_1, com.ptvag.mnp.common.POIViewSet[] arrayOfPOIViewSet_2, com.ptvag.mnp.common.ImageProperties imageProperties_3, java.lang.String string_4, java.lang.String string_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.mnp.common.exception.UnsupportedImageProfileException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.getMapByRectangle(boundingBox_1, arrayOfPOIViewSet_2, imageProperties_3, string_4, string_5, callerContext_6);
  }
  
  public com.ptvag.mnp.common.MapView getMapByRoads(java.lang.String[] arrayOfString_1, java.lang.String[] arrayOfString_2, java.lang.String string_3, com.ptvag.mnp.common.ImageProperties imageProperties_4, java.lang.String string_5, java.lang.String string_6, com.ptvag.jabba.service.baseservices.CallerContext callerContext_7) throws java.rmi.RemoteException, com.ptvag.mnp.common.exception.UnsupportedImageProfileException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.mapping.exception.NoPoisForBoundingMapFoundException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException, com.ptvag.mnp.common.exception.UnsupportedIsoCodeException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.getMapByRoads(arrayOfString_1, arrayOfString_2, string_3, imageProperties_4, string_5, string_6, callerContext_7);
  }
  
  public com.ptvag.mnp.common.POIViewSet getRegions(java.lang.String string_1, java.lang.String string_2, com.ptvag.jabba.service.baseservices.CallerContext callerContext_3) throws java.rmi.RemoteException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedIsoCodeException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.getRegions(string_1, string_2, callerContext_3);
  }
  
  public com.ptvag.mnp.common.POIViewSet[] getRoadsWithMessages(java.lang.String[] arrayOfString_1, com.ptvag.jabba.service.baseservices.CallerContext callerContext_2) throws java.rmi.RemoteException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.getRoadsWithMessages(arrayOfString_1, callerContext_2);
  }
  
  public com.ptvag.mnp.common.POIViewSet[] getTrafficInfosByProviders(com.ptvag.mnp.common.POIViewSet[] arrayOfPOIViewSet_1, com.ptvag.jabba.service.baseservices.CallerContext callerContext_2) throws java.rmi.RemoteException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.getTrafficInfosByProviders(arrayOfPOIViewSet_1, callerContext_2);
  }
  
  public com.ptvag.mnp.common.POIViewSet[] getTrafficInfosByRectangle(com.ptvag.mnp.common.BoundingBox boundingBox_1, com.ptvag.mnp.common.POIViewSet[] arrayOfPOIViewSet_2, com.ptvag.jabba.service.baseservices.CallerContext callerContext_3) throws java.rmi.RemoteException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.getTrafficInfosByRectangle(boundingBox_1, arrayOfPOIViewSet_2, callerContext_3);
  }
  
  public com.ptvag.mnp.common.POIViewSet[] getTrafficInfosByRoads(java.lang.String[] arrayOfString_1, java.lang.String[] arrayOfString_2, java.lang.String string_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedIsoCodeException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.getTrafficInfosByRoads(arrayOfString_1, arrayOfString_2, string_3, callerContext_4);
  }
  
  public com.ptvag.mnp.common.MapView moveMapByDevice(int int_1, int int_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.moveMapByDevice(int_1, int_2, string_3, string_4, callerContext_5);
  }
  
  public com.ptvag.mnp.common.MapView moveMapByPercentage(float float_1, float float_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.moveMapByPercentage(float_1, float_2, string_3, string_4, callerContext_5);
  }
  
  public com.ptvag.mnp.common.MapView scaleMapByWidthHeight(int int_1, int int_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.scaleMapByWidthHeight(int_1, int_2, string_3, string_4, callerContext_5);
  }
  
  public com.ptvag.mnp.common.MapView zoomMapByLevel(int int_1, com.ptvag.mnp.common.Coordinate coordinate_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.zoomMapByLevel(int_1, coordinate_2, string_3, string_4, callerContext_5);
  }
  
  public com.ptvag.mnp.common.MapView zoomMapByRectangle(com.ptvag.mnp.common.BoundingBox boundingBox_1, java.lang.String string_2, java.lang.String string_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.zoomMapByRectangle(boundingBox_1, string_2, string_3, callerContext_4);
  }
  
  public com.ptvag.mnp.common.MapView zoomMapByWidthHeight(double double_1, double double_2, com.ptvag.mnp.common.Coordinate coordinate_3, java.lang.String string_4, java.lang.String string_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException{
    if (trafficInfoServiceWS == null)
      _initTrafficInfoServiceWSProxy();
    return trafficInfoServiceWS.zoomMapByWidthHeight(double_1, double_2, coordinate_3, string_4, string_5, callerContext_6);
  }
  
  
}