/**
 * TimeEvent.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class TimeEvent  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private int period;  // attribute

    private int segmentIdx;  // attribute

    private int startTime;  // attribute

    private int tourPointIdx;  // attribute

    private com.ptvag.xserver.xroute.TimeEventType type;  // attribute

    public TimeEvent() {
    }

    public TimeEvent(
           int period,
           int segmentIdx,
           int startTime,
           int tourPointIdx,
           com.ptvag.xserver.xroute.TimeEventType type) {
        this.period = period;
        this.segmentIdx = segmentIdx;
        this.startTime = startTime;
        this.tourPointIdx = tourPointIdx;
        this.type = type;
    }


    /**
     * Gets the period value for this TimeEvent.
     * 
     * @return period
     */
    public int getPeriod() {
        return period;
    }


    /**
     * Sets the period value for this TimeEvent.
     * 
     * @param period
     */
    public void setPeriod(int period) {
        this.period = period;
    }


    /**
     * Gets the segmentIdx value for this TimeEvent.
     * 
     * @return segmentIdx
     */
    public int getSegmentIdx() {
        return segmentIdx;
    }


    /**
     * Sets the segmentIdx value for this TimeEvent.
     * 
     * @param segmentIdx
     */
    public void setSegmentIdx(int segmentIdx) {
        this.segmentIdx = segmentIdx;
    }


    /**
     * Gets the startTime value for this TimeEvent.
     * 
     * @return startTime
     */
    public int getStartTime() {
        return startTime;
    }


    /**
     * Sets the startTime value for this TimeEvent.
     * 
     * @param startTime
     */
    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }


    /**
     * Gets the tourPointIdx value for this TimeEvent.
     * 
     * @return tourPointIdx
     */
    public int getTourPointIdx() {
        return tourPointIdx;
    }


    /**
     * Sets the tourPointIdx value for this TimeEvent.
     * 
     * @param tourPointIdx
     */
    public void setTourPointIdx(int tourPointIdx) {
        this.tourPointIdx = tourPointIdx;
    }


    /**
     * Gets the type value for this TimeEvent.
     * 
     * @return type
     */
    public com.ptvag.xserver.xroute.TimeEventType getType() {
        return type;
    }


    /**
     * Sets the type value for this TimeEvent.
     * 
     * @param type
     */
    public void setType(com.ptvag.xserver.xroute.TimeEventType type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TimeEvent)) return false;
        TimeEvent other = (TimeEvent) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.period == other.getPeriod() &&
            this.segmentIdx == other.getSegmentIdx() &&
            this.startTime == other.getStartTime() &&
            this.tourPointIdx == other.getTourPointIdx() &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getPeriod();
        _hashCode += getSegmentIdx();
        _hashCode += getStartTime();
        _hashCode += getTourPointIdx();
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TimeEvent.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TimeEvent"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("period");
        attrField.setXmlName(new javax.xml.namespace.QName("", "period"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("segmentIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "segmentIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("startTime");
        attrField.setXmlName(new javax.xml.namespace.QName("", "startTime"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tourPointIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tourPointIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("type");
        attrField.setXmlName(new javax.xml.namespace.QName("", "type"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TimeEventType"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
