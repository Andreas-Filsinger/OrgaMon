/**
 * DistanceMatrix.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class DistanceMatrix  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xsequence.DistPeriod[] wrappedDistPeriods;

    private com.ptvag.xserver.common.Point[] wrappedLocations;

    public DistanceMatrix() {
    }

    public DistanceMatrix(
           com.ptvag.xserver.xsequence.DistPeriod[] wrappedDistPeriods,
           com.ptvag.xserver.common.Point[] wrappedLocations) {
        this.wrappedDistPeriods = wrappedDistPeriods;
        this.wrappedLocations = wrappedLocations;
    }


    /**
     * Gets the wrappedDistPeriods value for this DistanceMatrix.
     * 
     * @return wrappedDistPeriods
     */
    public com.ptvag.xserver.xsequence.DistPeriod[] getWrappedDistPeriods() {
        return wrappedDistPeriods;
    }


    /**
     * Sets the wrappedDistPeriods value for this DistanceMatrix.
     * 
     * @param wrappedDistPeriods
     */
    public void setWrappedDistPeriods(com.ptvag.xserver.xsequence.DistPeriod[] wrappedDistPeriods) {
        this.wrappedDistPeriods = wrappedDistPeriods;
    }


    /**
     * Gets the wrappedLocations value for this DistanceMatrix.
     * 
     * @return wrappedLocations
     */
    public com.ptvag.xserver.common.Point[] getWrappedLocations() {
        return wrappedLocations;
    }


    /**
     * Sets the wrappedLocations value for this DistanceMatrix.
     * 
     * @param wrappedLocations
     */
    public void setWrappedLocations(com.ptvag.xserver.common.Point[] wrappedLocations) {
        this.wrappedLocations = wrappedLocations;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DistanceMatrix)) return false;
        DistanceMatrix other = (DistanceMatrix) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedDistPeriods==null && other.getWrappedDistPeriods()==null) || 
             (this.wrappedDistPeriods!=null &&
              java.util.Arrays.equals(this.wrappedDistPeriods, other.getWrappedDistPeriods()))) &&
            ((this.wrappedLocations==null && other.getWrappedLocations()==null) || 
             (this.wrappedLocations!=null &&
              java.util.Arrays.equals(this.wrappedLocations, other.getWrappedLocations())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedDistPeriods() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedDistPeriods());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedDistPeriods(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedLocations() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedLocations());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedLocations(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DistanceMatrix.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistanceMatrix"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedDistPeriods");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "wrappedDistPeriods"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistPeriod"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistPeriod"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedLocations");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "wrappedLocations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
