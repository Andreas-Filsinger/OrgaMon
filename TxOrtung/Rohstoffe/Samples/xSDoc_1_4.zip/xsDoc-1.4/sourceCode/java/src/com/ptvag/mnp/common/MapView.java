/**
 * MapView.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class MapView  implements java.io.Serializable {
    private com.ptvag.mnp.common.BoundingBox bbox;

    private com.ptvag.mnp.common.Image image;

    private java.lang.String mapName;

    private com.ptvag.mnp.common.POIViewSet[] wrappedPoiViewSets;

    private com.ptvag.mnp.common.RouteView[] wrappedRoutes;

    public MapView() {
    }

    public MapView(
           com.ptvag.mnp.common.BoundingBox bbox,
           com.ptvag.mnp.common.Image image,
           java.lang.String mapName,
           com.ptvag.mnp.common.POIViewSet[] wrappedPoiViewSets,
           com.ptvag.mnp.common.RouteView[] wrappedRoutes) {
           this.bbox = bbox;
           this.image = image;
           this.mapName = mapName;
           this.wrappedPoiViewSets = wrappedPoiViewSets;
           this.wrappedRoutes = wrappedRoutes;
    }


    /**
     * Gets the bbox value for this MapView.
     * 
     * @return bbox
     */
    public com.ptvag.mnp.common.BoundingBox getBbox() {
        return bbox;
    }


    /**
     * Sets the bbox value for this MapView.
     * 
     * @param bbox
     */
    public void setBbox(com.ptvag.mnp.common.BoundingBox bbox) {
        this.bbox = bbox;
    }


    /**
     * Gets the image value for this MapView.
     * 
     * @return image
     */
    public com.ptvag.mnp.common.Image getImage() {
        return image;
    }


    /**
     * Sets the image value for this MapView.
     * 
     * @param image
     */
    public void setImage(com.ptvag.mnp.common.Image image) {
        this.image = image;
    }


    /**
     * Gets the mapName value for this MapView.
     * 
     * @return mapName
     */
    public java.lang.String getMapName() {
        return mapName;
    }


    /**
     * Sets the mapName value for this MapView.
     * 
     * @param mapName
     */
    public void setMapName(java.lang.String mapName) {
        this.mapName = mapName;
    }


    /**
     * Gets the wrappedPoiViewSets value for this MapView.
     * 
     * @return wrappedPoiViewSets
     */
    public com.ptvag.mnp.common.POIViewSet[] getWrappedPoiViewSets() {
        return wrappedPoiViewSets;
    }


    /**
     * Sets the wrappedPoiViewSets value for this MapView.
     * 
     * @param wrappedPoiViewSets
     */
    public void setWrappedPoiViewSets(com.ptvag.mnp.common.POIViewSet[] wrappedPoiViewSets) {
        this.wrappedPoiViewSets = wrappedPoiViewSets;
    }


    /**
     * Gets the wrappedRoutes value for this MapView.
     * 
     * @return wrappedRoutes
     */
    public com.ptvag.mnp.common.RouteView[] getWrappedRoutes() {
        return wrappedRoutes;
    }


    /**
     * Sets the wrappedRoutes value for this MapView.
     * 
     * @param wrappedRoutes
     */
    public void setWrappedRoutes(com.ptvag.mnp.common.RouteView[] wrappedRoutes) {
        this.wrappedRoutes = wrappedRoutes;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MapView)) return false;
        MapView other = (MapView) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.bbox==null && other.getBbox()==null) || 
             (this.bbox!=null &&
              this.bbox.equals(other.getBbox()))) &&
            ((this.image==null && other.getImage()==null) || 
             (this.image!=null &&
              this.image.equals(other.getImage()))) &&
            ((this.mapName==null && other.getMapName()==null) || 
             (this.mapName!=null &&
              this.mapName.equals(other.getMapName()))) &&
            ((this.wrappedPoiViewSets==null && other.getWrappedPoiViewSets()==null) || 
             (this.wrappedPoiViewSets!=null &&
              java.util.Arrays.equals(this.wrappedPoiViewSets, other.getWrappedPoiViewSets()))) &&
            ((this.wrappedRoutes==null && other.getWrappedRoutes()==null) || 
             (this.wrappedRoutes!=null &&
              java.util.Arrays.equals(this.wrappedRoutes, other.getWrappedRoutes())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBbox() != null) {
            _hashCode += getBbox().hashCode();
        }
        if (getImage() != null) {
            _hashCode += getImage().hashCode();
        }
        if (getMapName() != null) {
            _hashCode += getMapName().hashCode();
        }
        if (getWrappedPoiViewSets() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedPoiViewSets());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedPoiViewSets(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedRoutes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedRoutes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedRoutes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MapView.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MapView"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bbox");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "bbox"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BoundingBox"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("image");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "image"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Image"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mapName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "mapName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedPoiViewSets");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedPoiViewSets"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIViewSet"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedRoutes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedRoutes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteView"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfRouteView"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
