/**
 * PlanningParams.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class PlanningParams  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xsequence.DistanceCalculation distanceCalculation;

    private int costDistanceKm;  // attribute

    private int costPeriodMinute;  // attribute

    private int maxProcessorPeriod;  // attribute

    public PlanningParams() {
    }

    public PlanningParams(
           int costDistanceKm,
           int costPeriodMinute,
           int maxProcessorPeriod,
           com.ptvag.xserver.xsequence.DistanceCalculation distanceCalculation) {
        this.costDistanceKm = costDistanceKm;
        this.costPeriodMinute = costPeriodMinute;
        this.maxProcessorPeriod = maxProcessorPeriod;
        this.distanceCalculation = distanceCalculation;
    }


    /**
     * Gets the distanceCalculation value for this PlanningParams.
     * 
     * @return distanceCalculation
     */
    public com.ptvag.xserver.xsequence.DistanceCalculation getDistanceCalculation() {
        return distanceCalculation;
    }


    /**
     * Sets the distanceCalculation value for this PlanningParams.
     * 
     * @param distanceCalculation
     */
    public void setDistanceCalculation(com.ptvag.xserver.xsequence.DistanceCalculation distanceCalculation) {
        this.distanceCalculation = distanceCalculation;
    }


    /**
     * Gets the costDistanceKm value for this PlanningParams.
     * 
     * @return costDistanceKm
     */
    public int getCostDistanceKm() {
        return costDistanceKm;
    }


    /**
     * Sets the costDistanceKm value for this PlanningParams.
     * 
     * @param costDistanceKm
     */
    public void setCostDistanceKm(int costDistanceKm) {
        this.costDistanceKm = costDistanceKm;
    }


    /**
     * Gets the costPeriodMinute value for this PlanningParams.
     * 
     * @return costPeriodMinute
     */
    public int getCostPeriodMinute() {
        return costPeriodMinute;
    }


    /**
     * Sets the costPeriodMinute value for this PlanningParams.
     * 
     * @param costPeriodMinute
     */
    public void setCostPeriodMinute(int costPeriodMinute) {
        this.costPeriodMinute = costPeriodMinute;
    }


    /**
     * Gets the maxProcessorPeriod value for this PlanningParams.
     * 
     * @return maxProcessorPeriod
     */
    public int getMaxProcessorPeriod() {
        return maxProcessorPeriod;
    }


    /**
     * Sets the maxProcessorPeriod value for this PlanningParams.
     * 
     * @param maxProcessorPeriod
     */
    public void setMaxProcessorPeriod(int maxProcessorPeriod) {
        this.maxProcessorPeriod = maxProcessorPeriod;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PlanningParams)) return false;
        PlanningParams other = (PlanningParams) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.distanceCalculation==null && other.getDistanceCalculation()==null) || 
             (this.distanceCalculation!=null &&
              this.distanceCalculation.equals(other.getDistanceCalculation()))) &&
            this.costDistanceKm == other.getCostDistanceKm() &&
            this.costPeriodMinute == other.getCostPeriodMinute() &&
            this.maxProcessorPeriod == other.getMaxProcessorPeriod();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDistanceCalculation() != null) {
            _hashCode += getDistanceCalculation().hashCode();
        }
        _hashCode += getCostDistanceKm();
        _hashCode += getCostPeriodMinute();
        _hashCode += getMaxProcessorPeriod();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PlanningParams.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "PlanningParams"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("costDistanceKm");
        attrField.setXmlName(new javax.xml.namespace.QName("", "costDistanceKm"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("costPeriodMinute");
        attrField.setXmlName(new javax.xml.namespace.QName("", "costPeriodMinute"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("maxProcessorPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "maxProcessorPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("distanceCalculation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "distanceCalculation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistanceCalculation"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
