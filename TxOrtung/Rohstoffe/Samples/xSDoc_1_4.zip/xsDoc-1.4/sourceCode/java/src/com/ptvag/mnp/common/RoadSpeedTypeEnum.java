/**
 * RoadSpeedTypeEnum.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class RoadSpeedTypeEnum implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected RoadSpeedTypeEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _MOTORWAY_FAST = "MOTORWAY_FAST";
    public static final java.lang.String _MOTORWAY_NORMAL = "MOTORWAY_NORMAL";
    public static final java.lang.String _MOTORWAY_SLOW = "MOTORWAY_SLOW";
    public static final java.lang.String _TRUNKROAD_FAST = "TRUNKROAD_FAST";
    public static final java.lang.String _TRUNKROAD_NORMAL = "TRUNKROAD_NORMAL";
    public static final java.lang.String _TRUNKROAD_SLOW = "TRUNKROAD_SLOW";
    public static final java.lang.String _COUNTRYROAD_FAST = "COUNTRYROAD_FAST";
    public static final java.lang.String _COUNTRYROAD_NORMAL = "COUNTRYROAD_NORMAL";
    public static final java.lang.String _COUNTRYROAD_SLOW = "COUNTRYROAD_SLOW";
    public static final java.lang.String _TOWNROAD_FAST = "TOWNROAD_FAST";
    public static final java.lang.String _TOWNROAD_NORMAL = "TOWNROAD_NORMAL";
    public static final java.lang.String _TOWNROAD_SLOW = "TOWNROAD_SLOW";
    public static final java.lang.String _FERRY_TYPE1 = "FERRY_TYPE1";
    public static final java.lang.String _FERRY_TYPE2 = "FERRY_TYPE2";
    public static final java.lang.String _STREET = "STREET";
    public static final RoadSpeedTypeEnum MOTORWAY_FAST = new RoadSpeedTypeEnum(_MOTORWAY_FAST);
    public static final RoadSpeedTypeEnum MOTORWAY_NORMAL = new RoadSpeedTypeEnum(_MOTORWAY_NORMAL);
    public static final RoadSpeedTypeEnum MOTORWAY_SLOW = new RoadSpeedTypeEnum(_MOTORWAY_SLOW);
    public static final RoadSpeedTypeEnum TRUNKROAD_FAST = new RoadSpeedTypeEnum(_TRUNKROAD_FAST);
    public static final RoadSpeedTypeEnum TRUNKROAD_NORMAL = new RoadSpeedTypeEnum(_TRUNKROAD_NORMAL);
    public static final RoadSpeedTypeEnum TRUNKROAD_SLOW = new RoadSpeedTypeEnum(_TRUNKROAD_SLOW);
    public static final RoadSpeedTypeEnum COUNTRYROAD_FAST = new RoadSpeedTypeEnum(_COUNTRYROAD_FAST);
    public static final RoadSpeedTypeEnum COUNTRYROAD_NORMAL = new RoadSpeedTypeEnum(_COUNTRYROAD_NORMAL);
    public static final RoadSpeedTypeEnum COUNTRYROAD_SLOW = new RoadSpeedTypeEnum(_COUNTRYROAD_SLOW);
    public static final RoadSpeedTypeEnum TOWNROAD_FAST = new RoadSpeedTypeEnum(_TOWNROAD_FAST);
    public static final RoadSpeedTypeEnum TOWNROAD_NORMAL = new RoadSpeedTypeEnum(_TOWNROAD_NORMAL);
    public static final RoadSpeedTypeEnum TOWNROAD_SLOW = new RoadSpeedTypeEnum(_TOWNROAD_SLOW);
    public static final RoadSpeedTypeEnum FERRY_TYPE1 = new RoadSpeedTypeEnum(_FERRY_TYPE1);
    public static final RoadSpeedTypeEnum FERRY_TYPE2 = new RoadSpeedTypeEnum(_FERRY_TYPE2);
    public static final RoadSpeedTypeEnum STREET = new RoadSpeedTypeEnum(_STREET);
    public java.lang.String getValue() { return _value_;}
    public static RoadSpeedTypeEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        RoadSpeedTypeEnum enumeration = (RoadSpeedTypeEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static RoadSpeedTypeEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RoadSpeedTypeEnum.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RoadSpeedTypeEnum"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
