/**
 * TextOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class TextOptions  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xmap.Color bgColor;

    private com.ptvag.xserver.xmap.Font font;

    private com.ptvag.xserver.xmap.Color frameColor;

    private com.ptvag.xserver.xmap.Color textColor;

    private com.ptvag.xserver.xmap.TextAlignment alignment;  // attribute

    private boolean fillBg;  // attribute

    private int pixelX;  // attribute

    private int pixelY;  // attribute

    private int relX;  // attribute

    private int relY;  // attribute

    private boolean showFrame;  // attribute

    public TextOptions() {
    }

    public TextOptions(
           com.ptvag.xserver.xmap.TextAlignment alignment,
           boolean fillBg,
           int pixelX,
           int pixelY,
           int relX,
           int relY,
           boolean showFrame,
           com.ptvag.xserver.xmap.Color bgColor,
           com.ptvag.xserver.xmap.Font font,
           com.ptvag.xserver.xmap.Color frameColor,
           com.ptvag.xserver.xmap.Color textColor) {
        this.alignment = alignment;
        this.fillBg = fillBg;
        this.pixelX = pixelX;
        this.pixelY = pixelY;
        this.relX = relX;
        this.relY = relY;
        this.showFrame = showFrame;
        this.bgColor = bgColor;
        this.font = font;
        this.frameColor = frameColor;
        this.textColor = textColor;
    }


    /**
     * Gets the bgColor value for this TextOptions.
     * 
     * @return bgColor
     */
    public com.ptvag.xserver.xmap.Color getBgColor() {
        return bgColor;
    }


    /**
     * Sets the bgColor value for this TextOptions.
     * 
     * @param bgColor
     */
    public void setBgColor(com.ptvag.xserver.xmap.Color bgColor) {
        this.bgColor = bgColor;
    }


    /**
     * Gets the font value for this TextOptions.
     * 
     * @return font
     */
    public com.ptvag.xserver.xmap.Font getFont() {
        return font;
    }


    /**
     * Sets the font value for this TextOptions.
     * 
     * @param font
     */
    public void setFont(com.ptvag.xserver.xmap.Font font) {
        this.font = font;
    }


    /**
     * Gets the frameColor value for this TextOptions.
     * 
     * @return frameColor
     */
    public com.ptvag.xserver.xmap.Color getFrameColor() {
        return frameColor;
    }


    /**
     * Sets the frameColor value for this TextOptions.
     * 
     * @param frameColor
     */
    public void setFrameColor(com.ptvag.xserver.xmap.Color frameColor) {
        this.frameColor = frameColor;
    }


    /**
     * Gets the textColor value for this TextOptions.
     * 
     * @return textColor
     */
    public com.ptvag.xserver.xmap.Color getTextColor() {
        return textColor;
    }


    /**
     * Sets the textColor value for this TextOptions.
     * 
     * @param textColor
     */
    public void setTextColor(com.ptvag.xserver.xmap.Color textColor) {
        this.textColor = textColor;
    }


    /**
     * Gets the alignment value for this TextOptions.
     * 
     * @return alignment
     */
    public com.ptvag.xserver.xmap.TextAlignment getAlignment() {
        return alignment;
    }


    /**
     * Sets the alignment value for this TextOptions.
     * 
     * @param alignment
     */
    public void setAlignment(com.ptvag.xserver.xmap.TextAlignment alignment) {
        this.alignment = alignment;
    }


    /**
     * Gets the fillBg value for this TextOptions.
     * 
     * @return fillBg
     */
    public boolean isFillBg() {
        return fillBg;
    }


    /**
     * Sets the fillBg value for this TextOptions.
     * 
     * @param fillBg
     */
    public void setFillBg(boolean fillBg) {
        this.fillBg = fillBg;
    }


    /**
     * Gets the pixelX value for this TextOptions.
     * 
     * @return pixelX
     */
    public int getPixelX() {
        return pixelX;
    }


    /**
     * Sets the pixelX value for this TextOptions.
     * 
     * @param pixelX
     */
    public void setPixelX(int pixelX) {
        this.pixelX = pixelX;
    }


    /**
     * Gets the pixelY value for this TextOptions.
     * 
     * @return pixelY
     */
    public int getPixelY() {
        return pixelY;
    }


    /**
     * Sets the pixelY value for this TextOptions.
     * 
     * @param pixelY
     */
    public void setPixelY(int pixelY) {
        this.pixelY = pixelY;
    }


    /**
     * Gets the relX value for this TextOptions.
     * 
     * @return relX
     */
    public int getRelX() {
        return relX;
    }


    /**
     * Sets the relX value for this TextOptions.
     * 
     * @param relX
     */
    public void setRelX(int relX) {
        this.relX = relX;
    }


    /**
     * Gets the relY value for this TextOptions.
     * 
     * @return relY
     */
    public int getRelY() {
        return relY;
    }


    /**
     * Sets the relY value for this TextOptions.
     * 
     * @param relY
     */
    public void setRelY(int relY) {
        this.relY = relY;
    }


    /**
     * Gets the showFrame value for this TextOptions.
     * 
     * @return showFrame
     */
    public boolean isShowFrame() {
        return showFrame;
    }


    /**
     * Sets the showFrame value for this TextOptions.
     * 
     * @param showFrame
     */
    public void setShowFrame(boolean showFrame) {
        this.showFrame = showFrame;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TextOptions)) return false;
        TextOptions other = (TextOptions) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.bgColor==null && other.getBgColor()==null) || 
             (this.bgColor!=null &&
              this.bgColor.equals(other.getBgColor()))) &&
            ((this.font==null && other.getFont()==null) || 
             (this.font!=null &&
              this.font.equals(other.getFont()))) &&
            ((this.frameColor==null && other.getFrameColor()==null) || 
             (this.frameColor!=null &&
              this.frameColor.equals(other.getFrameColor()))) &&
            ((this.textColor==null && other.getTextColor()==null) || 
             (this.textColor!=null &&
              this.textColor.equals(other.getTextColor()))) &&
            ((this.alignment==null && other.getAlignment()==null) || 
             (this.alignment!=null &&
              this.alignment.equals(other.getAlignment()))) &&
            this.fillBg == other.isFillBg() &&
            this.pixelX == other.getPixelX() &&
            this.pixelY == other.getPixelY() &&
            this.relX == other.getRelX() &&
            this.relY == other.getRelY() &&
            this.showFrame == other.isShowFrame();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBgColor() != null) {
            _hashCode += getBgColor().hashCode();
        }
        if (getFont() != null) {
            _hashCode += getFont().hashCode();
        }
        if (getFrameColor() != null) {
            _hashCode += getFrameColor().hashCode();
        }
        if (getTextColor() != null) {
            _hashCode += getTextColor().hashCode();
        }
        if (getAlignment() != null) {
            _hashCode += getAlignment().hashCode();
        }
        _hashCode += (isFillBg() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getPixelX();
        _hashCode += getPixelY();
        _hashCode += getRelX();
        _hashCode += getRelY();
        _hashCode += (isShowFrame() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TextOptions.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "TextOptions"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("alignment");
        attrField.setXmlName(new javax.xml.namespace.QName("", "alignment"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "TextAlignment"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("fillBg");
        attrField.setXmlName(new javax.xml.namespace.QName("", "fillBg"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("pixelX");
        attrField.setXmlName(new javax.xml.namespace.QName("", "pixelX"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("pixelY");
        attrField.setXmlName(new javax.xml.namespace.QName("", "pixelY"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relX");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relX"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relY");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relY"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("showFrame");
        attrField.setXmlName(new javax.xml.namespace.QName("", "showFrame"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bgColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "bgColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Color"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("font");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "font"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Font"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frameColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "frameColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Color"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "textColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Color"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
