/**
 * GeometryExt.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class GeometryExt  extends com.ptvag.xserver.xmap.Geometry  implements java.io.Serializable {
    private java.lang.String geometryString;  // attribute

    public GeometryExt() {
    }

    public GeometryExt(
           java.lang.String description,
           int id,
           com.ptvag.xserver.common.EncodedGeometry geometry,
           com.ptvag.xserver.common.Point referencePoint,
           java.lang.String geometryString) {
        super(
            description,
            id,
            geometry,
            referencePoint);
        this.geometryString = geometryString;
    }


    /**
     * Gets the geometryString value for this GeometryExt.
     * 
     * @return geometryString
     */
    public java.lang.String getGeometryString() {
        return geometryString;
    }


    /**
     * Sets the geometryString value for this GeometryExt.
     * 
     * @param geometryString
     */
    public void setGeometryString(java.lang.String geometryString) {
        this.geometryString = geometryString;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GeometryExt)) return false;
        GeometryExt other = (GeometryExt) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.geometryString==null && other.getGeometryString()==null) || 
             (this.geometryString!=null &&
              this.geometryString.equals(other.getGeometryString())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getGeometryString() != null) {
            _hashCode += getGeometryString().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GeometryExt.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "GeometryExt"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("geometryString");
        attrField.setXmlName(new javax.xml.namespace.QName("", "geometryString"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
