/**
 * BoundingBox.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.common;

public class BoundingBox  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.common.Point leftTop;

    private com.ptvag.xserver.common.Point rightBottom;

    public BoundingBox() {
    }

    public BoundingBox(
           com.ptvag.xserver.common.Point leftTop,
           com.ptvag.xserver.common.Point rightBottom) {
        this.leftTop = leftTop;
        this.rightBottom = rightBottom;
    }


    /**
     * Gets the leftTop value for this BoundingBox.
     * 
     * @return leftTop
     */
    public com.ptvag.xserver.common.Point getLeftTop() {
        return leftTop;
    }


    /**
     * Sets the leftTop value for this BoundingBox.
     * 
     * @param leftTop
     */
    public void setLeftTop(com.ptvag.xserver.common.Point leftTop) {
        this.leftTop = leftTop;
    }


    /**
     * Gets the rightBottom value for this BoundingBox.
     * 
     * @return rightBottom
     */
    public com.ptvag.xserver.common.Point getRightBottom() {
        return rightBottom;
    }


    /**
     * Sets the rightBottom value for this BoundingBox.
     * 
     * @param rightBottom
     */
    public void setRightBottom(com.ptvag.xserver.common.Point rightBottom) {
        this.rightBottom = rightBottom;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BoundingBox)) return false;
        BoundingBox other = (BoundingBox) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.leftTop==null && other.getLeftTop()==null) || 
             (this.leftTop!=null &&
              this.leftTop.equals(other.getLeftTop()))) &&
            ((this.rightBottom==null && other.getRightBottom()==null) || 
             (this.rightBottom!=null &&
              this.rightBottom.equals(other.getRightBottom())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLeftTop() != null) {
            _hashCode += getLeftTop().hashCode();
        }
        if (getRightBottom() != null) {
            _hashCode += getRightBottom().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BoundingBox.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "BoundingBox"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftTop");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "leftTop"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightBottom");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "rightBottom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
