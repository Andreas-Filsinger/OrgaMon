package com.ptvag.xserver.xlocate.jwsdp;

public class XLocateWSProxy implements com.ptvag.xserver.xlocate.jwsdp.XLocateWS {
  private String _endpoint = null;
  private com.ptvag.xserver.xlocate.jwsdp.XLocateWS xLocateWS = null;
  
  public XLocateWSProxy() {
    _initXLocateWSProxy();
  }
  
  public XLocateWSProxy(String endpoint) {
    _endpoint = endpoint;
    _initXLocateWSProxy();
  }
  
  private void _initXLocateWSProxy() {
    try {
      xLocateWS = (new com.ptvag.xserver.xlocate.jwsdp.XLocateWSServiceLocator()).getXLocateWSPort();
      if (xLocateWS != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)xLocateWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)xLocateWS)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (xLocateWS != null)
      ((javax.xml.rpc.Stub)xLocateWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ptvag.xserver.xlocate.jwsdp.XLocateWS getXLocateWS() {
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS;
  }
  
  public com.ptvag.xserver.xlocate.AddressResponse findAddress(com.ptvag.xserver.xlocate.Address address_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS.findAddress(address_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xlocate.AddressResponse[] findAddresses(com.ptvag.xserver.xlocate.Address[] arrayOfAddress_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS.findAddresses(arrayOfAddress_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xlocate.AddressResponse findLocation(com.ptvag.xserver.xlocate.Location location_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS.findLocation(location_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xlocate.AddressResponse[] findLocations(com.ptvag.xserver.xlocate.Location[] arrayOfLocation_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS.findLocations(arrayOfLocation_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xlocate.PoiAddressResponse findPoiByAddress(com.ptvag.xserver.xlocate.PoiAddress poiAddress_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS.findPoiByAddress(poiAddress_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xlocate.PoiAddressResponse[] findPoiByAddresses(com.ptvag.xserver.xlocate.PoiAddress[] arrayOfPoiAddress_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS.findPoiByAddresses(arrayOfPoiAddress_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xlocate.PoiAddressResponse findPoiByLocation(com.ptvag.xserver.xlocate.PoiLocation poiLocation_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS.findPoiByLocation(poiLocation_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xlocate.PoiAddressResponse[] findPoiByLocations(com.ptvag.xserver.xlocate.PoiLocation[] arrayOfPoiLocation_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS.findPoiByLocations(arrayOfPoiLocation_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xlocate.ResultAddress[] matchAddress(com.ptvag.xserver.xlocate.Address address_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS.matchAddress(address_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xlocate.ResultAddress[][] matchAddresses(com.ptvag.xserver.xlocate.Address[] arrayOfAddress_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS.matchAddresses(arrayOfAddress_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xlocate.ResultAddress[] matchLocation(com.ptvag.xserver.common.Point point_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS.matchLocation(point_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5);
  }
  
  public com.ptvag.xserver.xlocate.ResultAddress[][] matchLocations(com.ptvag.xserver.common.Point[] arrayOfPoint_1, com.ptvag.xserver.xlocate.SearchOptionBase[] arrayOfSearchOptionBase_2, com.ptvag.xserver.xlocate.SortOption[] arrayOfSortOption_3, com.ptvag.xserver.xlocate.ResultField[] arrayOfResultField_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.xserver.xlocate.XLocateException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.common.XServiceException{
    if (xLocateWS == null)
      _initXLocateWSProxy();
    return xLocateWS.matchLocations(arrayOfPoint_1, arrayOfSearchOptionBase_2, arrayOfSortOption_3, arrayOfResultField_4, callerContext_5);
  }
  
  
}