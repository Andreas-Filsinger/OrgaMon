/**
 * RestRule.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class RestRule  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xsequence.RemainingPeriods firstShift;

    private int maxShiftDrivingPeriod;  // attribute

    private int minStopPeriodForRest;  // attribute

    private int restPeriod;  // attribute

    private int shiftPeriod;  // attribute

    public RestRule() {
    }

    public RestRule(
           int maxShiftDrivingPeriod,
           int minStopPeriodForRest,
           int restPeriod,
           int shiftPeriod,
           com.ptvag.xserver.xsequence.RemainingPeriods firstShift) {
        this.maxShiftDrivingPeriod = maxShiftDrivingPeriod;
        this.minStopPeriodForRest = minStopPeriodForRest;
        this.restPeriod = restPeriod;
        this.shiftPeriod = shiftPeriod;
        this.firstShift = firstShift;
    }


    /**
     * Gets the firstShift value for this RestRule.
     * 
     * @return firstShift
     */
    public com.ptvag.xserver.xsequence.RemainingPeriods getFirstShift() {
        return firstShift;
    }


    /**
     * Sets the firstShift value for this RestRule.
     * 
     * @param firstShift
     */
    public void setFirstShift(com.ptvag.xserver.xsequence.RemainingPeriods firstShift) {
        this.firstShift = firstShift;
    }


    /**
     * Gets the maxShiftDrivingPeriod value for this RestRule.
     * 
     * @return maxShiftDrivingPeriod
     */
    public int getMaxShiftDrivingPeriod() {
        return maxShiftDrivingPeriod;
    }


    /**
     * Sets the maxShiftDrivingPeriod value for this RestRule.
     * 
     * @param maxShiftDrivingPeriod
     */
    public void setMaxShiftDrivingPeriod(int maxShiftDrivingPeriod) {
        this.maxShiftDrivingPeriod = maxShiftDrivingPeriod;
    }


    /**
     * Gets the minStopPeriodForRest value for this RestRule.
     * 
     * @return minStopPeriodForRest
     */
    public int getMinStopPeriodForRest() {
        return minStopPeriodForRest;
    }


    /**
     * Sets the minStopPeriodForRest value for this RestRule.
     * 
     * @param minStopPeriodForRest
     */
    public void setMinStopPeriodForRest(int minStopPeriodForRest) {
        this.minStopPeriodForRest = minStopPeriodForRest;
    }


    /**
     * Gets the restPeriod value for this RestRule.
     * 
     * @return restPeriod
     */
    public int getRestPeriod() {
        return restPeriod;
    }


    /**
     * Sets the restPeriod value for this RestRule.
     * 
     * @param restPeriod
     */
    public void setRestPeriod(int restPeriod) {
        this.restPeriod = restPeriod;
    }


    /**
     * Gets the shiftPeriod value for this RestRule.
     * 
     * @return shiftPeriod
     */
    public int getShiftPeriod() {
        return shiftPeriod;
    }


    /**
     * Sets the shiftPeriod value for this RestRule.
     * 
     * @param shiftPeriod
     */
    public void setShiftPeriod(int shiftPeriod) {
        this.shiftPeriod = shiftPeriod;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RestRule)) return false;
        RestRule other = (RestRule) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.firstShift==null && other.getFirstShift()==null) || 
             (this.firstShift!=null &&
              this.firstShift.equals(other.getFirstShift()))) &&
            this.maxShiftDrivingPeriod == other.getMaxShiftDrivingPeriod() &&
            this.minStopPeriodForRest == other.getMinStopPeriodForRest() &&
            this.restPeriod == other.getRestPeriod() &&
            this.shiftPeriod == other.getShiftPeriod();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getFirstShift() != null) {
            _hashCode += getFirstShift().hashCode();
        }
        _hashCode += getMaxShiftDrivingPeriod();
        _hashCode += getMinStopPeriodForRest();
        _hashCode += getRestPeriod();
        _hashCode += getShiftPeriod();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RestRule.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "RestRule"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("maxShiftDrivingPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "maxShiftDrivingPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("minStopPeriodForRest");
        attrField.setXmlName(new javax.xml.namespace.QName("", "minStopPeriodForRest"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("restPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "restPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("shiftPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "shiftPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstShift");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "firstShift"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "RemainingPeriods"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
