/**
 * OutputTour.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class OutputTour  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xsequence.OutputTourPoint[] wrappedOutputTourPoints;

    private com.ptvag.xserver.xsequence.TimewindowTourResult timeWindowResult;

    private com.ptvag.xserver.xsequence.TourViolation[] wrappedTourViolations;

    private com.ptvag.xserver.xsequence.TransportTourResult transportResult;

    private int costs;  // attribute

    private int distance;  // attribute

    private int drivingPeriod;  // attribute

    private int score;  // attribute

    private int servicePeriod;  // attribute

    private int tourPeriod;  // attribute

    public OutputTour() {
    }

    public OutputTour(
           int costs,
           int distance,
           int drivingPeriod,
           int score,
           int servicePeriod,
           int tourPeriod,
           com.ptvag.xserver.xsequence.OutputTourPoint[] wrappedOutputTourPoints,
           com.ptvag.xserver.xsequence.TimewindowTourResult timeWindowResult,
           com.ptvag.xserver.xsequence.TourViolation[] wrappedTourViolations,
           com.ptvag.xserver.xsequence.TransportTourResult transportResult) {
        this.costs = costs;
        this.distance = distance;
        this.drivingPeriod = drivingPeriod;
        this.score = score;
        this.servicePeriod = servicePeriod;
        this.tourPeriod = tourPeriod;
        this.wrappedOutputTourPoints = wrappedOutputTourPoints;
        this.timeWindowResult = timeWindowResult;
        this.wrappedTourViolations = wrappedTourViolations;
        this.transportResult = transportResult;
    }


    /**
     * Gets the wrappedOutputTourPoints value for this OutputTour.
     * 
     * @return wrappedOutputTourPoints
     */
    public com.ptvag.xserver.xsequence.OutputTourPoint[] getWrappedOutputTourPoints() {
        return wrappedOutputTourPoints;
    }


    /**
     * Sets the wrappedOutputTourPoints value for this OutputTour.
     * 
     * @param wrappedOutputTourPoints
     */
    public void setWrappedOutputTourPoints(com.ptvag.xserver.xsequence.OutputTourPoint[] wrappedOutputTourPoints) {
        this.wrappedOutputTourPoints = wrappedOutputTourPoints;
    }


    /**
     * Gets the timeWindowResult value for this OutputTour.
     * 
     * @return timeWindowResult
     */
    public com.ptvag.xserver.xsequence.TimewindowTourResult getTimeWindowResult() {
        return timeWindowResult;
    }


    /**
     * Sets the timeWindowResult value for this OutputTour.
     * 
     * @param timeWindowResult
     */
    public void setTimeWindowResult(com.ptvag.xserver.xsequence.TimewindowTourResult timeWindowResult) {
        this.timeWindowResult = timeWindowResult;
    }


    /**
     * Gets the wrappedTourViolations value for this OutputTour.
     * 
     * @return wrappedTourViolations
     */
    public com.ptvag.xserver.xsequence.TourViolation[] getWrappedTourViolations() {
        return wrappedTourViolations;
    }


    /**
     * Sets the wrappedTourViolations value for this OutputTour.
     * 
     * @param wrappedTourViolations
     */
    public void setWrappedTourViolations(com.ptvag.xserver.xsequence.TourViolation[] wrappedTourViolations) {
        this.wrappedTourViolations = wrappedTourViolations;
    }


    /**
     * Gets the transportResult value for this OutputTour.
     * 
     * @return transportResult
     */
    public com.ptvag.xserver.xsequence.TransportTourResult getTransportResult() {
        return transportResult;
    }


    /**
     * Sets the transportResult value for this OutputTour.
     * 
     * @param transportResult
     */
    public void setTransportResult(com.ptvag.xserver.xsequence.TransportTourResult transportResult) {
        this.transportResult = transportResult;
    }


    /**
     * Gets the costs value for this OutputTour.
     * 
     * @return costs
     */
    public int getCosts() {
        return costs;
    }


    /**
     * Sets the costs value for this OutputTour.
     * 
     * @param costs
     */
    public void setCosts(int costs) {
        this.costs = costs;
    }


    /**
     * Gets the distance value for this OutputTour.
     * 
     * @return distance
     */
    public int getDistance() {
        return distance;
    }


    /**
     * Sets the distance value for this OutputTour.
     * 
     * @param distance
     */
    public void setDistance(int distance) {
        this.distance = distance;
    }


    /**
     * Gets the drivingPeriod value for this OutputTour.
     * 
     * @return drivingPeriod
     */
    public int getDrivingPeriod() {
        return drivingPeriod;
    }


    /**
     * Sets the drivingPeriod value for this OutputTour.
     * 
     * @param drivingPeriod
     */
    public void setDrivingPeriod(int drivingPeriod) {
        this.drivingPeriod = drivingPeriod;
    }


    /**
     * Gets the score value for this OutputTour.
     * 
     * @return score
     */
    public int getScore() {
        return score;
    }


    /**
     * Sets the score value for this OutputTour.
     * 
     * @param score
     */
    public void setScore(int score) {
        this.score = score;
    }


    /**
     * Gets the servicePeriod value for this OutputTour.
     * 
     * @return servicePeriod
     */
    public int getServicePeriod() {
        return servicePeriod;
    }


    /**
     * Sets the servicePeriod value for this OutputTour.
     * 
     * @param servicePeriod
     */
    public void setServicePeriod(int servicePeriod) {
        this.servicePeriod = servicePeriod;
    }


    /**
     * Gets the tourPeriod value for this OutputTour.
     * 
     * @return tourPeriod
     */
    public int getTourPeriod() {
        return tourPeriod;
    }


    /**
     * Sets the tourPeriod value for this OutputTour.
     * 
     * @param tourPeriod
     */
    public void setTourPeriod(int tourPeriod) {
        this.tourPeriod = tourPeriod;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OutputTour)) return false;
        OutputTour other = (OutputTour) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedOutputTourPoints==null && other.getWrappedOutputTourPoints()==null) || 
             (this.wrappedOutputTourPoints!=null &&
              java.util.Arrays.equals(this.wrappedOutputTourPoints, other.getWrappedOutputTourPoints()))) &&
            ((this.timeWindowResult==null && other.getTimeWindowResult()==null) || 
             (this.timeWindowResult!=null &&
              this.timeWindowResult.equals(other.getTimeWindowResult()))) &&
            ((this.wrappedTourViolations==null && other.getWrappedTourViolations()==null) || 
             (this.wrappedTourViolations!=null &&
              java.util.Arrays.equals(this.wrappedTourViolations, other.getWrappedTourViolations()))) &&
            ((this.transportResult==null && other.getTransportResult()==null) || 
             (this.transportResult!=null &&
              this.transportResult.equals(other.getTransportResult()))) &&
            this.costs == other.getCosts() &&
            this.distance == other.getDistance() &&
            this.drivingPeriod == other.getDrivingPeriod() &&
            this.score == other.getScore() &&
            this.servicePeriod == other.getServicePeriod() &&
            this.tourPeriod == other.getTourPeriod();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedOutputTourPoints() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedOutputTourPoints());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedOutputTourPoints(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTimeWindowResult() != null) {
            _hashCode += getTimeWindowResult().hashCode();
        }
        if (getWrappedTourViolations() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedTourViolations());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedTourViolations(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTransportResult() != null) {
            _hashCode += getTransportResult().hashCode();
        }
        _hashCode += getCosts();
        _hashCode += getDistance();
        _hashCode += getDrivingPeriod();
        _hashCode += getScore();
        _hashCode += getServicePeriod();
        _hashCode += getTourPeriod();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OutputTour.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OutputTour"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("costs");
        attrField.setXmlName(new javax.xml.namespace.QName("", "costs"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("distance");
        attrField.setXmlName(new javax.xml.namespace.QName("", "distance"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("drivingPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "drivingPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("score");
        attrField.setXmlName(new javax.xml.namespace.QName("", "score"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("servicePeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "servicePeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tourPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tourPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedOutputTourPoints");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "wrappedOutputTourPoints"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OutputTourPoint"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OutputTourPoint"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timeWindowResult");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "timeWindowResult"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimewindowTourResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedTourViolations");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "wrappedTourViolations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TourViolation"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TourViolation"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transportResult");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "transportResult"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TransportTourResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
