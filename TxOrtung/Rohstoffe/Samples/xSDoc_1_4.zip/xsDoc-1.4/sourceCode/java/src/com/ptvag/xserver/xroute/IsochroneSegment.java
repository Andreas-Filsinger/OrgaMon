/**
 * IsochroneSegment.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class IsochroneSegment  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.UniqueGeoID[] wrappedSegmentID;

    private boolean direction;  // attribute

    private int distOnSgm;  // attribute

    private int kumulDist;  // attribute

    private int kumulTime;  // attribute

    private int timeOnSgm;  // attribute

    public IsochroneSegment() {
    }

    public IsochroneSegment(
           boolean direction,
           int distOnSgm,
           int kumulDist,
           int kumulTime,
           int timeOnSgm,
           com.ptvag.xserver.xroute.UniqueGeoID[] wrappedSegmentID) {
        this.direction = direction;
        this.distOnSgm = distOnSgm;
        this.kumulDist = kumulDist;
        this.kumulTime = kumulTime;
        this.timeOnSgm = timeOnSgm;
        this.wrappedSegmentID = wrappedSegmentID;
    }


    /**
     * Gets the wrappedSegmentID value for this IsochroneSegment.
     * 
     * @return wrappedSegmentID
     */
    public com.ptvag.xserver.xroute.UniqueGeoID[] getWrappedSegmentID() {
        return wrappedSegmentID;
    }


    /**
     * Sets the wrappedSegmentID value for this IsochroneSegment.
     * 
     * @param wrappedSegmentID
     */
    public void setWrappedSegmentID(com.ptvag.xserver.xroute.UniqueGeoID[] wrappedSegmentID) {
        this.wrappedSegmentID = wrappedSegmentID;
    }


    /**
     * Gets the direction value for this IsochroneSegment.
     * 
     * @return direction
     */
    public boolean isDirection() {
        return direction;
    }


    /**
     * Sets the direction value for this IsochroneSegment.
     * 
     * @param direction
     */
    public void setDirection(boolean direction) {
        this.direction = direction;
    }


    /**
     * Gets the distOnSgm value for this IsochroneSegment.
     * 
     * @return distOnSgm
     */
    public int getDistOnSgm() {
        return distOnSgm;
    }


    /**
     * Sets the distOnSgm value for this IsochroneSegment.
     * 
     * @param distOnSgm
     */
    public void setDistOnSgm(int distOnSgm) {
        this.distOnSgm = distOnSgm;
    }


    /**
     * Gets the kumulDist value for this IsochroneSegment.
     * 
     * @return kumulDist
     */
    public int getKumulDist() {
        return kumulDist;
    }


    /**
     * Sets the kumulDist value for this IsochroneSegment.
     * 
     * @param kumulDist
     */
    public void setKumulDist(int kumulDist) {
        this.kumulDist = kumulDist;
    }


    /**
     * Gets the kumulTime value for this IsochroneSegment.
     * 
     * @return kumulTime
     */
    public int getKumulTime() {
        return kumulTime;
    }


    /**
     * Sets the kumulTime value for this IsochroneSegment.
     * 
     * @param kumulTime
     */
    public void setKumulTime(int kumulTime) {
        this.kumulTime = kumulTime;
    }


    /**
     * Gets the timeOnSgm value for this IsochroneSegment.
     * 
     * @return timeOnSgm
     */
    public int getTimeOnSgm() {
        return timeOnSgm;
    }


    /**
     * Sets the timeOnSgm value for this IsochroneSegment.
     * 
     * @param timeOnSgm
     */
    public void setTimeOnSgm(int timeOnSgm) {
        this.timeOnSgm = timeOnSgm;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IsochroneSegment)) return false;
        IsochroneSegment other = (IsochroneSegment) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedSegmentID==null && other.getWrappedSegmentID()==null) || 
             (this.wrappedSegmentID!=null &&
              java.util.Arrays.equals(this.wrappedSegmentID, other.getWrappedSegmentID()))) &&
            this.direction == other.isDirection() &&
            this.distOnSgm == other.getDistOnSgm() &&
            this.kumulDist == other.getKumulDist() &&
            this.kumulTime == other.getKumulTime() &&
            this.timeOnSgm == other.getTimeOnSgm();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedSegmentID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedSegmentID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedSegmentID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += (isDirection() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getDistOnSgm();
        _hashCode += getKumulDist();
        _hashCode += getKumulTime();
        _hashCode += getTimeOnSgm();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IsochroneSegment.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneSegment"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("direction");
        attrField.setXmlName(new javax.xml.namespace.QName("", "direction"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("distOnSgm");
        attrField.setXmlName(new javax.xml.namespace.QName("", "distOnSgm"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("kumulDist");
        attrField.setXmlName(new javax.xml.namespace.QName("", "kumulDist"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("kumulTime");
        attrField.setXmlName(new javax.xml.namespace.QName("", "kumulTime"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("timeOnSgm");
        attrField.setXmlName(new javax.xml.namespace.QName("", "timeOnSgm"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedSegmentID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedSegmentID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
