/**
 * DetailDescriptionOption.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class DetailDescriptionOption  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.DetailLevel minLevel;  // attribute

    private int radius;  // attribute

    public DetailDescriptionOption() {
    }

    public DetailDescriptionOption(
           com.ptvag.xserver.xroute.DetailLevel minLevel,
           int radius) {
        this.minLevel = minLevel;
        this.radius = radius;
    }


    /**
     * Gets the minLevel value for this DetailDescriptionOption.
     * 
     * @return minLevel
     */
    public com.ptvag.xserver.xroute.DetailLevel getMinLevel() {
        return minLevel;
    }


    /**
     * Sets the minLevel value for this DetailDescriptionOption.
     * 
     * @param minLevel
     */
    public void setMinLevel(com.ptvag.xserver.xroute.DetailLevel minLevel) {
        this.minLevel = minLevel;
    }


    /**
     * Gets the radius value for this DetailDescriptionOption.
     * 
     * @return radius
     */
    public int getRadius() {
        return radius;
    }


    /**
     * Sets the radius value for this DetailDescriptionOption.
     * 
     * @param radius
     */
    public void setRadius(int radius) {
        this.radius = radius;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DetailDescriptionOption)) return false;
        DetailDescriptionOption other = (DetailDescriptionOption) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.minLevel==null && other.getMinLevel()==null) || 
             (this.minLevel!=null &&
              this.minLevel.equals(other.getMinLevel()))) &&
            this.radius == other.getRadius();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getMinLevel() != null) {
            _hashCode += getMinLevel().hashCode();
        }
        _hashCode += getRadius();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DetailDescriptionOption.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "DetailDescriptionOption"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("minLevel");
        attrField.setXmlName(new javax.xml.namespace.QName("", "minLevel"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "DetailLevel"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("radius");
        attrField.setXmlName(new javax.xml.namespace.QName("", "radius"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
