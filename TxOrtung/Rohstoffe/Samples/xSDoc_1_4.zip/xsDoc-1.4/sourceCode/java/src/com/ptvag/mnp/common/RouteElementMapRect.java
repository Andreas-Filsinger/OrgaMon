/**
 * RouteElementMapRect.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class RouteElementMapRect  implements java.io.Serializable {
    private com.ptvag.mnp.common.BoundingBox detailMap;

    private com.ptvag.mnp.common.BoundingBox maxiMap;

    public RouteElementMapRect() {
    }

    public RouteElementMapRect(
           com.ptvag.mnp.common.BoundingBox detailMap,
           com.ptvag.mnp.common.BoundingBox maxiMap) {
           this.detailMap = detailMap;
           this.maxiMap = maxiMap;
    }


    /**
     * Gets the detailMap value for this RouteElementMapRect.
     * 
     * @return detailMap
     */
    public com.ptvag.mnp.common.BoundingBox getDetailMap() {
        return detailMap;
    }


    /**
     * Sets the detailMap value for this RouteElementMapRect.
     * 
     * @param detailMap
     */
    public void setDetailMap(com.ptvag.mnp.common.BoundingBox detailMap) {
        this.detailMap = detailMap;
    }


    /**
     * Gets the maxiMap value for this RouteElementMapRect.
     * 
     * @return maxiMap
     */
    public com.ptvag.mnp.common.BoundingBox getMaxiMap() {
        return maxiMap;
    }


    /**
     * Sets the maxiMap value for this RouteElementMapRect.
     * 
     * @param maxiMap
     */
    public void setMaxiMap(com.ptvag.mnp.common.BoundingBox maxiMap) {
        this.maxiMap = maxiMap;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RouteElementMapRect)) return false;
        RouteElementMapRect other = (RouteElementMapRect) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.detailMap==null && other.getDetailMap()==null) || 
             (this.detailMap!=null &&
              this.detailMap.equals(other.getDetailMap()))) &&
            ((this.maxiMap==null && other.getMaxiMap()==null) || 
             (this.maxiMap!=null &&
              this.maxiMap.equals(other.getMaxiMap())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDetailMap() != null) {
            _hashCode += getDetailMap().hashCode();
        }
        if (getMaxiMap() != null) {
            _hashCode += getMaxiMap().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RouteElementMapRect.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElementMapRect"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("detailMap");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "detailMap"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BoundingBox"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxiMap");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "maxiMap"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BoundingBox"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
