/**
 * RemainingPeriods.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class RemainingPeriods  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private int remainingDrivingPeriod;  // attribute

    private int remainingPeriod;  // attribute

    public RemainingPeriods() {
    }

    public RemainingPeriods(
           int remainingDrivingPeriod,
           int remainingPeriod) {
        this.remainingDrivingPeriod = remainingDrivingPeriod;
        this.remainingPeriod = remainingPeriod;
    }


    /**
     * Gets the remainingDrivingPeriod value for this RemainingPeriods.
     * 
     * @return remainingDrivingPeriod
     */
    public int getRemainingDrivingPeriod() {
        return remainingDrivingPeriod;
    }


    /**
     * Sets the remainingDrivingPeriod value for this RemainingPeriods.
     * 
     * @param remainingDrivingPeriod
     */
    public void setRemainingDrivingPeriod(int remainingDrivingPeriod) {
        this.remainingDrivingPeriod = remainingDrivingPeriod;
    }


    /**
     * Gets the remainingPeriod value for this RemainingPeriods.
     * 
     * @return remainingPeriod
     */
    public int getRemainingPeriod() {
        return remainingPeriod;
    }


    /**
     * Sets the remainingPeriod value for this RemainingPeriods.
     * 
     * @param remainingPeriod
     */
    public void setRemainingPeriod(int remainingPeriod) {
        this.remainingPeriod = remainingPeriod;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RemainingPeriods)) return false;
        RemainingPeriods other = (RemainingPeriods) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.remainingDrivingPeriod == other.getRemainingDrivingPeriod() &&
            this.remainingPeriod == other.getRemainingPeriod();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getRemainingDrivingPeriod();
        _hashCode += getRemainingPeriod();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RemainingPeriods.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "RemainingPeriods"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("remainingDrivingPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "remainingDrivingPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("remainingPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "remainingPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
