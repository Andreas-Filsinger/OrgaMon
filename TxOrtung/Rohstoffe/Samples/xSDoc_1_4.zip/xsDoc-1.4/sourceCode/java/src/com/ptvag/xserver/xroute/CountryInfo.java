/**
 * CountryInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class CountryInfo  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.RouteInfo partRouteInfo;

    private com.ptvag.xserver.xroute.RouteInfo[] wrappedPerNCRouteInfo;

    private int[] wrappedPerTypeTollDistance;

    private int[] wrappedPerTypeTollPrice;

    private com.ptvag.xserver.xroute.TollCostInfo[] wrappedTollCostInfos;

    private java.lang.String additionalInfo;  // attribute

    private java.lang.String countryCode;  // attribute

    private com.ptvag.xserver.xroute.Currency currency;  // attribute

    private java.lang.String currencyName;  // attribute

    private int iuCode;  // attribute

    public CountryInfo() {
    }

    public CountryInfo(
           java.lang.String additionalInfo,
           java.lang.String countryCode,
           com.ptvag.xserver.xroute.Currency currency,
           java.lang.String currencyName,
           int iuCode,
           com.ptvag.xserver.xroute.RouteInfo partRouteInfo,
           com.ptvag.xserver.xroute.RouteInfo[] wrappedPerNCRouteInfo,
           int[] wrappedPerTypeTollDistance,
           int[] wrappedPerTypeTollPrice,
           com.ptvag.xserver.xroute.TollCostInfo[] wrappedTollCostInfos) {
        this.additionalInfo = additionalInfo;
        this.countryCode = countryCode;
        this.currency = currency;
        this.currencyName = currencyName;
        this.iuCode = iuCode;
        this.partRouteInfo = partRouteInfo;
        this.wrappedPerNCRouteInfo = wrappedPerNCRouteInfo;
        this.wrappedPerTypeTollDistance = wrappedPerTypeTollDistance;
        this.wrappedPerTypeTollPrice = wrappedPerTypeTollPrice;
        this.wrappedTollCostInfos = wrappedTollCostInfos;
    }


    /**
     * Gets the partRouteInfo value for this CountryInfo.
     * 
     * @return partRouteInfo
     */
    public com.ptvag.xserver.xroute.RouteInfo getPartRouteInfo() {
        return partRouteInfo;
    }


    /**
     * Sets the partRouteInfo value for this CountryInfo.
     * 
     * @param partRouteInfo
     */
    public void setPartRouteInfo(com.ptvag.xserver.xroute.RouteInfo partRouteInfo) {
        this.partRouteInfo = partRouteInfo;
    }


    /**
     * Gets the wrappedPerNCRouteInfo value for this CountryInfo.
     * 
     * @return wrappedPerNCRouteInfo
     */
    public com.ptvag.xserver.xroute.RouteInfo[] getWrappedPerNCRouteInfo() {
        return wrappedPerNCRouteInfo;
    }


    /**
     * Sets the wrappedPerNCRouteInfo value for this CountryInfo.
     * 
     * @param wrappedPerNCRouteInfo
     */
    public void setWrappedPerNCRouteInfo(com.ptvag.xserver.xroute.RouteInfo[] wrappedPerNCRouteInfo) {
        this.wrappedPerNCRouteInfo = wrappedPerNCRouteInfo;
    }


    /**
     * Gets the wrappedPerTypeTollDistance value for this CountryInfo.
     * 
     * @return wrappedPerTypeTollDistance
     */
    public int[] getWrappedPerTypeTollDistance() {
        return wrappedPerTypeTollDistance;
    }


    /**
     * Sets the wrappedPerTypeTollDistance value for this CountryInfo.
     * 
     * @param wrappedPerTypeTollDistance
     */
    public void setWrappedPerTypeTollDistance(int[] wrappedPerTypeTollDistance) {
        this.wrappedPerTypeTollDistance = wrappedPerTypeTollDistance;
    }


    /**
     * Gets the wrappedPerTypeTollPrice value for this CountryInfo.
     * 
     * @return wrappedPerTypeTollPrice
     */
    public int[] getWrappedPerTypeTollPrice() {
        return wrappedPerTypeTollPrice;
    }


    /**
     * Sets the wrappedPerTypeTollPrice value for this CountryInfo.
     * 
     * @param wrappedPerTypeTollPrice
     */
    public void setWrappedPerTypeTollPrice(int[] wrappedPerTypeTollPrice) {
        this.wrappedPerTypeTollPrice = wrappedPerTypeTollPrice;
    }


    /**
     * Gets the wrappedTollCostInfos value for this CountryInfo.
     * 
     * @return wrappedTollCostInfos
     */
    public com.ptvag.xserver.xroute.TollCostInfo[] getWrappedTollCostInfos() {
        return wrappedTollCostInfos;
    }


    /**
     * Sets the wrappedTollCostInfos value for this CountryInfo.
     * 
     * @param wrappedTollCostInfos
     */
    public void setWrappedTollCostInfos(com.ptvag.xserver.xroute.TollCostInfo[] wrappedTollCostInfos) {
        this.wrappedTollCostInfos = wrappedTollCostInfos;
    }


    /**
     * Gets the additionalInfo value for this CountryInfo.
     * 
     * @return additionalInfo
     */
    public java.lang.String getAdditionalInfo() {
        return additionalInfo;
    }


    /**
     * Sets the additionalInfo value for this CountryInfo.
     * 
     * @param additionalInfo
     */
    public void setAdditionalInfo(java.lang.String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }


    /**
     * Gets the countryCode value for this CountryInfo.
     * 
     * @return countryCode
     */
    public java.lang.String getCountryCode() {
        return countryCode;
    }


    /**
     * Sets the countryCode value for this CountryInfo.
     * 
     * @param countryCode
     */
    public void setCountryCode(java.lang.String countryCode) {
        this.countryCode = countryCode;
    }


    /**
     * Gets the currency value for this CountryInfo.
     * 
     * @return currency
     */
    public com.ptvag.xserver.xroute.Currency getCurrency() {
        return currency;
    }


    /**
     * Sets the currency value for this CountryInfo.
     * 
     * @param currency
     */
    public void setCurrency(com.ptvag.xserver.xroute.Currency currency) {
        this.currency = currency;
    }


    /**
     * Gets the currencyName value for this CountryInfo.
     * 
     * @return currencyName
     */
    public java.lang.String getCurrencyName() {
        return currencyName;
    }


    /**
     * Sets the currencyName value for this CountryInfo.
     * 
     * @param currencyName
     */
    public void setCurrencyName(java.lang.String currencyName) {
        this.currencyName = currencyName;
    }


    /**
     * Gets the iuCode value for this CountryInfo.
     * 
     * @return iuCode
     */
    public int getIuCode() {
        return iuCode;
    }


    /**
     * Sets the iuCode value for this CountryInfo.
     * 
     * @param iuCode
     */
    public void setIuCode(int iuCode) {
        this.iuCode = iuCode;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CountryInfo)) return false;
        CountryInfo other = (CountryInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.partRouteInfo==null && other.getPartRouteInfo()==null) || 
             (this.partRouteInfo!=null &&
              this.partRouteInfo.equals(other.getPartRouteInfo()))) &&
            ((this.wrappedPerNCRouteInfo==null && other.getWrappedPerNCRouteInfo()==null) || 
             (this.wrappedPerNCRouteInfo!=null &&
              java.util.Arrays.equals(this.wrappedPerNCRouteInfo, other.getWrappedPerNCRouteInfo()))) &&
            ((this.wrappedPerTypeTollDistance==null && other.getWrappedPerTypeTollDistance()==null) || 
             (this.wrappedPerTypeTollDistance!=null &&
              java.util.Arrays.equals(this.wrappedPerTypeTollDistance, other.getWrappedPerTypeTollDistance()))) &&
            ((this.wrappedPerTypeTollPrice==null && other.getWrappedPerTypeTollPrice()==null) || 
             (this.wrappedPerTypeTollPrice!=null &&
              java.util.Arrays.equals(this.wrappedPerTypeTollPrice, other.getWrappedPerTypeTollPrice()))) &&
            ((this.wrappedTollCostInfos==null && other.getWrappedTollCostInfos()==null) || 
             (this.wrappedTollCostInfos!=null &&
              java.util.Arrays.equals(this.wrappedTollCostInfos, other.getWrappedTollCostInfos()))) &&
            ((this.additionalInfo==null && other.getAdditionalInfo()==null) || 
             (this.additionalInfo!=null &&
              this.additionalInfo.equals(other.getAdditionalInfo()))) &&
            ((this.countryCode==null && other.getCountryCode()==null) || 
             (this.countryCode!=null &&
              this.countryCode.equals(other.getCountryCode()))) &&
            ((this.currency==null && other.getCurrency()==null) || 
             (this.currency!=null &&
              this.currency.equals(other.getCurrency()))) &&
            ((this.currencyName==null && other.getCurrencyName()==null) || 
             (this.currencyName!=null &&
              this.currencyName.equals(other.getCurrencyName()))) &&
            this.iuCode == other.getIuCode();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getPartRouteInfo() != null) {
            _hashCode += getPartRouteInfo().hashCode();
        }
        if (getWrappedPerNCRouteInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedPerNCRouteInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedPerNCRouteInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedPerTypeTollDistance() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedPerTypeTollDistance());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedPerTypeTollDistance(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedPerTypeTollPrice() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedPerTypeTollPrice());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedPerTypeTollPrice(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedTollCostInfos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedTollCostInfos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedTollCostInfos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAdditionalInfo() != null) {
            _hashCode += getAdditionalInfo().hashCode();
        }
        if (getCountryCode() != null) {
            _hashCode += getCountryCode().hashCode();
        }
        if (getCurrency() != null) {
            _hashCode += getCurrency().hashCode();
        }
        if (getCurrencyName() != null) {
            _hashCode += getCurrencyName().hashCode();
        }
        _hashCode += getIuCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CountryInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "CountryInfo"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("additionalInfo");
        attrField.setXmlName(new javax.xml.namespace.QName("", "additionalInfo"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("countryCode");
        attrField.setXmlName(new javax.xml.namespace.QName("", "countryCode"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("currency");
        attrField.setXmlName(new javax.xml.namespace.QName("", "currency"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Currency"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("currencyName");
        attrField.setXmlName(new javax.xml.namespace.QName("", "currencyName"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("iuCode");
        attrField.setXmlName(new javax.xml.namespace.QName("", "iuCode"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partRouteInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "partRouteInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedPerNCRouteInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedPerNCRouteInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteInfo"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteInfo"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedPerTypeTollDistance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedPerTypeTollDistance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "Int"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedPerTypeTollPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedPerTypeTollPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "Int"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedTollCostInfos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedTollCostInfos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TollCostInfo"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TollCostInfo"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
