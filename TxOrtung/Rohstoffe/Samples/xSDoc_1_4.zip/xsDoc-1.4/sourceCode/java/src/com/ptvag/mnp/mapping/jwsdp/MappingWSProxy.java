package com.ptvag.mnp.mapping.jwsdp;

public class MappingWSProxy implements com.ptvag.mnp.mapping.jwsdp.MappingWS {
  private String _endpoint = null;
  private com.ptvag.mnp.mapping.jwsdp.MappingWS mappingWS = null;
  
  public MappingWSProxy() {
    _initMappingWSProxy();
  }
  
  public MappingWSProxy(String endpoint) {
    _endpoint = endpoint;
    _initMappingWSProxy();
  }
  
  private void _initMappingWSProxy() {
    try {
      mappingWS = (new com.ptvag.mnp.mapping.jwsdp.MappingWSServiceLocator()).getMappingWSPort();
      if (mappingWS != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)mappingWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)mappingWS)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (mappingWS != null)
      ((javax.xml.rpc.Stub)mappingWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ptvag.mnp.mapping.jwsdp.MappingWS getMappingWS() {
    if (mappingWS == null)
      _initMappingWSProxy();
    return mappingWS;
  }
  
  public void dummy(com.ptvag.mnp.common.POIViewMapSet POIViewMapSet_1, com.ptvag.jabba.service.baseservices.CallerContext callerContext_2) throws java.rmi.RemoteException, com.ptvag.mnp.common.exception.UnsupportedImageProfileException, com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException{
    if (mappingWS == null)
      _initMappingWSProxy();
    mappingWS.dummy(POIViewMapSet_1, callerContext_2);
  }
  
  public com.ptvag.mnp.common.MapView getBoundingMap(com.ptvag.mnp.common.POIViewSet[] arrayOfPOIViewSet_1, com.ptvag.mnp.common.ImageProperties imageProperties_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.mnp.common.exception.UnsupportedImageProfileException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.mapping.exception.NoPoisForBoundingMapFoundException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException{
    if (mappingWS == null)
      _initMappingWSProxy();
    return mappingWS.getBoundingMap(arrayOfPOIViewSet_1, imageProperties_2, string_3, string_4, callerContext_5);
  }
  
  public com.ptvag.mnp.common.MapView getCachedMap(com.ptvag.mnp.common.CachedObjectEnum cachedObjectEnum_1, java.lang.String string_2, com.ptvag.jabba.service.baseservices.CallerContext callerContext_3) throws java.rmi.RemoteException, com.ptvag.mnp.mapping.exception.MapHistoryNavigationException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException{
    if (mappingWS == null)
      _initMappingWSProxy();
    return mappingWS.getCachedMap(cachedObjectEnum_1, string_2, callerContext_3);
  }
  
  public com.ptvag.mnp.common.MapView getMapByCenterCoordinate(com.ptvag.mnp.common.Coordinate coordinate_1, double double_2, double double_3, com.ptvag.mnp.common.POIViewSet[] arrayOfPOIViewSet_4, com.ptvag.mnp.common.RouteView[] arrayOfRouteView_5, com.ptvag.mnp.common.ImageProperties imageProperties_6, java.lang.String string_7, java.lang.String string_8, com.ptvag.jabba.service.baseservices.CallerContext callerContext_9) throws java.rmi.RemoteException, com.ptvag.mnp.common.exception.UnsupportedImageProfileException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException{
    if (mappingWS == null)
      _initMappingWSProxy();
    return mappingWS.getMapByCenterCoordinate(coordinate_1, double_2, double_3, arrayOfPOIViewSet_4, arrayOfRouteView_5, imageProperties_6, string_7, string_8, callerContext_9);
  }
  
  public com.ptvag.mnp.common.MapView getMapByRectangle(com.ptvag.mnp.common.BoundingBox boundingBox_1, com.ptvag.mnp.common.POIViewSet[] arrayOfPOIViewSet_2, com.ptvag.mnp.common.RouteView[] arrayOfRouteView_3, com.ptvag.mnp.common.ImageProperties imageProperties_4, java.lang.String string_5, java.lang.String string_6, com.ptvag.jabba.service.baseservices.CallerContext callerContext_7) throws java.rmi.RemoteException, com.ptvag.mnp.common.exception.UnsupportedImageProfileException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException{
    if (mappingWS == null)
      _initMappingWSProxy();
    return mappingWS.getMapByRectangle(boundingBox_1, arrayOfPOIViewSet_2, arrayOfRouteView_3, imageProperties_4, string_5, string_6, callerContext_7);
  }
  
  public com.ptvag.mnp.common.MapView moveMapByDevice(int int_1, int int_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException{
    if (mappingWS == null)
      _initMappingWSProxy();
    return mappingWS.moveMapByDevice(int_1, int_2, string_3, string_4, callerContext_5);
  }
  
  public com.ptvag.mnp.common.MapView moveMapByPercentage(float float_1, float float_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException{
    if (mappingWS == null)
      _initMappingWSProxy();
    return mappingWS.moveMapByPercentage(float_1, float_2, string_3, string_4, callerContext_5);
  }
  
  public com.ptvag.mnp.common.MapView scaleMapByWidthHeight(int int_1, int int_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException{
    if (mappingWS == null)
      _initMappingWSProxy();
    return mappingWS.scaleMapByWidthHeight(int_1, int_2, string_3, string_4, callerContext_5);
  }
  
  public com.ptvag.mnp.common.MapView zoomMapByLevel(int int_1, com.ptvag.mnp.common.Coordinate coordinate_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException{
    if (mappingWS == null)
      _initMappingWSProxy();
    return mappingWS.zoomMapByLevel(int_1, coordinate_2, string_3, string_4, callerContext_5);
  }
  
  public com.ptvag.mnp.common.MapView zoomMapByRectangle(com.ptvag.mnp.common.BoundingBox boundingBox_1, java.lang.String string_2, java.lang.String string_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException{
    if (mappingWS == null)
      _initMappingWSProxy();
    return mappingWS.zoomMapByRectangle(boundingBox_1, string_2, string_3, callerContext_4);
  }
  
  public com.ptvag.mnp.common.MapView zoomMapByWidthHeight(double double_1, double double_2, com.ptvag.mnp.common.Coordinate coordinate_3, java.lang.String string_4, java.lang.String string_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException{
    if (mappingWS == null)
      _initMappingWSProxy();
    return mappingWS.zoomMapByWidthHeight(double_1, double_2, coordinate_3, string_4, string_5, callerContext_6);
  }
  
  
}