/**
 * ManoeuvreAttributes.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class ManoeuvreAttributes  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private boolean isBlockingEnd;  // attribute

    private boolean isBlockingStart;  // attribute

    private boolean isBorder;  // attribute

    private boolean isBrunnelEnd;  // attribute

    private boolean isBrunnelStart;  // attribute

    private boolean isUrbanEnd;  // attribute

    private boolean isUrbanStart;  // attribute

    private boolean tollRoadEnd;  // attribute

    private boolean tollRoadStart;  // attribute

    public ManoeuvreAttributes() {
    }

    public ManoeuvreAttributes(
           boolean isBlockingEnd,
           boolean isBlockingStart,
           boolean isBorder,
           boolean isBrunnelEnd,
           boolean isBrunnelStart,
           boolean isUrbanEnd,
           boolean isUrbanStart,
           boolean tollRoadEnd,
           boolean tollRoadStart) {
        this.isBlockingEnd = isBlockingEnd;
        this.isBlockingStart = isBlockingStart;
        this.isBorder = isBorder;
        this.isBrunnelEnd = isBrunnelEnd;
        this.isBrunnelStart = isBrunnelStart;
        this.isUrbanEnd = isUrbanEnd;
        this.isUrbanStart = isUrbanStart;
        this.tollRoadEnd = tollRoadEnd;
        this.tollRoadStart = tollRoadStart;
    }


    /**
     * Gets the isBlockingEnd value for this ManoeuvreAttributes.
     * 
     * @return isBlockingEnd
     */
    public boolean isIsBlockingEnd() {
        return isBlockingEnd;
    }


    /**
     * Sets the isBlockingEnd value for this ManoeuvreAttributes.
     * 
     * @param isBlockingEnd
     */
    public void setIsBlockingEnd(boolean isBlockingEnd) {
        this.isBlockingEnd = isBlockingEnd;
    }


    /**
     * Gets the isBlockingStart value for this ManoeuvreAttributes.
     * 
     * @return isBlockingStart
     */
    public boolean isIsBlockingStart() {
        return isBlockingStart;
    }


    /**
     * Sets the isBlockingStart value for this ManoeuvreAttributes.
     * 
     * @param isBlockingStart
     */
    public void setIsBlockingStart(boolean isBlockingStart) {
        this.isBlockingStart = isBlockingStart;
    }


    /**
     * Gets the isBorder value for this ManoeuvreAttributes.
     * 
     * @return isBorder
     */
    public boolean isIsBorder() {
        return isBorder;
    }


    /**
     * Sets the isBorder value for this ManoeuvreAttributes.
     * 
     * @param isBorder
     */
    public void setIsBorder(boolean isBorder) {
        this.isBorder = isBorder;
    }


    /**
     * Gets the isBrunnelEnd value for this ManoeuvreAttributes.
     * 
     * @return isBrunnelEnd
     */
    public boolean isIsBrunnelEnd() {
        return isBrunnelEnd;
    }


    /**
     * Sets the isBrunnelEnd value for this ManoeuvreAttributes.
     * 
     * @param isBrunnelEnd
     */
    public void setIsBrunnelEnd(boolean isBrunnelEnd) {
        this.isBrunnelEnd = isBrunnelEnd;
    }


    /**
     * Gets the isBrunnelStart value for this ManoeuvreAttributes.
     * 
     * @return isBrunnelStart
     */
    public boolean isIsBrunnelStart() {
        return isBrunnelStart;
    }


    /**
     * Sets the isBrunnelStart value for this ManoeuvreAttributes.
     * 
     * @param isBrunnelStart
     */
    public void setIsBrunnelStart(boolean isBrunnelStart) {
        this.isBrunnelStart = isBrunnelStart;
    }


    /**
     * Gets the isUrbanEnd value for this ManoeuvreAttributes.
     * 
     * @return isUrbanEnd
     */
    public boolean isIsUrbanEnd() {
        return isUrbanEnd;
    }


    /**
     * Sets the isUrbanEnd value for this ManoeuvreAttributes.
     * 
     * @param isUrbanEnd
     */
    public void setIsUrbanEnd(boolean isUrbanEnd) {
        this.isUrbanEnd = isUrbanEnd;
    }


    /**
     * Gets the isUrbanStart value for this ManoeuvreAttributes.
     * 
     * @return isUrbanStart
     */
    public boolean isIsUrbanStart() {
        return isUrbanStart;
    }


    /**
     * Sets the isUrbanStart value for this ManoeuvreAttributes.
     * 
     * @param isUrbanStart
     */
    public void setIsUrbanStart(boolean isUrbanStart) {
        this.isUrbanStart = isUrbanStart;
    }


    /**
     * Gets the tollRoadEnd value for this ManoeuvreAttributes.
     * 
     * @return tollRoadEnd
     */
    public boolean isTollRoadEnd() {
        return tollRoadEnd;
    }


    /**
     * Sets the tollRoadEnd value for this ManoeuvreAttributes.
     * 
     * @param tollRoadEnd
     */
    public void setTollRoadEnd(boolean tollRoadEnd) {
        this.tollRoadEnd = tollRoadEnd;
    }


    /**
     * Gets the tollRoadStart value for this ManoeuvreAttributes.
     * 
     * @return tollRoadStart
     */
    public boolean isTollRoadStart() {
        return tollRoadStart;
    }


    /**
     * Sets the tollRoadStart value for this ManoeuvreAttributes.
     * 
     * @param tollRoadStart
     */
    public void setTollRoadStart(boolean tollRoadStart) {
        this.tollRoadStart = tollRoadStart;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ManoeuvreAttributes)) return false;
        ManoeuvreAttributes other = (ManoeuvreAttributes) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.isBlockingEnd == other.isIsBlockingEnd() &&
            this.isBlockingStart == other.isIsBlockingStart() &&
            this.isBorder == other.isIsBorder() &&
            this.isBrunnelEnd == other.isIsBrunnelEnd() &&
            this.isBrunnelStart == other.isIsBrunnelStart() &&
            this.isUrbanEnd == other.isIsUrbanEnd() &&
            this.isUrbanStart == other.isIsUrbanStart() &&
            this.tollRoadEnd == other.isTollRoadEnd() &&
            this.tollRoadStart == other.isTollRoadStart();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += (isIsBlockingEnd() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsBlockingStart() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsBorder() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsBrunnelEnd() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsBrunnelStart() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsUrbanEnd() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsUrbanStart() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isTollRoadEnd() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isTollRoadStart() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ManoeuvreAttributes.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreAttributes"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("isBlockingEnd");
        attrField.setXmlName(new javax.xml.namespace.QName("", "isBlockingEnd"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("isBlockingStart");
        attrField.setXmlName(new javax.xml.namespace.QName("", "isBlockingStart"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("isBorder");
        attrField.setXmlName(new javax.xml.namespace.QName("", "isBorder"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("isBrunnelEnd");
        attrField.setXmlName(new javax.xml.namespace.QName("", "isBrunnelEnd"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("isBrunnelStart");
        attrField.setXmlName(new javax.xml.namespace.QName("", "isBrunnelStart"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("isUrbanEnd");
        attrField.setXmlName(new javax.xml.namespace.QName("", "isUrbanEnd"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("isUrbanStart");
        attrField.setXmlName(new javax.xml.namespace.QName("", "isUrbanStart"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tollRoadEnd");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tollRoadEnd"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("tollRoadStart");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tollRoadStart"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
