/**
 * IsochroneInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class IsochroneInfo  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.IsochroneSegment isoSegments;

    private com.ptvag.xserver.common.LineString polys;

    private int horizon;  // attribute

    public IsochroneInfo() {
    }

    public IsochroneInfo(
           int horizon,
           com.ptvag.xserver.xroute.IsochroneSegment isoSegments,
           com.ptvag.xserver.common.LineString polys) {
        this.horizon = horizon;
        this.isoSegments = isoSegments;
        this.polys = polys;
    }


    /**
     * Gets the isoSegments value for this IsochroneInfo.
     * 
     * @return isoSegments
     */
    public com.ptvag.xserver.xroute.IsochroneSegment getIsoSegments() {
        return isoSegments;
    }


    /**
     * Sets the isoSegments value for this IsochroneInfo.
     * 
     * @param isoSegments
     */
    public void setIsoSegments(com.ptvag.xserver.xroute.IsochroneSegment isoSegments) {
        this.isoSegments = isoSegments;
    }


    /**
     * Gets the polys value for this IsochroneInfo.
     * 
     * @return polys
     */
    public com.ptvag.xserver.common.LineString getPolys() {
        return polys;
    }


    /**
     * Sets the polys value for this IsochroneInfo.
     * 
     * @param polys
     */
    public void setPolys(com.ptvag.xserver.common.LineString polys) {
        this.polys = polys;
    }


    /**
     * Gets the horizon value for this IsochroneInfo.
     * 
     * @return horizon
     */
    public int getHorizon() {
        return horizon;
    }


    /**
     * Sets the horizon value for this IsochroneInfo.
     * 
     * @param horizon
     */
    public void setHorizon(int horizon) {
        this.horizon = horizon;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IsochroneInfo)) return false;
        IsochroneInfo other = (IsochroneInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.isoSegments==null && other.getIsoSegments()==null) || 
             (this.isoSegments!=null &&
              this.isoSegments.equals(other.getIsoSegments()))) &&
            ((this.polys==null && other.getPolys()==null) || 
             (this.polys!=null &&
              this.polys.equals(other.getPolys()))) &&
            this.horizon == other.getHorizon();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getIsoSegments() != null) {
            _hashCode += getIsoSegments().hashCode();
        }
        if (getPolys() != null) {
            _hashCode += getPolys().hashCode();
        }
        _hashCode += getHorizon();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IsochroneInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneInfo"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("horizon");
        attrField.setXmlName(new javax.xml.namespace.QName("", "horizon"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isoSegments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "isoSegments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneSegment"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("polys");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "polys"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "LineString"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
