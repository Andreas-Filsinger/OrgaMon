/**
 * ObjectGeometry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class ObjectGeometry  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.common.PlainGeometryBase pixelGeometry;

    private com.ptvag.xserver.common.EncodedGeometry refGeometry;

    public ObjectGeometry() {
    }

    public ObjectGeometry(
           com.ptvag.xserver.common.PlainGeometryBase pixelGeometry,
           com.ptvag.xserver.common.EncodedGeometry refGeometry) {
        this.pixelGeometry = pixelGeometry;
        this.refGeometry = refGeometry;
    }


    /**
     * Gets the pixelGeometry value for this ObjectGeometry.
     * 
     * @return pixelGeometry
     */
    public com.ptvag.xserver.common.PlainGeometryBase getPixelGeometry() {
        return pixelGeometry;
    }


    /**
     * Sets the pixelGeometry value for this ObjectGeometry.
     * 
     * @param pixelGeometry
     */
    public void setPixelGeometry(com.ptvag.xserver.common.PlainGeometryBase pixelGeometry) {
        this.pixelGeometry = pixelGeometry;
    }


    /**
     * Gets the refGeometry value for this ObjectGeometry.
     * 
     * @return refGeometry
     */
    public com.ptvag.xserver.common.EncodedGeometry getRefGeometry() {
        return refGeometry;
    }


    /**
     * Sets the refGeometry value for this ObjectGeometry.
     * 
     * @param refGeometry
     */
    public void setRefGeometry(com.ptvag.xserver.common.EncodedGeometry refGeometry) {
        this.refGeometry = refGeometry;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ObjectGeometry)) return false;
        ObjectGeometry other = (ObjectGeometry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.pixelGeometry==null && other.getPixelGeometry()==null) || 
             (this.pixelGeometry!=null &&
              this.pixelGeometry.equals(other.getPixelGeometry()))) &&
            ((this.refGeometry==null && other.getRefGeometry()==null) || 
             (this.refGeometry!=null &&
              this.refGeometry.equals(other.getRefGeometry())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getPixelGeometry() != null) {
            _hashCode += getPixelGeometry().hashCode();
        }
        if (getRefGeometry() != null) {
            _hashCode += getRefGeometry().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ObjectGeometry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "ObjectGeometry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pixelGeometry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "pixelGeometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryBase"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refGeometry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "refGeometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "EncodedGeometry"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
