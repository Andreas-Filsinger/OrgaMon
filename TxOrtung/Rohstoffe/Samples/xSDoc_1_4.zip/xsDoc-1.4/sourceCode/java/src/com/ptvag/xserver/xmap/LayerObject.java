/**
 * LayerObject.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class LayerObject  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xmap.ObjectGeometry geometry;

    private com.ptvag.xserver.common.PlainPoint pixel;

    private com.ptvag.xserver.common.Point ref;

    private java.lang.String descr;  // attribute

    private int hiId;  // attribute

    private int loId;  // attribute

    public LayerObject() {
    }

    public LayerObject(
           java.lang.String descr,
           int hiId,
           int loId,
           com.ptvag.xserver.xmap.ObjectGeometry geometry,
           com.ptvag.xserver.common.PlainPoint pixel,
           com.ptvag.xserver.common.Point ref) {
        this.descr = descr;
        this.hiId = hiId;
        this.loId = loId;
        this.geometry = geometry;
        this.pixel = pixel;
        this.ref = ref;
    }


    /**
     * Gets the geometry value for this LayerObject.
     * 
     * @return geometry
     */
    public com.ptvag.xserver.xmap.ObjectGeometry getGeometry() {
        return geometry;
    }


    /**
     * Sets the geometry value for this LayerObject.
     * 
     * @param geometry
     */
    public void setGeometry(com.ptvag.xserver.xmap.ObjectGeometry geometry) {
        this.geometry = geometry;
    }


    /**
     * Gets the pixel value for this LayerObject.
     * 
     * @return pixel
     */
    public com.ptvag.xserver.common.PlainPoint getPixel() {
        return pixel;
    }


    /**
     * Sets the pixel value for this LayerObject.
     * 
     * @param pixel
     */
    public void setPixel(com.ptvag.xserver.common.PlainPoint pixel) {
        this.pixel = pixel;
    }


    /**
     * Gets the ref value for this LayerObject.
     * 
     * @return ref
     */
    public com.ptvag.xserver.common.Point getRef() {
        return ref;
    }


    /**
     * Sets the ref value for this LayerObject.
     * 
     * @param ref
     */
    public void setRef(com.ptvag.xserver.common.Point ref) {
        this.ref = ref;
    }


    /**
     * Gets the descr value for this LayerObject.
     * 
     * @return descr
     */
    public java.lang.String getDescr() {
        return descr;
    }


    /**
     * Sets the descr value for this LayerObject.
     * 
     * @param descr
     */
    public void setDescr(java.lang.String descr) {
        this.descr = descr;
    }


    /**
     * Gets the hiId value for this LayerObject.
     * 
     * @return hiId
     */
    public int getHiId() {
        return hiId;
    }


    /**
     * Sets the hiId value for this LayerObject.
     * 
     * @param hiId
     */
    public void setHiId(int hiId) {
        this.hiId = hiId;
    }


    /**
     * Gets the loId value for this LayerObject.
     * 
     * @return loId
     */
    public int getLoId() {
        return loId;
    }


    /**
     * Sets the loId value for this LayerObject.
     * 
     * @param loId
     */
    public void setLoId(int loId) {
        this.loId = loId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LayerObject)) return false;
        LayerObject other = (LayerObject) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.geometry==null && other.getGeometry()==null) || 
             (this.geometry!=null &&
              this.geometry.equals(other.getGeometry()))) &&
            ((this.pixel==null && other.getPixel()==null) || 
             (this.pixel!=null &&
              this.pixel.equals(other.getPixel()))) &&
            ((this.ref==null && other.getRef()==null) || 
             (this.ref!=null &&
              this.ref.equals(other.getRef()))) &&
            ((this.descr==null && other.getDescr()==null) || 
             (this.descr!=null &&
              this.descr.equals(other.getDescr()))) &&
            this.hiId == other.getHiId() &&
            this.loId == other.getLoId();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getGeometry() != null) {
            _hashCode += getGeometry().hashCode();
        }
        if (getPixel() != null) {
            _hashCode += getPixel().hashCode();
        }
        if (getRef() != null) {
            _hashCode += getRef().hashCode();
        }
        if (getDescr() != null) {
            _hashCode += getDescr().hashCode();
        }
        _hashCode += getHiId();
        _hashCode += getLoId();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LayerObject.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "LayerObject"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("descr");
        attrField.setXmlName(new javax.xml.namespace.QName("", "descr"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("hiId");
        attrField.setXmlName(new javax.xml.namespace.QName("", "hiId"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("loId");
        attrField.setXmlName(new javax.xml.namespace.QName("", "loId"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("geometry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "geometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "ObjectGeometry"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pixel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "pixel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ref");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "ref"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
