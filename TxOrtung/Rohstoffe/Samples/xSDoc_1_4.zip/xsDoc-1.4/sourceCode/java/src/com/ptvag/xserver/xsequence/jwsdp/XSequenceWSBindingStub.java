/**
 * XSequenceWSBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence.jwsdp;

public class XSequenceWSBindingStub extends org.apache.axis.client.Stub implements com.ptvag.xserver.xsequence.jwsdp.XSequenceWS {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[7];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("calcTimewindowTour");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "ArrayOfTimewindowStop_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfTimewindowStop"), com.ptvag.xserver.xsequence.TimewindowStop[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimewindowStop"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "TimewindowPlanningParams_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimewindowPlanningParams"), com.ptvag.xserver.xsequence.TimewindowPlanningParams.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "InputTour_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "InputTour"), com.ptvag.xserver.xsequence.InputTour.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "CallerContext_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Plan"));
        oper.setReturnClass(com.ptvag.xserver.xsequence.Plan.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"),
                      "com.ptvag.jabba.core.exception.OptimisticRollbackException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"),
                      "com.ptvag.jabba.core.exception.TableNotFoundException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"),
                      "com.ptvag.jabba.core.exception.ConstraintViolationException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"),
                      "com.ptvag.jabba.core.exception.DatabaseException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"),
                      "com.ptvag.xserver.xsequence.XSequenceException",
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"), 
                      true
                     ));
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("calcTour");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "ArrayOfStop_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfStop"), com.ptvag.xserver.xsequence.Stop[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Stop"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "PlanningParams_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "PlanningParams"), com.ptvag.xserver.xsequence.PlanningParams.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "InputTour_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "InputTour"), com.ptvag.xserver.xsequence.InputTour.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "CallerContext_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Plan"));
        oper.setReturnClass(com.ptvag.xserver.xsequence.Plan.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"),
                      "com.ptvag.jabba.core.exception.OptimisticRollbackException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"),
                      "com.ptvag.jabba.core.exception.TableNotFoundException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"),
                      "com.ptvag.jabba.core.exception.ConstraintViolationException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"),
                      "com.ptvag.jabba.core.exception.DatabaseException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"),
                      "com.ptvag.xserver.xsequence.XSequenceException",
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"), 
                      true
                     ));
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("calcTransportTour");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "ArrayOfTransportStop_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfTransportStop"), com.ptvag.xserver.xsequence.TransportStop[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TransportStop"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "TransportPlanningParams_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TransportPlanningParams"), com.ptvag.xserver.xsequence.TransportPlanningParams.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "InputTour_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "InputTour"), com.ptvag.xserver.xsequence.InputTour.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "CallerContext_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Plan"));
        oper.setReturnClass(com.ptvag.xserver.xsequence.Plan.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"),
                      "com.ptvag.jabba.core.exception.OptimisticRollbackException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"),
                      "com.ptvag.jabba.core.exception.TableNotFoundException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"),
                      "com.ptvag.jabba.core.exception.ConstraintViolationException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"),
                      "com.ptvag.jabba.core.exception.DatabaseException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"),
                      "com.ptvag.xserver.xsequence.XSequenceException",
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"), 
                      true
                     ));
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("planOrienteeringTour");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "ArrayOfOrienteeringStop_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfOrienteeringStop"), com.ptvag.xserver.xsequence.OrienteeringStop[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OrienteeringStop"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "OrienteeringParams_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OrienteeringParams"), com.ptvag.xserver.xsequence.OrienteeringParams.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "InputTour_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "InputTour"), com.ptvag.xserver.xsequence.InputTour.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "CallerContext_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Plan"));
        oper.setReturnClass(com.ptvag.xserver.xsequence.Plan.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"),
                      "com.ptvag.jabba.core.exception.OptimisticRollbackException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"),
                      "com.ptvag.jabba.core.exception.TableNotFoundException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"),
                      "com.ptvag.jabba.core.exception.ConstraintViolationException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"),
                      "com.ptvag.jabba.core.exception.DatabaseException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"),
                      "com.ptvag.xserver.xsequence.XSequenceException",
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"), 
                      true
                     ));
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("planTimewindowTour");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "ArrayOfTimewindowStop_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfTimewindowStop"), com.ptvag.xserver.xsequence.TimewindowStop[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimewindowStop"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "TimewindowPlanningParams_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimewindowPlanningParams"), com.ptvag.xserver.xsequence.TimewindowPlanningParams.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "InputTour_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "InputTour"), com.ptvag.xserver.xsequence.InputTour.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "CallerContext_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Plan"));
        oper.setReturnClass(com.ptvag.xserver.xsequence.Plan.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"),
                      "com.ptvag.jabba.core.exception.OptimisticRollbackException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"),
                      "com.ptvag.jabba.core.exception.TableNotFoundException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"),
                      "com.ptvag.jabba.core.exception.ConstraintViolationException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"),
                      "com.ptvag.jabba.core.exception.DatabaseException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"),
                      "com.ptvag.xserver.xsequence.XSequenceException",
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"), 
                      true
                     ));
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("planTour");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "ArrayOfStop_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfStop"), com.ptvag.xserver.xsequence.Stop[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Stop"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "PlanningParams_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "PlanningParams"), com.ptvag.xserver.xsequence.PlanningParams.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "InputTour_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "InputTour"), com.ptvag.xserver.xsequence.InputTour.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "CallerContext_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Plan"));
        oper.setReturnClass(com.ptvag.xserver.xsequence.Plan.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"),
                      "com.ptvag.jabba.core.exception.OptimisticRollbackException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"),
                      "com.ptvag.jabba.core.exception.TableNotFoundException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"),
                      "com.ptvag.jabba.core.exception.ConstraintViolationException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"),
                      "com.ptvag.jabba.core.exception.DatabaseException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"),
                      "com.ptvag.xserver.xsequence.XSequenceException",
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"), 
                      true
                     ));
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("planTransportTour");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "ArrayOfTransportStop_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfTransportStop"), com.ptvag.xserver.xsequence.TransportStop[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TransportStop"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "TransportPlanningParams_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TransportPlanningParams"), com.ptvag.xserver.xsequence.TransportPlanningParams.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "InputTour_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "InputTour"), com.ptvag.xserver.xsequence.InputTour.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "CallerContext_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Plan"));
        oper.setReturnClass(com.ptvag.xserver.xsequence.Plan.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"),
                      "com.ptvag.jabba.core.exception.OptimisticRollbackException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"),
                      "com.ptvag.jabba.core.exception.TableNotFoundException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"),
                      "com.ptvag.jabba.core.exception.ConstraintViolationException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"),
                      "com.ptvag.jabba.core.exception.DatabaseException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"),
                      "com.ptvag.xserver.xsequence.XSequenceException",
                      new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException"), 
                      true
                     ));
        _operations[6] = oper;

    }

    public XSequenceWSBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public XSequenceWSBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public XSequenceWSBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
        addBindings0();
        addBindings1();
    }

    private void addBindings0() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "ArrayOfCallerContextProperty");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.CallerContextProperty[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty");
            qName2 = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.CallerContext.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.CallerContextProperty.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfGeometryEncoding");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.GeometryEncoding[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryEncoding");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryEncoding");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainGeometryBase");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainGeometryBase[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryBase");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryBase");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainLinearRing");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainLinearRing[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLinearRing");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLinearRing");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainLineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainLineString[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLineString");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLineString");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainPoint[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainPolygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainPolygon[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPolygon");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPolygon");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.Point[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "BoundingBox");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.BoundingBox.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "CoordFormat");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.CoordFormat.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "EncodedGeometry");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.EncodedGeometry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "EncodedGeometryBase");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.EncodedGeometryBase.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryCollection");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.GeometryCollection.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryEncoding");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.GeometryEncoding.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "LinearRing");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.LinearRing.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "LineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.LineString.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "MultiLineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.MultiLineString.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "MultiPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.MultiPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "MultiPolygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.MultiPolygon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryBase");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainGeometryBase.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryCollection");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainGeometryCollection.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLinearRing");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainLinearRing.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainLineString.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainMultiLineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainMultiLineString.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainMultiPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainMultiPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainMultiPolygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainMultiPolygon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPolygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainPolygon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.Point.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Polygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.Polygon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "RequestOptions");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.RequestOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.XServiceException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "BaseException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.BaseException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "BusinessException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.BusinessException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ConstraintViolationException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.ConstraintViolationException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "CreateException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.CreateException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DatabaseException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.DatabaseException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "DuplicateKeyException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.DuplicateKeyException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "FinderException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.FinderException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "IllegalParameterException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.IllegalParameterException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ObjectNotFoundException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.ObjectNotFoundException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "OptimisticRollbackException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.OptimisticRollbackException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ParameterNotSetException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.ParameterNotSetException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "RemoteAccessException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.RemoteAccessException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "RemoveException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.RemoveException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "StackElement");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.StackElement.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.SystemException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "TableNotFoundException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.TableNotFoundException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.UnexpectedException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.messaging.service.jabba.ptvag.com", "MessagingServiceException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.messaging.exception.MessagingServiceException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "BeanMappingException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.BeanMappingException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "InvalidPrefsScopeException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.InvalidPrefsScopeException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "KeyNotFoundException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.KeyNotFoundException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "NodeNotFoundException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.NodeNotFoundException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "PrefsAccessException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.PrefsAccessException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "PrefsEntryNotFoundException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.PrefsEntryNotFoundException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "PrefsException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.PrefsException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "PrefsImplNotDefinedException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.PrefsImplNotDefinedException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "PrefsInstantiationException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.PrefsInstantiationException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "PrefsProviderException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.PrefsProviderException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "TypeMismatchException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.TypeMismatchException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://persistent.core.jabba.ptvag.com", "OID");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.persistent.OID.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "ArrayOfPrefSubTree");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.PrefSubTree[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "PrefSubTree");
            qName2 = new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "PrefSubTree");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "ArrayOfProperty");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.Property[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "Property");
            qName2 = new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "Property");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "PrefSubTree");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.PrefSubTree.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "Property");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.Property.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://queryparams.service.jabba.ptvag.com", "BooleanParam");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.queryparams.BooleanParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://queryparams.service.jabba.ptvag.com", "ByteParam");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.queryparams.ByteParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://queryparams.service.jabba.ptvag.com", "CalendarParam");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.queryparams.CalendarParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://queryparams.service.jabba.ptvag.com", "DoubleParam");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.queryparams.DoubleParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://queryparams.service.jabba.ptvag.com", "EnumParam");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.queryparams.EnumParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://queryparams.service.jabba.ptvag.com", "FloatParam");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.queryparams.FloatParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://queryparams.service.jabba.ptvag.com", "IntegerParam");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.queryparams.IntegerParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://queryparams.service.jabba.ptvag.com", "LongParam");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.queryparams.LongParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://queryparams.service.jabba.ptvag.com", "OIDParam");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.queryparams.OIDParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://queryparams.service.jabba.ptvag.com", "QueryParam");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.queryparams.QueryParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://queryparams.service.jabba.ptvag.com", "ShortParam");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.queryparams.ShortParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://queryparams.service.jabba.ptvag.com", "StringParam");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.queryparams.StringParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://value.core.jabba.ptvag.com", "TransientVO");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.value.TransientVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfInt");
            cachedSerQNames.add(qName);
            cls = int[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int");
            qName2 = new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "Int");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "String");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfDistPeriod");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.DistPeriod[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistPeriod");
            qName2 = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistPeriod");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfInputTourPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.InputTourPoint[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "InputTourPoint");
            qName2 = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "InputTourPoint");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfInterval");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.Interval[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Interval");
            qName2 = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Interval");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfLLInterval");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.LLInterval[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "LLInterval");
            qName2 = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "LLInterval");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfOrienteeringStop");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.OrienteeringStop[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OrienteeringStop");
            qName2 = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OrienteeringStop");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfOutputTourPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.OutputTourPoint[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OutputTourPoint");
            qName2 = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OutputTourPoint");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfStop");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.Stop[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Stop");
            qName2 = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Stop");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfTimeEvent");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TimeEvent[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimeEvent");
            qName2 = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimeEvent");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfTimewindowStop");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TimewindowStop[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimewindowStop");
            qName2 = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimewindowStop");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfTourPointViolation");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TourPointViolation[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TourPointViolation");
            qName2 = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TourPointViolation");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfTourViolation");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TourViolation[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TourViolation");
            qName2 = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TourViolation");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "ArrayOfTransportStop");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TransportStop[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TransportStop");
            qName2 = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TransportStop");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "BreakRestTourPointResult");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.BreakRestTourPointResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "BreakRule");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.BreakRule.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DimaParams");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.DimaParams.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistanceCalculation");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.DistanceCalculation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistanceMatrix");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.DistanceMatrix.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings1() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistanceType");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.DistanceType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DistPeriod");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.DistPeriod.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "InputTour");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.InputTour.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "InputTourPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.InputTourPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Interval");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.Interval.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "LimitValues");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.LimitValues.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "LLInterval");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.LLInterval.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OrienteeringParams");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.OrienteeringParams.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OrienteeringStop");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.OrienteeringStop.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OutputTour");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.OutputTour.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OutputTourPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.OutputTourPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "PartnerInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.PartnerInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "PartnerPos");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.PartnerPos.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Plan");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.Plan.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "PlanningParams");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.PlanningParams.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Quantities");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.Quantities.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "RemainingPeriods");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.RemainingPeriods.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "RestRule");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.RestRule.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Stop");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.Stop.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "SubSequence");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.SubSequence.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimeEvent");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TimeEvent.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimeEventType");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TimeEventType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimewindowPlanningParams");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TimewindowPlanningParams.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimewindowStop");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TimewindowStop.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimewindowTourPointResult");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TimewindowTourPointResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimewindowTourResult");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TimewindowTourResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TourPointViolation");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TourPointViolation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TourViolation");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TourViolation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TransportPlanningParams");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TransportPlanningParams.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TransportStop");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TransportStop.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TransportTourPointResult");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TransportTourPointResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TransportTourResult");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.TransportTourResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "VehicleType");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.VehicleType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "XSequenceException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xsequence.XSequenceException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.ptvag.xserver.xsequence.Plan calcTimewindowTour(com.ptvag.xserver.xsequence.TimewindowStop[] arrayOfTimewindowStop_1, com.ptvag.xserver.xsequence.TimewindowPlanningParams timewindowPlanningParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "calcTimewindowTour"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfTimewindowStop_1, timewindowPlanningParams_2, inputTour_3, callerContext_4});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xsequence.Plan) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xsequence.Plan) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xsequence.Plan.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.OptimisticRollbackException) {
              throw (com.ptvag.jabba.core.exception.OptimisticRollbackException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.TableNotFoundException) {
              throw (com.ptvag.jabba.core.exception.TableNotFoundException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.ConstraintViolationException) {
              throw (com.ptvag.jabba.core.exception.ConstraintViolationException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.DatabaseException) {
              throw (com.ptvag.jabba.core.exception.DatabaseException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xsequence.XSequenceException) {
              throw (com.ptvag.xserver.xsequence.XSequenceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xsequence.Plan calcTour(com.ptvag.xserver.xsequence.Stop[] arrayOfStop_1, com.ptvag.xserver.xsequence.PlanningParams planningParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "calcTour"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfStop_1, planningParams_2, inputTour_3, callerContext_4});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xsequence.Plan) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xsequence.Plan) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xsequence.Plan.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.OptimisticRollbackException) {
              throw (com.ptvag.jabba.core.exception.OptimisticRollbackException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.TableNotFoundException) {
              throw (com.ptvag.jabba.core.exception.TableNotFoundException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.ConstraintViolationException) {
              throw (com.ptvag.jabba.core.exception.ConstraintViolationException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.DatabaseException) {
              throw (com.ptvag.jabba.core.exception.DatabaseException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xsequence.XSequenceException) {
              throw (com.ptvag.xserver.xsequence.XSequenceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xsequence.Plan calcTransportTour(com.ptvag.xserver.xsequence.TransportStop[] arrayOfTransportStop_1, com.ptvag.xserver.xsequence.TransportPlanningParams transportPlanningParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "calcTransportTour"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfTransportStop_1, transportPlanningParams_2, inputTour_3, callerContext_4});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xsequence.Plan) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xsequence.Plan) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xsequence.Plan.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.OptimisticRollbackException) {
              throw (com.ptvag.jabba.core.exception.OptimisticRollbackException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.TableNotFoundException) {
              throw (com.ptvag.jabba.core.exception.TableNotFoundException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.ConstraintViolationException) {
              throw (com.ptvag.jabba.core.exception.ConstraintViolationException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.DatabaseException) {
              throw (com.ptvag.jabba.core.exception.DatabaseException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xsequence.XSequenceException) {
              throw (com.ptvag.xserver.xsequence.XSequenceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xsequence.Plan planOrienteeringTour(com.ptvag.xserver.xsequence.OrienteeringStop[] arrayOfOrienteeringStop_1, com.ptvag.xserver.xsequence.OrienteeringParams orienteeringParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "planOrienteeringTour"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfOrienteeringStop_1, orienteeringParams_2, inputTour_3, callerContext_4});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xsequence.Plan) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xsequence.Plan) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xsequence.Plan.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.OptimisticRollbackException) {
              throw (com.ptvag.jabba.core.exception.OptimisticRollbackException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.TableNotFoundException) {
              throw (com.ptvag.jabba.core.exception.TableNotFoundException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.ConstraintViolationException) {
              throw (com.ptvag.jabba.core.exception.ConstraintViolationException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.DatabaseException) {
              throw (com.ptvag.jabba.core.exception.DatabaseException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xsequence.XSequenceException) {
              throw (com.ptvag.xserver.xsequence.XSequenceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xsequence.Plan planTimewindowTour(com.ptvag.xserver.xsequence.TimewindowStop[] arrayOfTimewindowStop_1, com.ptvag.xserver.xsequence.TimewindowPlanningParams timewindowPlanningParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "planTimewindowTour"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfTimewindowStop_1, timewindowPlanningParams_2, inputTour_3, callerContext_4});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xsequence.Plan) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xsequence.Plan) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xsequence.Plan.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.OptimisticRollbackException) {
              throw (com.ptvag.jabba.core.exception.OptimisticRollbackException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.TableNotFoundException) {
              throw (com.ptvag.jabba.core.exception.TableNotFoundException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.ConstraintViolationException) {
              throw (com.ptvag.jabba.core.exception.ConstraintViolationException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.DatabaseException) {
              throw (com.ptvag.jabba.core.exception.DatabaseException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xsequence.XSequenceException) {
              throw (com.ptvag.xserver.xsequence.XSequenceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xsequence.Plan planTour(com.ptvag.xserver.xsequence.Stop[] arrayOfStop_1, com.ptvag.xserver.xsequence.PlanningParams planningParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "planTour"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfStop_1, planningParams_2, inputTour_3, callerContext_4});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xsequence.Plan) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xsequence.Plan) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xsequence.Plan.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.OptimisticRollbackException) {
              throw (com.ptvag.jabba.core.exception.OptimisticRollbackException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.TableNotFoundException) {
              throw (com.ptvag.jabba.core.exception.TableNotFoundException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.ConstraintViolationException) {
              throw (com.ptvag.jabba.core.exception.ConstraintViolationException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.DatabaseException) {
              throw (com.ptvag.jabba.core.exception.DatabaseException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xsequence.XSequenceException) {
              throw (com.ptvag.xserver.xsequence.XSequenceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xsequence.Plan planTransportTour(com.ptvag.xserver.xsequence.TransportStop[] arrayOfTransportStop_1, com.ptvag.xserver.xsequence.TransportPlanningParams transportPlanningParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xsequence.xserver.ptvag.com", "planTransportTour"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfTransportStop_1, transportPlanningParams_2, inputTour_3, callerContext_4});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xsequence.Plan) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xsequence.Plan) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xsequence.Plan.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.OptimisticRollbackException) {
              throw (com.ptvag.jabba.core.exception.OptimisticRollbackException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.TableNotFoundException) {
              throw (com.ptvag.jabba.core.exception.TableNotFoundException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.ConstraintViolationException) {
              throw (com.ptvag.jabba.core.exception.ConstraintViolationException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.DatabaseException) {
              throw (com.ptvag.jabba.core.exception.DatabaseException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xsequence.XSequenceException) {
              throw (com.ptvag.xserver.xsequence.XSequenceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

}
