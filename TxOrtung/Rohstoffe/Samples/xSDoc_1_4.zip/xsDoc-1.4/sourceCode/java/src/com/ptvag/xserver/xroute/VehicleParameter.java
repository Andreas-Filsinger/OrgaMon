/**
 * VehicleParameter.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class VehicleParameter implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected VehicleParameter(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _TYPE = "TYPE";
    public static final java.lang.String _TOTAL_WEIGHT = "TOTAL_WEIGHT";
    public static final java.lang.String _TRAILER_WEIGHT = "TRAILER_WEIGHT";
    public static final java.lang.String _AXLE_WEIGHT = "AXLE_WEIGHT";
    public static final java.lang.String _NUMBER_OF_AXLES = "NUMBER_OF_AXLES";
    public static final java.lang.String _EMISSION_CLASS = "EMISSION_CLASS";
    public static final java.lang.String _HEIGHT = "HEIGHT";
    public static final java.lang.String _LENGTH = "LENGTH";
    public static final java.lang.String _WIDTH = "WIDTH";
    public static final java.lang.String _CYLINDER_CAPACITY = "CYLINDER_CAPACITY";
    public static final java.lang.String _NUMBER_OF_PASSENGERS = "NUMBER_OF_PASSENGERS";
    public static final java.lang.String _TRAILER_HAS_BREAKS = "TRAILER_HAS_BREAKS";
    public static final VehicleParameter TYPE = new VehicleParameter(_TYPE);
    public static final VehicleParameter TOTAL_WEIGHT = new VehicleParameter(_TOTAL_WEIGHT);
    public static final VehicleParameter TRAILER_WEIGHT = new VehicleParameter(_TRAILER_WEIGHT);
    public static final VehicleParameter AXLE_WEIGHT = new VehicleParameter(_AXLE_WEIGHT);
    public static final VehicleParameter NUMBER_OF_AXLES = new VehicleParameter(_NUMBER_OF_AXLES);
    public static final VehicleParameter EMISSION_CLASS = new VehicleParameter(_EMISSION_CLASS);
    public static final VehicleParameter HEIGHT = new VehicleParameter(_HEIGHT);
    public static final VehicleParameter LENGTH = new VehicleParameter(_LENGTH);
    public static final VehicleParameter WIDTH = new VehicleParameter(_WIDTH);
    public static final VehicleParameter CYLINDER_CAPACITY = new VehicleParameter(_CYLINDER_CAPACITY);
    public static final VehicleParameter NUMBER_OF_PASSENGERS = new VehicleParameter(_NUMBER_OF_PASSENGERS);
    public static final VehicleParameter TRAILER_HAS_BREAKS = new VehicleParameter(_TRAILER_HAS_BREAKS);
    public java.lang.String getValue() { return _value_;}
    public static VehicleParameter fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        VehicleParameter enumeration = (VehicleParameter)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static VehicleParameter fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(VehicleParameter.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "VehicleParameter"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
