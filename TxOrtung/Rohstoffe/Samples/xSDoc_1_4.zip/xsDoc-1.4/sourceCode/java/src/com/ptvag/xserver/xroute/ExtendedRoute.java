/**
 * ExtendedRoute.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class ExtendedRoute  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.CountryInfo[] wrappedCountryInfos;

    private com.ptvag.xserver.xroute.Route route;

    public ExtendedRoute() {
    }

    public ExtendedRoute(
           com.ptvag.xserver.xroute.CountryInfo[] wrappedCountryInfos,
           com.ptvag.xserver.xroute.Route route) {
        this.wrappedCountryInfos = wrappedCountryInfos;
        this.route = route;
    }


    /**
     * Gets the wrappedCountryInfos value for this ExtendedRoute.
     * 
     * @return wrappedCountryInfos
     */
    public com.ptvag.xserver.xroute.CountryInfo[] getWrappedCountryInfos() {
        return wrappedCountryInfos;
    }


    /**
     * Sets the wrappedCountryInfos value for this ExtendedRoute.
     * 
     * @param wrappedCountryInfos
     */
    public void setWrappedCountryInfos(com.ptvag.xserver.xroute.CountryInfo[] wrappedCountryInfos) {
        this.wrappedCountryInfos = wrappedCountryInfos;
    }


    /**
     * Gets the route value for this ExtendedRoute.
     * 
     * @return route
     */
    public com.ptvag.xserver.xroute.Route getRoute() {
        return route;
    }


    /**
     * Sets the route value for this ExtendedRoute.
     * 
     * @param route
     */
    public void setRoute(com.ptvag.xserver.xroute.Route route) {
        this.route = route;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ExtendedRoute)) return false;
        ExtendedRoute other = (ExtendedRoute) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedCountryInfos==null && other.getWrappedCountryInfos()==null) || 
             (this.wrappedCountryInfos!=null &&
              java.util.Arrays.equals(this.wrappedCountryInfos, other.getWrappedCountryInfos()))) &&
            ((this.route==null && other.getRoute()==null) || 
             (this.route!=null &&
              this.route.equals(other.getRoute())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedCountryInfos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedCountryInfos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedCountryInfos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRoute() != null) {
            _hashCode += getRoute().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ExtendedRoute.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExtendedRoute"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedCountryInfos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedCountryInfos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "CountryInfo"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "CountryInfo"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("route");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "route"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Route"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
