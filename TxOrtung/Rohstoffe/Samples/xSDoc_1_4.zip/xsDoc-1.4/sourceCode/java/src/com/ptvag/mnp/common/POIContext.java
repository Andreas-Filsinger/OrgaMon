/**
 * POIContext.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class POIContext  implements java.io.Serializable {
    private com.ptvag.mnp.common.DevCoord dev;

    private java.lang.String devWKB;

    private com.ptvag.mnp.common.DistanceProperties dist;

    private com.ptvag.mnp.common.RefTypeEnum refType;

    private com.ptvag.mnp.common.Coordinate reference;

    public POIContext() {
    }

    public POIContext(
           com.ptvag.mnp.common.DevCoord dev,
           java.lang.String devWKB,
           com.ptvag.mnp.common.DistanceProperties dist,
           com.ptvag.mnp.common.RefTypeEnum refType,
           com.ptvag.mnp.common.Coordinate reference) {
           this.dev = dev;
           this.devWKB = devWKB;
           this.dist = dist;
           this.refType = refType;
           this.reference = reference;
    }


    /**
     * Gets the dev value for this POIContext.
     * 
     * @return dev
     */
    public com.ptvag.mnp.common.DevCoord getDev() {
        return dev;
    }


    /**
     * Sets the dev value for this POIContext.
     * 
     * @param dev
     */
    public void setDev(com.ptvag.mnp.common.DevCoord dev) {
        this.dev = dev;
    }


    /**
     * Gets the devWKB value for this POIContext.
     * 
     * @return devWKB
     */
    public java.lang.String getDevWKB() {
        return devWKB;
    }


    /**
     * Sets the devWKB value for this POIContext.
     * 
     * @param devWKB
     */
    public void setDevWKB(java.lang.String devWKB) {
        this.devWKB = devWKB;
    }


    /**
     * Gets the dist value for this POIContext.
     * 
     * @return dist
     */
    public com.ptvag.mnp.common.DistanceProperties getDist() {
        return dist;
    }


    /**
     * Sets the dist value for this POIContext.
     * 
     * @param dist
     */
    public void setDist(com.ptvag.mnp.common.DistanceProperties dist) {
        this.dist = dist;
    }


    /**
     * Gets the refType value for this POIContext.
     * 
     * @return refType
     */
    public com.ptvag.mnp.common.RefTypeEnum getRefType() {
        return refType;
    }


    /**
     * Sets the refType value for this POIContext.
     * 
     * @param refType
     */
    public void setRefType(com.ptvag.mnp.common.RefTypeEnum refType) {
        this.refType = refType;
    }


    /**
     * Gets the reference value for this POIContext.
     * 
     * @return reference
     */
    public com.ptvag.mnp.common.Coordinate getReference() {
        return reference;
    }


    /**
     * Sets the reference value for this POIContext.
     * 
     * @param reference
     */
    public void setReference(com.ptvag.mnp.common.Coordinate reference) {
        this.reference = reference;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof POIContext)) return false;
        POIContext other = (POIContext) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.dev==null && other.getDev()==null) || 
             (this.dev!=null &&
              this.dev.equals(other.getDev()))) &&
            ((this.devWKB==null && other.getDevWKB()==null) || 
             (this.devWKB!=null &&
              this.devWKB.equals(other.getDevWKB()))) &&
            ((this.dist==null && other.getDist()==null) || 
             (this.dist!=null &&
              this.dist.equals(other.getDist()))) &&
            ((this.refType==null && other.getRefType()==null) || 
             (this.refType!=null &&
              this.refType.equals(other.getRefType()))) &&
            ((this.reference==null && other.getReference()==null) || 
             (this.reference!=null &&
              this.reference.equals(other.getReference())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDev() != null) {
            _hashCode += getDev().hashCode();
        }
        if (getDevWKB() != null) {
            _hashCode += getDevWKB().hashCode();
        }
        if (getDist() != null) {
            _hashCode += getDist().hashCode();
        }
        if (getRefType() != null) {
            _hashCode += getRefType().hashCode();
        }
        if (getReference() != null) {
            _hashCode += getReference().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(POIContext.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIContext"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dev");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "dev"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "DevCoord"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("devWKB");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "devWKB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dist");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "dist"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "DistanceProperties"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "refType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RefTypeEnum"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "reference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Coordinate"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
