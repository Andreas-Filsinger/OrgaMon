/**
 * OutputTourPoint.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class OutputTourPoint  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xsequence.TimewindowTourPointResult timewindowResult;

    private com.ptvag.xserver.xsequence.TourPointViolation[] wrappedTourPointViolations;

    private com.ptvag.xserver.xsequence.TransportTourPointResult transportResult;

    private int arrivalTime;  // attribute

    private int departureTime;  // attribute

    private int drivingDistance;  // attribute

    private int drivingPeriod;  // attribute

    private int endServiceTime;  // attribute

    private int servicePeriod;  // attribute

    private int startDistance;  // attribute

    private int startPeriod;  // attribute

    private int startServiceTime;  // attribute

    private int stopID;  // attribute

    public OutputTourPoint() {
    }

    public OutputTourPoint(
           int arrivalTime,
           int departureTime,
           int drivingDistance,
           int drivingPeriod,
           int endServiceTime,
           int servicePeriod,
           int startDistance,
           int startPeriod,
           int startServiceTime,
           int stopID,
           com.ptvag.xserver.xsequence.TimewindowTourPointResult timewindowResult,
           com.ptvag.xserver.xsequence.TourPointViolation[] wrappedTourPointViolations,
           com.ptvag.xserver.xsequence.TransportTourPointResult transportResult) {
        this.arrivalTime = arrivalTime;
        this.departureTime = departureTime;
        this.drivingDistance = drivingDistance;
        this.drivingPeriod = drivingPeriod;
        this.endServiceTime = endServiceTime;
        this.servicePeriod = servicePeriod;
        this.startDistance = startDistance;
        this.startPeriod = startPeriod;
        this.startServiceTime = startServiceTime;
        this.stopID = stopID;
        this.timewindowResult = timewindowResult;
        this.wrappedTourPointViolations = wrappedTourPointViolations;
        this.transportResult = transportResult;
    }


    /**
     * Gets the timewindowResult value for this OutputTourPoint.
     * 
     * @return timewindowResult
     */
    public com.ptvag.xserver.xsequence.TimewindowTourPointResult getTimewindowResult() {
        return timewindowResult;
    }


    /**
     * Sets the timewindowResult value for this OutputTourPoint.
     * 
     * @param timewindowResult
     */
    public void setTimewindowResult(com.ptvag.xserver.xsequence.TimewindowTourPointResult timewindowResult) {
        this.timewindowResult = timewindowResult;
    }


    /**
     * Gets the wrappedTourPointViolations value for this OutputTourPoint.
     * 
     * @return wrappedTourPointViolations
     */
    public com.ptvag.xserver.xsequence.TourPointViolation[] getWrappedTourPointViolations() {
        return wrappedTourPointViolations;
    }


    /**
     * Sets the wrappedTourPointViolations value for this OutputTourPoint.
     * 
     * @param wrappedTourPointViolations
     */
    public void setWrappedTourPointViolations(com.ptvag.xserver.xsequence.TourPointViolation[] wrappedTourPointViolations) {
        this.wrappedTourPointViolations = wrappedTourPointViolations;
    }


    /**
     * Gets the transportResult value for this OutputTourPoint.
     * 
     * @return transportResult
     */
    public com.ptvag.xserver.xsequence.TransportTourPointResult getTransportResult() {
        return transportResult;
    }


    /**
     * Sets the transportResult value for this OutputTourPoint.
     * 
     * @param transportResult
     */
    public void setTransportResult(com.ptvag.xserver.xsequence.TransportTourPointResult transportResult) {
        this.transportResult = transportResult;
    }


    /**
     * Gets the arrivalTime value for this OutputTourPoint.
     * 
     * @return arrivalTime
     */
    public int getArrivalTime() {
        return arrivalTime;
    }


    /**
     * Sets the arrivalTime value for this OutputTourPoint.
     * 
     * @param arrivalTime
     */
    public void setArrivalTime(int arrivalTime) {
        this.arrivalTime = arrivalTime;
    }


    /**
     * Gets the departureTime value for this OutputTourPoint.
     * 
     * @return departureTime
     */
    public int getDepartureTime() {
        return departureTime;
    }


    /**
     * Sets the departureTime value for this OutputTourPoint.
     * 
     * @param departureTime
     */
    public void setDepartureTime(int departureTime) {
        this.departureTime = departureTime;
    }


    /**
     * Gets the drivingDistance value for this OutputTourPoint.
     * 
     * @return drivingDistance
     */
    public int getDrivingDistance() {
        return drivingDistance;
    }


    /**
     * Sets the drivingDistance value for this OutputTourPoint.
     * 
     * @param drivingDistance
     */
    public void setDrivingDistance(int drivingDistance) {
        this.drivingDistance = drivingDistance;
    }


    /**
     * Gets the drivingPeriod value for this OutputTourPoint.
     * 
     * @return drivingPeriod
     */
    public int getDrivingPeriod() {
        return drivingPeriod;
    }


    /**
     * Sets the drivingPeriod value for this OutputTourPoint.
     * 
     * @param drivingPeriod
     */
    public void setDrivingPeriod(int drivingPeriod) {
        this.drivingPeriod = drivingPeriod;
    }


    /**
     * Gets the endServiceTime value for this OutputTourPoint.
     * 
     * @return endServiceTime
     */
    public int getEndServiceTime() {
        return endServiceTime;
    }


    /**
     * Sets the endServiceTime value for this OutputTourPoint.
     * 
     * @param endServiceTime
     */
    public void setEndServiceTime(int endServiceTime) {
        this.endServiceTime = endServiceTime;
    }


    /**
     * Gets the servicePeriod value for this OutputTourPoint.
     * 
     * @return servicePeriod
     */
    public int getServicePeriod() {
        return servicePeriod;
    }


    /**
     * Sets the servicePeriod value for this OutputTourPoint.
     * 
     * @param servicePeriod
     */
    public void setServicePeriod(int servicePeriod) {
        this.servicePeriod = servicePeriod;
    }


    /**
     * Gets the startDistance value for this OutputTourPoint.
     * 
     * @return startDistance
     */
    public int getStartDistance() {
        return startDistance;
    }


    /**
     * Sets the startDistance value for this OutputTourPoint.
     * 
     * @param startDistance
     */
    public void setStartDistance(int startDistance) {
        this.startDistance = startDistance;
    }


    /**
     * Gets the startPeriod value for this OutputTourPoint.
     * 
     * @return startPeriod
     */
    public int getStartPeriod() {
        return startPeriod;
    }


    /**
     * Sets the startPeriod value for this OutputTourPoint.
     * 
     * @param startPeriod
     */
    public void setStartPeriod(int startPeriod) {
        this.startPeriod = startPeriod;
    }


    /**
     * Gets the startServiceTime value for this OutputTourPoint.
     * 
     * @return startServiceTime
     */
    public int getStartServiceTime() {
        return startServiceTime;
    }


    /**
     * Sets the startServiceTime value for this OutputTourPoint.
     * 
     * @param startServiceTime
     */
    public void setStartServiceTime(int startServiceTime) {
        this.startServiceTime = startServiceTime;
    }


    /**
     * Gets the stopID value for this OutputTourPoint.
     * 
     * @return stopID
     */
    public int getStopID() {
        return stopID;
    }


    /**
     * Sets the stopID value for this OutputTourPoint.
     * 
     * @param stopID
     */
    public void setStopID(int stopID) {
        this.stopID = stopID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OutputTourPoint)) return false;
        OutputTourPoint other = (OutputTourPoint) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.timewindowResult==null && other.getTimewindowResult()==null) || 
             (this.timewindowResult!=null &&
              this.timewindowResult.equals(other.getTimewindowResult()))) &&
            ((this.wrappedTourPointViolations==null && other.getWrappedTourPointViolations()==null) || 
             (this.wrappedTourPointViolations!=null &&
              java.util.Arrays.equals(this.wrappedTourPointViolations, other.getWrappedTourPointViolations()))) &&
            ((this.transportResult==null && other.getTransportResult()==null) || 
             (this.transportResult!=null &&
              this.transportResult.equals(other.getTransportResult()))) &&
            this.arrivalTime == other.getArrivalTime() &&
            this.departureTime == other.getDepartureTime() &&
            this.drivingDistance == other.getDrivingDistance() &&
            this.drivingPeriod == other.getDrivingPeriod() &&
            this.endServiceTime == other.getEndServiceTime() &&
            this.servicePeriod == other.getServicePeriod() &&
            this.startDistance == other.getStartDistance() &&
            this.startPeriod == other.getStartPeriod() &&
            this.startServiceTime == other.getStartServiceTime() &&
            this.stopID == other.getStopID();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getTimewindowResult() != null) {
            _hashCode += getTimewindowResult().hashCode();
        }
        if (getWrappedTourPointViolations() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedTourPointViolations());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedTourPointViolations(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTransportResult() != null) {
            _hashCode += getTransportResult().hashCode();
        }
        _hashCode += getArrivalTime();
        _hashCode += getDepartureTime();
        _hashCode += getDrivingDistance();
        _hashCode += getDrivingPeriod();
        _hashCode += getEndServiceTime();
        _hashCode += getServicePeriod();
        _hashCode += getStartDistance();
        _hashCode += getStartPeriod();
        _hashCode += getStartServiceTime();
        _hashCode += getStopID();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OutputTourPoint.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OutputTourPoint"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("arrivalTime");
        attrField.setXmlName(new javax.xml.namespace.QName("", "arrivalTime"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("departureTime");
        attrField.setXmlName(new javax.xml.namespace.QName("", "departureTime"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("drivingDistance");
        attrField.setXmlName(new javax.xml.namespace.QName("", "drivingDistance"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("drivingPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "drivingPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("endServiceTime");
        attrField.setXmlName(new javax.xml.namespace.QName("", "endServiceTime"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("servicePeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "servicePeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("startDistance");
        attrField.setXmlName(new javax.xml.namespace.QName("", "startDistance"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("startPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "startPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("startServiceTime");
        attrField.setXmlName(new javax.xml.namespace.QName("", "startServiceTime"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("stopID");
        attrField.setXmlName(new javax.xml.namespace.QName("", "stopID"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timewindowResult");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "timewindowResult"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TimewindowTourPointResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedTourPointViolations");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "wrappedTourPointViolations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TourPointViolation"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TourPointViolation"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transportResult");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "transportResult"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "TransportTourPointResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
