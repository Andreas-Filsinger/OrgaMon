/**
 * POIViewSet.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class POIViewSet  implements java.io.Serializable {
    private com.ptvag.mnp.common.POIAttribute[] wrappedAttributes;

    private com.ptvag.mnp.common.POIFilter filter;

    private java.lang.Long maxResults;

    private java.lang.String poiSource;

    private java.lang.String poiType;

    private com.ptvag.mnp.common.POIView[] wrappedPoiViews;

    private java.lang.Boolean processed;

    public POIViewSet() {
    }

    public POIViewSet(
           com.ptvag.mnp.common.POIAttribute[] wrappedAttributes,
           com.ptvag.mnp.common.POIFilter filter,
           java.lang.Long maxResults,
           java.lang.String poiSource,
           java.lang.String poiType,
           com.ptvag.mnp.common.POIView[] wrappedPoiViews,
           java.lang.Boolean processed) {
           this.wrappedAttributes = wrappedAttributes;
           this.filter = filter;
           this.maxResults = maxResults;
           this.poiSource = poiSource;
           this.poiType = poiType;
           this.wrappedPoiViews = wrappedPoiViews;
           this.processed = processed;
    }


    /**
     * Gets the wrappedAttributes value for this POIViewSet.
     * 
     * @return wrappedAttributes
     */
    public com.ptvag.mnp.common.POIAttribute[] getWrappedAttributes() {
        return wrappedAttributes;
    }


    /**
     * Sets the wrappedAttributes value for this POIViewSet.
     * 
     * @param wrappedAttributes
     */
    public void setWrappedAttributes(com.ptvag.mnp.common.POIAttribute[] wrappedAttributes) {
        this.wrappedAttributes = wrappedAttributes;
    }


    /**
     * Gets the filter value for this POIViewSet.
     * 
     * @return filter
     */
    public com.ptvag.mnp.common.POIFilter getFilter() {
        return filter;
    }


    /**
     * Sets the filter value for this POIViewSet.
     * 
     * @param filter
     */
    public void setFilter(com.ptvag.mnp.common.POIFilter filter) {
        this.filter = filter;
    }


    /**
     * Gets the maxResults value for this POIViewSet.
     * 
     * @return maxResults
     */
    public java.lang.Long getMaxResults() {
        return maxResults;
    }


    /**
     * Sets the maxResults value for this POIViewSet.
     * 
     * @param maxResults
     */
    public void setMaxResults(java.lang.Long maxResults) {
        this.maxResults = maxResults;
    }


    /**
     * Gets the poiSource value for this POIViewSet.
     * 
     * @return poiSource
     */
    public java.lang.String getPoiSource() {
        return poiSource;
    }


    /**
     * Sets the poiSource value for this POIViewSet.
     * 
     * @param poiSource
     */
    public void setPoiSource(java.lang.String poiSource) {
        this.poiSource = poiSource;
    }


    /**
     * Gets the poiType value for this POIViewSet.
     * 
     * @return poiType
     */
    public java.lang.String getPoiType() {
        return poiType;
    }


    /**
     * Sets the poiType value for this POIViewSet.
     * 
     * @param poiType
     */
    public void setPoiType(java.lang.String poiType) {
        this.poiType = poiType;
    }


    /**
     * Gets the wrappedPoiViews value for this POIViewSet.
     * 
     * @return wrappedPoiViews
     */
    public com.ptvag.mnp.common.POIView[] getWrappedPoiViews() {
        return wrappedPoiViews;
    }


    /**
     * Sets the wrappedPoiViews value for this POIViewSet.
     * 
     * @param wrappedPoiViews
     */
    public void setWrappedPoiViews(com.ptvag.mnp.common.POIView[] wrappedPoiViews) {
        this.wrappedPoiViews = wrappedPoiViews;
    }


    /**
     * Gets the processed value for this POIViewSet.
     * 
     * @return processed
     */
    public java.lang.Boolean getProcessed() {
        return processed;
    }


    /**
     * Sets the processed value for this POIViewSet.
     * 
     * @param processed
     */
    public void setProcessed(java.lang.Boolean processed) {
        this.processed = processed;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof POIViewSet)) return false;
        POIViewSet other = (POIViewSet) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.wrappedAttributes==null && other.getWrappedAttributes()==null) || 
             (this.wrappedAttributes!=null &&
              java.util.Arrays.equals(this.wrappedAttributes, other.getWrappedAttributes()))) &&
            ((this.filter==null && other.getFilter()==null) || 
             (this.filter!=null &&
              this.filter.equals(other.getFilter()))) &&
            ((this.maxResults==null && other.getMaxResults()==null) || 
             (this.maxResults!=null &&
              this.maxResults.equals(other.getMaxResults()))) &&
            ((this.poiSource==null && other.getPoiSource()==null) || 
             (this.poiSource!=null &&
              this.poiSource.equals(other.getPoiSource()))) &&
            ((this.poiType==null && other.getPoiType()==null) || 
             (this.poiType!=null &&
              this.poiType.equals(other.getPoiType()))) &&
            ((this.wrappedPoiViews==null && other.getWrappedPoiViews()==null) || 
             (this.wrappedPoiViews!=null &&
              java.util.Arrays.equals(this.wrappedPoiViews, other.getWrappedPoiViews()))) &&
            ((this.processed==null && other.getProcessed()==null) || 
             (this.processed!=null &&
              this.processed.equals(other.getProcessed())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getWrappedAttributes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedAttributes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedAttributes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFilter() != null) {
            _hashCode += getFilter().hashCode();
        }
        if (getMaxResults() != null) {
            _hashCode += getMaxResults().hashCode();
        }
        if (getPoiSource() != null) {
            _hashCode += getPoiSource().hashCode();
        }
        if (getPoiType() != null) {
            _hashCode += getPoiType().hashCode();
        }
        if (getWrappedPoiViews() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedPoiViews());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedPoiViews(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getProcessed() != null) {
            _hashCode += getProcessed().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(POIViewSet.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIViewSet"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedAttributes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedAttributes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIAttribute"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIAttribute"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("filter");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "filter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIFilter"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxResults");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "maxResults"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("poiSource");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "poiSource"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("poiType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "poiType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedPoiViews");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedPoiViews"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIView"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIView"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processed");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "processed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
