/**
 * Route.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class Route  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.BoundingRectangle[] wrappedBoundingRectangles;

    private com.ptvag.xserver.xroute.DynamicInfo dynamicInfo;

    private com.ptvag.xserver.xroute.RouteInfo info;

    private com.ptvag.xserver.xroute.ManoeuvreGroup[] wrappedManoeuvreGroup;

    private com.ptvag.xserver.xroute.RouteManoeuvre[] wrappedManoeuvres;

    private com.ptvag.xserver.xroute.UniqueGeoID[] wrappedNodes;

    private com.ptvag.xserver.common.LineString polygon;

    private com.ptvag.xserver.xroute.RouteListSegment[] wrappedSegments;

    private com.ptvag.xserver.xroute.WayPoint[] wrappedStations;

    private java.lang.String[] wrappedTexts;

    private com.ptvag.xserver.xroute.BoundingRectangle totalRectangle;

    private java.lang.String binaryPathDesc;  // attribute

    private java.lang.String extSegments;  // attribute

    public Route() {
    }

    public Route(
           java.lang.String binaryPathDesc,
           java.lang.String extSegments,
           com.ptvag.xserver.xroute.BoundingRectangle[] wrappedBoundingRectangles,
           com.ptvag.xserver.xroute.DynamicInfo dynamicInfo,
           com.ptvag.xserver.xroute.RouteInfo info,
           com.ptvag.xserver.xroute.ManoeuvreGroup[] wrappedManoeuvreGroup,
           com.ptvag.xserver.xroute.RouteManoeuvre[] wrappedManoeuvres,
           com.ptvag.xserver.xroute.UniqueGeoID[] wrappedNodes,
           com.ptvag.xserver.common.LineString polygon,
           com.ptvag.xserver.xroute.RouteListSegment[] wrappedSegments,
           com.ptvag.xserver.xroute.WayPoint[] wrappedStations,
           java.lang.String[] wrappedTexts,
           com.ptvag.xserver.xroute.BoundingRectangle totalRectangle) {
        this.binaryPathDesc = binaryPathDesc;
        this.extSegments = extSegments;
        this.wrappedBoundingRectangles = wrappedBoundingRectangles;
        this.dynamicInfo = dynamicInfo;
        this.info = info;
        this.wrappedManoeuvreGroup = wrappedManoeuvreGroup;
        this.wrappedManoeuvres = wrappedManoeuvres;
        this.wrappedNodes = wrappedNodes;
        this.polygon = polygon;
        this.wrappedSegments = wrappedSegments;
        this.wrappedStations = wrappedStations;
        this.wrappedTexts = wrappedTexts;
        this.totalRectangle = totalRectangle;
    }


    /**
     * Gets the wrappedBoundingRectangles value for this Route.
     * 
     * @return wrappedBoundingRectangles
     */
    public com.ptvag.xserver.xroute.BoundingRectangle[] getWrappedBoundingRectangles() {
        return wrappedBoundingRectangles;
    }


    /**
     * Sets the wrappedBoundingRectangles value for this Route.
     * 
     * @param wrappedBoundingRectangles
     */
    public void setWrappedBoundingRectangles(com.ptvag.xserver.xroute.BoundingRectangle[] wrappedBoundingRectangles) {
        this.wrappedBoundingRectangles = wrappedBoundingRectangles;
    }


    /**
     * Gets the dynamicInfo value for this Route.
     * 
     * @return dynamicInfo
     */
    public com.ptvag.xserver.xroute.DynamicInfo getDynamicInfo() {
        return dynamicInfo;
    }


    /**
     * Sets the dynamicInfo value for this Route.
     * 
     * @param dynamicInfo
     */
    public void setDynamicInfo(com.ptvag.xserver.xroute.DynamicInfo dynamicInfo) {
        this.dynamicInfo = dynamicInfo;
    }


    /**
     * Gets the info value for this Route.
     * 
     * @return info
     */
    public com.ptvag.xserver.xroute.RouteInfo getInfo() {
        return info;
    }


    /**
     * Sets the info value for this Route.
     * 
     * @param info
     */
    public void setInfo(com.ptvag.xserver.xroute.RouteInfo info) {
        this.info = info;
    }


    /**
     * Gets the wrappedManoeuvreGroup value for this Route.
     * 
     * @return wrappedManoeuvreGroup
     */
    public com.ptvag.xserver.xroute.ManoeuvreGroup[] getWrappedManoeuvreGroup() {
        return wrappedManoeuvreGroup;
    }


    /**
     * Sets the wrappedManoeuvreGroup value for this Route.
     * 
     * @param wrappedManoeuvreGroup
     */
    public void setWrappedManoeuvreGroup(com.ptvag.xserver.xroute.ManoeuvreGroup[] wrappedManoeuvreGroup) {
        this.wrappedManoeuvreGroup = wrappedManoeuvreGroup;
    }


    /**
     * Gets the wrappedManoeuvres value for this Route.
     * 
     * @return wrappedManoeuvres
     */
    public com.ptvag.xserver.xroute.RouteManoeuvre[] getWrappedManoeuvres() {
        return wrappedManoeuvres;
    }


    /**
     * Sets the wrappedManoeuvres value for this Route.
     * 
     * @param wrappedManoeuvres
     */
    public void setWrappedManoeuvres(com.ptvag.xserver.xroute.RouteManoeuvre[] wrappedManoeuvres) {
        this.wrappedManoeuvres = wrappedManoeuvres;
    }


    /**
     * Gets the wrappedNodes value for this Route.
     * 
     * @return wrappedNodes
     */
    public com.ptvag.xserver.xroute.UniqueGeoID[] getWrappedNodes() {
        return wrappedNodes;
    }


    /**
     * Sets the wrappedNodes value for this Route.
     * 
     * @param wrappedNodes
     */
    public void setWrappedNodes(com.ptvag.xserver.xroute.UniqueGeoID[] wrappedNodes) {
        this.wrappedNodes = wrappedNodes;
    }


    /**
     * Gets the polygon value for this Route.
     * 
     * @return polygon
     */
    public com.ptvag.xserver.common.LineString getPolygon() {
        return polygon;
    }


    /**
     * Sets the polygon value for this Route.
     * 
     * @param polygon
     */
    public void setPolygon(com.ptvag.xserver.common.LineString polygon) {
        this.polygon = polygon;
    }


    /**
     * Gets the wrappedSegments value for this Route.
     * 
     * @return wrappedSegments
     */
    public com.ptvag.xserver.xroute.RouteListSegment[] getWrappedSegments() {
        return wrappedSegments;
    }


    /**
     * Sets the wrappedSegments value for this Route.
     * 
     * @param wrappedSegments
     */
    public void setWrappedSegments(com.ptvag.xserver.xroute.RouteListSegment[] wrappedSegments) {
        this.wrappedSegments = wrappedSegments;
    }


    /**
     * Gets the wrappedStations value for this Route.
     * 
     * @return wrappedStations
     */
    public com.ptvag.xserver.xroute.WayPoint[] getWrappedStations() {
        return wrappedStations;
    }


    /**
     * Sets the wrappedStations value for this Route.
     * 
     * @param wrappedStations
     */
    public void setWrappedStations(com.ptvag.xserver.xroute.WayPoint[] wrappedStations) {
        this.wrappedStations = wrappedStations;
    }


    /**
     * Gets the wrappedTexts value for this Route.
     * 
     * @return wrappedTexts
     */
    public java.lang.String[] getWrappedTexts() {
        return wrappedTexts;
    }


    /**
     * Sets the wrappedTexts value for this Route.
     * 
     * @param wrappedTexts
     */
    public void setWrappedTexts(java.lang.String[] wrappedTexts) {
        this.wrappedTexts = wrappedTexts;
    }


    /**
     * Gets the totalRectangle value for this Route.
     * 
     * @return totalRectangle
     */
    public com.ptvag.xserver.xroute.BoundingRectangle getTotalRectangle() {
        return totalRectangle;
    }


    /**
     * Sets the totalRectangle value for this Route.
     * 
     * @param totalRectangle
     */
    public void setTotalRectangle(com.ptvag.xserver.xroute.BoundingRectangle totalRectangle) {
        this.totalRectangle = totalRectangle;
    }


    /**
     * Gets the binaryPathDesc value for this Route.
     * 
     * @return binaryPathDesc
     */
    public java.lang.String getBinaryPathDesc() {
        return binaryPathDesc;
    }


    /**
     * Sets the binaryPathDesc value for this Route.
     * 
     * @param binaryPathDesc
     */
    public void setBinaryPathDesc(java.lang.String binaryPathDesc) {
        this.binaryPathDesc = binaryPathDesc;
    }


    /**
     * Gets the extSegments value for this Route.
     * 
     * @return extSegments
     */
    public java.lang.String getExtSegments() {
        return extSegments;
    }


    /**
     * Sets the extSegments value for this Route.
     * 
     * @param extSegments
     */
    public void setExtSegments(java.lang.String extSegments) {
        this.extSegments = extSegments;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Route)) return false;
        Route other = (Route) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedBoundingRectangles==null && other.getWrappedBoundingRectangles()==null) || 
             (this.wrappedBoundingRectangles!=null &&
              java.util.Arrays.equals(this.wrappedBoundingRectangles, other.getWrappedBoundingRectangles()))) &&
            ((this.dynamicInfo==null && other.getDynamicInfo()==null) || 
             (this.dynamicInfo!=null &&
              this.dynamicInfo.equals(other.getDynamicInfo()))) &&
            ((this.info==null && other.getInfo()==null) || 
             (this.info!=null &&
              this.info.equals(other.getInfo()))) &&
            ((this.wrappedManoeuvreGroup==null && other.getWrappedManoeuvreGroup()==null) || 
             (this.wrappedManoeuvreGroup!=null &&
              java.util.Arrays.equals(this.wrappedManoeuvreGroup, other.getWrappedManoeuvreGroup()))) &&
            ((this.wrappedManoeuvres==null && other.getWrappedManoeuvres()==null) || 
             (this.wrappedManoeuvres!=null &&
              java.util.Arrays.equals(this.wrappedManoeuvres, other.getWrappedManoeuvres()))) &&
            ((this.wrappedNodes==null && other.getWrappedNodes()==null) || 
             (this.wrappedNodes!=null &&
              java.util.Arrays.equals(this.wrappedNodes, other.getWrappedNodes()))) &&
            ((this.polygon==null && other.getPolygon()==null) || 
             (this.polygon!=null &&
              this.polygon.equals(other.getPolygon()))) &&
            ((this.wrappedSegments==null && other.getWrappedSegments()==null) || 
             (this.wrappedSegments!=null &&
              java.util.Arrays.equals(this.wrappedSegments, other.getWrappedSegments()))) &&
            ((this.wrappedStations==null && other.getWrappedStations()==null) || 
             (this.wrappedStations!=null &&
              java.util.Arrays.equals(this.wrappedStations, other.getWrappedStations()))) &&
            ((this.wrappedTexts==null && other.getWrappedTexts()==null) || 
             (this.wrappedTexts!=null &&
              java.util.Arrays.equals(this.wrappedTexts, other.getWrappedTexts()))) &&
            ((this.totalRectangle==null && other.getTotalRectangle()==null) || 
             (this.totalRectangle!=null &&
              this.totalRectangle.equals(other.getTotalRectangle()))) &&
            ((this.binaryPathDesc==null && other.getBinaryPathDesc()==null) || 
             (this.binaryPathDesc!=null &&
              this.binaryPathDesc.equals(other.getBinaryPathDesc()))) &&
            ((this.extSegments==null && other.getExtSegments()==null) || 
             (this.extSegments!=null &&
              this.extSegments.equals(other.getExtSegments())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedBoundingRectangles() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedBoundingRectangles());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedBoundingRectangles(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDynamicInfo() != null) {
            _hashCode += getDynamicInfo().hashCode();
        }
        if (getInfo() != null) {
            _hashCode += getInfo().hashCode();
        }
        if (getWrappedManoeuvreGroup() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedManoeuvreGroup());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedManoeuvreGroup(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedManoeuvres() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedManoeuvres());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedManoeuvres(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedNodes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedNodes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedNodes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPolygon() != null) {
            _hashCode += getPolygon().hashCode();
        }
        if (getWrappedSegments() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedSegments());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedSegments(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedStations() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedStations());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedStations(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedTexts() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedTexts());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedTexts(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTotalRectangle() != null) {
            _hashCode += getTotalRectangle().hashCode();
        }
        if (getBinaryPathDesc() != null) {
            _hashCode += getBinaryPathDesc().hashCode();
        }
        if (getExtSegments() != null) {
            _hashCode += getExtSegments().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Route.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Route"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("binaryPathDesc");
        attrField.setXmlName(new javax.xml.namespace.QName("", "binaryPathDesc"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("extSegments");
        attrField.setXmlName(new javax.xml.namespace.QName("", "extSegments"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedBoundingRectangles");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedBoundingRectangles"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "BoundingRectangle"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "BoundingRectangle"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dynamicInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "dynamicInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "DynamicInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("info");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "info"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedManoeuvreGroup");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedManoeuvreGroup"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreGroup"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreGroup"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedManoeuvres");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedManoeuvres"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteManoeuvre"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteManoeuvre"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedNodes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedNodes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("polygon");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "polygon"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "LineString"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedSegments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedSegments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteListSegment"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteListSegment"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedStations");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedStations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WayPoint"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WayPoint"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedTexts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedTexts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "String"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalRectangle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "totalRectangle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "BoundingRectangle"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
