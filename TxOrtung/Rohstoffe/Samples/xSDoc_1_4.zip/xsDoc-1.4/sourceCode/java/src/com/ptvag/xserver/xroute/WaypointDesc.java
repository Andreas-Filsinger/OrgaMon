/**
 * WaypointDesc.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class WaypointDesc  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.common.Point[] wrappedCoords;

    private com.ptvag.xserver.xroute.UniqueGeoID nodeID;

    private com.ptvag.xserver.xroute.UniqueGeoID[] wrappedSegmentID;

    private int fuzzyRadius;  // attribute

    private java.lang.Integer heading;  // attribute

    private com.ptvag.xserver.xroute.LinkType linkType;  // attribute

    private java.lang.String street;  // attribute

    public WaypointDesc() {
    }

    public WaypointDesc(
           int fuzzyRadius,
           java.lang.Integer heading,
           com.ptvag.xserver.xroute.LinkType linkType,
           java.lang.String street,
           com.ptvag.xserver.common.Point[] wrappedCoords,
           com.ptvag.xserver.xroute.UniqueGeoID nodeID,
           com.ptvag.xserver.xroute.UniqueGeoID[] wrappedSegmentID) {
        this.fuzzyRadius = fuzzyRadius;
        this.heading = heading;
        this.linkType = linkType;
        this.street = street;
        this.wrappedCoords = wrappedCoords;
        this.nodeID = nodeID;
        this.wrappedSegmentID = wrappedSegmentID;
    }


    /**
     * Gets the wrappedCoords value for this WaypointDesc.
     * 
     * @return wrappedCoords
     */
    public com.ptvag.xserver.common.Point[] getWrappedCoords() {
        return wrappedCoords;
    }


    /**
     * Sets the wrappedCoords value for this WaypointDesc.
     * 
     * @param wrappedCoords
     */
    public void setWrappedCoords(com.ptvag.xserver.common.Point[] wrappedCoords) {
        this.wrappedCoords = wrappedCoords;
    }


    /**
     * Gets the nodeID value for this WaypointDesc.
     * 
     * @return nodeID
     */
    public com.ptvag.xserver.xroute.UniqueGeoID getNodeID() {
        return nodeID;
    }


    /**
     * Sets the nodeID value for this WaypointDesc.
     * 
     * @param nodeID
     */
    public void setNodeID(com.ptvag.xserver.xroute.UniqueGeoID nodeID) {
        this.nodeID = nodeID;
    }


    /**
     * Gets the wrappedSegmentID value for this WaypointDesc.
     * 
     * @return wrappedSegmentID
     */
    public com.ptvag.xserver.xroute.UniqueGeoID[] getWrappedSegmentID() {
        return wrappedSegmentID;
    }


    /**
     * Sets the wrappedSegmentID value for this WaypointDesc.
     * 
     * @param wrappedSegmentID
     */
    public void setWrappedSegmentID(com.ptvag.xserver.xroute.UniqueGeoID[] wrappedSegmentID) {
        this.wrappedSegmentID = wrappedSegmentID;
    }


    /**
     * Gets the fuzzyRadius value for this WaypointDesc.
     * 
     * @return fuzzyRadius
     */
    public int getFuzzyRadius() {
        return fuzzyRadius;
    }


    /**
     * Sets the fuzzyRadius value for this WaypointDesc.
     * 
     * @param fuzzyRadius
     */
    public void setFuzzyRadius(int fuzzyRadius) {
        this.fuzzyRadius = fuzzyRadius;
    }


    /**
     * Gets the heading value for this WaypointDesc.
     * 
     * @return heading
     */
    public java.lang.Integer getHeading() {
        return heading;
    }


    /**
     * Sets the heading value for this WaypointDesc.
     * 
     * @param heading
     */
    public void setHeading(java.lang.Integer heading) {
        this.heading = heading;
    }


    /**
     * Gets the linkType value for this WaypointDesc.
     * 
     * @return linkType
     */
    public com.ptvag.xserver.xroute.LinkType getLinkType() {
        return linkType;
    }


    /**
     * Sets the linkType value for this WaypointDesc.
     * 
     * @param linkType
     */
    public void setLinkType(com.ptvag.xserver.xroute.LinkType linkType) {
        this.linkType = linkType;
    }


    /**
     * Gets the street value for this WaypointDesc.
     * 
     * @return street
     */
    public java.lang.String getStreet() {
        return street;
    }


    /**
     * Sets the street value for this WaypointDesc.
     * 
     * @param street
     */
    public void setStreet(java.lang.String street) {
        this.street = street;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof WaypointDesc)) return false;
        WaypointDesc other = (WaypointDesc) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedCoords==null && other.getWrappedCoords()==null) || 
             (this.wrappedCoords!=null &&
              java.util.Arrays.equals(this.wrappedCoords, other.getWrappedCoords()))) &&
            ((this.nodeID==null && other.getNodeID()==null) || 
             (this.nodeID!=null &&
              this.nodeID.equals(other.getNodeID()))) &&
            ((this.wrappedSegmentID==null && other.getWrappedSegmentID()==null) || 
             (this.wrappedSegmentID!=null &&
              java.util.Arrays.equals(this.wrappedSegmentID, other.getWrappedSegmentID()))) &&
            this.fuzzyRadius == other.getFuzzyRadius() &&
            ((this.heading==null && other.getHeading()==null) || 
             (this.heading!=null &&
              this.heading.equals(other.getHeading()))) &&
            ((this.linkType==null && other.getLinkType()==null) || 
             (this.linkType!=null &&
              this.linkType.equals(other.getLinkType()))) &&
            ((this.street==null && other.getStreet()==null) || 
             (this.street!=null &&
              this.street.equals(other.getStreet())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedCoords() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedCoords());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedCoords(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNodeID() != null) {
            _hashCode += getNodeID().hashCode();
        }
        if (getWrappedSegmentID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedSegmentID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedSegmentID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getFuzzyRadius();
        if (getHeading() != null) {
            _hashCode += getHeading().hashCode();
        }
        if (getLinkType() != null) {
            _hashCode += getLinkType().hashCode();
        }
        if (getStreet() != null) {
            _hashCode += getStreet().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WaypointDesc.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("fuzzyRadius");
        attrField.setXmlName(new javax.xml.namespace.QName("", "fuzzyRadius"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("heading");
        attrField.setXmlName(new javax.xml.namespace.QName("", "heading"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("linkType");
        attrField.setXmlName(new javax.xml.namespace.QName("", "linkType"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "LinkType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("street");
        attrField.setXmlName(new javax.xml.namespace.QName("", "street"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedCoords");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedCoords"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nodeID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "nodeID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedSegmentID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedSegmentID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
