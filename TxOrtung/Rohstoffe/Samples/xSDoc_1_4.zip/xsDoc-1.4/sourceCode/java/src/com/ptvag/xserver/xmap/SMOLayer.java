/**
 * SMOLayer.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class SMOLayer  extends com.ptvag.xserver.xmap.Layer  implements java.io.Serializable {
    private java.lang.String configuration;  // attribute

    private com.ptvag.xserver.xmap.ObjectInfoType objectInfos;  // attribute

    private byte[] smoData;  // attribute

    public SMOLayer() {
    }

    public SMOLayer(
           java.lang.String name,
           boolean visible,
           java.lang.String configuration,
           com.ptvag.xserver.xmap.ObjectInfoType objectInfos,
           byte[] smoData) {
        super(
            name,
            visible);
        this.configuration = configuration;
        this.objectInfos = objectInfos;
        this.smoData = smoData;
    }


    /**
     * Gets the configuration value for this SMOLayer.
     * 
     * @return configuration
     */
    public java.lang.String getConfiguration() {
        return configuration;
    }


    /**
     * Sets the configuration value for this SMOLayer.
     * 
     * @param configuration
     */
    public void setConfiguration(java.lang.String configuration) {
        this.configuration = configuration;
    }


    /**
     * Gets the objectInfos value for this SMOLayer.
     * 
     * @return objectInfos
     */
    public com.ptvag.xserver.xmap.ObjectInfoType getObjectInfos() {
        return objectInfos;
    }


    /**
     * Sets the objectInfos value for this SMOLayer.
     * 
     * @param objectInfos
     */
    public void setObjectInfos(com.ptvag.xserver.xmap.ObjectInfoType objectInfos) {
        this.objectInfos = objectInfos;
    }


    /**
     * Gets the smoData value for this SMOLayer.
     * 
     * @return smoData
     */
    public byte[] getSmoData() {
        return smoData;
    }


    /**
     * Sets the smoData value for this SMOLayer.
     * 
     * @param smoData
     */
    public void setSmoData(byte[] smoData) {
        this.smoData = smoData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SMOLayer)) return false;
        SMOLayer other = (SMOLayer) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.configuration==null && other.getConfiguration()==null) || 
             (this.configuration!=null &&
              this.configuration.equals(other.getConfiguration()))) &&
            ((this.objectInfos==null && other.getObjectInfos()==null) || 
             (this.objectInfos!=null &&
              this.objectInfos.equals(other.getObjectInfos()))) &&
            ((this.smoData==null && other.getSmoData()==null) || 
             (this.smoData!=null &&
              java.util.Arrays.equals(this.smoData, other.getSmoData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getConfiguration() != null) {
            _hashCode += getConfiguration().hashCode();
        }
        if (getObjectInfos() != null) {
            _hashCode += getObjectInfos().hashCode();
        }
        if (getSmoData() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSmoData());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSmoData(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SMOLayer.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "SMOLayer"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("configuration");
        attrField.setXmlName(new javax.xml.namespace.QName("", "configuration"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("objectInfos");
        attrField.setXmlName(new javax.xml.namespace.QName("", "objectInfos"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "ObjectInfoType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("smoData");
        attrField.setXmlName(new javax.xml.namespace.QName("", "smoData"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
