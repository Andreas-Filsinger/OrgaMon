/**
 * Geometry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class Geometry  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.common.EncodedGeometry geometry;

    private com.ptvag.xserver.common.Point referencePoint;

    private java.lang.String description;  // attribute

    private int id;  // attribute

    public Geometry() {
    }

    public Geometry(
           java.lang.String description,
           int id,
           com.ptvag.xserver.common.EncodedGeometry geometry,
           com.ptvag.xserver.common.Point referencePoint) {
        this.description = description;
        this.id = id;
        this.geometry = geometry;
        this.referencePoint = referencePoint;
    }


    /**
     * Gets the geometry value for this Geometry.
     * 
     * @return geometry
     */
    public com.ptvag.xserver.common.EncodedGeometry getGeometry() {
        return geometry;
    }


    /**
     * Sets the geometry value for this Geometry.
     * 
     * @param geometry
     */
    public void setGeometry(com.ptvag.xserver.common.EncodedGeometry geometry) {
        this.geometry = geometry;
    }


    /**
     * Gets the referencePoint value for this Geometry.
     * 
     * @return referencePoint
     */
    public com.ptvag.xserver.common.Point getReferencePoint() {
        return referencePoint;
    }


    /**
     * Sets the referencePoint value for this Geometry.
     * 
     * @param referencePoint
     */
    public void setReferencePoint(com.ptvag.xserver.common.Point referencePoint) {
        this.referencePoint = referencePoint;
    }


    /**
     * Gets the description value for this Geometry.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this Geometry.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the id value for this Geometry.
     * 
     * @return id
     */
    public int getId() {
        return id;
    }


    /**
     * Sets the id value for this Geometry.
     * 
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Geometry)) return false;
        Geometry other = (Geometry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.geometry==null && other.getGeometry()==null) || 
             (this.geometry!=null &&
              this.geometry.equals(other.getGeometry()))) &&
            ((this.referencePoint==null && other.getReferencePoint()==null) || 
             (this.referencePoint!=null &&
              this.referencePoint.equals(other.getReferencePoint()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            this.id == other.getId();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getGeometry() != null) {
            _hashCode += getGeometry().hashCode();
        }
        if (getReferencePoint() != null) {
            _hashCode += getReferencePoint().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        _hashCode += getId();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Geometry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Geometry"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("description");
        attrField.setXmlName(new javax.xml.namespace.QName("", "description"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("id");
        attrField.setXmlName(new javax.xml.namespace.QName("", "id"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("geometry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "geometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "EncodedGeometry"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referencePoint");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "referencePoint"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
