/**
 * POIViewMapSet.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class POIViewMapSet  extends com.ptvag.mnp.common.POIViewSet  implements java.io.Serializable {
    private com.ptvag.mnp.common.Icon defaultSymbol;

    private java.lang.String profile;

    public POIViewMapSet() {
    }

    public POIViewMapSet(
           com.ptvag.mnp.common.POIAttribute[] wrappedAttributes,
           com.ptvag.mnp.common.POIFilter filter,
           java.lang.Long maxResults,
           java.lang.String poiSource,
           java.lang.String poiType,
           com.ptvag.mnp.common.POIView[] wrappedPoiViews,
           java.lang.Boolean processed,
           com.ptvag.mnp.common.Icon defaultSymbol,
           java.lang.String profile) {
        super(
            wrappedAttributes,
            filter,
            maxResults,
            poiSource,
            poiType,
            wrappedPoiViews,
            processed);
        this.defaultSymbol = defaultSymbol;
        this.profile = profile;
    }


    /**
     * Gets the defaultSymbol value for this POIViewMapSet.
     * 
     * @return defaultSymbol
     */
    public com.ptvag.mnp.common.Icon getDefaultSymbol() {
        return defaultSymbol;
    }


    /**
     * Sets the defaultSymbol value for this POIViewMapSet.
     * 
     * @param defaultSymbol
     */
    public void setDefaultSymbol(com.ptvag.mnp.common.Icon defaultSymbol) {
        this.defaultSymbol = defaultSymbol;
    }


    /**
     * Gets the profile value for this POIViewMapSet.
     * 
     * @return profile
     */
    public java.lang.String getProfile() {
        return profile;
    }


    /**
     * Sets the profile value for this POIViewMapSet.
     * 
     * @param profile
     */
    public void setProfile(java.lang.String profile) {
        this.profile = profile;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof POIViewMapSet)) return false;
        POIViewMapSet other = (POIViewMapSet) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.defaultSymbol==null && other.getDefaultSymbol()==null) || 
             (this.defaultSymbol!=null &&
              this.defaultSymbol.equals(other.getDefaultSymbol()))) &&
            ((this.profile==null && other.getProfile()==null) || 
             (this.profile!=null &&
              this.profile.equals(other.getProfile())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDefaultSymbol() != null) {
            _hashCode += getDefaultSymbol().hashCode();
        }
        if (getProfile() != null) {
            _hashCode += getProfile().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(POIViewMapSet.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIViewMapSet"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defaultSymbol");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "defaultSymbol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Icon"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("profile");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "profile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
