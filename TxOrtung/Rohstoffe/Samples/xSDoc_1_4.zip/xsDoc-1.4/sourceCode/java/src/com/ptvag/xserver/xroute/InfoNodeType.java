/**
 * InfoNodeType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class InfoNodeType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected InfoNodeType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _NORMAL = "NORMAL";
    public static final java.lang.String _AE = "AE";
    public static final java.lang.String _AS = "AS";
    public static final java.lang.String _AD = "AD";
    public static final java.lang.String _AK = "AK";
    public static final java.lang.String _BORDER = "BORDER";
    public static final java.lang.String _BUILT_UP = "BUILT_UP";
    public static final java.lang.String _FERRY = "FERRY";
    public static final java.lang.String _TOLL_ROAD = "TOLL_ROAD";
    public static final java.lang.String _SIGN = "SIGN";
    public static final InfoNodeType NORMAL = new InfoNodeType(_NORMAL);
    public static final InfoNodeType AE = new InfoNodeType(_AE);
    public static final InfoNodeType AS = new InfoNodeType(_AS);
    public static final InfoNodeType AD = new InfoNodeType(_AD);
    public static final InfoNodeType AK = new InfoNodeType(_AK);
    public static final InfoNodeType BORDER = new InfoNodeType(_BORDER);
    public static final InfoNodeType BUILT_UP = new InfoNodeType(_BUILT_UP);
    public static final InfoNodeType FERRY = new InfoNodeType(_FERRY);
    public static final InfoNodeType TOLL_ROAD = new InfoNodeType(_TOLL_ROAD);
    public static final InfoNodeType SIGN = new InfoNodeType(_SIGN);
    public java.lang.String getValue() { return _value_;}
    public static InfoNodeType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        InfoNodeType enumeration = (InfoNodeType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static InfoNodeType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(InfoNodeType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "InfoNodeType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
