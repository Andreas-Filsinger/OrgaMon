/**
 * RequestOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.common;

public class RequestOptions  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.common.GeometryEncoding[] wrappedResponseGeometry;

    private com.ptvag.xserver.common.CoordFormat coordFormat;  // attribute

    private java.lang.String profile;  // attribute

    public RequestOptions() {
    }

    public RequestOptions(
           com.ptvag.xserver.common.CoordFormat coordFormat,
           java.lang.String profile,
           com.ptvag.xserver.common.GeometryEncoding[] wrappedResponseGeometry) {
        this.coordFormat = coordFormat;
        this.profile = profile;
        this.wrappedResponseGeometry = wrappedResponseGeometry;
    }


    /**
     * Gets the wrappedResponseGeometry value for this RequestOptions.
     * 
     * @return wrappedResponseGeometry
     */
    public com.ptvag.xserver.common.GeometryEncoding[] getWrappedResponseGeometry() {
        return wrappedResponseGeometry;
    }


    /**
     * Sets the wrappedResponseGeometry value for this RequestOptions.
     * 
     * @param wrappedResponseGeometry
     */
    public void setWrappedResponseGeometry(com.ptvag.xserver.common.GeometryEncoding[] wrappedResponseGeometry) {
        this.wrappedResponseGeometry = wrappedResponseGeometry;
    }


    /**
     * Gets the coordFormat value for this RequestOptions.
     * 
     * @return coordFormat
     */
    public com.ptvag.xserver.common.CoordFormat getCoordFormat() {
        return coordFormat;
    }


    /**
     * Sets the coordFormat value for this RequestOptions.
     * 
     * @param coordFormat
     */
    public void setCoordFormat(com.ptvag.xserver.common.CoordFormat coordFormat) {
        this.coordFormat = coordFormat;
    }


    /**
     * Gets the profile value for this RequestOptions.
     * 
     * @return profile
     */
    public java.lang.String getProfile() {
        return profile;
    }


    /**
     * Sets the profile value for this RequestOptions.
     * 
     * @param profile
     */
    public void setProfile(java.lang.String profile) {
        this.profile = profile;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RequestOptions)) return false;
        RequestOptions other = (RequestOptions) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedResponseGeometry==null && other.getWrappedResponseGeometry()==null) || 
             (this.wrappedResponseGeometry!=null &&
              java.util.Arrays.equals(this.wrappedResponseGeometry, other.getWrappedResponseGeometry()))) &&
            ((this.coordFormat==null && other.getCoordFormat()==null) || 
             (this.coordFormat!=null &&
              this.coordFormat.equals(other.getCoordFormat()))) &&
            ((this.profile==null && other.getProfile()==null) || 
             (this.profile!=null &&
              this.profile.equals(other.getProfile())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedResponseGeometry() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedResponseGeometry());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedResponseGeometry(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCoordFormat() != null) {
            _hashCode += getCoordFormat().hashCode();
        }
        if (getProfile() != null) {
            _hashCode += getProfile().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RequestOptions.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "RequestOptions"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("coordFormat");
        attrField.setXmlName(new javax.xml.namespace.QName("", "coordFormat"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "CoordFormat"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("profile");
        attrField.setXmlName(new javax.xml.namespace.QName("", "profile"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedResponseGeometry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "wrappedResponseGeometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryEncoding"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryEncoding"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
