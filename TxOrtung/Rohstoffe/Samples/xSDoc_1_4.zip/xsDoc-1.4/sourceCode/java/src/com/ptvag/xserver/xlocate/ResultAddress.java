/**
 * ResultAddress.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xlocate;

public class ResultAddress  extends com.ptvag.xserver.xlocate.Address  implements java.io.Serializable {
    private com.ptvag.xserver.xlocate.AdditionalField[] wrappedAdditionalFields;

    private com.ptvag.xserver.common.Point coordinates;

    private java.lang.String adminRegion;  // attribute

    private java.lang.String appendix;  // attribute

    private com.ptvag.xserver.xlocate.ClassificationDescription classificationDescription;  // attribute

    private java.lang.String countryCapital;  // attribute

    private com.ptvag.xserver.xlocate.DetailLevelDescription detailLevelDescription;  // attribute

    private int totalScore;  // attribute

    public ResultAddress() {
    }

    public ResultAddress(
           java.lang.String city,
           java.lang.String city2,
           java.lang.String country,
           java.lang.String houseNumber,
           java.lang.String postCode,
           java.lang.String state,
           java.lang.String street,
           java.lang.String adminRegion,
           java.lang.String appendix,
           com.ptvag.xserver.xlocate.ClassificationDescription classificationDescription,
           java.lang.String countryCapital,
           com.ptvag.xserver.xlocate.DetailLevelDescription detailLevelDescription,
           int totalScore,
           com.ptvag.xserver.xlocate.AdditionalField[] wrappedAdditionalFields,
           com.ptvag.xserver.common.Point coordinates) {
        super(
            city,
            city2,
            country,
            houseNumber,
            postCode,
            state,
            street);
        this.adminRegion = adminRegion;
        this.appendix = appendix;
        this.classificationDescription = classificationDescription;
        this.countryCapital = countryCapital;
        this.detailLevelDescription = detailLevelDescription;
        this.totalScore = totalScore;
        this.wrappedAdditionalFields = wrappedAdditionalFields;
        this.coordinates = coordinates;
    }


    /**
     * Gets the wrappedAdditionalFields value for this ResultAddress.
     * 
     * @return wrappedAdditionalFields
     */
    public com.ptvag.xserver.xlocate.AdditionalField[] getWrappedAdditionalFields() {
        return wrappedAdditionalFields;
    }


    /**
     * Sets the wrappedAdditionalFields value for this ResultAddress.
     * 
     * @param wrappedAdditionalFields
     */
    public void setWrappedAdditionalFields(com.ptvag.xserver.xlocate.AdditionalField[] wrappedAdditionalFields) {
        this.wrappedAdditionalFields = wrappedAdditionalFields;
    }


    /**
     * Gets the coordinates value for this ResultAddress.
     * 
     * @return coordinates
     */
    public com.ptvag.xserver.common.Point getCoordinates() {
        return coordinates;
    }


    /**
     * Sets the coordinates value for this ResultAddress.
     * 
     * @param coordinates
     */
    public void setCoordinates(com.ptvag.xserver.common.Point coordinates) {
        this.coordinates = coordinates;
    }


    /**
     * Gets the adminRegion value for this ResultAddress.
     * 
     * @return adminRegion
     */
    public java.lang.String getAdminRegion() {
        return adminRegion;
    }


    /**
     * Sets the adminRegion value for this ResultAddress.
     * 
     * @param adminRegion
     */
    public void setAdminRegion(java.lang.String adminRegion) {
        this.adminRegion = adminRegion;
    }


    /**
     * Gets the appendix value for this ResultAddress.
     * 
     * @return appendix
     */
    public java.lang.String getAppendix() {
        return appendix;
    }


    /**
     * Sets the appendix value for this ResultAddress.
     * 
     * @param appendix
     */
    public void setAppendix(java.lang.String appendix) {
        this.appendix = appendix;
    }


    /**
     * Gets the classificationDescription value for this ResultAddress.
     * 
     * @return classificationDescription
     */
    public com.ptvag.xserver.xlocate.ClassificationDescription getClassificationDescription() {
        return classificationDescription;
    }


    /**
     * Sets the classificationDescription value for this ResultAddress.
     * 
     * @param classificationDescription
     */
    public void setClassificationDescription(com.ptvag.xserver.xlocate.ClassificationDescription classificationDescription) {
        this.classificationDescription = classificationDescription;
    }


    /**
     * Gets the countryCapital value for this ResultAddress.
     * 
     * @return countryCapital
     */
    public java.lang.String getCountryCapital() {
        return countryCapital;
    }


    /**
     * Sets the countryCapital value for this ResultAddress.
     * 
     * @param countryCapital
     */
    public void setCountryCapital(java.lang.String countryCapital) {
        this.countryCapital = countryCapital;
    }


    /**
     * Gets the detailLevelDescription value for this ResultAddress.
     * 
     * @return detailLevelDescription
     */
    public com.ptvag.xserver.xlocate.DetailLevelDescription getDetailLevelDescription() {
        return detailLevelDescription;
    }


    /**
     * Sets the detailLevelDescription value for this ResultAddress.
     * 
     * @param detailLevelDescription
     */
    public void setDetailLevelDescription(com.ptvag.xserver.xlocate.DetailLevelDescription detailLevelDescription) {
        this.detailLevelDescription = detailLevelDescription;
    }


    /**
     * Gets the totalScore value for this ResultAddress.
     * 
     * @return totalScore
     */
    public int getTotalScore() {
        return totalScore;
    }


    /**
     * Sets the totalScore value for this ResultAddress.
     * 
     * @param totalScore
     */
    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ResultAddress)) return false;
        ResultAddress other = (ResultAddress) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedAdditionalFields==null && other.getWrappedAdditionalFields()==null) || 
             (this.wrappedAdditionalFields!=null &&
              java.util.Arrays.equals(this.wrappedAdditionalFields, other.getWrappedAdditionalFields()))) &&
            ((this.coordinates==null && other.getCoordinates()==null) || 
             (this.coordinates!=null &&
              this.coordinates.equals(other.getCoordinates()))) &&
            ((this.adminRegion==null && other.getAdminRegion()==null) || 
             (this.adminRegion!=null &&
              this.adminRegion.equals(other.getAdminRegion()))) &&
            ((this.appendix==null && other.getAppendix()==null) || 
             (this.appendix!=null &&
              this.appendix.equals(other.getAppendix()))) &&
            ((this.classificationDescription==null && other.getClassificationDescription()==null) || 
             (this.classificationDescription!=null &&
              this.classificationDescription.equals(other.getClassificationDescription()))) &&
            ((this.countryCapital==null && other.getCountryCapital()==null) || 
             (this.countryCapital!=null &&
              this.countryCapital.equals(other.getCountryCapital()))) &&
            ((this.detailLevelDescription==null && other.getDetailLevelDescription()==null) || 
             (this.detailLevelDescription!=null &&
              this.detailLevelDescription.equals(other.getDetailLevelDescription()))) &&
            this.totalScore == other.getTotalScore();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedAdditionalFields() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedAdditionalFields());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedAdditionalFields(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCoordinates() != null) {
            _hashCode += getCoordinates().hashCode();
        }
        if (getAdminRegion() != null) {
            _hashCode += getAdminRegion().hashCode();
        }
        if (getAppendix() != null) {
            _hashCode += getAppendix().hashCode();
        }
        if (getClassificationDescription() != null) {
            _hashCode += getClassificationDescription().hashCode();
        }
        if (getCountryCapital() != null) {
            _hashCode += getCountryCapital().hashCode();
        }
        if (getDetailLevelDescription() != null) {
            _hashCode += getDetailLevelDescription().hashCode();
        }
        _hashCode += getTotalScore();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ResultAddress.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ResultAddress"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("adminRegion");
        attrField.setXmlName(new javax.xml.namespace.QName("", "adminRegion"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("appendix");
        attrField.setXmlName(new javax.xml.namespace.QName("", "appendix"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("classificationDescription");
        attrField.setXmlName(new javax.xml.namespace.QName("", "classificationDescription"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "ClassificationDescription"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("countryCapital");
        attrField.setXmlName(new javax.xml.namespace.QName("", "countryCapital"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("detailLevelDescription");
        attrField.setXmlName(new javax.xml.namespace.QName("", "detailLevelDescription"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "DetailLevelDescription"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("totalScore");
        attrField.setXmlName(new javax.xml.namespace.QName("", "totalScore"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedAdditionalFields");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "wrappedAdditionalFields"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "AdditionalField"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "AdditionalField"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("coordinates");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "coordinates"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
