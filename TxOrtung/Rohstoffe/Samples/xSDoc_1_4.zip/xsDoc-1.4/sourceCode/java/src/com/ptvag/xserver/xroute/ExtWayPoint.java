/**
 * ExtWayPoint.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class ExtWayPoint  extends com.ptvag.xserver.xroute.WayPoint  implements java.io.Serializable {
    private int exitAngle;  // attribute

    private int exitAngleNorth;  // attribute

    private int linkingDistance;  // attribute

    private int linkingRouteListSegmentIdx;  // attribute

    private int linkingTime;  // attribute

    private java.lang.String manoeuvreDesc;  // attribute

    private com.ptvag.xserver.xroute.ManoeuvreType manoeuvreType;  // attribute

    private com.ptvag.xserver.xroute.TurnOrient turnOrient;  // attribute

    private com.ptvag.xserver.xroute.TurnWeight turnWeight;  // attribute

    public ExtWayPoint() {
    }

    public ExtWayPoint(
           int accDist,
           int accTime,
           java.lang.String countryCode,
           int iuCode,
           int manoeuvreIdx,
           int nodeIdx,
           int polyIdx,
           int segmentIdx,
           com.ptvag.xserver.xroute.WayPointType wayPointType,
           com.ptvag.xserver.common.Point locationCoord,
           com.ptvag.xserver.common.Point matchCoord,
           int exitAngle,
           int exitAngleNorth,
           int linkingDistance,
           int linkingRouteListSegmentIdx,
           int linkingTime,
           java.lang.String manoeuvreDesc,
           com.ptvag.xserver.xroute.ManoeuvreType manoeuvreType,
           com.ptvag.xserver.xroute.TurnOrient turnOrient,
           com.ptvag.xserver.xroute.TurnWeight turnWeight) {
        super(
            accDist,
            accTime,
            countryCode,
            iuCode,
            manoeuvreIdx,
            nodeIdx,
            polyIdx,
            segmentIdx,
            wayPointType,
            locationCoord,
            matchCoord);
        this.exitAngle = exitAngle;
        this.exitAngleNorth = exitAngleNorth;
        this.linkingDistance = linkingDistance;
        this.linkingRouteListSegmentIdx = linkingRouteListSegmentIdx;
        this.linkingTime = linkingTime;
        this.manoeuvreDesc = manoeuvreDesc;
        this.manoeuvreType = manoeuvreType;
        this.turnOrient = turnOrient;
        this.turnWeight = turnWeight;
    }


    /**
     * Gets the exitAngle value for this ExtWayPoint.
     * 
     * @return exitAngle
     */
    public int getExitAngle() {
        return exitAngle;
    }


    /**
     * Sets the exitAngle value for this ExtWayPoint.
     * 
     * @param exitAngle
     */
    public void setExitAngle(int exitAngle) {
        this.exitAngle = exitAngle;
    }


    /**
     * Gets the exitAngleNorth value for this ExtWayPoint.
     * 
     * @return exitAngleNorth
     */
    public int getExitAngleNorth() {
        return exitAngleNorth;
    }


    /**
     * Sets the exitAngleNorth value for this ExtWayPoint.
     * 
     * @param exitAngleNorth
     */
    public void setExitAngleNorth(int exitAngleNorth) {
        this.exitAngleNorth = exitAngleNorth;
    }


    /**
     * Gets the linkingDistance value for this ExtWayPoint.
     * 
     * @return linkingDistance
     */
    public int getLinkingDistance() {
        return linkingDistance;
    }


    /**
     * Sets the linkingDistance value for this ExtWayPoint.
     * 
     * @param linkingDistance
     */
    public void setLinkingDistance(int linkingDistance) {
        this.linkingDistance = linkingDistance;
    }


    /**
     * Gets the linkingRouteListSegmentIdx value for this ExtWayPoint.
     * 
     * @return linkingRouteListSegmentIdx
     */
    public int getLinkingRouteListSegmentIdx() {
        return linkingRouteListSegmentIdx;
    }


    /**
     * Sets the linkingRouteListSegmentIdx value for this ExtWayPoint.
     * 
     * @param linkingRouteListSegmentIdx
     */
    public void setLinkingRouteListSegmentIdx(int linkingRouteListSegmentIdx) {
        this.linkingRouteListSegmentIdx = linkingRouteListSegmentIdx;
    }


    /**
     * Gets the linkingTime value for this ExtWayPoint.
     * 
     * @return linkingTime
     */
    public int getLinkingTime() {
        return linkingTime;
    }


    /**
     * Sets the linkingTime value for this ExtWayPoint.
     * 
     * @param linkingTime
     */
    public void setLinkingTime(int linkingTime) {
        this.linkingTime = linkingTime;
    }


    /**
     * Gets the manoeuvreDesc value for this ExtWayPoint.
     * 
     * @return manoeuvreDesc
     */
    public java.lang.String getManoeuvreDesc() {
        return manoeuvreDesc;
    }


    /**
     * Sets the manoeuvreDesc value for this ExtWayPoint.
     * 
     * @param manoeuvreDesc
     */
    public void setManoeuvreDesc(java.lang.String manoeuvreDesc) {
        this.manoeuvreDesc = manoeuvreDesc;
    }


    /**
     * Gets the manoeuvreType value for this ExtWayPoint.
     * 
     * @return manoeuvreType
     */
    public com.ptvag.xserver.xroute.ManoeuvreType getManoeuvreType() {
        return manoeuvreType;
    }


    /**
     * Sets the manoeuvreType value for this ExtWayPoint.
     * 
     * @param manoeuvreType
     */
    public void setManoeuvreType(com.ptvag.xserver.xroute.ManoeuvreType manoeuvreType) {
        this.manoeuvreType = manoeuvreType;
    }


    /**
     * Gets the turnOrient value for this ExtWayPoint.
     * 
     * @return turnOrient
     */
    public com.ptvag.xserver.xroute.TurnOrient getTurnOrient() {
        return turnOrient;
    }


    /**
     * Sets the turnOrient value for this ExtWayPoint.
     * 
     * @param turnOrient
     */
    public void setTurnOrient(com.ptvag.xserver.xroute.TurnOrient turnOrient) {
        this.turnOrient = turnOrient;
    }


    /**
     * Gets the turnWeight value for this ExtWayPoint.
     * 
     * @return turnWeight
     */
    public com.ptvag.xserver.xroute.TurnWeight getTurnWeight() {
        return turnWeight;
    }


    /**
     * Sets the turnWeight value for this ExtWayPoint.
     * 
     * @param turnWeight
     */
    public void setTurnWeight(com.ptvag.xserver.xroute.TurnWeight turnWeight) {
        this.turnWeight = turnWeight;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ExtWayPoint)) return false;
        ExtWayPoint other = (ExtWayPoint) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.exitAngle == other.getExitAngle() &&
            this.exitAngleNorth == other.getExitAngleNorth() &&
            this.linkingDistance == other.getLinkingDistance() &&
            this.linkingRouteListSegmentIdx == other.getLinkingRouteListSegmentIdx() &&
            this.linkingTime == other.getLinkingTime() &&
            ((this.manoeuvreDesc==null && other.getManoeuvreDesc()==null) || 
             (this.manoeuvreDesc!=null &&
              this.manoeuvreDesc.equals(other.getManoeuvreDesc()))) &&
            ((this.manoeuvreType==null && other.getManoeuvreType()==null) || 
             (this.manoeuvreType!=null &&
              this.manoeuvreType.equals(other.getManoeuvreType()))) &&
            ((this.turnOrient==null && other.getTurnOrient()==null) || 
             (this.turnOrient!=null &&
              this.turnOrient.equals(other.getTurnOrient()))) &&
            ((this.turnWeight==null && other.getTurnWeight()==null) || 
             (this.turnWeight!=null &&
              this.turnWeight.equals(other.getTurnWeight())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getExitAngle();
        _hashCode += getExitAngleNorth();
        _hashCode += getLinkingDistance();
        _hashCode += getLinkingRouteListSegmentIdx();
        _hashCode += getLinkingTime();
        if (getManoeuvreDesc() != null) {
            _hashCode += getManoeuvreDesc().hashCode();
        }
        if (getManoeuvreType() != null) {
            _hashCode += getManoeuvreType().hashCode();
        }
        if (getTurnOrient() != null) {
            _hashCode += getTurnOrient().hashCode();
        }
        if (getTurnWeight() != null) {
            _hashCode += getTurnWeight().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ExtWayPoint.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExtWayPoint"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("exitAngle");
        attrField.setXmlName(new javax.xml.namespace.QName("", "exitAngle"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("exitAngleNorth");
        attrField.setXmlName(new javax.xml.namespace.QName("", "exitAngleNorth"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("linkingDistance");
        attrField.setXmlName(new javax.xml.namespace.QName("", "linkingDistance"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("linkingRouteListSegmentIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "linkingRouteListSegmentIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("linkingTime");
        attrField.setXmlName(new javax.xml.namespace.QName("", "linkingTime"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("manoeuvreDesc");
        attrField.setXmlName(new javax.xml.namespace.QName("", "manoeuvreDesc"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("manoeuvreType");
        attrField.setXmlName(new javax.xml.namespace.QName("", "manoeuvreType"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("turnOrient");
        attrField.setXmlName(new javax.xml.namespace.QName("", "turnOrient"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TurnOrient"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("turnWeight");
        attrField.setXmlName(new javax.xml.namespace.QName("", "turnWeight"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TurnWeight"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
