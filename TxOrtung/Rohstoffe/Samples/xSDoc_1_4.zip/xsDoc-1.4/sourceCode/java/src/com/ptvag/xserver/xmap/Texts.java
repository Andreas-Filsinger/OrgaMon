/**
 * Texts.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class Texts  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xmap.TextOptions options;

    private com.ptvag.xserver.xmap.Text[] wrappedTexts;

    public Texts() {
    }

    public Texts(
           com.ptvag.xserver.xmap.TextOptions options,
           com.ptvag.xserver.xmap.Text[] wrappedTexts) {
        this.options = options;
        this.wrappedTexts = wrappedTexts;
    }


    /**
     * Gets the options value for this Texts.
     * 
     * @return options
     */
    public com.ptvag.xserver.xmap.TextOptions getOptions() {
        return options;
    }


    /**
     * Sets the options value for this Texts.
     * 
     * @param options
     */
    public void setOptions(com.ptvag.xserver.xmap.TextOptions options) {
        this.options = options;
    }


    /**
     * Gets the wrappedTexts value for this Texts.
     * 
     * @return wrappedTexts
     */
    public com.ptvag.xserver.xmap.Text[] getWrappedTexts() {
        return wrappedTexts;
    }


    /**
     * Sets the wrappedTexts value for this Texts.
     * 
     * @param wrappedTexts
     */
    public void setWrappedTexts(com.ptvag.xserver.xmap.Text[] wrappedTexts) {
        this.wrappedTexts = wrappedTexts;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Texts)) return false;
        Texts other = (Texts) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.options==null && other.getOptions()==null) || 
             (this.options!=null &&
              this.options.equals(other.getOptions()))) &&
            ((this.wrappedTexts==null && other.getWrappedTexts()==null) || 
             (this.wrappedTexts!=null &&
              java.util.Arrays.equals(this.wrappedTexts, other.getWrappedTexts())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getOptions() != null) {
            _hashCode += getOptions().hashCode();
        }
        if (getWrappedTexts() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedTexts());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedTexts(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Texts.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Texts"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("options");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "options"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "TextOptions"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedTexts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "wrappedTexts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Text"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Text"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
