/**
 * UniqueGeoID.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class UniqueGeoID  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private int iuCode;  // attribute

    private int n;  // attribute

    private long tID;  // attribute

    private int xOff;  // attribute

    private int yOff;  // attribute

    public UniqueGeoID() {
    }

    public UniqueGeoID(
           int iuCode,
           int n,
           long tID,
           int xOff,
           int yOff) {
        this.iuCode = iuCode;
        this.n = n;
        this.tID = tID;
        this.xOff = xOff;
        this.yOff = yOff;
    }


    /**
     * Gets the iuCode value for this UniqueGeoID.
     * 
     * @return iuCode
     */
    public int getIuCode() {
        return iuCode;
    }


    /**
     * Sets the iuCode value for this UniqueGeoID.
     * 
     * @param iuCode
     */
    public void setIuCode(int iuCode) {
        this.iuCode = iuCode;
    }


    /**
     * Gets the n value for this UniqueGeoID.
     * 
     * @return n
     */
    public int getN() {
        return n;
    }


    /**
     * Sets the n value for this UniqueGeoID.
     * 
     * @param n
     */
    public void setN(int n) {
        this.n = n;
    }


    /**
     * Gets the tID value for this UniqueGeoID.
     * 
     * @return tID
     */
    public long getTID() {
        return tID;
    }


    /**
     * Sets the tID value for this UniqueGeoID.
     * 
     * @param tID
     */
    public void setTID(long tID) {
        this.tID = tID;
    }


    /**
     * Gets the xOff value for this UniqueGeoID.
     * 
     * @return xOff
     */
    public int getXOff() {
        return xOff;
    }


    /**
     * Sets the xOff value for this UniqueGeoID.
     * 
     * @param xOff
     */
    public void setXOff(int xOff) {
        this.xOff = xOff;
    }


    /**
     * Gets the yOff value for this UniqueGeoID.
     * 
     * @return yOff
     */
    public int getYOff() {
        return yOff;
    }


    /**
     * Sets the yOff value for this UniqueGeoID.
     * 
     * @param yOff
     */
    public void setYOff(int yOff) {
        this.yOff = yOff;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof UniqueGeoID)) return false;
        UniqueGeoID other = (UniqueGeoID) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.iuCode == other.getIuCode() &&
            this.n == other.getN() &&
            this.tID == other.getTID() &&
            this.xOff == other.getXOff() &&
            this.yOff == other.getYOff();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getIuCode();
        _hashCode += getN();
        _hashCode += new Long(getTID()).hashCode();
        _hashCode += getXOff();
        _hashCode += getYOff();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(UniqueGeoID.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("iuCode");
        attrField.setXmlName(new javax.xml.namespace.QName("", "iuCode"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("n");
        attrField.setXmlName(new javax.xml.namespace.QName("", "n"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("TID");
        attrField.setXmlName(new javax.xml.namespace.QName("", "tID"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("XOff");
        attrField.setXmlName(new javax.xml.namespace.QName("", "xOff"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("YOff");
        attrField.setXmlName(new javax.xml.namespace.QName("", "yOff"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
