/**
 * PoiLocation.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xlocate;

public class PoiLocation  extends com.ptvag.xserver.xlocate.Location  implements java.io.Serializable {
    private com.ptvag.xserver.common.Polygon poiArea;

    private java.lang.String poiName;  // attribute

    private int poiSearchRange;  // attribute

    private java.lang.String poiType;  // attribute

    public PoiLocation() {
    }

    public PoiLocation(
           com.ptvag.xserver.common.Point coordinate,
           java.lang.String poiName,
           int poiSearchRange,
           java.lang.String poiType,
           com.ptvag.xserver.common.Polygon poiArea) {
        super(
            coordinate);
        this.poiName = poiName;
        this.poiSearchRange = poiSearchRange;
        this.poiType = poiType;
        this.poiArea = poiArea;
    }


    /**
     * Gets the poiArea value for this PoiLocation.
     * 
     * @return poiArea
     */
    public com.ptvag.xserver.common.Polygon getPoiArea() {
        return poiArea;
    }


    /**
     * Sets the poiArea value for this PoiLocation.
     * 
     * @param poiArea
     */
    public void setPoiArea(com.ptvag.xserver.common.Polygon poiArea) {
        this.poiArea = poiArea;
    }


    /**
     * Gets the poiName value for this PoiLocation.
     * 
     * @return poiName
     */
    public java.lang.String getPoiName() {
        return poiName;
    }


    /**
     * Sets the poiName value for this PoiLocation.
     * 
     * @param poiName
     */
    public void setPoiName(java.lang.String poiName) {
        this.poiName = poiName;
    }


    /**
     * Gets the poiSearchRange value for this PoiLocation.
     * 
     * @return poiSearchRange
     */
    public int getPoiSearchRange() {
        return poiSearchRange;
    }


    /**
     * Sets the poiSearchRange value for this PoiLocation.
     * 
     * @param poiSearchRange
     */
    public void setPoiSearchRange(int poiSearchRange) {
        this.poiSearchRange = poiSearchRange;
    }


    /**
     * Gets the poiType value for this PoiLocation.
     * 
     * @return poiType
     */
    public java.lang.String getPoiType() {
        return poiType;
    }


    /**
     * Sets the poiType value for this PoiLocation.
     * 
     * @param poiType
     */
    public void setPoiType(java.lang.String poiType) {
        this.poiType = poiType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PoiLocation)) return false;
        PoiLocation other = (PoiLocation) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.poiArea==null && other.getPoiArea()==null) || 
             (this.poiArea!=null &&
              this.poiArea.equals(other.getPoiArea()))) &&
            ((this.poiName==null && other.getPoiName()==null) || 
             (this.poiName!=null &&
              this.poiName.equals(other.getPoiName()))) &&
            this.poiSearchRange == other.getPoiSearchRange() &&
            ((this.poiType==null && other.getPoiType()==null) || 
             (this.poiType!=null &&
              this.poiType.equals(other.getPoiType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getPoiArea() != null) {
            _hashCode += getPoiArea().hashCode();
        }
        if (getPoiName() != null) {
            _hashCode += getPoiName().hashCode();
        }
        _hashCode += getPoiSearchRange();
        if (getPoiType() != null) {
            _hashCode += getPoiType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PoiLocation.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "PoiLocation"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("poiName");
        attrField.setXmlName(new javax.xml.namespace.QName("", "poiName"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("poiSearchRange");
        attrField.setXmlName(new javax.xml.namespace.QName("", "poiSearchRange"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("poiType");
        attrField.setXmlName(new javax.xml.namespace.QName("", "poiType"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("poiArea");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "poiArea"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Polygon"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
