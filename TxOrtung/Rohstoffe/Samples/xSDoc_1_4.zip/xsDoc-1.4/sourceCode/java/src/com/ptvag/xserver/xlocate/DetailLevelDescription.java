/**
 * DetailLevelDescription.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xlocate;

public class DetailLevelDescription implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected DetailLevelDescription(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _COUNTRY = "COUNTRY";
    public static final java.lang.String _STATE = "STATE";
    public static final java.lang.String _EXTPOSTCODE = "EXTPOSTCODE";
    public static final java.lang.String _CITY = "CITY";
    public static final java.lang.String _CITY2 = "CITY2";
    public static final java.lang.String _POSTCODE = "POSTCODE";
    public static final java.lang.String _STREET = "STREET";
    public static final java.lang.String _HNRSECTION = "HNRSECTION";
    public static final java.lang.String _HNRLINK = "HNRLINK";
    public static final java.lang.String _HNRINTERPOLATED = "HNRINTERPOLATED";
    public static final java.lang.String _HNREXACT = "HNREXACT";
    public static final java.lang.String _INTERSECTION = "INTERSECTION";
    public static final DetailLevelDescription COUNTRY = new DetailLevelDescription(_COUNTRY);
    public static final DetailLevelDescription STATE = new DetailLevelDescription(_STATE);
    public static final DetailLevelDescription EXTPOSTCODE = new DetailLevelDescription(_EXTPOSTCODE);
    public static final DetailLevelDescription CITY = new DetailLevelDescription(_CITY);
    public static final DetailLevelDescription CITY2 = new DetailLevelDescription(_CITY2);
    public static final DetailLevelDescription POSTCODE = new DetailLevelDescription(_POSTCODE);
    public static final DetailLevelDescription STREET = new DetailLevelDescription(_STREET);
    public static final DetailLevelDescription HNRSECTION = new DetailLevelDescription(_HNRSECTION);
    public static final DetailLevelDescription HNRLINK = new DetailLevelDescription(_HNRLINK);
    public static final DetailLevelDescription HNRINTERPOLATED = new DetailLevelDescription(_HNRINTERPOLATED);
    public static final DetailLevelDescription HNREXACT = new DetailLevelDescription(_HNREXACT);
    public static final DetailLevelDescription INTERSECTION = new DetailLevelDescription(_INTERSECTION);
    public java.lang.String getValue() { return _value_;}
    public static DetailLevelDescription fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        DetailLevelDescription enumeration = (DetailLevelDescription)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static DetailLevelDescription fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DetailLevelDescription.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "DetailLevelDescription"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
