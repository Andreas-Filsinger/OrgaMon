/**
 * OrienteeringParams.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class OrienteeringParams  extends com.ptvag.xserver.xsequence.PlanningParams  implements java.io.Serializable {
    private int maxTourDistance;  // attribute

    public OrienteeringParams() {
    }

    public OrienteeringParams(
           int costDistanceKm,
           int costPeriodMinute,
           int maxProcessorPeriod,
           com.ptvag.xserver.xsequence.DistanceCalculation distanceCalculation,
           int maxTourDistance) {
        super(
            costDistanceKm,
            costPeriodMinute,
            maxProcessorPeriod,
            distanceCalculation);
        this.maxTourDistance = maxTourDistance;
    }


    /**
     * Gets the maxTourDistance value for this OrienteeringParams.
     * 
     * @return maxTourDistance
     */
    public int getMaxTourDistance() {
        return maxTourDistance;
    }


    /**
     * Sets the maxTourDistance value for this OrienteeringParams.
     * 
     * @param maxTourDistance
     */
    public void setMaxTourDistance(int maxTourDistance) {
        this.maxTourDistance = maxTourDistance;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OrienteeringParams)) return false;
        OrienteeringParams other = (OrienteeringParams) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.maxTourDistance == other.getMaxTourDistance();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getMaxTourDistance();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrienteeringParams.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OrienteeringParams"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("maxTourDistance");
        attrField.setXmlName(new javax.xml.namespace.QName("", "maxTourDistance"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
