/**
 * Bitmaps.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class Bitmaps  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xmap.BasicBitmap[] wrappedBitmaps;

    private com.ptvag.xserver.xmap.BitmapOptions options;

    public Bitmaps() {
    }

    public Bitmaps(
           com.ptvag.xserver.xmap.BasicBitmap[] wrappedBitmaps,
           com.ptvag.xserver.xmap.BitmapOptions options) {
        this.wrappedBitmaps = wrappedBitmaps;
        this.options = options;
    }


    /**
     * Gets the wrappedBitmaps value for this Bitmaps.
     * 
     * @return wrappedBitmaps
     */
    public com.ptvag.xserver.xmap.BasicBitmap[] getWrappedBitmaps() {
        return wrappedBitmaps;
    }


    /**
     * Sets the wrappedBitmaps value for this Bitmaps.
     * 
     * @param wrappedBitmaps
     */
    public void setWrappedBitmaps(com.ptvag.xserver.xmap.BasicBitmap[] wrappedBitmaps) {
        this.wrappedBitmaps = wrappedBitmaps;
    }


    /**
     * Gets the options value for this Bitmaps.
     * 
     * @return options
     */
    public com.ptvag.xserver.xmap.BitmapOptions getOptions() {
        return options;
    }


    /**
     * Sets the options value for this Bitmaps.
     * 
     * @param options
     */
    public void setOptions(com.ptvag.xserver.xmap.BitmapOptions options) {
        this.options = options;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Bitmaps)) return false;
        Bitmaps other = (Bitmaps) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedBitmaps==null && other.getWrappedBitmaps()==null) || 
             (this.wrappedBitmaps!=null &&
              java.util.Arrays.equals(this.wrappedBitmaps, other.getWrappedBitmaps()))) &&
            ((this.options==null && other.getOptions()==null) || 
             (this.options!=null &&
              this.options.equals(other.getOptions())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedBitmaps() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedBitmaps());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedBitmaps(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOptions() != null) {
            _hashCode += getOptions().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Bitmaps.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Bitmaps"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedBitmaps");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "wrappedBitmaps"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "BasicBitmap"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "BasicBitmap"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("options");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "options"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "BitmapOptions"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
