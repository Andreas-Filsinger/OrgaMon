package com.ptvag.xserver.xsequence.jwsdp;

public class XSequenceWSProxy implements com.ptvag.xserver.xsequence.jwsdp.XSequenceWS {
  private String _endpoint = null;
  private com.ptvag.xserver.xsequence.jwsdp.XSequenceWS xSequenceWS = null;
  
  public XSequenceWSProxy() {
    _initXSequenceWSProxy();
  }
  
  public XSequenceWSProxy(String endpoint) {
    _endpoint = endpoint;
    _initXSequenceWSProxy();
  }
  
  private void _initXSequenceWSProxy() {
    try {
      xSequenceWS = (new com.ptvag.xserver.xsequence.jwsdp.XSequenceWSServiceLocator()).getXSequenceWSPort();
      if (xSequenceWS != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)xSequenceWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)xSequenceWS)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (xSequenceWS != null)
      ((javax.xml.rpc.Stub)xSequenceWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ptvag.xserver.xsequence.jwsdp.XSequenceWS getXSequenceWS() {
    if (xSequenceWS == null)
      _initXSequenceWSProxy();
    return xSequenceWS;
  }
  
  public com.ptvag.xserver.xsequence.Plan calcTimewindowTour(com.ptvag.xserver.xsequence.TimewindowStop[] arrayOfTimewindowStop_1, com.ptvag.xserver.xsequence.TimewindowPlanningParams timewindowPlanningParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException{
    if (xSequenceWS == null)
      _initXSequenceWSProxy();
    return xSequenceWS.calcTimewindowTour(arrayOfTimewindowStop_1, timewindowPlanningParams_2, inputTour_3, callerContext_4);
  }
  
  public com.ptvag.xserver.xsequence.Plan calcTour(com.ptvag.xserver.xsequence.Stop[] arrayOfStop_1, com.ptvag.xserver.xsequence.PlanningParams planningParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException{
    if (xSequenceWS == null)
      _initXSequenceWSProxy();
    return xSequenceWS.calcTour(arrayOfStop_1, planningParams_2, inputTour_3, callerContext_4);
  }
  
  public com.ptvag.xserver.xsequence.Plan calcTransportTour(com.ptvag.xserver.xsequence.TransportStop[] arrayOfTransportStop_1, com.ptvag.xserver.xsequence.TransportPlanningParams transportPlanningParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException{
    if (xSequenceWS == null)
      _initXSequenceWSProxy();
    return xSequenceWS.calcTransportTour(arrayOfTransportStop_1, transportPlanningParams_2, inputTour_3, callerContext_4);
  }
  
  public com.ptvag.xserver.xsequence.Plan planOrienteeringTour(com.ptvag.xserver.xsequence.OrienteeringStop[] arrayOfOrienteeringStop_1, com.ptvag.xserver.xsequence.OrienteeringParams orienteeringParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException{
    if (xSequenceWS == null)
      _initXSequenceWSProxy();
    return xSequenceWS.planOrienteeringTour(arrayOfOrienteeringStop_1, orienteeringParams_2, inputTour_3, callerContext_4);
  }
  
  public com.ptvag.xserver.xsequence.Plan planTimewindowTour(com.ptvag.xserver.xsequence.TimewindowStop[] arrayOfTimewindowStop_1, com.ptvag.xserver.xsequence.TimewindowPlanningParams timewindowPlanningParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException{
    if (xSequenceWS == null)
      _initXSequenceWSProxy();
    return xSequenceWS.planTimewindowTour(arrayOfTimewindowStop_1, timewindowPlanningParams_2, inputTour_3, callerContext_4);
  }
  
  public com.ptvag.xserver.xsequence.Plan planTour(com.ptvag.xserver.xsequence.Stop[] arrayOfStop_1, com.ptvag.xserver.xsequence.PlanningParams planningParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException{
    if (xSequenceWS == null)
      _initXSequenceWSProxy();
    return xSequenceWS.planTour(arrayOfStop_1, planningParams_2, inputTour_3, callerContext_4);
  }
  
  public com.ptvag.xserver.xsequence.Plan planTransportTour(com.ptvag.xserver.xsequence.TransportStop[] arrayOfTransportStop_1, com.ptvag.xserver.xsequence.TransportPlanningParams transportPlanningParams_2, com.ptvag.xserver.xsequence.InputTour inputTour_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.OptimisticRollbackException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.jabba.core.exception.TableNotFoundException, com.ptvag.jabba.core.exception.ConstraintViolationException, com.ptvag.jabba.core.exception.DatabaseException, com.ptvag.xserver.common.XServiceException, com.ptvag.xserver.xsequence.XSequenceException{
    if (xSequenceWS == null)
      _initXSequenceWSProxy();
    return xSequenceWS.planTransportTour(arrayOfTransportStop_1, transportPlanningParams_2, inputTour_3, callerContext_4);
  }
  
  
}