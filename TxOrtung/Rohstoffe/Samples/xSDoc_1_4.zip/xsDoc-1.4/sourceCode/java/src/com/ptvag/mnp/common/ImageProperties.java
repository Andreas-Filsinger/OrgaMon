/**
 * ImageProperties.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class ImageProperties  implements java.io.Serializable {
    private com.ptvag.mnp.common.Icon centerIcon;

    private com.ptvag.mnp.common.POIViewSet[] wrappedDefaultPois;

    private com.ptvag.mnp.common.DetailLevelType detailLevel;

    private int deviceHeight;

    private int deviceWidth;

    private com.ptvag.mnp.common.FileFormatEnum fileFormat;

    private java.lang.String imageProfile;

    private com.ptvag.mnp.common.RouteDisplayProperties routeDisplay;

    private com.ptvag.mnp.common.DistanceUnitEnum scaleUnit;

    private java.lang.Boolean showScale;

    private java.lang.Boolean urlOnly;

    private java.lang.Boolean urlSecure;

    public ImageProperties() {
    }

    public ImageProperties(
           com.ptvag.mnp.common.Icon centerIcon,
           com.ptvag.mnp.common.POIViewSet[] wrappedDefaultPois,
           com.ptvag.mnp.common.DetailLevelType detailLevel,
           int deviceHeight,
           int deviceWidth,
           com.ptvag.mnp.common.FileFormatEnum fileFormat,
           java.lang.String imageProfile,
           com.ptvag.mnp.common.RouteDisplayProperties routeDisplay,
           com.ptvag.mnp.common.DistanceUnitEnum scaleUnit,
           java.lang.Boolean showScale,
           java.lang.Boolean urlOnly,
           java.lang.Boolean urlSecure) {
           this.centerIcon = centerIcon;
           this.wrappedDefaultPois = wrappedDefaultPois;
           this.detailLevel = detailLevel;
           this.deviceHeight = deviceHeight;
           this.deviceWidth = deviceWidth;
           this.fileFormat = fileFormat;
           this.imageProfile = imageProfile;
           this.routeDisplay = routeDisplay;
           this.scaleUnit = scaleUnit;
           this.showScale = showScale;
           this.urlOnly = urlOnly;
           this.urlSecure = urlSecure;
    }


    /**
     * Gets the centerIcon value for this ImageProperties.
     * 
     * @return centerIcon
     */
    public com.ptvag.mnp.common.Icon getCenterIcon() {
        return centerIcon;
    }


    /**
     * Sets the centerIcon value for this ImageProperties.
     * 
     * @param centerIcon
     */
    public void setCenterIcon(com.ptvag.mnp.common.Icon centerIcon) {
        this.centerIcon = centerIcon;
    }


    /**
     * Gets the wrappedDefaultPois value for this ImageProperties.
     * 
     * @return wrappedDefaultPois
     */
    public com.ptvag.mnp.common.POIViewSet[] getWrappedDefaultPois() {
        return wrappedDefaultPois;
    }


    /**
     * Sets the wrappedDefaultPois value for this ImageProperties.
     * 
     * @param wrappedDefaultPois
     */
    public void setWrappedDefaultPois(com.ptvag.mnp.common.POIViewSet[] wrappedDefaultPois) {
        this.wrappedDefaultPois = wrappedDefaultPois;
    }


    /**
     * Gets the detailLevel value for this ImageProperties.
     * 
     * @return detailLevel
     */
    public com.ptvag.mnp.common.DetailLevelType getDetailLevel() {
        return detailLevel;
    }


    /**
     * Sets the detailLevel value for this ImageProperties.
     * 
     * @param detailLevel
     */
    public void setDetailLevel(com.ptvag.mnp.common.DetailLevelType detailLevel) {
        this.detailLevel = detailLevel;
    }


    /**
     * Gets the deviceHeight value for this ImageProperties.
     * 
     * @return deviceHeight
     */
    public int getDeviceHeight() {
        return deviceHeight;
    }


    /**
     * Sets the deviceHeight value for this ImageProperties.
     * 
     * @param deviceHeight
     */
    public void setDeviceHeight(int deviceHeight) {
        this.deviceHeight = deviceHeight;
    }


    /**
     * Gets the deviceWidth value for this ImageProperties.
     * 
     * @return deviceWidth
     */
    public int getDeviceWidth() {
        return deviceWidth;
    }


    /**
     * Sets the deviceWidth value for this ImageProperties.
     * 
     * @param deviceWidth
     */
    public void setDeviceWidth(int deviceWidth) {
        this.deviceWidth = deviceWidth;
    }


    /**
     * Gets the fileFormat value for this ImageProperties.
     * 
     * @return fileFormat
     */
    public com.ptvag.mnp.common.FileFormatEnum getFileFormat() {
        return fileFormat;
    }


    /**
     * Sets the fileFormat value for this ImageProperties.
     * 
     * @param fileFormat
     */
    public void setFileFormat(com.ptvag.mnp.common.FileFormatEnum fileFormat) {
        this.fileFormat = fileFormat;
    }


    /**
     * Gets the imageProfile value for this ImageProperties.
     * 
     * @return imageProfile
     */
    public java.lang.String getImageProfile() {
        return imageProfile;
    }


    /**
     * Sets the imageProfile value for this ImageProperties.
     * 
     * @param imageProfile
     */
    public void setImageProfile(java.lang.String imageProfile) {
        this.imageProfile = imageProfile;
    }


    /**
     * Gets the routeDisplay value for this ImageProperties.
     * 
     * @return routeDisplay
     */
    public com.ptvag.mnp.common.RouteDisplayProperties getRouteDisplay() {
        return routeDisplay;
    }


    /**
     * Sets the routeDisplay value for this ImageProperties.
     * 
     * @param routeDisplay
     */
    public void setRouteDisplay(com.ptvag.mnp.common.RouteDisplayProperties routeDisplay) {
        this.routeDisplay = routeDisplay;
    }


    /**
     * Gets the scaleUnit value for this ImageProperties.
     * 
     * @return scaleUnit
     */
    public com.ptvag.mnp.common.DistanceUnitEnum getScaleUnit() {
        return scaleUnit;
    }


    /**
     * Sets the scaleUnit value for this ImageProperties.
     * 
     * @param scaleUnit
     */
    public void setScaleUnit(com.ptvag.mnp.common.DistanceUnitEnum scaleUnit) {
        this.scaleUnit = scaleUnit;
    }


    /**
     * Gets the showScale value for this ImageProperties.
     * 
     * @return showScale
     */
    public java.lang.Boolean getShowScale() {
        return showScale;
    }


    /**
     * Sets the showScale value for this ImageProperties.
     * 
     * @param showScale
     */
    public void setShowScale(java.lang.Boolean showScale) {
        this.showScale = showScale;
    }


    /**
     * Gets the urlOnly value for this ImageProperties.
     * 
     * @return urlOnly
     */
    public java.lang.Boolean getUrlOnly() {
        return urlOnly;
    }


    /**
     * Sets the urlOnly value for this ImageProperties.
     * 
     * @param urlOnly
     */
    public void setUrlOnly(java.lang.Boolean urlOnly) {
        this.urlOnly = urlOnly;
    }


    /**
     * Gets the urlSecure value for this ImageProperties.
     * 
     * @return urlSecure
     */
    public java.lang.Boolean getUrlSecure() {
        return urlSecure;
    }


    /**
     * Sets the urlSecure value for this ImageProperties.
     * 
     * @param urlSecure
     */
    public void setUrlSecure(java.lang.Boolean urlSecure) {
        this.urlSecure = urlSecure;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ImageProperties)) return false;
        ImageProperties other = (ImageProperties) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.centerIcon==null && other.getCenterIcon()==null) || 
             (this.centerIcon!=null &&
              this.centerIcon.equals(other.getCenterIcon()))) &&
            ((this.wrappedDefaultPois==null && other.getWrappedDefaultPois()==null) || 
             (this.wrappedDefaultPois!=null &&
              java.util.Arrays.equals(this.wrappedDefaultPois, other.getWrappedDefaultPois()))) &&
            ((this.detailLevel==null && other.getDetailLevel()==null) || 
             (this.detailLevel!=null &&
              this.detailLevel.equals(other.getDetailLevel()))) &&
            this.deviceHeight == other.getDeviceHeight() &&
            this.deviceWidth == other.getDeviceWidth() &&
            ((this.fileFormat==null && other.getFileFormat()==null) || 
             (this.fileFormat!=null &&
              this.fileFormat.equals(other.getFileFormat()))) &&
            ((this.imageProfile==null && other.getImageProfile()==null) || 
             (this.imageProfile!=null &&
              this.imageProfile.equals(other.getImageProfile()))) &&
            ((this.routeDisplay==null && other.getRouteDisplay()==null) || 
             (this.routeDisplay!=null &&
              this.routeDisplay.equals(other.getRouteDisplay()))) &&
            ((this.scaleUnit==null && other.getScaleUnit()==null) || 
             (this.scaleUnit!=null &&
              this.scaleUnit.equals(other.getScaleUnit()))) &&
            ((this.showScale==null && other.getShowScale()==null) || 
             (this.showScale!=null &&
              this.showScale.equals(other.getShowScale()))) &&
            ((this.urlOnly==null && other.getUrlOnly()==null) || 
             (this.urlOnly!=null &&
              this.urlOnly.equals(other.getUrlOnly()))) &&
            ((this.urlSecure==null && other.getUrlSecure()==null) || 
             (this.urlSecure!=null &&
              this.urlSecure.equals(other.getUrlSecure())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCenterIcon() != null) {
            _hashCode += getCenterIcon().hashCode();
        }
        if (getWrappedDefaultPois() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedDefaultPois());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedDefaultPois(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDetailLevel() != null) {
            _hashCode += getDetailLevel().hashCode();
        }
        _hashCode += getDeviceHeight();
        _hashCode += getDeviceWidth();
        if (getFileFormat() != null) {
            _hashCode += getFileFormat().hashCode();
        }
        if (getImageProfile() != null) {
            _hashCode += getImageProfile().hashCode();
        }
        if (getRouteDisplay() != null) {
            _hashCode += getRouteDisplay().hashCode();
        }
        if (getScaleUnit() != null) {
            _hashCode += getScaleUnit().hashCode();
        }
        if (getShowScale() != null) {
            _hashCode += getShowScale().hashCode();
        }
        if (getUrlOnly() != null) {
            _hashCode += getUrlOnly().hashCode();
        }
        if (getUrlSecure() != null) {
            _hashCode += getUrlSecure().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ImageProperties.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ImageProperties"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("centerIcon");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "centerIcon"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Icon"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedDefaultPois");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedDefaultPois"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIViewSet"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("detailLevel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "detailLevel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "DetailLevelType"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deviceHeight");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "deviceHeight"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deviceWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "deviceWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fileFormat");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "fileFormat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "FileFormatEnum"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("imageProfile");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "imageProfile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("routeDisplay");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "routeDisplay"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteDisplayProperties"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scaleUnit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "scaleUnit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "DistanceUnitEnum"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showScale");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "showScale"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("urlOnly");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "urlOnly"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("urlSecure");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "urlSecure"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
