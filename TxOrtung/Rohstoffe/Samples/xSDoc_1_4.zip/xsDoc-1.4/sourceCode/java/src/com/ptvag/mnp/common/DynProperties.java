/**
 * DynProperties.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class DynProperties  implements java.io.Serializable {
    private java.lang.Double distanceDiff;

    private java.lang.Long timeBenefit;

    private java.lang.Long timeLoss;

    public DynProperties() {
    }

    public DynProperties(
           java.lang.Double distanceDiff,
           java.lang.Long timeBenefit,
           java.lang.Long timeLoss) {
           this.distanceDiff = distanceDiff;
           this.timeBenefit = timeBenefit;
           this.timeLoss = timeLoss;
    }


    /**
     * Gets the distanceDiff value for this DynProperties.
     * 
     * @return distanceDiff
     */
    public java.lang.Double getDistanceDiff() {
        return distanceDiff;
    }


    /**
     * Sets the distanceDiff value for this DynProperties.
     * 
     * @param distanceDiff
     */
    public void setDistanceDiff(java.lang.Double distanceDiff) {
        this.distanceDiff = distanceDiff;
    }


    /**
     * Gets the timeBenefit value for this DynProperties.
     * 
     * @return timeBenefit
     */
    public java.lang.Long getTimeBenefit() {
        return timeBenefit;
    }


    /**
     * Sets the timeBenefit value for this DynProperties.
     * 
     * @param timeBenefit
     */
    public void setTimeBenefit(java.lang.Long timeBenefit) {
        this.timeBenefit = timeBenefit;
    }


    /**
     * Gets the timeLoss value for this DynProperties.
     * 
     * @return timeLoss
     */
    public java.lang.Long getTimeLoss() {
        return timeLoss;
    }


    /**
     * Sets the timeLoss value for this DynProperties.
     * 
     * @param timeLoss
     */
    public void setTimeLoss(java.lang.Long timeLoss) {
        this.timeLoss = timeLoss;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DynProperties)) return false;
        DynProperties other = (DynProperties) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.distanceDiff==null && other.getDistanceDiff()==null) || 
             (this.distanceDiff!=null &&
              this.distanceDiff.equals(other.getDistanceDiff()))) &&
            ((this.timeBenefit==null && other.getTimeBenefit()==null) || 
             (this.timeBenefit!=null &&
              this.timeBenefit.equals(other.getTimeBenefit()))) &&
            ((this.timeLoss==null && other.getTimeLoss()==null) || 
             (this.timeLoss!=null &&
              this.timeLoss.equals(other.getTimeLoss())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDistanceDiff() != null) {
            _hashCode += getDistanceDiff().hashCode();
        }
        if (getTimeBenefit() != null) {
            _hashCode += getTimeBenefit().hashCode();
        }
        if (getTimeLoss() != null) {
            _hashCode += getTimeLoss().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DynProperties.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "DynProperties"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("distanceDiff");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "distanceDiff"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timeBenefit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "timeBenefit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timeLoss");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "timeLoss"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
