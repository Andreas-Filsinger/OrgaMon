/**
 * TourPoint.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class TourPoint  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private int arrivalTime;  // attribute

    private int departureTime;  // attribute

    private int endOfService;  // attribute

    private boolean serviceViolation;  // attribute

    private int startOfService;  // attribute

    private int stationIdx;  // attribute

    private boolean timeWindowViolation;  // attribute

    public TourPoint() {
    }

    public TourPoint(
           int arrivalTime,
           int departureTime,
           int endOfService,
           boolean serviceViolation,
           int startOfService,
           int stationIdx,
           boolean timeWindowViolation) {
        this.arrivalTime = arrivalTime;
        this.departureTime = departureTime;
        this.endOfService = endOfService;
        this.serviceViolation = serviceViolation;
        this.startOfService = startOfService;
        this.stationIdx = stationIdx;
        this.timeWindowViolation = timeWindowViolation;
    }


    /**
     * Gets the arrivalTime value for this TourPoint.
     * 
     * @return arrivalTime
     */
    public int getArrivalTime() {
        return arrivalTime;
    }


    /**
     * Sets the arrivalTime value for this TourPoint.
     * 
     * @param arrivalTime
     */
    public void setArrivalTime(int arrivalTime) {
        this.arrivalTime = arrivalTime;
    }


    /**
     * Gets the departureTime value for this TourPoint.
     * 
     * @return departureTime
     */
    public int getDepartureTime() {
        return departureTime;
    }


    /**
     * Sets the departureTime value for this TourPoint.
     * 
     * @param departureTime
     */
    public void setDepartureTime(int departureTime) {
        this.departureTime = departureTime;
    }


    /**
     * Gets the endOfService value for this TourPoint.
     * 
     * @return endOfService
     */
    public int getEndOfService() {
        return endOfService;
    }


    /**
     * Sets the endOfService value for this TourPoint.
     * 
     * @param endOfService
     */
    public void setEndOfService(int endOfService) {
        this.endOfService = endOfService;
    }


    /**
     * Gets the serviceViolation value for this TourPoint.
     * 
     * @return serviceViolation
     */
    public boolean isServiceViolation() {
        return serviceViolation;
    }


    /**
     * Sets the serviceViolation value for this TourPoint.
     * 
     * @param serviceViolation
     */
    public void setServiceViolation(boolean serviceViolation) {
        this.serviceViolation = serviceViolation;
    }


    /**
     * Gets the startOfService value for this TourPoint.
     * 
     * @return startOfService
     */
    public int getStartOfService() {
        return startOfService;
    }


    /**
     * Sets the startOfService value for this TourPoint.
     * 
     * @param startOfService
     */
    public void setStartOfService(int startOfService) {
        this.startOfService = startOfService;
    }


    /**
     * Gets the stationIdx value for this TourPoint.
     * 
     * @return stationIdx
     */
    public int getStationIdx() {
        return stationIdx;
    }


    /**
     * Sets the stationIdx value for this TourPoint.
     * 
     * @param stationIdx
     */
    public void setStationIdx(int stationIdx) {
        this.stationIdx = stationIdx;
    }


    /**
     * Gets the timeWindowViolation value for this TourPoint.
     * 
     * @return timeWindowViolation
     */
    public boolean isTimeWindowViolation() {
        return timeWindowViolation;
    }


    /**
     * Sets the timeWindowViolation value for this TourPoint.
     * 
     * @param timeWindowViolation
     */
    public void setTimeWindowViolation(boolean timeWindowViolation) {
        this.timeWindowViolation = timeWindowViolation;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TourPoint)) return false;
        TourPoint other = (TourPoint) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.arrivalTime == other.getArrivalTime() &&
            this.departureTime == other.getDepartureTime() &&
            this.endOfService == other.getEndOfService() &&
            this.serviceViolation == other.isServiceViolation() &&
            this.startOfService == other.getStartOfService() &&
            this.stationIdx == other.getStationIdx() &&
            this.timeWindowViolation == other.isTimeWindowViolation();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getArrivalTime();
        _hashCode += getDepartureTime();
        _hashCode += getEndOfService();
        _hashCode += (isServiceViolation() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getStartOfService();
        _hashCode += getStationIdx();
        _hashCode += (isTimeWindowViolation() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TourPoint.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TourPoint"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("arrivalTime");
        attrField.setXmlName(new javax.xml.namespace.QName("", "arrivalTime"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("departureTime");
        attrField.setXmlName(new javax.xml.namespace.QName("", "departureTime"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("endOfService");
        attrField.setXmlName(new javax.xml.namespace.QName("", "endOfService"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("serviceViolation");
        attrField.setXmlName(new javax.xml.namespace.QName("", "serviceViolation"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("startOfService");
        attrField.setXmlName(new javax.xml.namespace.QName("", "startOfService"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("stationIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "stationIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("timeWindowViolation");
        attrField.setXmlName(new javax.xml.namespace.QName("", "timeWindowViolation"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
