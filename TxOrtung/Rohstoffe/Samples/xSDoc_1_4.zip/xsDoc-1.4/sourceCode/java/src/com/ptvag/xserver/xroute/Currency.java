/**
 * Currency.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class Currency implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected Currency(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _NONE = "NONE";
    public static final java.lang.String _EUR = "EUR";
    public static final java.lang.String _GBP = "GBP";
    public static final java.lang.String _DKK = "DKK";
    public static final java.lang.String _NOK = "NOK";
    public static final java.lang.String _SEK = "SEK";
    public static final java.lang.String _CHF = "CHF";
    public static final java.lang.String _PLN = "PLN";
    public static final java.lang.String _SIT = "SIT";
    public static final java.lang.String _SKK = "SKK";
    public static final java.lang.String _SK = "SK";
    public static final java.lang.String _TRL = "TRL";
    public static final java.lang.String _USD = "USD";
    public static final java.lang.String _CAD = "CAD";
    public static final java.lang.String _JPY = "JPY";
    public static final java.lang.String _ROL = "ROL";
    public static final java.lang.String _BGN = "BGN";
    public static final java.lang.String _HUF = "HUF";
    public static final java.lang.String _HRK = "HRK";
    public static final java.lang.String _MKD = "MKD";
    public static final java.lang.String _ALL = "ALL";
    public static final java.lang.String _BAM = "BAM";
    public static final java.lang.String _EEK = "EEK";
    public static final java.lang.String _CSD = "CSD";
    public static final java.lang.String _LVL = "LVL";
    public static final java.lang.String _LTL = "LTL";
    public static final java.lang.String _MTL = "MTL";
    public static final java.lang.String _MDL = "MDL";
    public static final java.lang.String _CYP = "CYP";
    public static final java.lang.String _ZAR = "ZAR";
    public static final java.lang.String _CZK = "CZK";
    public static final Currency NONE = new Currency(_NONE);
    public static final Currency EUR = new Currency(_EUR);
    public static final Currency GBP = new Currency(_GBP);
    public static final Currency DKK = new Currency(_DKK);
    public static final Currency NOK = new Currency(_NOK);
    public static final Currency SEK = new Currency(_SEK);
    public static final Currency CHF = new Currency(_CHF);
    public static final Currency PLN = new Currency(_PLN);
    public static final Currency SIT = new Currency(_SIT);
    public static final Currency SKK = new Currency(_SKK);
    public static final Currency SK = new Currency(_SK);
    public static final Currency TRL = new Currency(_TRL);
    public static final Currency USD = new Currency(_USD);
    public static final Currency CAD = new Currency(_CAD);
    public static final Currency JPY = new Currency(_JPY);
    public static final Currency ROL = new Currency(_ROL);
    public static final Currency BGN = new Currency(_BGN);
    public static final Currency HUF = new Currency(_HUF);
    public static final Currency HRK = new Currency(_HRK);
    public static final Currency MKD = new Currency(_MKD);
    public static final Currency ALL = new Currency(_ALL);
    public static final Currency BAM = new Currency(_BAM);
    public static final Currency EEK = new Currency(_EEK);
    public static final Currency CSD = new Currency(_CSD);
    public static final Currency LVL = new Currency(_LVL);
    public static final Currency LTL = new Currency(_LTL);
    public static final Currency MTL = new Currency(_MTL);
    public static final Currency MDL = new Currency(_MDL);
    public static final Currency CYP = new Currency(_CYP);
    public static final Currency ZAR = new Currency(_ZAR);
    public static final Currency CZK = new Currency(_CZK);
    public java.lang.String getValue() { return _value_;}
    public static Currency fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        Currency enumeration = (Currency)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static Currency fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Currency.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Currency"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
