/**
 * BreakRule.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class BreakRule  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xsequence.RemainingPeriods firstBreak;

    private int breakPeriod;  // attribute

    private int maxBreakDrivingPeriod;  // attribute

    private int minBreakPeriod;  // attribute

    public BreakRule() {
    }

    public BreakRule(
           int breakPeriod,
           int maxBreakDrivingPeriod,
           int minBreakPeriod,
           com.ptvag.xserver.xsequence.RemainingPeriods firstBreak) {
        this.breakPeriod = breakPeriod;
        this.maxBreakDrivingPeriod = maxBreakDrivingPeriod;
        this.minBreakPeriod = minBreakPeriod;
        this.firstBreak = firstBreak;
    }


    /**
     * Gets the firstBreak value for this BreakRule.
     * 
     * @return firstBreak
     */
    public com.ptvag.xserver.xsequence.RemainingPeriods getFirstBreak() {
        return firstBreak;
    }


    /**
     * Sets the firstBreak value for this BreakRule.
     * 
     * @param firstBreak
     */
    public void setFirstBreak(com.ptvag.xserver.xsequence.RemainingPeriods firstBreak) {
        this.firstBreak = firstBreak;
    }


    /**
     * Gets the breakPeriod value for this BreakRule.
     * 
     * @return breakPeriod
     */
    public int getBreakPeriod() {
        return breakPeriod;
    }


    /**
     * Sets the breakPeriod value for this BreakRule.
     * 
     * @param breakPeriod
     */
    public void setBreakPeriod(int breakPeriod) {
        this.breakPeriod = breakPeriod;
    }


    /**
     * Gets the maxBreakDrivingPeriod value for this BreakRule.
     * 
     * @return maxBreakDrivingPeriod
     */
    public int getMaxBreakDrivingPeriod() {
        return maxBreakDrivingPeriod;
    }


    /**
     * Sets the maxBreakDrivingPeriod value for this BreakRule.
     * 
     * @param maxBreakDrivingPeriod
     */
    public void setMaxBreakDrivingPeriod(int maxBreakDrivingPeriod) {
        this.maxBreakDrivingPeriod = maxBreakDrivingPeriod;
    }


    /**
     * Gets the minBreakPeriod value for this BreakRule.
     * 
     * @return minBreakPeriod
     */
    public int getMinBreakPeriod() {
        return minBreakPeriod;
    }


    /**
     * Sets the minBreakPeriod value for this BreakRule.
     * 
     * @param minBreakPeriod
     */
    public void setMinBreakPeriod(int minBreakPeriod) {
        this.minBreakPeriod = minBreakPeriod;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BreakRule)) return false;
        BreakRule other = (BreakRule) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.firstBreak==null && other.getFirstBreak()==null) || 
             (this.firstBreak!=null &&
              this.firstBreak.equals(other.getFirstBreak()))) &&
            this.breakPeriod == other.getBreakPeriod() &&
            this.maxBreakDrivingPeriod == other.getMaxBreakDrivingPeriod() &&
            this.minBreakPeriod == other.getMinBreakPeriod();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getFirstBreak() != null) {
            _hashCode += getFirstBreak().hashCode();
        }
        _hashCode += getBreakPeriod();
        _hashCode += getMaxBreakDrivingPeriod();
        _hashCode += getMinBreakPeriod();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BreakRule.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "BreakRule"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("breakPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "breakPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("maxBreakDrivingPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "maxBreakDrivingPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("minBreakPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "minBreakPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstBreak");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "firstBreak"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "RemainingPeriods"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
