/**
 * Color.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class Color  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private int blue;  // attribute

    private int green;  // attribute

    private int red;  // attribute

    public Color() {
    }

    public Color(
           int blue,
           int green,
           int red) {
        this.blue = blue;
        this.green = green;
        this.red = red;
    }


    /**
     * Gets the blue value for this Color.
     * 
     * @return blue
     */
    public int getBlue() {
        return blue;
    }


    /**
     * Sets the blue value for this Color.
     * 
     * @param blue
     */
    public void setBlue(int blue) {
        this.blue = blue;
    }


    /**
     * Gets the green value for this Color.
     * 
     * @return green
     */
    public int getGreen() {
        return green;
    }


    /**
     * Sets the green value for this Color.
     * 
     * @param green
     */
    public void setGreen(int green) {
        this.green = green;
    }


    /**
     * Gets the red value for this Color.
     * 
     * @return red
     */
    public int getRed() {
        return red;
    }


    /**
     * Sets the red value for this Color.
     * 
     * @param red
     */
    public void setRed(int red) {
        this.red = red;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Color)) return false;
        Color other = (Color) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.blue == other.getBlue() &&
            this.green == other.getGreen() &&
            this.red == other.getRed();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getBlue();
        _hashCode += getGreen();
        _hashCode += getRed();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Color.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Color"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("blue");
        attrField.setXmlName(new javax.xml.namespace.QName("", "blue"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("green");
        attrField.setXmlName(new javax.xml.namespace.QName("", "green"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("red");
        attrField.setXmlName(new javax.xml.namespace.QName("", "red"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
