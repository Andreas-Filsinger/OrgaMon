/**
 * ManoeuvreGroup.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class ManoeuvreGroup  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.BoundingRectangle extend;

    private int fromIdx;  // attribute

    private int toIdx;  // attribute

    private com.ptvag.xserver.xroute.ManoeuvreGroupType type;  // attribute

    public ManoeuvreGroup() {
    }

    public ManoeuvreGroup(
           int fromIdx,
           int toIdx,
           com.ptvag.xserver.xroute.ManoeuvreGroupType type,
           com.ptvag.xserver.xroute.BoundingRectangle extend) {
        this.fromIdx = fromIdx;
        this.toIdx = toIdx;
        this.type = type;
        this.extend = extend;
    }


    /**
     * Gets the extend value for this ManoeuvreGroup.
     * 
     * @return extend
     */
    public com.ptvag.xserver.xroute.BoundingRectangle getExtend() {
        return extend;
    }


    /**
     * Sets the extend value for this ManoeuvreGroup.
     * 
     * @param extend
     */
    public void setExtend(com.ptvag.xserver.xroute.BoundingRectangle extend) {
        this.extend = extend;
    }


    /**
     * Gets the fromIdx value for this ManoeuvreGroup.
     * 
     * @return fromIdx
     */
    public int getFromIdx() {
        return fromIdx;
    }


    /**
     * Sets the fromIdx value for this ManoeuvreGroup.
     * 
     * @param fromIdx
     */
    public void setFromIdx(int fromIdx) {
        this.fromIdx = fromIdx;
    }


    /**
     * Gets the toIdx value for this ManoeuvreGroup.
     * 
     * @return toIdx
     */
    public int getToIdx() {
        return toIdx;
    }


    /**
     * Sets the toIdx value for this ManoeuvreGroup.
     * 
     * @param toIdx
     */
    public void setToIdx(int toIdx) {
        this.toIdx = toIdx;
    }


    /**
     * Gets the type value for this ManoeuvreGroup.
     * 
     * @return type
     */
    public com.ptvag.xserver.xroute.ManoeuvreGroupType getType() {
        return type;
    }


    /**
     * Sets the type value for this ManoeuvreGroup.
     * 
     * @param type
     */
    public void setType(com.ptvag.xserver.xroute.ManoeuvreGroupType type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ManoeuvreGroup)) return false;
        ManoeuvreGroup other = (ManoeuvreGroup) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.extend==null && other.getExtend()==null) || 
             (this.extend!=null &&
              this.extend.equals(other.getExtend()))) &&
            this.fromIdx == other.getFromIdx() &&
            this.toIdx == other.getToIdx() &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getExtend() != null) {
            _hashCode += getExtend().hashCode();
        }
        _hashCode += getFromIdx();
        _hashCode += getToIdx();
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ManoeuvreGroup.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreGroup"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("fromIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "fromIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("toIdx");
        attrField.setXmlName(new javax.xml.namespace.QName("", "toIdx"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("type");
        attrField.setXmlName(new javax.xml.namespace.QName("", "type"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreGroupType"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("extend");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "extend"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "BoundingRectangle"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
