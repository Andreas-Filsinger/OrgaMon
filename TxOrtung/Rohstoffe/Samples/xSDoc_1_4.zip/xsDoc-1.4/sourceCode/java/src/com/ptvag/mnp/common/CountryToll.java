/**
 * CountryToll.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class CountryToll  implements java.io.Serializable {
    private java.lang.String country;

    private com.ptvag.mnp.common.RoadSpeedTypeToll[] wrappedRoadSpeedTypeToll;

    private com.ptvag.mnp.common.TollFee tollFeeCountry;

    private java.lang.Double totalDistance;

    private java.lang.Double totalTollDistance;

    public CountryToll() {
    }

    public CountryToll(
           java.lang.String country,
           com.ptvag.mnp.common.RoadSpeedTypeToll[] wrappedRoadSpeedTypeToll,
           com.ptvag.mnp.common.TollFee tollFeeCountry,
           java.lang.Double totalDistance,
           java.lang.Double totalTollDistance) {
           this.country = country;
           this.wrappedRoadSpeedTypeToll = wrappedRoadSpeedTypeToll;
           this.tollFeeCountry = tollFeeCountry;
           this.totalDistance = totalDistance;
           this.totalTollDistance = totalTollDistance;
    }


    /**
     * Gets the country value for this CountryToll.
     * 
     * @return country
     */
    public java.lang.String getCountry() {
        return country;
    }


    /**
     * Sets the country value for this CountryToll.
     * 
     * @param country
     */
    public void setCountry(java.lang.String country) {
        this.country = country;
    }


    /**
     * Gets the wrappedRoadSpeedTypeToll value for this CountryToll.
     * 
     * @return wrappedRoadSpeedTypeToll
     */
    public com.ptvag.mnp.common.RoadSpeedTypeToll[] getWrappedRoadSpeedTypeToll() {
        return wrappedRoadSpeedTypeToll;
    }


    /**
     * Sets the wrappedRoadSpeedTypeToll value for this CountryToll.
     * 
     * @param wrappedRoadSpeedTypeToll
     */
    public void setWrappedRoadSpeedTypeToll(com.ptvag.mnp.common.RoadSpeedTypeToll[] wrappedRoadSpeedTypeToll) {
        this.wrappedRoadSpeedTypeToll = wrappedRoadSpeedTypeToll;
    }


    /**
     * Gets the tollFeeCountry value for this CountryToll.
     * 
     * @return tollFeeCountry
     */
    public com.ptvag.mnp.common.TollFee getTollFeeCountry() {
        return tollFeeCountry;
    }


    /**
     * Sets the tollFeeCountry value for this CountryToll.
     * 
     * @param tollFeeCountry
     */
    public void setTollFeeCountry(com.ptvag.mnp.common.TollFee tollFeeCountry) {
        this.tollFeeCountry = tollFeeCountry;
    }


    /**
     * Gets the totalDistance value for this CountryToll.
     * 
     * @return totalDistance
     */
    public java.lang.Double getTotalDistance() {
        return totalDistance;
    }


    /**
     * Sets the totalDistance value for this CountryToll.
     * 
     * @param totalDistance
     */
    public void setTotalDistance(java.lang.Double totalDistance) {
        this.totalDistance = totalDistance;
    }


    /**
     * Gets the totalTollDistance value for this CountryToll.
     * 
     * @return totalTollDistance
     */
    public java.lang.Double getTotalTollDistance() {
        return totalTollDistance;
    }


    /**
     * Sets the totalTollDistance value for this CountryToll.
     * 
     * @param totalTollDistance
     */
    public void setTotalTollDistance(java.lang.Double totalTollDistance) {
        this.totalTollDistance = totalTollDistance;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CountryToll)) return false;
        CountryToll other = (CountryToll) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.country==null && other.getCountry()==null) || 
             (this.country!=null &&
              this.country.equals(other.getCountry()))) &&
            ((this.wrappedRoadSpeedTypeToll==null && other.getWrappedRoadSpeedTypeToll()==null) || 
             (this.wrappedRoadSpeedTypeToll!=null &&
              java.util.Arrays.equals(this.wrappedRoadSpeedTypeToll, other.getWrappedRoadSpeedTypeToll()))) &&
            ((this.tollFeeCountry==null && other.getTollFeeCountry()==null) || 
             (this.tollFeeCountry!=null &&
              this.tollFeeCountry.equals(other.getTollFeeCountry()))) &&
            ((this.totalDistance==null && other.getTotalDistance()==null) || 
             (this.totalDistance!=null &&
              this.totalDistance.equals(other.getTotalDistance()))) &&
            ((this.totalTollDistance==null && other.getTotalTollDistance()==null) || 
             (this.totalTollDistance!=null &&
              this.totalTollDistance.equals(other.getTotalTollDistance())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCountry() != null) {
            _hashCode += getCountry().hashCode();
        }
        if (getWrappedRoadSpeedTypeToll() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedRoadSpeedTypeToll());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedRoadSpeedTypeToll(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTollFeeCountry() != null) {
            _hashCode += getTollFeeCountry().hashCode();
        }
        if (getTotalDistance() != null) {
            _hashCode += getTotalDistance().hashCode();
        }
        if (getTotalTollDistance() != null) {
            _hashCode += getTotalTollDistance().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CountryToll.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "CountryToll"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("country");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "country"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedRoadSpeedTypeToll");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedRoadSpeedTypeToll"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RoadSpeedTypeToll"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfRoadSpeedTypeToll"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tollFeeCountry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "tollFeeCountry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "TollFee"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalDistance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "totalDistance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalTollDistance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "totalTollDistance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
