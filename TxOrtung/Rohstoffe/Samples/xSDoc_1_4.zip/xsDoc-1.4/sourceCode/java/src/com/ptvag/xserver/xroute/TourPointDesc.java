/**
 * TourPointDesc.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class TourPointDesc  extends com.ptvag.xserver.xroute.WaypointDesc  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.Interval[] wrappedOpeningIntervals;

    private boolean completeServiceInIntervals;  // attribute

    private int servicePeriod;  // attribute

    private boolean useServicePeriodForRecreation;  // attribute

    public TourPointDesc() {
    }

    public TourPointDesc(
           int fuzzyRadius,
           java.lang.Integer heading,
           com.ptvag.xserver.xroute.LinkType linkType,
           java.lang.String street,
           com.ptvag.xserver.common.Point[] wrappedCoords,
           com.ptvag.xserver.xroute.UniqueGeoID nodeID,
           com.ptvag.xserver.xroute.UniqueGeoID[] wrappedSegmentID,
           boolean completeServiceInIntervals,
           int servicePeriod,
           boolean useServicePeriodForRecreation,
           com.ptvag.xserver.xroute.Interval[] wrappedOpeningIntervals) {
        super(
            fuzzyRadius,
            heading,
            linkType,
            street,
            wrappedCoords,
            nodeID,
            wrappedSegmentID);
        this.completeServiceInIntervals = completeServiceInIntervals;
        this.servicePeriod = servicePeriod;
        this.useServicePeriodForRecreation = useServicePeriodForRecreation;
        this.wrappedOpeningIntervals = wrappedOpeningIntervals;
    }


    /**
     * Gets the wrappedOpeningIntervals value for this TourPointDesc.
     * 
     * @return wrappedOpeningIntervals
     */
    public com.ptvag.xserver.xroute.Interval[] getWrappedOpeningIntervals() {
        return wrappedOpeningIntervals;
    }


    /**
     * Sets the wrappedOpeningIntervals value for this TourPointDesc.
     * 
     * @param wrappedOpeningIntervals
     */
    public void setWrappedOpeningIntervals(com.ptvag.xserver.xroute.Interval[] wrappedOpeningIntervals) {
        this.wrappedOpeningIntervals = wrappedOpeningIntervals;
    }


    /**
     * Gets the completeServiceInIntervals value for this TourPointDesc.
     * 
     * @return completeServiceInIntervals
     */
    public boolean isCompleteServiceInIntervals() {
        return completeServiceInIntervals;
    }


    /**
     * Sets the completeServiceInIntervals value for this TourPointDesc.
     * 
     * @param completeServiceInIntervals
     */
    public void setCompleteServiceInIntervals(boolean completeServiceInIntervals) {
        this.completeServiceInIntervals = completeServiceInIntervals;
    }


    /**
     * Gets the servicePeriod value for this TourPointDesc.
     * 
     * @return servicePeriod
     */
    public int getServicePeriod() {
        return servicePeriod;
    }


    /**
     * Sets the servicePeriod value for this TourPointDesc.
     * 
     * @param servicePeriod
     */
    public void setServicePeriod(int servicePeriod) {
        this.servicePeriod = servicePeriod;
    }


    /**
     * Gets the useServicePeriodForRecreation value for this TourPointDesc.
     * 
     * @return useServicePeriodForRecreation
     */
    public boolean isUseServicePeriodForRecreation() {
        return useServicePeriodForRecreation;
    }


    /**
     * Sets the useServicePeriodForRecreation value for this TourPointDesc.
     * 
     * @param useServicePeriodForRecreation
     */
    public void setUseServicePeriodForRecreation(boolean useServicePeriodForRecreation) {
        this.useServicePeriodForRecreation = useServicePeriodForRecreation;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TourPointDesc)) return false;
        TourPointDesc other = (TourPointDesc) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedOpeningIntervals==null && other.getWrappedOpeningIntervals()==null) || 
             (this.wrappedOpeningIntervals!=null &&
              java.util.Arrays.equals(this.wrappedOpeningIntervals, other.getWrappedOpeningIntervals()))) &&
            this.completeServiceInIntervals == other.isCompleteServiceInIntervals() &&
            this.servicePeriod == other.getServicePeriod() &&
            this.useServicePeriodForRecreation == other.isUseServicePeriodForRecreation();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedOpeningIntervals() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedOpeningIntervals());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedOpeningIntervals(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += (isCompleteServiceInIntervals() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getServicePeriod();
        _hashCode += (isUseServicePeriodForRecreation() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TourPointDesc.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TourPointDesc"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("completeServiceInIntervals");
        attrField.setXmlName(new javax.xml.namespace.QName("", "completeServiceInIntervals"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("servicePeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "servicePeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("useServicePeriodForRecreation");
        attrField.setXmlName(new javax.xml.namespace.QName("", "useServicePeriodForRecreation"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedOpeningIntervals");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedOpeningIntervals"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Interval"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Interval"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
