/**
 * CoordFormat.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.common;

public class CoordFormat implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected CoordFormat(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _OG_GEODECIMAL = "OG_GEODECIMAL";
    public static final java.lang.String _PTV_MERCATOR = "PTV_MERCATOR";
    public static final java.lang.String _PTV_GEOMINSEC = "PTV_GEOMINSEC";
    public static final java.lang.String _PTV_GEODECIMAL = "PTV_GEODECIMAL";
    public static final java.lang.String _PTV_CONFORM = "PTV_CONFORM";
    public static final java.lang.String _PTV_SUPERCONFORM = "PTV_SUPERCONFORM";
    public static final java.lang.String _PTV_SMARTUNITS = "PTV_SMARTUNITS";
    public static final CoordFormat OG_GEODECIMAL = new CoordFormat(_OG_GEODECIMAL);
    public static final CoordFormat PTV_MERCATOR = new CoordFormat(_PTV_MERCATOR);
    public static final CoordFormat PTV_GEOMINSEC = new CoordFormat(_PTV_GEOMINSEC);
    public static final CoordFormat PTV_GEODECIMAL = new CoordFormat(_PTV_GEODECIMAL);
    public static final CoordFormat PTV_CONFORM = new CoordFormat(_PTV_CONFORM);
    public static final CoordFormat PTV_SUPERCONFORM = new CoordFormat(_PTV_SUPERCONFORM);
    public static final CoordFormat PTV_SMARTUNITS = new CoordFormat(_PTV_SMARTUNITS);
    public java.lang.String getValue() { return _value_;}
    public static CoordFormat fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        CoordFormat enumeration = (CoordFormat)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static CoordFormat fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CoordFormat.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "CoordFormat"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
