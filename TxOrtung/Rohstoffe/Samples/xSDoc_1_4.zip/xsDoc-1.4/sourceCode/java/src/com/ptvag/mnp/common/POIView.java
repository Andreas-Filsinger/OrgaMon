/**
 * POIView.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class POIView  implements java.io.Serializable {
    private com.ptvag.mnp.common.BoundingBox boundingRect;

    private com.ptvag.mnp.common.POIContext context;

    private com.ptvag.mnp.common.Coordinate coordinate;

    private java.lang.Integer index;

    private java.lang.String poiID;

    private java.lang.String[] wrappedValues;

    private byte[] wkbGeometry;

    public POIView() {
    }

    public POIView(
           com.ptvag.mnp.common.BoundingBox boundingRect,
           com.ptvag.mnp.common.POIContext context,
           com.ptvag.mnp.common.Coordinate coordinate,
           java.lang.Integer index,
           java.lang.String poiID,
           java.lang.String[] wrappedValues,
           byte[] wkbGeometry) {
           this.boundingRect = boundingRect;
           this.context = context;
           this.coordinate = coordinate;
           this.index = index;
           this.poiID = poiID;
           this.wrappedValues = wrappedValues;
           this.wkbGeometry = wkbGeometry;
    }


    /**
     * Gets the boundingRect value for this POIView.
     * 
     * @return boundingRect
     */
    public com.ptvag.mnp.common.BoundingBox getBoundingRect() {
        return boundingRect;
    }


    /**
     * Sets the boundingRect value for this POIView.
     * 
     * @param boundingRect
     */
    public void setBoundingRect(com.ptvag.mnp.common.BoundingBox boundingRect) {
        this.boundingRect = boundingRect;
    }


    /**
     * Gets the context value for this POIView.
     * 
     * @return context
     */
    public com.ptvag.mnp.common.POIContext getContext() {
        return context;
    }


    /**
     * Sets the context value for this POIView.
     * 
     * @param context
     */
    public void setContext(com.ptvag.mnp.common.POIContext context) {
        this.context = context;
    }


    /**
     * Gets the coordinate value for this POIView.
     * 
     * @return coordinate
     */
    public com.ptvag.mnp.common.Coordinate getCoordinate() {
        return coordinate;
    }


    /**
     * Sets the coordinate value for this POIView.
     * 
     * @param coordinate
     */
    public void setCoordinate(com.ptvag.mnp.common.Coordinate coordinate) {
        this.coordinate = coordinate;
    }


    /**
     * Gets the index value for this POIView.
     * 
     * @return index
     */
    public java.lang.Integer getIndex() {
        return index;
    }


    /**
     * Sets the index value for this POIView.
     * 
     * @param index
     */
    public void setIndex(java.lang.Integer index) {
        this.index = index;
    }


    /**
     * Gets the poiID value for this POIView.
     * 
     * @return poiID
     */
    public java.lang.String getPoiID() {
        return poiID;
    }


    /**
     * Sets the poiID value for this POIView.
     * 
     * @param poiID
     */
    public void setPoiID(java.lang.String poiID) {
        this.poiID = poiID;
    }


    /**
     * Gets the wrappedValues value for this POIView.
     * 
     * @return wrappedValues
     */
    public java.lang.String[] getWrappedValues() {
        return wrappedValues;
    }


    /**
     * Sets the wrappedValues value for this POIView.
     * 
     * @param wrappedValues
     */
    public void setWrappedValues(java.lang.String[] wrappedValues) {
        this.wrappedValues = wrappedValues;
    }


    /**
     * Gets the wkbGeometry value for this POIView.
     * 
     * @return wkbGeometry
     */
    public byte[] getWkbGeometry() {
        return wkbGeometry;
    }


    /**
     * Sets the wkbGeometry value for this POIView.
     * 
     * @param wkbGeometry
     */
    public void setWkbGeometry(byte[] wkbGeometry) {
        this.wkbGeometry = wkbGeometry;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof POIView)) return false;
        POIView other = (POIView) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.boundingRect==null && other.getBoundingRect()==null) || 
             (this.boundingRect!=null &&
              this.boundingRect.equals(other.getBoundingRect()))) &&
            ((this.context==null && other.getContext()==null) || 
             (this.context!=null &&
              this.context.equals(other.getContext()))) &&
            ((this.coordinate==null && other.getCoordinate()==null) || 
             (this.coordinate!=null &&
              this.coordinate.equals(other.getCoordinate()))) &&
            ((this.index==null && other.getIndex()==null) || 
             (this.index!=null &&
              this.index.equals(other.getIndex()))) &&
            ((this.poiID==null && other.getPoiID()==null) || 
             (this.poiID!=null &&
              this.poiID.equals(other.getPoiID()))) &&
            ((this.wrappedValues==null && other.getWrappedValues()==null) || 
             (this.wrappedValues!=null &&
              java.util.Arrays.equals(this.wrappedValues, other.getWrappedValues()))) &&
            ((this.wkbGeometry==null && other.getWkbGeometry()==null) || 
             (this.wkbGeometry!=null &&
              java.util.Arrays.equals(this.wkbGeometry, other.getWkbGeometry())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBoundingRect() != null) {
            _hashCode += getBoundingRect().hashCode();
        }
        if (getContext() != null) {
            _hashCode += getContext().hashCode();
        }
        if (getCoordinate() != null) {
            _hashCode += getCoordinate().hashCode();
        }
        if (getIndex() != null) {
            _hashCode += getIndex().hashCode();
        }
        if (getPoiID() != null) {
            _hashCode += getPoiID().hashCode();
        }
        if (getWrappedValues() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedValues());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedValues(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWkbGeometry() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWkbGeometry());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWkbGeometry(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(POIView.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIView"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boundingRect");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "boundingRect"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BoundingBox"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("context");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "context"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIContext"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("coordinate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "coordinate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Coordinate"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("poiID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "poiID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedValues");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedValues"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wkbGeometry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wkbGeometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
