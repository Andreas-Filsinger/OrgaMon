/**
 * XRouteWSBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute.jwsdp;

public class XRouteWSBindingStub extends org.apache.axis.client.Stub implements com.ptvag.xserver.xroute.jwsdp.XRouteWS {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[7];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("calculateExtendedRoute");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfWaypointDesc_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfWaypointDesc"), com.ptvag.xserver.xroute.WaypointDesc[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfRoutingOption_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfRoutingOption"), com.ptvag.xserver.xroute.RoutingOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RoutingOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfExceptionPath_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfExceptionPath"), com.ptvag.xserver.xroute.ExceptionPath[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExceptionPath"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ResultListOptions_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ResultListOptions"), com.ptvag.xserver.xroute.ResultListOptions.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "CountryInfoOptions_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "CountryInfoOptions"), com.ptvag.xserver.xroute.CountryInfoOptions.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "CallerContext_6"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExtendedRoute"));
        oper.setReturnClass(com.ptvag.xserver.xroute.ExtendedRoute.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"),
                      "com.ptvag.xserver.xroute.XRouteException",
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("calculateIsochrones");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "WaypointDesc_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc"), com.ptvag.xserver.xroute.WaypointDesc.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfRoutingOption_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfRoutingOption"), com.ptvag.xserver.xroute.RoutingOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RoutingOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "IsochroneOptions_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneOptions"), com.ptvag.xserver.xroute.IsochroneOptions.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "CallerContext_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Isochrone"));
        oper.setReturnClass(com.ptvag.xserver.xroute.Isochrone.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"),
                      "com.ptvag.xserver.xroute.XRouteException",
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("calculateMatrixInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfWaypointDesc_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfWaypointDesc"), com.ptvag.xserver.xroute.WaypointDesc[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfWaypointDesc_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfWaypointDesc"), com.ptvag.xserver.xroute.WaypointDesc[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfRoutingOption_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfRoutingOption"), com.ptvag.xserver.xroute.RoutingOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RoutingOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "MatrixOptions_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "MatrixOptions"), com.ptvag.xserver.xroute.MatrixOptions.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "MatrixInfo"));
        oper.setReturnClass(com.ptvag.xserver.xroute.MatrixInfo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"),
                      "com.ptvag.xserver.xroute.XRouteException",
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("calculateReachableObjects");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "WaypointDesc_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc"), com.ptvag.xserver.xroute.WaypointDesc.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "String_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfWaypointDesc_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfWaypointDesc"), com.ptvag.xserver.xroute.WaypointDesc[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfRoutingOption_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfRoutingOption"), com.ptvag.xserver.xroute.RoutingOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RoutingOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ExpansionDescription_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExpansionDescription"), com.ptvag.xserver.xroute.ExpansionDescription.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "CallerContext_6"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Reach"));
        oper.setReturnClass(com.ptvag.xserver.xroute.Reach.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"),
                      "com.ptvag.xserver.xroute.XRouteException",
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("calculateRoute");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfWaypointDesc_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfWaypointDesc"), com.ptvag.xserver.xroute.WaypointDesc[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfRoutingOption_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfRoutingOption"), com.ptvag.xserver.xroute.RoutingOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RoutingOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfExceptionPath_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfExceptionPath"), com.ptvag.xserver.xroute.ExceptionPath[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExceptionPath"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ResultListOptions_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ResultListOptions"), com.ptvag.xserver.xroute.ResultListOptions.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Route"));
        oper.setReturnClass(com.ptvag.xserver.xroute.Route.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"),
                      "com.ptvag.xserver.xroute.XRouteException",
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("calculateRouteInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfWaypointDesc_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfWaypointDesc"), com.ptvag.xserver.xroute.WaypointDesc[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfRoutingOption_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfRoutingOption"), com.ptvag.xserver.xroute.RoutingOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RoutingOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfExceptionPath_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfExceptionPath"), com.ptvag.xserver.xroute.ExceptionPath[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExceptionPath"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "CallerContext_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteInfo"));
        oper.setReturnClass(com.ptvag.xserver.xroute.RouteInfo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"),
                      "com.ptvag.xserver.xroute.XRouteException",
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("calculateTour");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfWaypointDesc_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfWaypointDesc"), com.ptvag.xserver.xroute.WaypointDesc[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfRoutingOption_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfRoutingOption"), com.ptvag.xserver.xroute.RoutingOption[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RoutingOption"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ArrayOfExceptionPath_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfExceptionPath"), com.ptvag.xserver.xroute.ExceptionPath[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExceptionPath"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "ResultListOptions_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ResultListOptions"), com.ptvag.xserver.xroute.ResultListOptions.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "CountryInfoOptions_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "CountryInfoOptions"), com.ptvag.xserver.xroute.CountryInfoOptions.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "CallerContext_6"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Tour"));
        oper.setReturnClass(com.ptvag.xserver.xroute.Tour.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"),
                      "com.ptvag.jabba.core.exception.SystemException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"),
                      "com.ptvag.jabba.core.exception.UnexpectedException",
                      new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"),
                      "com.ptvag.xserver.xroute.XRouteException",
                      new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"),
                      "com.ptvag.xserver.common.XServiceException",
                      new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException"), 
                      true
                     ));
        _operations[6] = oper;

    }

    public XRouteWSBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public XRouteWSBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public XRouteWSBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
        addBindings0();
        addBindings1();
    }

    private void addBindings0() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "ArrayOfCallerContextProperty");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.CallerContextProperty[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty");
            qName2 = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.CallerContext.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.CallerContextProperty.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfGeometryEncoding");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.GeometryEncoding[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryEncoding");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryEncoding");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainGeometryBase");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainGeometryBase[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryBase");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryBase");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainLinearRing");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainLinearRing[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLinearRing");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLinearRing");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainLineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainLineString[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLineString");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLineString");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainPoint[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPlainPolygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainPolygon[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPolygon");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPolygon");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "ArrayOfPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.Point[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point");
            qName2 = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "BoundingBox");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.BoundingBox.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "CoordFormat");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.CoordFormat.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "EncodedGeometry");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.EncodedGeometry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "EncodedGeometryBase");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.EncodedGeometryBase.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryCollection");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.GeometryCollection.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "GeometryEncoding");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.GeometryEncoding.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "LinearRing");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.LinearRing.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "LineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.LineString.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "MultiLineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.MultiLineString.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "MultiPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.MultiPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "MultiPolygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.MultiPolygon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryBase");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainGeometryBase.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainGeometryCollection");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainGeometryCollection.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLinearRing");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainLinearRing.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainLineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainLineString.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainMultiLineString");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainMultiLineString.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainMultiPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainMultiPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainMultiPolygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainMultiPolygon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "PlainPolygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.PlainPolygon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.Point.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Polygon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.Polygon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "RequestOptions");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.RequestOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "XServiceException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.common.XServiceException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "BaseException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.BaseException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "BusinessException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.BusinessException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "IllegalParameterException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.IllegalParameterException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "ParameterNotSetException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.ParameterNotSetException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "RemoteAccessException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.RemoteAccessException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "StackElement");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.StackElement.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "SystemException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.SystemException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.core.jabba.ptvag.com", "UnexpectedException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.exception.UnexpectedException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.messaging.service.jabba.ptvag.com", "MessagingServiceException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.messaging.exception.MessagingServiceException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://value.core.jabba.ptvag.com", "TransientVO");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.core.value.TransientVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfInt");
            cachedSerQNames.add(qName);
            cls = int[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int");
            qName2 = new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "Int");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "String");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfBoundingRectangle");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.BoundingRectangle[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "BoundingRectangle");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "BoundingRectangle");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfCountryInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.CountryInfo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "CountryInfo");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "CountryInfo");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfExceptionPath");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ExceptionPath[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExceptionPath");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExceptionPath");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfInterval");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.Interval[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Interval");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Interval");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfIsochroneInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.IsochroneInfo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneInfo");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneInfo");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfManoeuvreGroup");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ManoeuvreGroup[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreGroup");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreGroup");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfReachInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ReachInfo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ReachInfo");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ReachInfo");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfRouteInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.RouteInfo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteInfo");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteInfo");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfRouteListSegment");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.RouteListSegment[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteListSegment");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteListSegment");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfRouteManoeuvre");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.RouteManoeuvre[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteManoeuvre");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteManoeuvre");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfRoutingOption");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.RoutingOption[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RoutingOption");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RoutingOption");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfTimeEvent");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TimeEvent[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TimeEvent");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TimeEvent");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfTollCostInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TollCostInfo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TollCostInfo");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TollCostInfo");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfTourPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TourPoint[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TourPoint");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TourPoint");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfUniqueGeoID");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.UniqueGeoID[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfVehicleOption");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.VehicleOption[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "VehicleOption");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "VehicleOption");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfWayPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.WayPoint[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WayPoint");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WayPoint");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ArrayOfWaypointDesc");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.WaypointDesc[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc");
            qName2 = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "BoundingRectangle");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.BoundingRectangle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "BrunnelCode");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.BrunnelCode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "BrunnelManoeuvre");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.BrunnelManoeuvre.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "CountryInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.CountryInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "CountryInfoOptions");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.CountryInfoOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "CountryInfoVehicleOptions");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.CountryInfoVehicleOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Currency");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.Currency.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "DetailDescriptionOption");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.DetailDescriptionOption.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "DetailLevel");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.DetailLevel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "DynamicInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.DynamicInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExceptionPath");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ExceptionPath.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExpansionDescription");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ExpansionDescription.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExpansionType");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ExpansionType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExtendedRoute");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ExtendedRoute.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExtWayPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ExtWayPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "InfoNodeType");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.InfoNodeType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Interval");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.Interval.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Isochrone");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.Isochrone.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneDetail");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.IsochroneDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.IsochroneInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneOptions");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.IsochroneOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneSegment");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.IsochroneSegment.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "LinkType");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.LinkType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreAttributes");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ManoeuvreAttributes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreGroup");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ManoeuvreGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreGroupType");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ManoeuvreGroupType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ManoeuvreType");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ManoeuvreType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "MatrixInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.MatrixInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "MatrixOptions");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.MatrixOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "NetworkClass");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.NetworkClass.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Reach");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.Reach.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ReachInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ReachInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ResultListOptions");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.ResultListOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Route");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.Route.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.RouteInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteListSegment");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.RouteListSegment.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings1() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteManoeuvre");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.RouteManoeuvre.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RoutingOption");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.RoutingOption.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RoutingParameter");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.RoutingParameter.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "SegmentAttributes");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.SegmentAttributes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TimeEvent");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TimeEvent.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TimeEventType");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TimeEventType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TollCostInfo");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TollCostInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TollStationDescription");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TollStationDescription.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TollType");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TollType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Tour");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.Tour.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TourPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TourPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TourPointDesc");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TourPointDesc.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TourSummary");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TourSummary.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TurnOrient");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TurnOrient.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TurnWeight");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.TurnWeight.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.UniqueGeoID.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UrbanManoeuvre");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.UrbanManoeuvre.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "VehicleOption");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.VehicleOption.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "VehicleParameter");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.VehicleParameter.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WayPoint");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.WayPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WaypointDesc");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.WaypointDesc.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "WayPointType");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.WayPointType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "XRouteException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.xserver.xroute.XRouteException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.ptvag.xserver.xroute.ExtendedRoute calculateExtendedRoute(com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_1, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_2, com.ptvag.xserver.xroute.ExceptionPath[] arrayOfExceptionPath_3, com.ptvag.xserver.xroute.ResultListOptions resultListOptions_4, com.ptvag.xserver.xroute.CountryInfoOptions countryInfoOptions_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "calculateExtendedRoute"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfWaypointDesc_1, arrayOfRoutingOption_2, arrayOfExceptionPath_3, resultListOptions_4, countryInfoOptions_5, callerContext_6});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xroute.ExtendedRoute) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xroute.ExtendedRoute) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xroute.ExtendedRoute.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xroute.XRouteException) {
              throw (com.ptvag.xserver.xroute.XRouteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xroute.Isochrone calculateIsochrones(com.ptvag.xserver.xroute.WaypointDesc waypointDesc_1, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_2, com.ptvag.xserver.xroute.IsochroneOptions isochroneOptions_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "calculateIsochrones"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {waypointDesc_1, arrayOfRoutingOption_2, isochroneOptions_3, callerContext_4});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xroute.Isochrone) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xroute.Isochrone) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xroute.Isochrone.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xroute.XRouteException) {
              throw (com.ptvag.xserver.xroute.XRouteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xroute.MatrixInfo calculateMatrixInfo(com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_1, com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_2, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_3, com.ptvag.xserver.xroute.MatrixOptions matrixOptions_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "calculateMatrixInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfWaypointDesc_1, arrayOfWaypointDesc_2, arrayOfRoutingOption_3, matrixOptions_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xroute.MatrixInfo) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xroute.MatrixInfo) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xroute.MatrixInfo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xroute.XRouteException) {
              throw (com.ptvag.xserver.xroute.XRouteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xroute.Reach calculateReachableObjects(com.ptvag.xserver.xroute.WaypointDesc waypointDesc_1, java.lang.String string_2, com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_3, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_4, com.ptvag.xserver.xroute.ExpansionDescription expansionDescription_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "calculateReachableObjects"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {waypointDesc_1, string_2, arrayOfWaypointDesc_3, arrayOfRoutingOption_4, expansionDescription_5, callerContext_6});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xroute.Reach) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xroute.Reach) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xroute.Reach.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xroute.XRouteException) {
              throw (com.ptvag.xserver.xroute.XRouteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xroute.Route calculateRoute(com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_1, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_2, com.ptvag.xserver.xroute.ExceptionPath[] arrayOfExceptionPath_3, com.ptvag.xserver.xroute.ResultListOptions resultListOptions_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "calculateRoute"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfWaypointDesc_1, arrayOfRoutingOption_2, arrayOfExceptionPath_3, resultListOptions_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xroute.Route) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xroute.Route) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xroute.Route.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xroute.XRouteException) {
              throw (com.ptvag.xserver.xroute.XRouteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xroute.RouteInfo calculateRouteInfo(com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_1, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_2, com.ptvag.xserver.xroute.ExceptionPath[] arrayOfExceptionPath_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "calculateRouteInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfWaypointDesc_1, arrayOfRoutingOption_2, arrayOfExceptionPath_3, callerContext_4});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xroute.RouteInfo) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xroute.RouteInfo) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xroute.RouteInfo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xroute.XRouteException) {
              throw (com.ptvag.xserver.xroute.XRouteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.xserver.xroute.Tour calculateTour(com.ptvag.xserver.xroute.WaypointDesc[] arrayOfWaypointDesc_1, com.ptvag.xserver.xroute.RoutingOption[] arrayOfRoutingOption_2, com.ptvag.xserver.xroute.ExceptionPath[] arrayOfExceptionPath_3, com.ptvag.xserver.xroute.ResultListOptions resultListOptions_4, com.ptvag.xserver.xroute.CountryInfoOptions countryInfoOptions_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.core.exception.SystemException, com.ptvag.jabba.core.exception.UnexpectedException, com.ptvag.xserver.xroute.XRouteException, com.ptvag.xserver.common.XServiceException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.xroute.xserver.ptvag.com", "calculateTour"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfWaypointDesc_1, arrayOfRoutingOption_2, arrayOfExceptionPath_3, resultListOptions_4, countryInfoOptions_5, callerContext_6});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.xserver.xroute.Tour) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.xserver.xroute.Tour) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.xserver.xroute.Tour.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.SystemException) {
              throw (com.ptvag.jabba.core.exception.SystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.core.exception.UnexpectedException) {
              throw (com.ptvag.jabba.core.exception.UnexpectedException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.xroute.XRouteException) {
              throw (com.ptvag.xserver.xroute.XRouteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.xserver.common.XServiceException) {
              throw (com.ptvag.xserver.common.XServiceException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

}
