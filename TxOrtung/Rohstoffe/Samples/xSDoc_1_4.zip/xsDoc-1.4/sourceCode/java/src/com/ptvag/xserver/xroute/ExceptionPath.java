/**
 * ExceptionPath.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class ExceptionPath  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.UniqueGeoID[] wrappedNodes;

    private java.lang.Integer absTimeMalus;  // attribute

    private java.lang.String binaryPathDesc;  // attribute

    private java.lang.String extSegments;  // attribute

    private int relMalus;  // attribute

    private java.lang.String street;  // attribute

    public ExceptionPath() {
    }

    public ExceptionPath(
           java.lang.Integer absTimeMalus,
           java.lang.String binaryPathDesc,
           java.lang.String extSegments,
           int relMalus,
           java.lang.String street,
           com.ptvag.xserver.xroute.UniqueGeoID[] wrappedNodes) {
        this.absTimeMalus = absTimeMalus;
        this.binaryPathDesc = binaryPathDesc;
        this.extSegments = extSegments;
        this.relMalus = relMalus;
        this.street = street;
        this.wrappedNodes = wrappedNodes;
    }


    /**
     * Gets the wrappedNodes value for this ExceptionPath.
     * 
     * @return wrappedNodes
     */
    public com.ptvag.xserver.xroute.UniqueGeoID[] getWrappedNodes() {
        return wrappedNodes;
    }


    /**
     * Sets the wrappedNodes value for this ExceptionPath.
     * 
     * @param wrappedNodes
     */
    public void setWrappedNodes(com.ptvag.xserver.xroute.UniqueGeoID[] wrappedNodes) {
        this.wrappedNodes = wrappedNodes;
    }


    /**
     * Gets the absTimeMalus value for this ExceptionPath.
     * 
     * @return absTimeMalus
     */
    public java.lang.Integer getAbsTimeMalus() {
        return absTimeMalus;
    }


    /**
     * Sets the absTimeMalus value for this ExceptionPath.
     * 
     * @param absTimeMalus
     */
    public void setAbsTimeMalus(java.lang.Integer absTimeMalus) {
        this.absTimeMalus = absTimeMalus;
    }


    /**
     * Gets the binaryPathDesc value for this ExceptionPath.
     * 
     * @return binaryPathDesc
     */
    public java.lang.String getBinaryPathDesc() {
        return binaryPathDesc;
    }


    /**
     * Sets the binaryPathDesc value for this ExceptionPath.
     * 
     * @param binaryPathDesc
     */
    public void setBinaryPathDesc(java.lang.String binaryPathDesc) {
        this.binaryPathDesc = binaryPathDesc;
    }


    /**
     * Gets the extSegments value for this ExceptionPath.
     * 
     * @return extSegments
     */
    public java.lang.String getExtSegments() {
        return extSegments;
    }


    /**
     * Sets the extSegments value for this ExceptionPath.
     * 
     * @param extSegments
     */
    public void setExtSegments(java.lang.String extSegments) {
        this.extSegments = extSegments;
    }


    /**
     * Gets the relMalus value for this ExceptionPath.
     * 
     * @return relMalus
     */
    public int getRelMalus() {
        return relMalus;
    }


    /**
     * Sets the relMalus value for this ExceptionPath.
     * 
     * @param relMalus
     */
    public void setRelMalus(int relMalus) {
        this.relMalus = relMalus;
    }


    /**
     * Gets the street value for this ExceptionPath.
     * 
     * @return street
     */
    public java.lang.String getStreet() {
        return street;
    }


    /**
     * Sets the street value for this ExceptionPath.
     * 
     * @param street
     */
    public void setStreet(java.lang.String street) {
        this.street = street;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ExceptionPath)) return false;
        ExceptionPath other = (ExceptionPath) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedNodes==null && other.getWrappedNodes()==null) || 
             (this.wrappedNodes!=null &&
              java.util.Arrays.equals(this.wrappedNodes, other.getWrappedNodes()))) &&
            ((this.absTimeMalus==null && other.getAbsTimeMalus()==null) || 
             (this.absTimeMalus!=null &&
              this.absTimeMalus.equals(other.getAbsTimeMalus()))) &&
            ((this.binaryPathDesc==null && other.getBinaryPathDesc()==null) || 
             (this.binaryPathDesc!=null &&
              this.binaryPathDesc.equals(other.getBinaryPathDesc()))) &&
            ((this.extSegments==null && other.getExtSegments()==null) || 
             (this.extSegments!=null &&
              this.extSegments.equals(other.getExtSegments()))) &&
            this.relMalus == other.getRelMalus() &&
            ((this.street==null && other.getStreet()==null) || 
             (this.street!=null &&
              this.street.equals(other.getStreet())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedNodes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedNodes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedNodes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAbsTimeMalus() != null) {
            _hashCode += getAbsTimeMalus().hashCode();
        }
        if (getBinaryPathDesc() != null) {
            _hashCode += getBinaryPathDesc().hashCode();
        }
        if (getExtSegments() != null) {
            _hashCode += getExtSegments().hashCode();
        }
        _hashCode += getRelMalus();
        if (getStreet() != null) {
            _hashCode += getStreet().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ExceptionPath.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExceptionPath"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("absTimeMalus");
        attrField.setXmlName(new javax.xml.namespace.QName("", "absTimeMalus"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("binaryPathDesc");
        attrField.setXmlName(new javax.xml.namespace.QName("", "binaryPathDesc"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("extSegments");
        attrField.setXmlName(new javax.xml.namespace.QName("", "extSegments"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relMalus");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relMalus"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("street");
        attrField.setXmlName(new javax.xml.namespace.QName("", "street"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedNodes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedNodes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
