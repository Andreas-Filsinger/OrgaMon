/**
 * RouteElement.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class RouteElement  implements java.io.Serializable {
    private com.ptvag.mnp.common.POIViewSet[] wrappedAttached;

    private com.ptvag.mnp.common.Coordinate coordinate;

    private java.lang.Double diffDistance;

    private java.lang.Long diffTime;

    private java.lang.String direction;

    private java.lang.Double distance;

    private java.lang.String fromInfo;

    private java.lang.String nodeInfo;

    private com.ptvag.mnp.common.NodeTypeEnum nodeType;

    private com.ptvag.mnp.common.RouteElementMapRef reMapRef;

    private java.lang.String sign;

    private com.ptvag.mnp.common.StreetTypeEnum streetType;

    private java.lang.String textInfo;

    private java.util.Calendar time;

    private java.lang.String toInfo;

    private com.ptvag.mnp.common.TurnSymbolEnum turn;

    private com.ptvag.mnp.common.RouteElementTypeEnum type;

    public RouteElement() {
    }

    public RouteElement(
           com.ptvag.mnp.common.POIViewSet[] wrappedAttached,
           com.ptvag.mnp.common.Coordinate coordinate,
           java.lang.Double diffDistance,
           java.lang.Long diffTime,
           java.lang.String direction,
           java.lang.Double distance,
           java.lang.String fromInfo,
           java.lang.String nodeInfo,
           com.ptvag.mnp.common.NodeTypeEnum nodeType,
           com.ptvag.mnp.common.RouteElementMapRef reMapRef,
           java.lang.String sign,
           com.ptvag.mnp.common.StreetTypeEnum streetType,
           java.lang.String textInfo,
           java.util.Calendar time,
           java.lang.String toInfo,
           com.ptvag.mnp.common.TurnSymbolEnum turn,
           com.ptvag.mnp.common.RouteElementTypeEnum type) {
           this.wrappedAttached = wrappedAttached;
           this.coordinate = coordinate;
           this.diffDistance = diffDistance;
           this.diffTime = diffTime;
           this.direction = direction;
           this.distance = distance;
           this.fromInfo = fromInfo;
           this.nodeInfo = nodeInfo;
           this.nodeType = nodeType;
           this.reMapRef = reMapRef;
           this.sign = sign;
           this.streetType = streetType;
           this.textInfo = textInfo;
           this.time = time;
           this.toInfo = toInfo;
           this.turn = turn;
           this.type = type;
    }


    /**
     * Gets the wrappedAttached value for this RouteElement.
     * 
     * @return wrappedAttached
     */
    public com.ptvag.mnp.common.POIViewSet[] getWrappedAttached() {
        return wrappedAttached;
    }


    /**
     * Sets the wrappedAttached value for this RouteElement.
     * 
     * @param wrappedAttached
     */
    public void setWrappedAttached(com.ptvag.mnp.common.POIViewSet[] wrappedAttached) {
        this.wrappedAttached = wrappedAttached;
    }


    /**
     * Gets the coordinate value for this RouteElement.
     * 
     * @return coordinate
     */
    public com.ptvag.mnp.common.Coordinate getCoordinate() {
        return coordinate;
    }


    /**
     * Sets the coordinate value for this RouteElement.
     * 
     * @param coordinate
     */
    public void setCoordinate(com.ptvag.mnp.common.Coordinate coordinate) {
        this.coordinate = coordinate;
    }


    /**
     * Gets the diffDistance value for this RouteElement.
     * 
     * @return diffDistance
     */
    public java.lang.Double getDiffDistance() {
        return diffDistance;
    }


    /**
     * Sets the diffDistance value for this RouteElement.
     * 
     * @param diffDistance
     */
    public void setDiffDistance(java.lang.Double diffDistance) {
        this.diffDistance = diffDistance;
    }


    /**
     * Gets the diffTime value for this RouteElement.
     * 
     * @return diffTime
     */
    public java.lang.Long getDiffTime() {
        return diffTime;
    }


    /**
     * Sets the diffTime value for this RouteElement.
     * 
     * @param diffTime
     */
    public void setDiffTime(java.lang.Long diffTime) {
        this.diffTime = diffTime;
    }


    /**
     * Gets the direction value for this RouteElement.
     * 
     * @return direction
     */
    public java.lang.String getDirection() {
        return direction;
    }


    /**
     * Sets the direction value for this RouteElement.
     * 
     * @param direction
     */
    public void setDirection(java.lang.String direction) {
        this.direction = direction;
    }


    /**
     * Gets the distance value for this RouteElement.
     * 
     * @return distance
     */
    public java.lang.Double getDistance() {
        return distance;
    }


    /**
     * Sets the distance value for this RouteElement.
     * 
     * @param distance
     */
    public void setDistance(java.lang.Double distance) {
        this.distance = distance;
    }


    /**
     * Gets the fromInfo value for this RouteElement.
     * 
     * @return fromInfo
     */
    public java.lang.String getFromInfo() {
        return fromInfo;
    }


    /**
     * Sets the fromInfo value for this RouteElement.
     * 
     * @param fromInfo
     */
    public void setFromInfo(java.lang.String fromInfo) {
        this.fromInfo = fromInfo;
    }


    /**
     * Gets the nodeInfo value for this RouteElement.
     * 
     * @return nodeInfo
     */
    public java.lang.String getNodeInfo() {
        return nodeInfo;
    }


    /**
     * Sets the nodeInfo value for this RouteElement.
     * 
     * @param nodeInfo
     */
    public void setNodeInfo(java.lang.String nodeInfo) {
        this.nodeInfo = nodeInfo;
    }


    /**
     * Gets the nodeType value for this RouteElement.
     * 
     * @return nodeType
     */
    public com.ptvag.mnp.common.NodeTypeEnum getNodeType() {
        return nodeType;
    }


    /**
     * Sets the nodeType value for this RouteElement.
     * 
     * @param nodeType
     */
    public void setNodeType(com.ptvag.mnp.common.NodeTypeEnum nodeType) {
        this.nodeType = nodeType;
    }


    /**
     * Gets the reMapRef value for this RouteElement.
     * 
     * @return reMapRef
     */
    public com.ptvag.mnp.common.RouteElementMapRef getReMapRef() {
        return reMapRef;
    }


    /**
     * Sets the reMapRef value for this RouteElement.
     * 
     * @param reMapRef
     */
    public void setReMapRef(com.ptvag.mnp.common.RouteElementMapRef reMapRef) {
        this.reMapRef = reMapRef;
    }


    /**
     * Gets the sign value for this RouteElement.
     * 
     * @return sign
     */
    public java.lang.String getSign() {
        return sign;
    }


    /**
     * Sets the sign value for this RouteElement.
     * 
     * @param sign
     */
    public void setSign(java.lang.String sign) {
        this.sign = sign;
    }


    /**
     * Gets the streetType value for this RouteElement.
     * 
     * @return streetType
     */
    public com.ptvag.mnp.common.StreetTypeEnum getStreetType() {
        return streetType;
    }


    /**
     * Sets the streetType value for this RouteElement.
     * 
     * @param streetType
     */
    public void setStreetType(com.ptvag.mnp.common.StreetTypeEnum streetType) {
        this.streetType = streetType;
    }


    /**
     * Gets the textInfo value for this RouteElement.
     * 
     * @return textInfo
     */
    public java.lang.String getTextInfo() {
        return textInfo;
    }


    /**
     * Sets the textInfo value for this RouteElement.
     * 
     * @param textInfo
     */
    public void setTextInfo(java.lang.String textInfo) {
        this.textInfo = textInfo;
    }


    /**
     * Gets the time value for this RouteElement.
     * 
     * @return time
     */
    public java.util.Calendar getTime() {
        return time;
    }


    /**
     * Sets the time value for this RouteElement.
     * 
     * @param time
     */
    public void setTime(java.util.Calendar time) {
        this.time = time;
    }


    /**
     * Gets the toInfo value for this RouteElement.
     * 
     * @return toInfo
     */
    public java.lang.String getToInfo() {
        return toInfo;
    }


    /**
     * Sets the toInfo value for this RouteElement.
     * 
     * @param toInfo
     */
    public void setToInfo(java.lang.String toInfo) {
        this.toInfo = toInfo;
    }


    /**
     * Gets the turn value for this RouteElement.
     * 
     * @return turn
     */
    public com.ptvag.mnp.common.TurnSymbolEnum getTurn() {
        return turn;
    }


    /**
     * Sets the turn value for this RouteElement.
     * 
     * @param turn
     */
    public void setTurn(com.ptvag.mnp.common.TurnSymbolEnum turn) {
        this.turn = turn;
    }


    /**
     * Gets the type value for this RouteElement.
     * 
     * @return type
     */
    public com.ptvag.mnp.common.RouteElementTypeEnum getType() {
        return type;
    }


    /**
     * Sets the type value for this RouteElement.
     * 
     * @param type
     */
    public void setType(com.ptvag.mnp.common.RouteElementTypeEnum type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RouteElement)) return false;
        RouteElement other = (RouteElement) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.wrappedAttached==null && other.getWrappedAttached()==null) || 
             (this.wrappedAttached!=null &&
              java.util.Arrays.equals(this.wrappedAttached, other.getWrappedAttached()))) &&
            ((this.coordinate==null && other.getCoordinate()==null) || 
             (this.coordinate!=null &&
              this.coordinate.equals(other.getCoordinate()))) &&
            ((this.diffDistance==null && other.getDiffDistance()==null) || 
             (this.diffDistance!=null &&
              this.diffDistance.equals(other.getDiffDistance()))) &&
            ((this.diffTime==null && other.getDiffTime()==null) || 
             (this.diffTime!=null &&
              this.diffTime.equals(other.getDiffTime()))) &&
            ((this.direction==null && other.getDirection()==null) || 
             (this.direction!=null &&
              this.direction.equals(other.getDirection()))) &&
            ((this.distance==null && other.getDistance()==null) || 
             (this.distance!=null &&
              this.distance.equals(other.getDistance()))) &&
            ((this.fromInfo==null && other.getFromInfo()==null) || 
             (this.fromInfo!=null &&
              this.fromInfo.equals(other.getFromInfo()))) &&
            ((this.nodeInfo==null && other.getNodeInfo()==null) || 
             (this.nodeInfo!=null &&
              this.nodeInfo.equals(other.getNodeInfo()))) &&
            ((this.nodeType==null && other.getNodeType()==null) || 
             (this.nodeType!=null &&
              this.nodeType.equals(other.getNodeType()))) &&
            ((this.reMapRef==null && other.getReMapRef()==null) || 
             (this.reMapRef!=null &&
              this.reMapRef.equals(other.getReMapRef()))) &&
            ((this.sign==null && other.getSign()==null) || 
             (this.sign!=null &&
              this.sign.equals(other.getSign()))) &&
            ((this.streetType==null && other.getStreetType()==null) || 
             (this.streetType!=null &&
              this.streetType.equals(other.getStreetType()))) &&
            ((this.textInfo==null && other.getTextInfo()==null) || 
             (this.textInfo!=null &&
              this.textInfo.equals(other.getTextInfo()))) &&
            ((this.time==null && other.getTime()==null) || 
             (this.time!=null &&
              this.time.equals(other.getTime()))) &&
            ((this.toInfo==null && other.getToInfo()==null) || 
             (this.toInfo!=null &&
              this.toInfo.equals(other.getToInfo()))) &&
            ((this.turn==null && other.getTurn()==null) || 
             (this.turn!=null &&
              this.turn.equals(other.getTurn()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getWrappedAttached() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedAttached());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedAttached(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCoordinate() != null) {
            _hashCode += getCoordinate().hashCode();
        }
        if (getDiffDistance() != null) {
            _hashCode += getDiffDistance().hashCode();
        }
        if (getDiffTime() != null) {
            _hashCode += getDiffTime().hashCode();
        }
        if (getDirection() != null) {
            _hashCode += getDirection().hashCode();
        }
        if (getDistance() != null) {
            _hashCode += getDistance().hashCode();
        }
        if (getFromInfo() != null) {
            _hashCode += getFromInfo().hashCode();
        }
        if (getNodeInfo() != null) {
            _hashCode += getNodeInfo().hashCode();
        }
        if (getNodeType() != null) {
            _hashCode += getNodeType().hashCode();
        }
        if (getReMapRef() != null) {
            _hashCode += getReMapRef().hashCode();
        }
        if (getSign() != null) {
            _hashCode += getSign().hashCode();
        }
        if (getStreetType() != null) {
            _hashCode += getStreetType().hashCode();
        }
        if (getTextInfo() != null) {
            _hashCode += getTextInfo().hashCode();
        }
        if (getTime() != null) {
            _hashCode += getTime().hashCode();
        }
        if (getToInfo() != null) {
            _hashCode += getToInfo().hashCode();
        }
        if (getTurn() != null) {
            _hashCode += getTurn().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RouteElement.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElement"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedAttached");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "wrappedAttached"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIViewSet"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("coordinate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "coordinate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Coordinate"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("diffDistance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "diffDistance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("diffTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "diffTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("direction");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "direction"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("distance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "distance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "fromInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nodeInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "nodeInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nodeType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "nodeType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "NodeTypeEnum"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reMapRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "reMapRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElementMapRef"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sign");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "sign"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("streetType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "streetType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "StreetTypeEnum"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "textInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("time");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "time"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("toInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "toInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("turn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "turn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "TurnSymbolEnum"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElementTypeEnum"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
