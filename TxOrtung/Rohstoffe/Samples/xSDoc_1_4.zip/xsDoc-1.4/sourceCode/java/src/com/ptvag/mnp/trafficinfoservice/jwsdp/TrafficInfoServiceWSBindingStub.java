/**
 * TrafficInfoServiceWSBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.trafficinfoservice.jwsdp;

public class TrafficInfoServiceWSBindingStub extends org.apache.axis.client.Stub implements com.ptvag.mnp.trafficinfoservice.jwsdp.TrafficInfoServiceWS {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[17];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("dummy");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ConstBoolExpr_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ConstBoolExpr"), com.ptvag.mnp.common.ConstBoolExpr.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "BinBoolExpr_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BinBoolExpr"), com.ptvag.mnp.common.BinBoolExpr.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "LikeExpr_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "LikeExpr"), com.ptvag.mnp.common.LikeExpr.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CompExpr_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "CompExpr"), com.ptvag.mnp.common.CompExpr.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "MathExpr_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MathExpr"), com.ptvag.mnp.common.MathExpr.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ColExpr_6"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ColExpr"), com.ptvag.mnp.common.ColExpr.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ConstExpr_7"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ConstExpr"), com.ptvag.mnp.common.ConstExpr.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ScalarExpr_8"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ScalarExpr"), com.ptvag.mnp.common.ScalarExpr.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "POIViewMapSet_9"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIViewMapSet"), com.ptvag.mnp.common.POIViewMapSet.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "NullExpr_10"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "NullExpr"), com.ptvag.mnp.common.NullExpr.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_11"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCachedMap");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CachedObjectEnum_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "CachedObjectEnum"), com.ptvag.mnp.common.CachedObjectEnum.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MapView"));
        oper.setReturnClass(com.ptvag.mnp.common.MapView.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryNavigationException"),
                      "com.ptvag.mnp.mapping.exception.MapHistoryNavigationException",
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryNavigationException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"),
                      "com.ptvag.jabba.exception.ParameterNotSetException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"),
                      "com.ptvag.mnp.mapping.exception.MapHistoryEmptyException",
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getGeneralTrafficInfos");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ArrayOfString_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"), java.lang.String[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        oper.setReturnClass(com.ptvag.mnp.common.POIViewSet[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"),
                      "com.ptvag.jabba.exception.ParameterNotSetException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedIsoCodeException"),
                      "com.ptvag.mnp.common.exception.UnsupportedIsoCodeException",
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedIsoCodeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOITypeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getMapByProviders");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ArrayOfPOIViewSet_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"), com.ptvag.mnp.common.POIViewSet[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ImageProperties_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ImageProperties"), com.ptvag.mnp.common.ImageProperties.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MapView"));
        oper.setReturnClass(com.ptvag.mnp.common.MapView.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedImageProfileException"),
                      "com.ptvag.mnp.common.exception.UnsupportedImageProfileException",
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedImageProfileException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"),
                      "com.ptvag.jabba.exception.ParameterNotSetException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "NoPoisForBoundingMapFoundException"),
                      "com.ptvag.mnp.mapping.exception.NoPoisForBoundingMapFoundException",
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "NoPoisForBoundingMapFoundException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedGeoDataSourceException"),
                      "com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException",
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedGeoDataSourceException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedIsoCodeException"),
                      "com.ptvag.mnp.common.exception.UnsupportedIsoCodeException",
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedIsoCodeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOITypeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getMapByRectangle");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "BoundingBox_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BoundingBox"), com.ptvag.mnp.common.BoundingBox.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ArrayOfPOIViewSet_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"), com.ptvag.mnp.common.POIViewSet[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ImageProperties_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ImageProperties"), com.ptvag.mnp.common.ImageProperties.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_6"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MapView"));
        oper.setReturnClass(com.ptvag.mnp.common.MapView.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedImageProfileException"),
                      "com.ptvag.mnp.common.exception.UnsupportedImageProfileException",
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedImageProfileException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"),
                      "com.ptvag.jabba.exception.ParameterNotSetException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedGeoDataSourceException"),
                      "com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException",
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedGeoDataSourceException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOITypeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getMapByRoads");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ArrayOfString_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"), java.lang.String[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ArrayOfString_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"), java.lang.String[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ImageProperties_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ImageProperties"), com.ptvag.mnp.common.ImageProperties.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_6"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_7"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MapView"));
        oper.setReturnClass(com.ptvag.mnp.common.MapView.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedImageProfileException"),
                      "com.ptvag.mnp.common.exception.UnsupportedImageProfileException",
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedImageProfileException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"),
                      "com.ptvag.jabba.exception.ParameterNotSetException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "NoPoisForBoundingMapFoundException"),
                      "com.ptvag.mnp.mapping.exception.NoPoisForBoundingMapFoundException",
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "NoPoisForBoundingMapFoundException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedGeoDataSourceException"),
                      "com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException",
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedGeoDataSourceException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedIsoCodeException"),
                      "com.ptvag.mnp.common.exception.UnsupportedIsoCodeException",
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedIsoCodeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOITypeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getRegions");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIViewSet"));
        oper.setReturnClass(com.ptvag.mnp.common.POIViewSet.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"),
                      "com.ptvag.jabba.exception.ParameterNotSetException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedIsoCodeException"),
                      "com.ptvag.mnp.common.exception.UnsupportedIsoCodeException",
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedIsoCodeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOITypeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getRoadsWithMessages");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ArrayOfString_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"), java.lang.String[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        oper.setReturnClass(com.ptvag.mnp.common.POIViewSet[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"),
                      "com.ptvag.jabba.exception.ParameterNotSetException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOITypeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getTrafficInfosByProviders");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ArrayOfPOIViewSet_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"), com.ptvag.mnp.common.POIViewSet[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        oper.setReturnClass(com.ptvag.mnp.common.POIViewSet[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"),
                      "com.ptvag.jabba.exception.ParameterNotSetException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOITypeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getTrafficInfosByRectangle");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "BoundingBox_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BoundingBox"), com.ptvag.mnp.common.BoundingBox.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ArrayOfPOIViewSet_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"), com.ptvag.mnp.common.POIViewSet[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        oper.setReturnClass(com.ptvag.mnp.common.POIViewSet[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOITypeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getTrafficInfosByRoads");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ArrayOfString_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"), java.lang.String[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "ArrayOfString_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"), java.lang.String[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString"));
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        oper.setReturnClass(com.ptvag.mnp.common.POIViewSet[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"),
                      "com.ptvag.jabba.exception.ParameterNotSetException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedIsoCodeException"),
                      "com.ptvag.mnp.common.exception.UnsupportedIsoCodeException",
                      new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedIsoCodeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"),
                      "com.ptvag.mnp.poisearch.exception.InvalidPOITypeException",
                      new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("moveMapByDevice");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "int_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "int_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MapView"));
        oper.setReturnClass(com.ptvag.mnp.common.MapView.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"),
                      "com.ptvag.mnp.mapping.exception.MapHistoryEmptyException",
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("moveMapByPercentage");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "float_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "float"), float.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "float_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "float"), float.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MapView"));
        oper.setReturnClass(com.ptvag.mnp.common.MapView.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"),
                      "com.ptvag.mnp.mapping.exception.MapHistoryEmptyException",
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("scaleMapByWidthHeight");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "int_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "int_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MapView"));
        oper.setReturnClass(com.ptvag.mnp.common.MapView.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"),
                      "com.ptvag.mnp.mapping.exception.MapHistoryEmptyException",
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("zoomMapByLevel");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "int_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "Coordinate_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Coordinate"), com.ptvag.mnp.common.Coordinate.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MapView"));
        oper.setReturnClass(com.ptvag.mnp.common.MapView.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"),
                      "com.ptvag.mnp.mapping.exception.MapHistoryEmptyException",
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("zoomMapByRectangle");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "BoundingBox_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BoundingBox"), com.ptvag.mnp.common.BoundingBox.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MapView"));
        oper.setReturnClass(com.ptvag.mnp.common.MapView.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"),
                      "com.ptvag.mnp.mapping.exception.MapHistoryEmptyException",
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("zoomMapByWidthHeight");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "double_1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"), double.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "double_2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"), double.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "Coordinate_3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Coordinate"), com.ptvag.mnp.common.Coordinate.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "String_5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "CallerContext_6"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext"), com.ptvag.jabba.service.baseservices.CallerContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MapView"));
        oper.setReturnClass(com.ptvag.mnp.common.MapView.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "result"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"),
                      "com.ptvag.jabba.exception.IllegalParameterException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"),
                      "com.ptvag.jabba.exception.PTVSystemException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"),
                      "com.ptvag.mnp.mapping.exception.MapHistoryEmptyException",
                      new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"),
                      "com.ptvag.jabba.exception.EJBAccessException",
                      new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException"), 
                      true
                     ));
        _operations[16] = oper;

    }

    public TrafficInfoServiceWSBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public TrafficInfoServiceWSBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public TrafficInfoServiceWSBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
        addBindings0();
        addBindings1();
    }

    private void addBindings0() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "ArrayOfCallerContextProperty");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.CallerContextProperty[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty");
            qName2 = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "ArrayOfCallerContextProperty");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContext");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.CallerContext.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://baseservices.service.jabba.ptvag.com", "CallerContextProperty");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.CallerContextProperty.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfCoordinate");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.Coordinate[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Coordinate");
            qName2 = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfCoordinate");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfCountryToll");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.CountryToll[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "CountryToll");
            qName2 = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfCountryToll");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfEntityDetailLevel");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.EntityDetailLevel[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "EntityDetailLevel");
            qName2 = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfEntityDetailLevel");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIAttribute");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.POIAttribute[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIAttribute");
            qName2 = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIAttribute");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIView");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.POIView[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIView");
            qName2 = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIView");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.POIViewSet[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIViewSet");
            qName2 = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfPOIViewSet");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfRoadSpeedTypeToll");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RoadSpeedTypeToll[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RoadSpeedTypeToll");
            qName2 = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfRoadSpeedTypeToll");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfRouteElement");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RouteElement[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElement");
            qName2 = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfRouteElement");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfRouteElementMapRect");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RouteElementMapRect[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElementMapRect");
            qName2 = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfRouteElementMapRect");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfRouteView");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RouteView[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteView");
            qName2 = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ArrayOfRouteView");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BinBoolEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.BinBoolEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BinBoolExpr");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.BinBoolExpr.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BoolExpr");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.BoolExpr.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "BoundingBox");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.BoundingBox.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "CachedObjectEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.CachedObjectEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ColExpr");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.ColExpr.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "CompExpr");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.CompExpr.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "CompExprEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.CompExprEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ConstBoolEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.ConstBoolEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ConstBoolExpr");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.ConstBoolExpr.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ConstExpr");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.ConstExpr.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Coordinate");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.Coordinate.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "CoordinateList");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.CoordinateList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "CoordTypeEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.CoordTypeEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "CountryToll");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.CountryToll.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "DetailLevelType");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.DetailLevelType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "DevCoord");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.DevCoord.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "DistanceProperties");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.DistanceProperties.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "DistanceUnitEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.DistanceUnitEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "DistTypeEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.DistTypeEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "DynProperties");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.DynProperties.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "EntityDetailLevel");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.EntityDetailLevel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Expr");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.Expr.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "FileFormatEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.FileFormatEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Icon");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.Icon.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Image");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.Image.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ImageProperties");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.ImageProperties.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "LikeExpr");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.LikeExpr.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MapView");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.MapView.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MathExpr");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.MathExpr.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "MathExprEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.MathExprEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "NodeTypeEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.NodeTypeEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "NullExpr");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.NullExpr.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIAttribute");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.POIAttribute.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIContext");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.POIContext.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIFilter");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.POIFilter.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIView");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.POIView.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIViewMapSet");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.POIViewMapSet.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "POIViewSet");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.POIViewSet.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Polyline");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.Polyline.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ProximityProperties");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.ProximityProperties.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RefTypeEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RefTypeEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RoadSpeedTypeEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RoadSpeedTypeEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RoadSpeedTypeToll");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RoadSpeedTypeToll.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteDisplayProperties");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RouteDisplayProperties.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElement");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RouteElement.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElementMapRect");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RouteElementMapRect.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElementMapRef");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RouteElementMapRef.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteElementTypeEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RouteElementTypeEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteOptimizationEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RouteOptimizationEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "RouteView");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.RouteView.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ScalarExpr");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.ScalarExpr.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "ScalarExprEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.ScalarExprEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "SpeedProfileEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.SpeedProfileEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "StreetTypeEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.StreetTypeEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "Toll");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.Toll.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "TollFee");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.TollFee.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "TurnSymbolEnum");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.TurnSymbolEnum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://exception.base.compobench.org", "CompobenchBusinessException");
            cachedSerQNames.add(qName);
            cls = org.compobench.base.exception.CompobenchBusinessException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.base.compobench.org", "CompobenchException");
            cachedSerQNames.add(qName);
            cls = org.compobench.base.exception.CompobenchException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.base.compobench.org", "CompobenchTechnicalException");
            cachedSerQNames.add(qName);
            cls = org.compobench.base.exception.CompobenchTechnicalException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.base.compobench.org", "ErrorRecord");
            cachedSerQNames.add(qName);
            cls = org.compobench.base.exception.ErrorRecord.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.baseservices.service.jabba.ptvag.com", "BaseConfigFileMissingException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.exception.BaseConfigFileMissingException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.baseservices.service.jabba.ptvag.com", "BaseServicesInstantiationException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.exception.BaseServicesInstantiationException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.baseservices.service.jabba.ptvag.com", "BaseServicesNotDefinedException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.exception.BaseServicesNotDefinedException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.baseservices.service.jabba.ptvag.com", "BaseServicesProviderException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.baseservices.exception.BaseServicesProviderException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "AddressNotFoundException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.exception.AddressNotFoundException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "InsufficientAddressException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.exception.InsufficientAddressException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "InvalidPropertyException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.exception.InvalidPropertyException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "MessagingServiceException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.exception.MessagingServiceException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "OQLHolderCreationException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.exception.OQLHolderCreationException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedGeoDataSourceException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedImageProfileException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.exception.UnsupportedImageProfileException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.common.mnp.ptvag.com", "UnsupportedIsoCodeException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.common.exception.UnsupportedIsoCodeException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "DatabaseConnectionException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.exception.DatabaseConnectionException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EJBAccessException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.exception.EJBAccessException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EServerConnectionException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.exception.EServerConnectionException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "EServerStatusException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.exception.EServerStatusException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "IllegalParameterException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.exception.IllegalParameterException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "ParameterNotSetException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.exception.ParameterNotSetException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVBusinessException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.exception.PTVBusinessException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVDatabaseException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.exception.PTVDatabaseException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.jabba.ptvag.com", "PTVSystemException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.exception.PTVSystemException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryEmptyException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.mapping.exception.MapHistoryEmptyException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MapHistoryNavigationException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.mapping.exception.MapHistoryNavigationException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "MappingException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.mapping.exception.MappingException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.mapping.mnp.ptvag.com", "NoPoisForBoundingMapFoundException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.mapping.exception.NoPoisForBoundingMapFoundException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings1() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOIAttributeException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "InvalidPOITypeException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.poisearch.exception.InvalidPOITypeException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.poisearch.mnp.ptvag.com", "POISearchException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.mnp.poisearch.exception.POISearchException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "BeanMappingException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.BeanMappingException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "InvalidPrefsScopeException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.InvalidPrefsScopeException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "KeyNotFoundException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.KeyNotFoundException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "NodeNotFoundException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.NodeNotFoundException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "PrefsAccessException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.PrefsAccessException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "PrefsEntryNotFoundException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.PrefsEntryNotFoundException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "PrefsException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.PrefsException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "PrefsImplNotDefinedException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.PrefsImplNotDefinedException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "PrefsInstantiationException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.PrefsInstantiationException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "PrefsProviderException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.PrefsProviderException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.prefs.service.jabba.ptvag.com", "TypeMismatchException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.prefs.exception.TypeMismatchException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.security.service.jabba.ptvag.com", "IllegalPasswordException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.security.exception.IllegalPasswordException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.security.service.jabba.ptvag.com", "JabbaSecurityException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.security.exception.JabbaSecurityException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.security.service.jabba.ptvag.com", "PasswordEncryptionException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.security.exception.PasswordEncryptionException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.security.service.jabba.ptvag.com", "SecurityImplNotDefinedException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.security.exception.SecurityImplNotDefinedException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.security.service.jabba.ptvag.com", "SecurityInstantiationException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.security.exception.SecurityInstantiationException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.security.service.jabba.ptvag.com", "SecurityProviderException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.security.exception.SecurityProviderException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.security.service.jabba.ptvag.com", "SystemUserAccessException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.security.exception.SystemUserAccessException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.security.service.jabba.ptvag.com", "SystemUserAdminException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.security.exception.SystemUserAdminException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.security.service.jabba.ptvag.com", "SystemUserAlreadyExistsException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.security.exception.SystemUserAlreadyExistsException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.security.service.jabba.ptvag.com", "SystemUserNotFoundException");
            cachedSerQNames.add(qName);
            cls = com.ptvag.jabba.service.security.exception.SystemUserNotFoundException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exceptions.persistent.base.compobench.org", "CreateException");
            cachedSerQNames.add(qName);
            cls = org.compobench.base.persistent.exceptions.CreateException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exceptions.persistent.base.compobench.org", "DuplicateKeyException");
            cachedSerQNames.add(qName);
            cls = org.compobench.base.persistent.exceptions.DuplicateKeyException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exceptions.persistent.base.compobench.org", "FinderException");
            cachedSerQNames.add(qName);
            cls = org.compobench.base.persistent.exceptions.FinderException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exceptions.persistent.base.compobench.org", "ObjectNotFoundException");
            cachedSerQNames.add(qName);
            cls = org.compobench.base.persistent.exceptions.ObjectNotFoundException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exceptions.persistent.base.compobench.org", "RemoveException");
            cachedSerQNames.add(qName);
            cls = org.compobench.base.persistent.exceptions.RemoveException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "ArrayOfString");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public void dummy(com.ptvag.mnp.common.ConstBoolExpr constBoolExpr_1, com.ptvag.mnp.common.BinBoolExpr binBoolExpr_2, com.ptvag.mnp.common.LikeExpr likeExpr_3, com.ptvag.mnp.common.CompExpr compExpr_4, com.ptvag.mnp.common.MathExpr mathExpr_5, com.ptvag.mnp.common.ColExpr colExpr_6, com.ptvag.mnp.common.ConstExpr constExpr_7, com.ptvag.mnp.common.ScalarExpr scalarExpr_8, com.ptvag.mnp.common.POIViewMapSet POIViewMapSet_9, com.ptvag.mnp.common.NullExpr nullExpr_10, com.ptvag.jabba.service.baseservices.CallerContext callerContext_11) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "dummy"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {constBoolExpr_1, binBoolExpr_2, likeExpr_3, compExpr_4, mathExpr_5, colExpr_6, constExpr_7, scalarExpr_8, POIViewMapSet_9, nullExpr_10, callerContext_11});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.MapView getCachedMap(com.ptvag.mnp.common.CachedObjectEnum cachedObjectEnum_1, java.lang.String string_2, com.ptvag.jabba.service.baseservices.CallerContext callerContext_3) throws java.rmi.RemoteException, com.ptvag.mnp.mapping.exception.MapHistoryNavigationException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "getCachedMap"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cachedObjectEnum_1, string_2, callerContext_3});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.MapView) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.MapView) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.MapView.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.mapping.exception.MapHistoryNavigationException) {
              throw (com.ptvag.mnp.mapping.exception.MapHistoryNavigationException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.ParameterNotSetException) {
              throw (com.ptvag.jabba.exception.ParameterNotSetException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) {
              throw (com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.POIViewSet[] getGeneralTrafficInfos(java.lang.String[] arrayOfString_1, java.lang.String string_2, com.ptvag.jabba.service.baseservices.CallerContext callerContext_3) throws java.rmi.RemoteException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedIsoCodeException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "getGeneralTrafficInfos"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfString_1, string_2, callerContext_3});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.POIViewSet[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.POIViewSet[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.POIViewSet[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.ParameterNotSetException) {
              throw (com.ptvag.jabba.exception.ParameterNotSetException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.common.exception.UnsupportedIsoCodeException) {
              throw (com.ptvag.mnp.common.exception.UnsupportedIsoCodeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.MapView getMapByProviders(com.ptvag.mnp.common.POIViewSet[] arrayOfPOIViewSet_1, com.ptvag.mnp.common.ImageProperties imageProperties_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.mnp.common.exception.UnsupportedImageProfileException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.mapping.exception.NoPoisForBoundingMapFoundException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException, com.ptvag.mnp.common.exception.UnsupportedIsoCodeException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "getMapByProviders"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfPOIViewSet_1, imageProperties_2, string_3, string_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.MapView) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.MapView) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.MapView.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.common.exception.UnsupportedImageProfileException) {
              throw (com.ptvag.mnp.common.exception.UnsupportedImageProfileException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.ParameterNotSetException) {
              throw (com.ptvag.jabba.exception.ParameterNotSetException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.mapping.exception.NoPoisForBoundingMapFoundException) {
              throw (com.ptvag.mnp.mapping.exception.NoPoisForBoundingMapFoundException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException) {
              throw (com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.common.exception.UnsupportedIsoCodeException) {
              throw (com.ptvag.mnp.common.exception.UnsupportedIsoCodeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.MapView getMapByRectangle(com.ptvag.mnp.common.BoundingBox boundingBox_1, com.ptvag.mnp.common.POIViewSet[] arrayOfPOIViewSet_2, com.ptvag.mnp.common.ImageProperties imageProperties_3, java.lang.String string_4, java.lang.String string_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.mnp.common.exception.UnsupportedImageProfileException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "getMapByRectangle"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {boundingBox_1, arrayOfPOIViewSet_2, imageProperties_3, string_4, string_5, callerContext_6});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.MapView) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.MapView) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.MapView.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.common.exception.UnsupportedImageProfileException) {
              throw (com.ptvag.mnp.common.exception.UnsupportedImageProfileException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.ParameterNotSetException) {
              throw (com.ptvag.jabba.exception.ParameterNotSetException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException) {
              throw (com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.MapView getMapByRoads(java.lang.String[] arrayOfString_1, java.lang.String[] arrayOfString_2, java.lang.String string_3, com.ptvag.mnp.common.ImageProperties imageProperties_4, java.lang.String string_5, java.lang.String string_6, com.ptvag.jabba.service.baseservices.CallerContext callerContext_7) throws java.rmi.RemoteException, com.ptvag.mnp.common.exception.UnsupportedImageProfileException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.mapping.exception.NoPoisForBoundingMapFoundException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException, com.ptvag.mnp.common.exception.UnsupportedIsoCodeException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "getMapByRoads"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfString_1, arrayOfString_2, string_3, imageProperties_4, string_5, string_6, callerContext_7});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.MapView) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.MapView) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.MapView.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.common.exception.UnsupportedImageProfileException) {
              throw (com.ptvag.mnp.common.exception.UnsupportedImageProfileException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.ParameterNotSetException) {
              throw (com.ptvag.jabba.exception.ParameterNotSetException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.mapping.exception.NoPoisForBoundingMapFoundException) {
              throw (com.ptvag.mnp.mapping.exception.NoPoisForBoundingMapFoundException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException) {
              throw (com.ptvag.mnp.common.exception.UnsupportedGeoDataSourceException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.common.exception.UnsupportedIsoCodeException) {
              throw (com.ptvag.mnp.common.exception.UnsupportedIsoCodeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.POIViewSet getRegions(java.lang.String string_1, java.lang.String string_2, com.ptvag.jabba.service.baseservices.CallerContext callerContext_3) throws java.rmi.RemoteException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedIsoCodeException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "getRegions"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {string_1, string_2, callerContext_3});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.POIViewSet) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.POIViewSet) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.POIViewSet.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.ParameterNotSetException) {
              throw (com.ptvag.jabba.exception.ParameterNotSetException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.common.exception.UnsupportedIsoCodeException) {
              throw (com.ptvag.mnp.common.exception.UnsupportedIsoCodeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.POIViewSet[] getRoadsWithMessages(java.lang.String[] arrayOfString_1, com.ptvag.jabba.service.baseservices.CallerContext callerContext_2) throws java.rmi.RemoteException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "getRoadsWithMessages"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfString_1, callerContext_2});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.POIViewSet[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.POIViewSet[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.POIViewSet[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.ParameterNotSetException) {
              throw (com.ptvag.jabba.exception.ParameterNotSetException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.POIViewSet[] getTrafficInfosByProviders(com.ptvag.mnp.common.POIViewSet[] arrayOfPOIViewSet_1, com.ptvag.jabba.service.baseservices.CallerContext callerContext_2) throws java.rmi.RemoteException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "getTrafficInfosByProviders"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfPOIViewSet_1, callerContext_2});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.POIViewSet[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.POIViewSet[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.POIViewSet[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.ParameterNotSetException) {
              throw (com.ptvag.jabba.exception.ParameterNotSetException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.POIViewSet[] getTrafficInfosByRectangle(com.ptvag.mnp.common.BoundingBox boundingBox_1, com.ptvag.mnp.common.POIViewSet[] arrayOfPOIViewSet_2, com.ptvag.jabba.service.baseservices.CallerContext callerContext_3) throws java.rmi.RemoteException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "getTrafficInfosByRectangle"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {boundingBox_1, arrayOfPOIViewSet_2, callerContext_3});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.POIViewSet[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.POIViewSet[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.POIViewSet[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.POIViewSet[] getTrafficInfosByRoads(java.lang.String[] arrayOfString_1, java.lang.String[] arrayOfString_2, java.lang.String string_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.exception.ParameterNotSetException, com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.common.exception.UnsupportedIsoCodeException, com.ptvag.mnp.poisearch.exception.InvalidPOITypeException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "getTrafficInfosByRoads"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arrayOfString_1, arrayOfString_2, string_3, callerContext_4});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.POIViewSet[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.POIViewSet[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.POIViewSet[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.ParameterNotSetException) {
              throw (com.ptvag.jabba.exception.ParameterNotSetException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOIAttributeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.common.exception.UnsupportedIsoCodeException) {
              throw (com.ptvag.mnp.common.exception.UnsupportedIsoCodeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) {
              throw (com.ptvag.mnp.poisearch.exception.InvalidPOITypeException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.MapView moveMapByDevice(int int_1, int int_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "moveMapByDevice"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(int_1), new java.lang.Integer(int_2), string_3, string_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.MapView) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.MapView) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.MapView.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) {
              throw (com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.MapView moveMapByPercentage(float float_1, float float_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "moveMapByPercentage"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Float(float_1), new java.lang.Float(float_2), string_3, string_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.MapView) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.MapView) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.MapView.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) {
              throw (com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.MapView scaleMapByWidthHeight(int int_1, int int_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "scaleMapByWidthHeight"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(int_1), new java.lang.Integer(int_2), string_3, string_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.MapView) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.MapView) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.MapView.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) {
              throw (com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.MapView zoomMapByLevel(int int_1, com.ptvag.mnp.common.Coordinate coordinate_2, java.lang.String string_3, java.lang.String string_4, com.ptvag.jabba.service.baseservices.CallerContext callerContext_5) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "zoomMapByLevel"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(int_1), coordinate_2, string_3, string_4, callerContext_5});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.MapView) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.MapView) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.MapView.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) {
              throw (com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.MapView zoomMapByRectangle(com.ptvag.mnp.common.BoundingBox boundingBox_1, java.lang.String string_2, java.lang.String string_3, com.ptvag.jabba.service.baseservices.CallerContext callerContext_4) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "zoomMapByRectangle"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {boundingBox_1, string_2, string_3, callerContext_4});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.MapView) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.MapView) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.MapView.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) {
              throw (com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.ptvag.mnp.common.MapView zoomMapByWidthHeight(double double_1, double double_2, com.ptvag.mnp.common.Coordinate coordinate_3, java.lang.String string_4, java.lang.String string_5, com.ptvag.jabba.service.baseservices.CallerContext callerContext_6) throws java.rmi.RemoteException, com.ptvag.jabba.exception.IllegalParameterException, com.ptvag.jabba.exception.PTVSystemException, com.ptvag.mnp.mapping.exception.MapHistoryEmptyException, com.ptvag.jabba.exception.EJBAccessException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://types.trafficinfoservice.mnp.ptvag.com", "zoomMapByWidthHeight"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Double(double_1), new java.lang.Double(double_2), coordinate_3, string_4, string_5, callerContext_6});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ptvag.mnp.common.MapView) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ptvag.mnp.common.MapView) org.apache.axis.utils.JavaUtils.convert(_resp, com.ptvag.mnp.common.MapView.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.IllegalParameterException) {
              throw (com.ptvag.jabba.exception.IllegalParameterException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.PTVSystemException) {
              throw (com.ptvag.jabba.exception.PTVSystemException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) {
              throw (com.ptvag.mnp.mapping.exception.MapHistoryEmptyException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.ptvag.jabba.exception.EJBAccessException) {
              throw (com.ptvag.jabba.exception.EJBAccessException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

}
