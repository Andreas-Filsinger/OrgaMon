/**
 * ReachInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class ReachInfo  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.UniqueGeoID branchNode;

    private com.ptvag.xserver.xroute.RouteInfo routeInfo;

    private boolean reachable;  // attribute

    public ReachInfo() {
    }

    public ReachInfo(
           boolean reachable,
           com.ptvag.xserver.xroute.UniqueGeoID branchNode,
           com.ptvag.xserver.xroute.RouteInfo routeInfo) {
        this.reachable = reachable;
        this.branchNode = branchNode;
        this.routeInfo = routeInfo;
    }


    /**
     * Gets the branchNode value for this ReachInfo.
     * 
     * @return branchNode
     */
    public com.ptvag.xserver.xroute.UniqueGeoID getBranchNode() {
        return branchNode;
    }


    /**
     * Sets the branchNode value for this ReachInfo.
     * 
     * @param branchNode
     */
    public void setBranchNode(com.ptvag.xserver.xroute.UniqueGeoID branchNode) {
        this.branchNode = branchNode;
    }


    /**
     * Gets the routeInfo value for this ReachInfo.
     * 
     * @return routeInfo
     */
    public com.ptvag.xserver.xroute.RouteInfo getRouteInfo() {
        return routeInfo;
    }


    /**
     * Sets the routeInfo value for this ReachInfo.
     * 
     * @param routeInfo
     */
    public void setRouteInfo(com.ptvag.xserver.xroute.RouteInfo routeInfo) {
        this.routeInfo = routeInfo;
    }


    /**
     * Gets the reachable value for this ReachInfo.
     * 
     * @return reachable
     */
    public boolean isReachable() {
        return reachable;
    }


    /**
     * Sets the reachable value for this ReachInfo.
     * 
     * @param reachable
     */
    public void setReachable(boolean reachable) {
        this.reachable = reachable;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ReachInfo)) return false;
        ReachInfo other = (ReachInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.branchNode==null && other.getBranchNode()==null) || 
             (this.branchNode!=null &&
              this.branchNode.equals(other.getBranchNode()))) &&
            ((this.routeInfo==null && other.getRouteInfo()==null) || 
             (this.routeInfo!=null &&
              this.routeInfo.equals(other.getRouteInfo()))) &&
            this.reachable == other.isReachable();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBranchNode() != null) {
            _hashCode += getBranchNode().hashCode();
        }
        if (getRouteInfo() != null) {
            _hashCode += getRouteInfo().hashCode();
        }
        _hashCode += (isReachable() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ReachInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ReachInfo"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("reachable");
        attrField.setXmlName(new javax.xml.namespace.QName("", "reachable"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("branchNode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "branchNode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "UniqueGeoID"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("routeInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "routeInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RouteInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
