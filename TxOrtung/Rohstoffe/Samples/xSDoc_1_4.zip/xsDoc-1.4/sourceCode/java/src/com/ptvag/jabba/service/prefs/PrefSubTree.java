/**
 * PrefSubTree.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.jabba.service.prefs;

public class PrefSubTree  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.jabba.service.prefs.Property[] wrappedProperties;

    private com.ptvag.jabba.service.prefs.PrefSubTree[] wrappedSubTrees;

    private java.lang.String nodeName;  // attribute

    public PrefSubTree() {
    }

    public PrefSubTree(
           java.lang.String nodeName,
           com.ptvag.jabba.service.prefs.Property[] wrappedProperties,
           com.ptvag.jabba.service.prefs.PrefSubTree[] wrappedSubTrees) {
        this.nodeName = nodeName;
        this.wrappedProperties = wrappedProperties;
        this.wrappedSubTrees = wrappedSubTrees;
    }


    /**
     * Gets the wrappedProperties value for this PrefSubTree.
     * 
     * @return wrappedProperties
     */
    public com.ptvag.jabba.service.prefs.Property[] getWrappedProperties() {
        return wrappedProperties;
    }


    /**
     * Sets the wrappedProperties value for this PrefSubTree.
     * 
     * @param wrappedProperties
     */
    public void setWrappedProperties(com.ptvag.jabba.service.prefs.Property[] wrappedProperties) {
        this.wrappedProperties = wrappedProperties;
    }


    /**
     * Gets the wrappedSubTrees value for this PrefSubTree.
     * 
     * @return wrappedSubTrees
     */
    public com.ptvag.jabba.service.prefs.PrefSubTree[] getWrappedSubTrees() {
        return wrappedSubTrees;
    }


    /**
     * Sets the wrappedSubTrees value for this PrefSubTree.
     * 
     * @param wrappedSubTrees
     */
    public void setWrappedSubTrees(com.ptvag.jabba.service.prefs.PrefSubTree[] wrappedSubTrees) {
        this.wrappedSubTrees = wrappedSubTrees;
    }


    /**
     * Gets the nodeName value for this PrefSubTree.
     * 
     * @return nodeName
     */
    public java.lang.String getNodeName() {
        return nodeName;
    }


    /**
     * Sets the nodeName value for this PrefSubTree.
     * 
     * @param nodeName
     */
    public void setNodeName(java.lang.String nodeName) {
        this.nodeName = nodeName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PrefSubTree)) return false;
        PrefSubTree other = (PrefSubTree) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedProperties==null && other.getWrappedProperties()==null) || 
             (this.wrappedProperties!=null &&
              java.util.Arrays.equals(this.wrappedProperties, other.getWrappedProperties()))) &&
            ((this.wrappedSubTrees==null && other.getWrappedSubTrees()==null) || 
             (this.wrappedSubTrees!=null &&
              java.util.Arrays.equals(this.wrappedSubTrees, other.getWrappedSubTrees()))) &&
            ((this.nodeName==null && other.getNodeName()==null) || 
             (this.nodeName!=null &&
              this.nodeName.equals(other.getNodeName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedProperties() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedProperties());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedProperties(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWrappedSubTrees() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedSubTrees());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedSubTrees(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNodeName() != null) {
            _hashCode += getNodeName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PrefSubTree.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "PrefSubTree"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("nodeName");
        attrField.setXmlName(new javax.xml.namespace.QName("", "nodeName"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedProperties");
        elemField.setXmlName(new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "wrappedProperties"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "Property"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "Property"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedSubTrees");
        elemField.setXmlName(new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "wrappedSubTrees"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "PrefSubTree"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://prefs.service.jabba.ptvag.com", "PrefSubTree"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
