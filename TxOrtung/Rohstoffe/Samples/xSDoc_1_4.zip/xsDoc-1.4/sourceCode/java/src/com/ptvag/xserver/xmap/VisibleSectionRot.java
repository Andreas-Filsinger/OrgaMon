/**
 * VisibleSectionRot.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class VisibleSectionRot  extends com.ptvag.xserver.xmap.VisibleSection  implements java.io.Serializable {
    private com.ptvag.xserver.common.Point leftBottom;

    private com.ptvag.xserver.common.Point leftTop;

    private com.ptvag.xserver.common.Point rightBottom;

    private com.ptvag.xserver.common.Point rightTop;

    private int angle;  // attribute

    public VisibleSectionRot() {
    }

    public VisibleSectionRot(
           int scale,
           com.ptvag.xserver.common.BoundingBox boundingBox,
           com.ptvag.xserver.common.Point center,
           int angle,
           com.ptvag.xserver.common.Point leftBottom,
           com.ptvag.xserver.common.Point leftTop,
           com.ptvag.xserver.common.Point rightBottom,
           com.ptvag.xserver.common.Point rightTop) {
        super(
            scale,
            boundingBox,
            center);
        this.angle = angle;
        this.leftBottom = leftBottom;
        this.leftTop = leftTop;
        this.rightBottom = rightBottom;
        this.rightTop = rightTop;
    }


    /**
     * Gets the leftBottom value for this VisibleSectionRot.
     * 
     * @return leftBottom
     */
    public com.ptvag.xserver.common.Point getLeftBottom() {
        return leftBottom;
    }


    /**
     * Sets the leftBottom value for this VisibleSectionRot.
     * 
     * @param leftBottom
     */
    public void setLeftBottom(com.ptvag.xserver.common.Point leftBottom) {
        this.leftBottom = leftBottom;
    }


    /**
     * Gets the leftTop value for this VisibleSectionRot.
     * 
     * @return leftTop
     */
    public com.ptvag.xserver.common.Point getLeftTop() {
        return leftTop;
    }


    /**
     * Sets the leftTop value for this VisibleSectionRot.
     * 
     * @param leftTop
     */
    public void setLeftTop(com.ptvag.xserver.common.Point leftTop) {
        this.leftTop = leftTop;
    }


    /**
     * Gets the rightBottom value for this VisibleSectionRot.
     * 
     * @return rightBottom
     */
    public com.ptvag.xserver.common.Point getRightBottom() {
        return rightBottom;
    }


    /**
     * Sets the rightBottom value for this VisibleSectionRot.
     * 
     * @param rightBottom
     */
    public void setRightBottom(com.ptvag.xserver.common.Point rightBottom) {
        this.rightBottom = rightBottom;
    }


    /**
     * Gets the rightTop value for this VisibleSectionRot.
     * 
     * @return rightTop
     */
    public com.ptvag.xserver.common.Point getRightTop() {
        return rightTop;
    }


    /**
     * Sets the rightTop value for this VisibleSectionRot.
     * 
     * @param rightTop
     */
    public void setRightTop(com.ptvag.xserver.common.Point rightTop) {
        this.rightTop = rightTop;
    }


    /**
     * Gets the angle value for this VisibleSectionRot.
     * 
     * @return angle
     */
    public int getAngle() {
        return angle;
    }


    /**
     * Sets the angle value for this VisibleSectionRot.
     * 
     * @param angle
     */
    public void setAngle(int angle) {
        this.angle = angle;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof VisibleSectionRot)) return false;
        VisibleSectionRot other = (VisibleSectionRot) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.leftBottom==null && other.getLeftBottom()==null) || 
             (this.leftBottom!=null &&
              this.leftBottom.equals(other.getLeftBottom()))) &&
            ((this.leftTop==null && other.getLeftTop()==null) || 
             (this.leftTop!=null &&
              this.leftTop.equals(other.getLeftTop()))) &&
            ((this.rightBottom==null && other.getRightBottom()==null) || 
             (this.rightBottom!=null &&
              this.rightBottom.equals(other.getRightBottom()))) &&
            ((this.rightTop==null && other.getRightTop()==null) || 
             (this.rightTop!=null &&
              this.rightTop.equals(other.getRightTop()))) &&
            this.angle == other.getAngle();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLeftBottom() != null) {
            _hashCode += getLeftBottom().hashCode();
        }
        if (getLeftTop() != null) {
            _hashCode += getLeftTop().hashCode();
        }
        if (getRightBottom() != null) {
            _hashCode += getRightBottom().hashCode();
        }
        if (getRightTop() != null) {
            _hashCode += getRightTop().hashCode();
        }
        _hashCode += getAngle();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(VisibleSectionRot.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "VisibleSectionRot"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("angle");
        attrField.setXmlName(new javax.xml.namespace.QName("", "angle"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftBottom");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "leftBottom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftTop");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "leftTop"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightBottom");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "rightBottom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightTop");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "rightTop"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://common.xserver.ptvag.com", "Point"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
