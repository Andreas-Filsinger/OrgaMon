/**
 * Map.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xmap;

public class Map  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xmap.Image image;

    private com.ptvag.xserver.xmap.ObjectInfos[] wrappedObjects;

    private com.ptvag.xserver.xmap.VisibleSection visibleSection;

    public Map() {
    }

    public Map(
           com.ptvag.xserver.xmap.Image image,
           com.ptvag.xserver.xmap.ObjectInfos[] wrappedObjects,
           com.ptvag.xserver.xmap.VisibleSection visibleSection) {
        this.image = image;
        this.wrappedObjects = wrappedObjects;
        this.visibleSection = visibleSection;
    }


    /**
     * Gets the image value for this Map.
     * 
     * @return image
     */
    public com.ptvag.xserver.xmap.Image getImage() {
        return image;
    }


    /**
     * Sets the image value for this Map.
     * 
     * @param image
     */
    public void setImage(com.ptvag.xserver.xmap.Image image) {
        this.image = image;
    }


    /**
     * Gets the wrappedObjects value for this Map.
     * 
     * @return wrappedObjects
     */
    public com.ptvag.xserver.xmap.ObjectInfos[] getWrappedObjects() {
        return wrappedObjects;
    }


    /**
     * Sets the wrappedObjects value for this Map.
     * 
     * @param wrappedObjects
     */
    public void setWrappedObjects(com.ptvag.xserver.xmap.ObjectInfos[] wrappedObjects) {
        this.wrappedObjects = wrappedObjects;
    }


    /**
     * Gets the visibleSection value for this Map.
     * 
     * @return visibleSection
     */
    public com.ptvag.xserver.xmap.VisibleSection getVisibleSection() {
        return visibleSection;
    }


    /**
     * Sets the visibleSection value for this Map.
     * 
     * @param visibleSection
     */
    public void setVisibleSection(com.ptvag.xserver.xmap.VisibleSection visibleSection) {
        this.visibleSection = visibleSection;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Map)) return false;
        Map other = (Map) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.image==null && other.getImage()==null) || 
             (this.image!=null &&
              this.image.equals(other.getImage()))) &&
            ((this.wrappedObjects==null && other.getWrappedObjects()==null) || 
             (this.wrappedObjects!=null &&
              java.util.Arrays.equals(this.wrappedObjects, other.getWrappedObjects()))) &&
            ((this.visibleSection==null && other.getVisibleSection()==null) || 
             (this.visibleSection!=null &&
              this.visibleSection.equals(other.getVisibleSection())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getImage() != null) {
            _hashCode += getImage().hashCode();
        }
        if (getWrappedObjects() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedObjects());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedObjects(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getVisibleSection() != null) {
            _hashCode += getVisibleSection().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Map.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Map"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("image");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "image"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "Image"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedObjects");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "wrappedObjects"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "ObjectInfos"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "ObjectInfos"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("visibleSection");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "visibleSection"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xmap.xserver.ptvag.com", "VisibleSection"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
