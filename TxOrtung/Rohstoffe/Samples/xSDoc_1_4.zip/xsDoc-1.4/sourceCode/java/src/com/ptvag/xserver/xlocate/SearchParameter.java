/**
 * SearchParameter.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xlocate;

public class SearchParameter implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected SearchParameter(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _COUNTRY_CODETYPE = "COUNTRY_CODETYPE";
    public static final java.lang.String _SEARCH_BINARY = "SEARCH_BINARY";
    public static final java.lang.String _SEARCH_PHONETIC = "SEARCH_PHONETIC";
    public static final java.lang.String _SEARCH_FUZZY = "SEARCH_FUZZY";
    public static final java.lang.String _SWAPANDSPLITMODE = "SWAPANDSPLITMODE";
    public static final java.lang.String _STREET_HNRPOSITION = "STREET_HNRPOSITION";
    public static final java.lang.String _STREET_RETURNALLHNR = "STREET_RETURNALLHNR";
    public static final java.lang.String _RESULT_LANGUAGE = "RESULT_LANGUAGE";
    public static final java.lang.String _CITY_RETURNALLCITY2 = "CITY_RETURNALLCITY2";
    public static final java.lang.String _MULTIWORDINDEX_ENABLE = "MULTIWORDINDEX_ENABLE";
    public static final java.lang.String _POSTCODE_AGGREGATE = "POSTCODE_AGGREGATE";
    public static final java.lang.String _ASTERISKMODE = "ASTERISKMODE";
    public static final java.lang.String _INTERSECTIONS_ENABLE = "INTERSECTIONS_ENABLE";
    public static final java.lang.String _HNR_OFFSET = "HNR_OFFSET";
    public static final SearchParameter COUNTRY_CODETYPE = new SearchParameter(_COUNTRY_CODETYPE);
    public static final SearchParameter SEARCH_BINARY = new SearchParameter(_SEARCH_BINARY);
    public static final SearchParameter SEARCH_PHONETIC = new SearchParameter(_SEARCH_PHONETIC);
    public static final SearchParameter SEARCH_FUZZY = new SearchParameter(_SEARCH_FUZZY);
    public static final SearchParameter SWAPANDSPLITMODE = new SearchParameter(_SWAPANDSPLITMODE);
    public static final SearchParameter STREET_HNRPOSITION = new SearchParameter(_STREET_HNRPOSITION);
    public static final SearchParameter STREET_RETURNALLHNR = new SearchParameter(_STREET_RETURNALLHNR);
    public static final SearchParameter RESULT_LANGUAGE = new SearchParameter(_RESULT_LANGUAGE);
    public static final SearchParameter CITY_RETURNALLCITY2 = new SearchParameter(_CITY_RETURNALLCITY2);
    public static final SearchParameter MULTIWORDINDEX_ENABLE = new SearchParameter(_MULTIWORDINDEX_ENABLE);
    public static final SearchParameter POSTCODE_AGGREGATE = new SearchParameter(_POSTCODE_AGGREGATE);
    public static final SearchParameter ASTERISKMODE = new SearchParameter(_ASTERISKMODE);
    public static final SearchParameter INTERSECTIONS_ENABLE = new SearchParameter(_INTERSECTIONS_ENABLE);
    public static final SearchParameter HNR_OFFSET = new SearchParameter(_HNR_OFFSET);
    public java.lang.String getValue() { return _value_;}
    public static SearchParameter fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        SearchParameter enumeration = (SearchParameter)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static SearchParameter fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SearchParameter.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xlocate.xserver.ptvag.com", "SearchParameter"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
