/**
 * DimaParams.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class DimaParams  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private boolean deleteAfterUsage;  // attribute

    private boolean deleteBeforeUsage;  // attribute

    private int dimaID;  // attribute

    private byte optimisation;  // attribute

    private java.lang.String speedProfile;  // attribute

    private com.ptvag.xserver.xsequence.VehicleType vehicleType;  // attribute

    public DimaParams() {
    }

    public DimaParams(
           boolean deleteAfterUsage,
           boolean deleteBeforeUsage,
           int dimaID,
           byte optimisation,
           java.lang.String speedProfile,
           com.ptvag.xserver.xsequence.VehicleType vehicleType) {
        this.deleteAfterUsage = deleteAfterUsage;
        this.deleteBeforeUsage = deleteBeforeUsage;
        this.dimaID = dimaID;
        this.optimisation = optimisation;
        this.speedProfile = speedProfile;
        this.vehicleType = vehicleType;
    }


    /**
     * Gets the deleteAfterUsage value for this DimaParams.
     * 
     * @return deleteAfterUsage
     */
    public boolean isDeleteAfterUsage() {
        return deleteAfterUsage;
    }


    /**
     * Sets the deleteAfterUsage value for this DimaParams.
     * 
     * @param deleteAfterUsage
     */
    public void setDeleteAfterUsage(boolean deleteAfterUsage) {
        this.deleteAfterUsage = deleteAfterUsage;
    }


    /**
     * Gets the deleteBeforeUsage value for this DimaParams.
     * 
     * @return deleteBeforeUsage
     */
    public boolean isDeleteBeforeUsage() {
        return deleteBeforeUsage;
    }


    /**
     * Sets the deleteBeforeUsage value for this DimaParams.
     * 
     * @param deleteBeforeUsage
     */
    public void setDeleteBeforeUsage(boolean deleteBeforeUsage) {
        this.deleteBeforeUsage = deleteBeforeUsage;
    }


    /**
     * Gets the dimaID value for this DimaParams.
     * 
     * @return dimaID
     */
    public int getDimaID() {
        return dimaID;
    }


    /**
     * Sets the dimaID value for this DimaParams.
     * 
     * @param dimaID
     */
    public void setDimaID(int dimaID) {
        this.dimaID = dimaID;
    }


    /**
     * Gets the optimisation value for this DimaParams.
     * 
     * @return optimisation
     */
    public byte getOptimisation() {
        return optimisation;
    }


    /**
     * Sets the optimisation value for this DimaParams.
     * 
     * @param optimisation
     */
    public void setOptimisation(byte optimisation) {
        this.optimisation = optimisation;
    }


    /**
     * Gets the speedProfile value for this DimaParams.
     * 
     * @return speedProfile
     */
    public java.lang.String getSpeedProfile() {
        return speedProfile;
    }


    /**
     * Sets the speedProfile value for this DimaParams.
     * 
     * @param speedProfile
     */
    public void setSpeedProfile(java.lang.String speedProfile) {
        this.speedProfile = speedProfile;
    }


    /**
     * Gets the vehicleType value for this DimaParams.
     * 
     * @return vehicleType
     */
    public com.ptvag.xserver.xsequence.VehicleType getVehicleType() {
        return vehicleType;
    }


    /**
     * Sets the vehicleType value for this DimaParams.
     * 
     * @param vehicleType
     */
    public void setVehicleType(com.ptvag.xserver.xsequence.VehicleType vehicleType) {
        this.vehicleType = vehicleType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DimaParams)) return false;
        DimaParams other = (DimaParams) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.deleteAfterUsage == other.isDeleteAfterUsage() &&
            this.deleteBeforeUsage == other.isDeleteBeforeUsage() &&
            this.dimaID == other.getDimaID() &&
            this.optimisation == other.getOptimisation() &&
            ((this.speedProfile==null && other.getSpeedProfile()==null) || 
             (this.speedProfile!=null &&
              this.speedProfile.equals(other.getSpeedProfile()))) &&
            ((this.vehicleType==null && other.getVehicleType()==null) || 
             (this.vehicleType!=null &&
              this.vehicleType.equals(other.getVehicleType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += (isDeleteAfterUsage() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isDeleteBeforeUsage() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getDimaID();
        _hashCode += getOptimisation();
        if (getSpeedProfile() != null) {
            _hashCode += getSpeedProfile().hashCode();
        }
        if (getVehicleType() != null) {
            _hashCode += getVehicleType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DimaParams.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "DimaParams"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteAfterUsage");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteAfterUsage"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteBeforeUsage");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteBeforeUsage"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("dimaID");
        attrField.setXmlName(new javax.xml.namespace.QName("", "dimaID"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("optimisation");
        attrField.setXmlName(new javax.xml.namespace.QName("", "optimisation"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "byte"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("speedProfile");
        attrField.setXmlName(new javax.xml.namespace.QName("", "speedProfile"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("vehicleType");
        attrField.setXmlName(new javax.xml.namespace.QName("", "vehicleType"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "VehicleType"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
