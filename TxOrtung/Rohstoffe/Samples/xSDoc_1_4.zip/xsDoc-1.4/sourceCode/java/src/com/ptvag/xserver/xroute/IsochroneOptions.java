/**
 * IsochroneOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class IsochroneOptions  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.ExpansionDescription expansionDesc;

    private com.ptvag.xserver.xroute.IsochroneDetail isoDetail;  // attribute

    public IsochroneOptions() {
    }

    public IsochroneOptions(
           com.ptvag.xserver.xroute.IsochroneDetail isoDetail,
           com.ptvag.xserver.xroute.ExpansionDescription expansionDesc) {
        this.isoDetail = isoDetail;
        this.expansionDesc = expansionDesc;
    }


    /**
     * Gets the expansionDesc value for this IsochroneOptions.
     * 
     * @return expansionDesc
     */
    public com.ptvag.xserver.xroute.ExpansionDescription getExpansionDesc() {
        return expansionDesc;
    }


    /**
     * Sets the expansionDesc value for this IsochroneOptions.
     * 
     * @param expansionDesc
     */
    public void setExpansionDesc(com.ptvag.xserver.xroute.ExpansionDescription expansionDesc) {
        this.expansionDesc = expansionDesc;
    }


    /**
     * Gets the isoDetail value for this IsochroneOptions.
     * 
     * @return isoDetail
     */
    public com.ptvag.xserver.xroute.IsochroneDetail getIsoDetail() {
        return isoDetail;
    }


    /**
     * Sets the isoDetail value for this IsochroneOptions.
     * 
     * @param isoDetail
     */
    public void setIsoDetail(com.ptvag.xserver.xroute.IsochroneDetail isoDetail) {
        this.isoDetail = isoDetail;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IsochroneOptions)) return false;
        IsochroneOptions other = (IsochroneOptions) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.expansionDesc==null && other.getExpansionDesc()==null) || 
             (this.expansionDesc!=null &&
              this.expansionDesc.equals(other.getExpansionDesc()))) &&
            ((this.isoDetail==null && other.getIsoDetail()==null) || 
             (this.isoDetail!=null &&
              this.isoDetail.equals(other.getIsoDetail())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getExpansionDesc() != null) {
            _hashCode += getExpansionDesc().hashCode();
        }
        if (getIsoDetail() != null) {
            _hashCode += getIsoDetail().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IsochroneOptions.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneOptions"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("isoDetail");
        attrField.setXmlName(new javax.xml.namespace.QName("", "isoDetail"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneDetail"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expansionDesc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "expansionDesc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "ExpansionDescription"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
