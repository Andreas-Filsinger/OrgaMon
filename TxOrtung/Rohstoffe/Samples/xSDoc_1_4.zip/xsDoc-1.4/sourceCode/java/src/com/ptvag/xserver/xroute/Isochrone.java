/**
 * Isochrone.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class Isochrone  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xroute.IsochroneInfo[] wrappedIsochrones;

    private java.lang.String additional;  // attribute

    public Isochrone() {
    }

    public Isochrone(
           java.lang.String additional,
           com.ptvag.xserver.xroute.IsochroneInfo[] wrappedIsochrones) {
        this.additional = additional;
        this.wrappedIsochrones = wrappedIsochrones;
    }


    /**
     * Gets the wrappedIsochrones value for this Isochrone.
     * 
     * @return wrappedIsochrones
     */
    public com.ptvag.xserver.xroute.IsochroneInfo[] getWrappedIsochrones() {
        return wrappedIsochrones;
    }


    /**
     * Sets the wrappedIsochrones value for this Isochrone.
     * 
     * @param wrappedIsochrones
     */
    public void setWrappedIsochrones(com.ptvag.xserver.xroute.IsochroneInfo[] wrappedIsochrones) {
        this.wrappedIsochrones = wrappedIsochrones;
    }


    /**
     * Gets the additional value for this Isochrone.
     * 
     * @return additional
     */
    public java.lang.String getAdditional() {
        return additional;
    }


    /**
     * Sets the additional value for this Isochrone.
     * 
     * @param additional
     */
    public void setAdditional(java.lang.String additional) {
        this.additional = additional;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Isochrone)) return false;
        Isochrone other = (Isochrone) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedIsochrones==null && other.getWrappedIsochrones()==null) || 
             (this.wrappedIsochrones!=null &&
              java.util.Arrays.equals(this.wrappedIsochrones, other.getWrappedIsochrones()))) &&
            ((this.additional==null && other.getAdditional()==null) || 
             (this.additional!=null &&
              this.additional.equals(other.getAdditional())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedIsochrones() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedIsochrones());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedIsochrones(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAdditional() != null) {
            _hashCode += getAdditional().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Isochrone.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "Isochrone"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("additional");
        attrField.setXmlName(new javax.xml.namespace.QName("", "additional"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedIsochrones");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedIsochrones"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneInfo"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "IsochroneInfo"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
