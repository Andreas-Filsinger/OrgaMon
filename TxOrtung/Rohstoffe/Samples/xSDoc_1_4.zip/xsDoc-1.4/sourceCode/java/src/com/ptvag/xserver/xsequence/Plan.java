/**
 * Plan.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xsequence;

public class Plan  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private com.ptvag.xserver.xsequence.OutputTour tour;

    private int[] wrappedUnscheduledStopIDs;

    private java.lang.String result;  // attribute

    public Plan() {
    }

    public Plan(
           java.lang.String result,
           com.ptvag.xserver.xsequence.OutputTour tour,
           int[] wrappedUnscheduledStopIDs) {
        this.result = result;
        this.tour = tour;
        this.wrappedUnscheduledStopIDs = wrappedUnscheduledStopIDs;
    }


    /**
     * Gets the tour value for this Plan.
     * 
     * @return tour
     */
    public com.ptvag.xserver.xsequence.OutputTour getTour() {
        return tour;
    }


    /**
     * Sets the tour value for this Plan.
     * 
     * @param tour
     */
    public void setTour(com.ptvag.xserver.xsequence.OutputTour tour) {
        this.tour = tour;
    }


    /**
     * Gets the wrappedUnscheduledStopIDs value for this Plan.
     * 
     * @return wrappedUnscheduledStopIDs
     */
    public int[] getWrappedUnscheduledStopIDs() {
        return wrappedUnscheduledStopIDs;
    }


    /**
     * Sets the wrappedUnscheduledStopIDs value for this Plan.
     * 
     * @param wrappedUnscheduledStopIDs
     */
    public void setWrappedUnscheduledStopIDs(int[] wrappedUnscheduledStopIDs) {
        this.wrappedUnscheduledStopIDs = wrappedUnscheduledStopIDs;
    }


    /**
     * Gets the result value for this Plan.
     * 
     * @return result
     */
    public java.lang.String getResult() {
        return result;
    }


    /**
     * Sets the result value for this Plan.
     * 
     * @param result
     */
    public void setResult(java.lang.String result) {
        this.result = result;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Plan)) return false;
        Plan other = (Plan) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.tour==null && other.getTour()==null) || 
             (this.tour!=null &&
              this.tour.equals(other.getTour()))) &&
            ((this.wrappedUnscheduledStopIDs==null && other.getWrappedUnscheduledStopIDs()==null) || 
             (this.wrappedUnscheduledStopIDs!=null &&
              java.util.Arrays.equals(this.wrappedUnscheduledStopIDs, other.getWrappedUnscheduledStopIDs()))) &&
            ((this.result==null && other.getResult()==null) || 
             (this.result!=null &&
              this.result.equals(other.getResult())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getTour() != null) {
            _hashCode += getTour().hashCode();
        }
        if (getWrappedUnscheduledStopIDs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedUnscheduledStopIDs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedUnscheduledStopIDs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getResult() != null) {
            _hashCode += getResult().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Plan.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "Plan"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("result");
        attrField.setXmlName(new javax.xml.namespace.QName("", "result"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tour");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "tour"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "OutputTour"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedUnscheduledStopIDs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xsequence.xserver.ptvag.com", "wrappedUnscheduledStopIDs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "Int"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
