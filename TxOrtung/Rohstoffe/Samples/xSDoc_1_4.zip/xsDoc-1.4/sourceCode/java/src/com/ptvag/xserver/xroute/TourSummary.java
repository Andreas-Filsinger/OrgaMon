/**
 * TourSummary.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class TourSummary  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private int drivingPeriod;  // attribute

    private int earliness;  // attribute

    private int idlePeriod;  // attribute

    private java.util.Calendar lastestTourStart;  // attribute

    private int servicePeriod;  // attribute

    private int totalPeriod;  // attribute

    private int waitingPeriod;  // attribute

    public TourSummary() {
    }

    public TourSummary(
           int drivingPeriod,
           int earliness,
           int idlePeriod,
           java.util.Calendar lastestTourStart,
           int servicePeriod,
           int totalPeriod,
           int waitingPeriod) {
        this.drivingPeriod = drivingPeriod;
        this.earliness = earliness;
        this.idlePeriod = idlePeriod;
        this.lastestTourStart = lastestTourStart;
        this.servicePeriod = servicePeriod;
        this.totalPeriod = totalPeriod;
        this.waitingPeriod = waitingPeriod;
    }


    /**
     * Gets the drivingPeriod value for this TourSummary.
     * 
     * @return drivingPeriod
     */
    public int getDrivingPeriod() {
        return drivingPeriod;
    }


    /**
     * Sets the drivingPeriod value for this TourSummary.
     * 
     * @param drivingPeriod
     */
    public void setDrivingPeriod(int drivingPeriod) {
        this.drivingPeriod = drivingPeriod;
    }


    /**
     * Gets the earliness value for this TourSummary.
     * 
     * @return earliness
     */
    public int getEarliness() {
        return earliness;
    }


    /**
     * Sets the earliness value for this TourSummary.
     * 
     * @param earliness
     */
    public void setEarliness(int earliness) {
        this.earliness = earliness;
    }


    /**
     * Gets the idlePeriod value for this TourSummary.
     * 
     * @return idlePeriod
     */
    public int getIdlePeriod() {
        return idlePeriod;
    }


    /**
     * Sets the idlePeriod value for this TourSummary.
     * 
     * @param idlePeriod
     */
    public void setIdlePeriod(int idlePeriod) {
        this.idlePeriod = idlePeriod;
    }


    /**
     * Gets the lastestTourStart value for this TourSummary.
     * 
     * @return lastestTourStart
     */
    public java.util.Calendar getLastestTourStart() {
        return lastestTourStart;
    }


    /**
     * Sets the lastestTourStart value for this TourSummary.
     * 
     * @param lastestTourStart
     */
    public void setLastestTourStart(java.util.Calendar lastestTourStart) {
        this.lastestTourStart = lastestTourStart;
    }


    /**
     * Gets the servicePeriod value for this TourSummary.
     * 
     * @return servicePeriod
     */
    public int getServicePeriod() {
        return servicePeriod;
    }


    /**
     * Sets the servicePeriod value for this TourSummary.
     * 
     * @param servicePeriod
     */
    public void setServicePeriod(int servicePeriod) {
        this.servicePeriod = servicePeriod;
    }


    /**
     * Gets the totalPeriod value for this TourSummary.
     * 
     * @return totalPeriod
     */
    public int getTotalPeriod() {
        return totalPeriod;
    }


    /**
     * Sets the totalPeriod value for this TourSummary.
     * 
     * @param totalPeriod
     */
    public void setTotalPeriod(int totalPeriod) {
        this.totalPeriod = totalPeriod;
    }


    /**
     * Gets the waitingPeriod value for this TourSummary.
     * 
     * @return waitingPeriod
     */
    public int getWaitingPeriod() {
        return waitingPeriod;
    }


    /**
     * Sets the waitingPeriod value for this TourSummary.
     * 
     * @param waitingPeriod
     */
    public void setWaitingPeriod(int waitingPeriod) {
        this.waitingPeriod = waitingPeriod;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TourSummary)) return false;
        TourSummary other = (TourSummary) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.drivingPeriod == other.getDrivingPeriod() &&
            this.earliness == other.getEarliness() &&
            this.idlePeriod == other.getIdlePeriod() &&
            ((this.lastestTourStart==null && other.getLastestTourStart()==null) || 
             (this.lastestTourStart!=null &&
              this.lastestTourStart.equals(other.getLastestTourStart()))) &&
            this.servicePeriod == other.getServicePeriod() &&
            this.totalPeriod == other.getTotalPeriod() &&
            this.waitingPeriod == other.getWaitingPeriod();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getDrivingPeriod();
        _hashCode += getEarliness();
        _hashCode += getIdlePeriod();
        if (getLastestTourStart() != null) {
            _hashCode += getLastestTourStart().hashCode();
        }
        _hashCode += getServicePeriod();
        _hashCode += getTotalPeriod();
        _hashCode += getWaitingPeriod();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TourSummary.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "TourSummary"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("drivingPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "drivingPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("earliness");
        attrField.setXmlName(new javax.xml.namespace.QName("", "earliness"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("idlePeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "idlePeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("lastestTourStart");
        attrField.setXmlName(new javax.xml.namespace.QName("", "lastestTourStart"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("servicePeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "servicePeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("totalPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "totalPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("waitingPeriod");
        attrField.setXmlName(new javax.xml.namespace.QName("", "waitingPeriod"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
