/**
 * CountryInfoOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class CountryInfoOptions  extends com.ptvag.jabba.core.value.TransientVO  implements java.io.Serializable {
    private int[] wrappedReductionIDs;

    private boolean allEuro;  // attribute

    private boolean detailedTollCosts;  // attribute

    public CountryInfoOptions() {
    }

    public CountryInfoOptions(
           boolean allEuro,
           boolean detailedTollCosts,
           int[] wrappedReductionIDs) {
        this.allEuro = allEuro;
        this.detailedTollCosts = detailedTollCosts;
        this.wrappedReductionIDs = wrappedReductionIDs;
    }


    /**
     * Gets the wrappedReductionIDs value for this CountryInfoOptions.
     * 
     * @return wrappedReductionIDs
     */
    public int[] getWrappedReductionIDs() {
        return wrappedReductionIDs;
    }


    /**
     * Sets the wrappedReductionIDs value for this CountryInfoOptions.
     * 
     * @param wrappedReductionIDs
     */
    public void setWrappedReductionIDs(int[] wrappedReductionIDs) {
        this.wrappedReductionIDs = wrappedReductionIDs;
    }


    /**
     * Gets the allEuro value for this CountryInfoOptions.
     * 
     * @return allEuro
     */
    public boolean isAllEuro() {
        return allEuro;
    }


    /**
     * Sets the allEuro value for this CountryInfoOptions.
     * 
     * @param allEuro
     */
    public void setAllEuro(boolean allEuro) {
        this.allEuro = allEuro;
    }


    /**
     * Gets the detailedTollCosts value for this CountryInfoOptions.
     * 
     * @return detailedTollCosts
     */
    public boolean isDetailedTollCosts() {
        return detailedTollCosts;
    }


    /**
     * Sets the detailedTollCosts value for this CountryInfoOptions.
     * 
     * @param detailedTollCosts
     */
    public void setDetailedTollCosts(boolean detailedTollCosts) {
        this.detailedTollCosts = detailedTollCosts;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CountryInfoOptions)) return false;
        CountryInfoOptions other = (CountryInfoOptions) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.wrappedReductionIDs==null && other.getWrappedReductionIDs()==null) || 
             (this.wrappedReductionIDs!=null &&
              java.util.Arrays.equals(this.wrappedReductionIDs, other.getWrappedReductionIDs()))) &&
            this.allEuro == other.isAllEuro() &&
            this.detailedTollCosts == other.isDetailedTollCosts();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getWrappedReductionIDs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWrappedReductionIDs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWrappedReductionIDs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += (isAllEuro() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isDetailedTollCosts() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CountryInfoOptions.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "CountryInfoOptions"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("allEuro");
        attrField.setXmlName(new javax.xml.namespace.QName("", "allEuro"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("detailedTollCosts");
        attrField.setXmlName(new javax.xml.namespace.QName("", "detailedTollCosts"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wrappedReductionIDs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "wrappedReductionIDs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://wrappertypes.service.jabba.ptvag.com", "Int"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
