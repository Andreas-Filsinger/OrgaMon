/**
 * RoutingParameter.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.xserver.xroute;

public class RoutingParameter implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected RoutingParameter(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _OPTIMIZATION = "OPTIMIZATION";
    public static final java.lang.String _SPEED_PROFILE = "SPEED_PROFILE";
    public static final java.lang.String _AVOID_TOLLROADS = "AVOID_TOLLROADS";
    public static final java.lang.String _AVOID_VIGNETTEROADS = "AVOID_VIGNETTEROADS";
    public static final java.lang.String _AVOID_HIGHWAYS = "AVOID_HIGHWAYS";
    public static final java.lang.String _AVOID_FERRIES = "AVOID_FERRIES";
    public static final java.lang.String _AVOID_RESIDENTS_ONLY = "AVOID_RESIDENTS_ONLY";
    public static final java.lang.String _AVOID_URBAN_AREAS = "AVOID_URBAN_AREAS";
    public static final java.lang.String _AVOID_RAMPS = "AVOID_RAMPS";
    public static final java.lang.String _EXCLUDE_COUNTRIES = "EXCLUDE_COUNTRIES";
    public static final java.lang.String _ROUTING_COUNTRIES = "ROUTING_COUNTRIES";
    public static final java.lang.String _ROUTING_RECTANGLE = "ROUTING_RECTANGLE";
    public static final java.lang.String _ROUTE_LANGUAGE = "ROUTE_LANGUAGE";
    public static final java.lang.String _START_TIME = "START_TIME";
    public static final java.lang.String _IS_DESTTIME = "IS_DESTTIME";
    public static final java.lang.String _DYNAMIC_PROFILE = "DYNAMIC_PROFILE";
    public static final java.lang.String _ENABLE_DYNAMIC = "ENABLE_DYNAMIC";
    public static final java.lang.String _ENABLE_ROADEDITOR = "ENABLE_ROADEDITOR";
    public static final java.lang.String _START_TIME_ROADEDITOR = "START_TIME_ROADEDITOR";
    public static final java.lang.String _ROADEDITOR_LAYERNAME = "ROADEDITOR_LAYERNAME";
    public static final java.lang.String _ROADEDITOR_ATTRIBUTESET = "ROADEDITOR_ATTRIBUTESET";
    public static final java.lang.String _ROADEDITOR_ADDITIONAL_OPTIONS = "ROADEDITOR_ADDITIONAL_OPTIONS";
    public static final java.lang.String _DISTANCE_MEASURE = "DISTANCE_MEASURE";
    public static final java.lang.String _COUNTRY_ENCODING = "COUNTRY_ENCODING";
    public static final java.lang.String _GENERATE_EXTWAYPOINTS = "GENERATE_EXTWAYPOINTS";
    public static final java.lang.String _EXPERT_OPTIONS = "EXPERT_OPTIONS";
    public static final java.lang.String _REQUEST_VERSION = "REQUEST_VERSION";
    public static final java.lang.String _DYNAMIC_TIME_ON_STATICROUTE = "DYNAMIC_TIME_ON_STATICROUTE";
    public static final RoutingParameter OPTIMIZATION = new RoutingParameter(_OPTIMIZATION);
    public static final RoutingParameter SPEED_PROFILE = new RoutingParameter(_SPEED_PROFILE);
    public static final RoutingParameter AVOID_TOLLROADS = new RoutingParameter(_AVOID_TOLLROADS);
    public static final RoutingParameter AVOID_VIGNETTEROADS = new RoutingParameter(_AVOID_VIGNETTEROADS);
    public static final RoutingParameter AVOID_HIGHWAYS = new RoutingParameter(_AVOID_HIGHWAYS);
    public static final RoutingParameter AVOID_FERRIES = new RoutingParameter(_AVOID_FERRIES);
    public static final RoutingParameter AVOID_RESIDENTS_ONLY = new RoutingParameter(_AVOID_RESIDENTS_ONLY);
    public static final RoutingParameter AVOID_URBAN_AREAS = new RoutingParameter(_AVOID_URBAN_AREAS);
    public static final RoutingParameter AVOID_RAMPS = new RoutingParameter(_AVOID_RAMPS);
    public static final RoutingParameter EXCLUDE_COUNTRIES = new RoutingParameter(_EXCLUDE_COUNTRIES);
    public static final RoutingParameter ROUTING_COUNTRIES = new RoutingParameter(_ROUTING_COUNTRIES);
    public static final RoutingParameter ROUTING_RECTANGLE = new RoutingParameter(_ROUTING_RECTANGLE);
    public static final RoutingParameter ROUTE_LANGUAGE = new RoutingParameter(_ROUTE_LANGUAGE);
    public static final RoutingParameter START_TIME = new RoutingParameter(_START_TIME);
    public static final RoutingParameter IS_DESTTIME = new RoutingParameter(_IS_DESTTIME);
    public static final RoutingParameter DYNAMIC_PROFILE = new RoutingParameter(_DYNAMIC_PROFILE);
    public static final RoutingParameter ENABLE_DYNAMIC = new RoutingParameter(_ENABLE_DYNAMIC);
    public static final RoutingParameter ENABLE_ROADEDITOR = new RoutingParameter(_ENABLE_ROADEDITOR);
    public static final RoutingParameter START_TIME_ROADEDITOR = new RoutingParameter(_START_TIME_ROADEDITOR);
    public static final RoutingParameter ROADEDITOR_LAYERNAME = new RoutingParameter(_ROADEDITOR_LAYERNAME);
    public static final RoutingParameter ROADEDITOR_ATTRIBUTESET = new RoutingParameter(_ROADEDITOR_ATTRIBUTESET);
    public static final RoutingParameter ROADEDITOR_ADDITIONAL_OPTIONS = new RoutingParameter(_ROADEDITOR_ADDITIONAL_OPTIONS);
    public static final RoutingParameter DISTANCE_MEASURE = new RoutingParameter(_DISTANCE_MEASURE);
    public static final RoutingParameter COUNTRY_ENCODING = new RoutingParameter(_COUNTRY_ENCODING);
    public static final RoutingParameter GENERATE_EXTWAYPOINTS = new RoutingParameter(_GENERATE_EXTWAYPOINTS);
    public static final RoutingParameter EXPERT_OPTIONS = new RoutingParameter(_EXPERT_OPTIONS);
    public static final RoutingParameter REQUEST_VERSION = new RoutingParameter(_REQUEST_VERSION);
    public static final RoutingParameter DYNAMIC_TIME_ON_STATICROUTE = new RoutingParameter(_DYNAMIC_TIME_ON_STATICROUTE);
    public java.lang.String getValue() { return _value_;}
    public static RoutingParameter fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        RoutingParameter enumeration = (RoutingParameter)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static RoutingParameter fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RoutingParameter.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xroute.xserver.ptvag.com", "RoutingParameter"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
