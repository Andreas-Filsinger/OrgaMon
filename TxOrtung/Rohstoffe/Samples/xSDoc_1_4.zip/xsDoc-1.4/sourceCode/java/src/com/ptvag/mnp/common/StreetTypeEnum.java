/**
 * StreetTypeEnum.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ptvag.mnp.common;

public class StreetTypeEnum implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected StreetTypeEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _MOTORWAY = "MOTORWAY";
    public static final java.lang.String _FOUR_LANE = "FOUR_LANE";
    public static final java.lang.String _TWO_LANE = "TWO_LANE";
    public static final java.lang.String _COUNTRY1 = "COUNTRY1";
    public static final java.lang.String _COUNTRY2 = "COUNTRY2";
    public static final java.lang.String _CITY = "CITY";
    public static final java.lang.String _FERRY = "FERRY";
    public static final java.lang.String _BORDER_CROSSING = "BORDER_CROSSING";
    public static final java.lang.String _TOLL_ROAD = "TOLL_ROAD";
    public static final java.lang.String _OTHER = "OTHER";
    public static final StreetTypeEnum MOTORWAY = new StreetTypeEnum(_MOTORWAY);
    public static final StreetTypeEnum FOUR_LANE = new StreetTypeEnum(_FOUR_LANE);
    public static final StreetTypeEnum TWO_LANE = new StreetTypeEnum(_TWO_LANE);
    public static final StreetTypeEnum COUNTRY1 = new StreetTypeEnum(_COUNTRY1);
    public static final StreetTypeEnum COUNTRY2 = new StreetTypeEnum(_COUNTRY2);
    public static final StreetTypeEnum CITY = new StreetTypeEnum(_CITY);
    public static final StreetTypeEnum FERRY = new StreetTypeEnum(_FERRY);
    public static final StreetTypeEnum BORDER_CROSSING = new StreetTypeEnum(_BORDER_CROSSING);
    public static final StreetTypeEnum TOLL_ROAD = new StreetTypeEnum(_TOLL_ROAD);
    public static final StreetTypeEnum OTHER = new StreetTypeEnum(_OTHER);
    public java.lang.String getValue() { return _value_;}
    public static StreetTypeEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        StreetTypeEnum enumeration = (StreetTypeEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static StreetTypeEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(StreetTypeEnum.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://common.mnp.ptvag.com", "StreetTypeEnum"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
