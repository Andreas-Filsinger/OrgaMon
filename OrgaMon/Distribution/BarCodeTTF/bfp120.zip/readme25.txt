This font is provided as shareware. There is no explicit charge for using this font if you are an individual or an educational institution, but a registration fee of $10.00US is encouraged to support ongoing development of new fonts. The $10.00US registration fee is mandatory for commercial use and distribution. Furthermore, distribution is permitted only if the font is not altered in any way and is accompanied by this readme file.

WARNING:

This font contains only the glyphs to BUILD I2of5 barcodes, which must be assembled manually or through software to obtain the final mechanicaly readable product. In order for a barcode reader to properly recognize the barcode, the following instructions must be followed exactly.

To use these fonts:

The Interleaved 2 of 5 barcode is a compact method for encoding continuous numerical character sequences; only the 0 to 9 digits can be encoded, but in an indefinite string lenght.

All Interleaved 2 of 5 barcodes have an even number of characters. Therefore, a barcode with an odd number of digits must be padded with a leading zero. The barcode uses a leading 'Start' and trailing 'Stop' character to delimit the encoded digits.

Each font character represents 2 digits from 00 to 99. Divide the digit string to encode into 2 digit elements and convert them to barcode format by using a lookup table or such manner.  The following formula could be used in VBasic: 'A + ABS(A<=49)*48 + ABS(A>=50)*142' where 'A' represents the value of the 2 digits to encode.

The first 50 font glyphs located at characters 48 (0x30) to 97 (0x61) encode the digits 00 to 49; while the next 50 located at 192 (0xC0) to 241 (0xF1) encode 50 to 99. The Start charcter is "(" or 40 (0x28) and the Stop character is ")" or 41 (0x29). A checksum character is not required.

Example:  '(1G)' or '40 49 71 41' would barcode the digits '0123'


Please submit the registration fee to the address below in your local currency, US or Canadian dollars. Include your company information and a return E-MAIL address where the registration information will be sent.


Chaos Microsystems Inc.
22-5330 Canotek Road
Gloucester, ON, Canada
K1J 9C3
