This font is provided as shareware. There is no explicit charge for using this font if you are an individual or an educational institution, but a registration fee of $10.00US is encouraged to support ongoing development of new fonts. The $10.00US registration fee is mandatory for commercial use and distribution. Furthermore, distribution is permitted only if the font is not altered in any way and is accompanied by this readme file.

WARNING:

This font contains only the glyphs to BUILD UPC-E barcodes, which must be assembled manually or through software to obtain the final mechanicaly readable product. In order for a barcode reader to properly recognize the barcode, the following instructions must be followed exactly.


The Universal Product Code (UPC) specifications include three versions: A, D, and E. Version A, the regular version, is used to encode a twelve digit number. Version E, the zero suppressed version, is a six digit code used for marking small packages. Version D, the variable length version, is not commonly used for package marking. It is used in limited special applications. 

Both Version A and E may include either a 2 digit or a 5 digit supplemental encodation. These extra digits are primarily used on periodicals and books. Supplemental encodations are supported.

Version E allows zeros to be removed from the data to be encoded, resulting in a shorter tag. The encodation of the data characters is different than Version A.

Version E even parity characters are the same as Version A left hand characters. The odd parity characters are reversed right hand characters.

UPC E Character Set:

Odd Parity   Number   Even Parity

  0001101      0      0100111
  0011001      1      0110011
  0010011      2      0011011
  0111101      3      0100001
  0100011      4      0011101
  0110001      5      0111001
  0101111      6      0000101
  0111011      7      0010001
  0110111      8      0001001
  0001011      9      0010111


UPC E Parity Pattern Table:

Number System 0  (Leading character 0)

Check	     Character Position	
Character    1  2  3  4  5  6

    0        E  E  E  O  O  O	
    1        E  E  O  E  O  O
    2        E  E  O  O  E  O
    3        E  E  O  O  O  E
    4        E  O  E  E  O  O
    5        E  O  O  E  E  O
    6        E  O  O  O  E  E
    7        E  O  E  O  E  O
    8        E  O  E  O  O  E
    9        E  O  O  E  O  E

Number System 1   (Leading character 1)

Check	     Character Position	
Character    1  2  3  4  5  6
    0        O  O  O  E  E  E
    1        O  O  E  O  E  E
    2        O  O  E  E  O  E
    3        O  O  E  E  E  O
    4        O  E  O  O  E  E
    5        O  E  E  O  O  E
    6        O  E  E  E  O  O
    7        O  E  O  E  O  E
    8        O  E  O  E  E  O
    9        O  E  E  O  E  O


UPC-E Construction:

The physical structure of the UPC-E symbol is as follows:

Left hand guard bars, encoded 101
Six explicit data characters, encoded from the parity table.
Right hand guard bars, encoded 010101

To determine how to encode the data characters, first the check character must be found. Once known, it is used to set the pattern of even and odd parity to be used to encode the six explicit characters from the UPC E Parity Table.

IMPORTANT!!!

To calculate the check character, the UPC-E code must be expanded to it's UPC-A form and calculated from it's 11 digit format!!!

Determining the explicit characters:

If the manufacturers number ends in 000, 100, or 200, valid item numbers are 00000 to 00999. The six explicit characters are the first two characters of the manufacturer's number, the last three characters of the item number, and the third character of the manufacturer's number.

If the manufacturers number ends in 300, 400, 500, 600, 700, 800 or 900, valid item numbers are 00000 to 00099. The six explicit characters are the first three characters of the manufacturer's number, the last two characters of the item number, and the character ``3''.

If the manufacturers number ends in 10, 20, 30, 40, 50, 60, 70, 80, or 90, valid item numbers are 00000 to 00009. The six explicit characters are the first four characters of the manufacturer's number, the last character of the item number, and the character ``4''.

If the manufacturers number does not end in zero, the valid numbers are 00005 to 00009. The six explicit characters are all five characters of the manufacturer's number, and the last character of the item number.

To convert back to UPC-A:
(A indicates the Number System and should always be 0)

If the UPC-E code ends in 0, 1 or 2: (G = 1, 2, 3)
    UPC-E     UPC-A
    ABCDEFG   A BCG00 00DEF 

If the UPC-E code ends in 3: (G = 3)
    UPC-E     UPC-A
    ABCDEFG   A BCD00 000EF   (The digit 3 indicates the compression used) 

If the UPC-E code ends in 4: (G = 4)
    UPC-E     UPC-A
    ABCDEFG   A BCDE0 0000F   (The digit 4 indicates the compression used) 

If the UPC-E code ends in 5, 6, 7, 8 or 9: (G = 5, 6, 7, 8, 9)
    UPC-E     UPC-A
    ABCDEFG   A BCDEF 0000G 


Check Characters:

The check character for the UPC/EAN codes is generated by the following method:

1 - Designate the rightmost character odd.
2 - Sum all of the characters in the odd positions and multiply the result by three. (Remember to include the Number System Character)
3 - Sum all of the characters in the even positions
4 - Add the odd and even totals from steps two and three.
5 - Determine the smallest number that when added to the result from step four, will result in a multiple of 10. This is the check character.

UPC E Example:

Number system character =  0 (This digit is implied, not encoded)
Message characters =        123454
UPC-A Format =             01234000005
Position =                 OEOEOEOEOEO
Sum of odd positions =     0 + 2 + 4 + 0 + 0 + 5 = 11
Odd positions X 3 =        11 x 3 = 33
Sum of even positions =	   1 + 3 + 0 + 0 + 0 = 4
Sum of even and odd =      33 + 4 = 37
Check character =          3 (37 + 3 = 40 - Closest multiple of 10)

Use the Number System 0 parity table to find the odd/parity sequence - 
        E E O O O E
Use the Even parity 1
        Even parity 2
        Odd parity  3
        Odd parity  4
        Odd parity  5
        Even parity 4

Odd parity barcode glyphs 0 to 9 are located at characters 48 (0x30) to 59 (0x39). Even parity barcode glyphs 0 to 9 are located at characters 64 (0x40) to 73 (0x49). The 'Start' characters indicating the number system used are at 80 (0x50) and 81 (0x51). The 'Stop' characters indicating the check character are located at 96 (0x60) to 105 (0x69). The Start and Stop characters are actually the same barcodes, only the human readable character changes.


Please submit the registration fee to the address below in your local currency, US or Canadian dollars. Include your company information and a return E-MAIL address where the registration information will be sent.


Chaos Microsystems Inc.
22-5330 Canotek Road
Gloucester, ON, Canada
K1J 9C3