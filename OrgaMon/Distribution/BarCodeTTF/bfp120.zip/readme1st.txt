For help or information you can E-Mail support@chaos.ca

Most questions we receive concern the EAN-13 barcode. It is by far the most difficult to understand and build. So we included two files to help people understand how to put the barcode together. The 'ean13.doc' file is a Word document showing how to build the barcode and the 'Barcode EAN13.xls' file is an Excel file with a macro that builds the barcode.

To register the fonts, send $10.00 US to:

Chaos Microsystems Inc.
22-5330 Canotek Road
Gloucester, ON, Canada
K1J 9C3

Include your E-Mail address in order to receive your confirmation of registration.

Daniel Lajeunesse
Chaos Microsystems Inc.
sales@chaos.ca
